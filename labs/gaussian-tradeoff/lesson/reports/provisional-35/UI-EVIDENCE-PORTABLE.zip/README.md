# Portable actual UI-download replay

These are 16 unchanged raw/history files captured from 8 production mounted lesson UI cases, with their original manifest and receipts. This small bundle contains the exact final frozen runtime and independent record decoder/replay CLI. It does not contain a browser or mount the UI during replay.

Requirements: Node.js 24 (captured with 24.19.0); no packages or network required. From this extracted directory:

```sh
node labs/gaussian-tradeoff/lesson/tests/replay-ui-records.mjs --manifest "$PWD/ui-exports/UI-EXPORT-MANIFEST.json"
```

The command starts a fresh actual Node Worker for each file, independently verifies binary64 tagged encoding and SHA-256, and checks bitwise agreement with downloaded historical results. It writes ui-exports/UI-REPLAY-REPORT.json. The original report remains under receipts. The command refuses to overwrite a report; use a fresh extraction for another run. This is Node execution, not browser/layout/performance validation. Digests identify content; they do not certify scientific truth.
