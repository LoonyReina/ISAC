# Portable mounted-UI and actual-download evidence

Contains the production lesson source, exact final frozen numerical runtime, portable 45-gate tests, independent tagged-record audit/replay CLI, and 18 unchanged raw/history downloads from 9 real mounted UI scenarios. The maximum case uses M=Nc=Ns=6, T=32, B=512 and six weights.

Requirements: Node.js 24 (captured with 24.19.0). No packages or network required. From this extracted directory:

```sh
node --test labs/gaussian-tradeoff/lesson/tests/*.test.mjs
node labs/gaussian-tradeoff/lesson/tests/replay-ui-records.mjs --manifest "$PWD/ui-exports/UI-EXPORT-MANIFEST.json"
node labs/gaussian-tradeoff/lesson/tests/export-ui-records.mjs --out "$PWD/new-ui-exports"
```

The first command mounts production event handlers and uses actual Node Workers. The second independently verifies tagged binary64 encoding and SHA-256, then replays every file in a fresh actual Worker and compares downloaded historical results bit-for-bit. It creates ui-exports/UI-REPLAY-REPORT.json; the original report is retained under receipts. The third independently regenerates actual UI downloads through the bundled production controls. Existing manifests/replay reports are never overwritten; use a fresh directory or extraction to repeat.

The DOM harness is not a browser, layout engine, screen reader or browser-memory test. Shared site styling/navigation is intentionally not bundled as a runnable website. Production HTML is included as the mounted-test fixture. Node RSS observations belong to this run and are not browser budgets. Digests identify content and do not certify scientific truth. BUNDLE-CONTENTS.json lists every included payload by bytes and SHA-256.
