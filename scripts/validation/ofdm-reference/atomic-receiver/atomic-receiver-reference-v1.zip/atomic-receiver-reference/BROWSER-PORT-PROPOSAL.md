# Smallest genuine browser port, proposed after the numerical gate

No browser implementation or UI change is made in this package.

## First bounded slice

- Start with M=N=4, one or two continuous off-grid paths, unit-energy QPSK, optional bit errors, complex Gaussian noise, and the exact-block equation-(27) ADMM validated here. The complex PSD matrix is 17×17. This is an explicitly reduced genuine problem, not original Figure8 scale
- Keep the original 16×16 checkpoint offline with its seed, full observations, solver traces and independent SCS solution. Do not imply that changing a slider recomputes the offline checkpoint
- Run the complex PSD projection in a cancellable Worker. One self-contained route is the equivalent 34×34 real-symmetric embedding, followed by an independently validated symmetric eigensolver and reconstruction of the complex Hermitian projection. This is a proposed route, not an already measured fast eigensolver
- Preserve all lag multiplicities, centered-zero-lag trace penalty, complex conjugation, unnormalized atom scale, exact joint (z,e) update and source multiplier sign. Compare each update/operator and final PSD/objective against this independent package before declaring a port faithful
- Keep maximum iterations, primal/dual tolerances and finite moment norm/certificate status visible. Cancellation/max iterations must return an unfinished state, never a fake completed estimate

## Interaction derived from the solver

Inputs: explicit Run, seed, one-dimensional controls for path separation, SNR, BER, lambda/mu/rho, iteration cap; optional step/run/pause. Keep actual symbols and truth outside the receiver function, exactly as in this package. A CS-AN/CS-ANL1 toggle solves both on the same observations, with CS-AN setting e=0.

Show observations and reconstructed complex samples, error estimates, PSD/Toeplitz residuals, objective trace and distinct parameter-extraction output. Explain that convex estimation is continuous but the extracted dual roots have finite numerical search/refinement tolerance. A declared support threshold can expose misses/false candidates across values. Evaluation truth is separately passed to a scoring function; it never chooses the receiver's support, model order or threshold.

Include a failure preset with close paths or dense errors. Include an export containing all inputs, source hash, runtime version, random seed, settings, iteration trace, status and extraction/evaluation choices. Do not label any introduced threshold as the paper's missing detection rule.

## Browser acceptance still required

- Fresh-input recomputation, baseline equality at zero errors where appropriate, and comparison with independent PSD checkpoints
- Correct complex PSD projection, especially repeated eigenvalues, zero matrix, tiny negative eigenvalues and ill-conditioned inputs
- Real worker cancellation, interrupted/repeated runs, stale-state presentation, superseded-result rejection, parameter export
- Measured desktop p50/p95/worst control-to-result latency, memory, error logs, keyboard/no-JS behavior
- Only after these checks consider M=N=6 or 8. No promise of original-size real time: one genuine 16×16 fixed-rho cloud run took about ten minutes, including its continued checkpoint

Source-default rho=.05 is preserved for source comparisons. A differently scaled formulation, adaptive rho, approximate projection or other acceleration must have its own label and be cross-checked against the unchanged objective before adoption.
