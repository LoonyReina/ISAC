import json,numpy as np,cvxpy as cp
from receiver import shrink,solve_admm,solve_cvx
rng=np.random.default_rng(161004218);r=rng.normal(size=9)+1j*rng.normal(size=9);s=rng.normal(size=9)+1j*rng.normal(size=9);A=rng.normal(size=9)+1j*rng.normal(size=9);beta=.1;mu=.15
w=beta/(abs(s)**2+beta);e=shrink(r-s*A,mu/w);z=(s.conj()*(r-e)+beta*A)/(abs(s)**2+beta)
x=cp.Variable(9,complex=True);y=cp.Variable(9,complex=True);p=cp.Problem(cp.Minimize(.5*cp.sum_squares(cp.abs(r-y-cp.multiply(s,x)))+beta/2*cp.sum_squares(cp.abs(x-A))+mu*cp.sum(cp.abs(y))));p.solve(solver='CLARABEL',tol_gap_abs=1e-10,tol_feas=1e-10,tol_gap_rel=1e-10)
obj=.5*np.linalg.norm(r-e-s*z)**2+beta/2*np.linalg.norm(z-A)**2+mu*np.sum(abs(e));case={'joint_block_objective_difference':float(abs(obj-p.value)),'joint_block_relative_z_difference':float(np.linalg.norm(z-x.value)/np.linalg.norm(x.value)),'joint_block_relative_e_difference':float(np.linalg.norm(e-y.value)/max(1,np.linalg.norm(y.value)))}
r=np.array([1.+0j]);s=np.array([1.+0j]);A=np.array([0j]);mu=.1;w=beta/(abs(s)**2+beta);e=shrink(r-s*A,mu/w);z=(s.conj()*(r-e)+beta*A)/(abs(s)**2+beta);jz=r/(1+beta);je=shrink(r,mu)
fun=lambda z,e: float(.5*np.linalg.norm(r-e-s*z)**2+beta/2*np.linalg.norm(z)**2+mu*np.sum(abs(e)))
case['simple_exact_block_objective']=fun(z,e);case['simple_printed_jacobi_objective']=fun(jz,je)
from experiment import fig8_scene
# Small instance solely checks adaptive variant same objective, not original physical experiment.
M=N=3;r=rng.normal(size=9)+1j*rng.normal(size=9);s=np.exp(.5j*np.pi*rng.integers(4,size=9));ad=solve_admm(r,s,M,N,.3,.12,adaptive_rho=True,atol=1e-9,rtol=1e-8);cv=solve_cvx(r,s,M,N,.3,.12,eps=1e-8)
case['adaptive_small_status']=ad['status'];case['adaptive_small_objective_difference']=float(abs(ad['objective']-cv['objective']));case['adaptive_final_rho']=ad['final_rho'];case['passed']=case['joint_block_objective_difference']<1e-8 and max(case['joint_block_relative_z_difference'],case['joint_block_relative_e_difference'])<1e-4 and ad['status']=='converged' and case['adaptive_small_objective_difference']<1e-5
open('results/block-update-checks.json','w').write(json.dumps(case,indent=2));print(case)
