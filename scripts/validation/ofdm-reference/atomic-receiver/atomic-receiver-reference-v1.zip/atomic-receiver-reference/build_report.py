import json,pathlib,hashlib,zipfile
p=pathlib.Path('.')
load=lambda s:json.loads((p/s).read_text())
v=load('results/validation.json');b=load('results/reduced-benchmark.json');orig=load('results/original16_s1_b0.02_161004218_fixed_rho_resume.json');scs=load('results/original16_s1_b0.02_161004218_scs.json');csan=load('results/original16_s1_b0.02_161004218_CSAN_adaptive_fresh.json');diag=load('results/original16-analysis.json');cert=load('results/original16-sdp-certificate.json')
text=f'''# Bounded numerical gate report

## Established

- Fixed source and complete observation/operator/update audit; all files stay in this independent reference directory
- Genuine continuous two-level-Toeplitz Eq27 solver; independent full-Hermitian-matrix CVXPY/SCS reference, with no frequency grid in either optimization
- {v['checks']} reduced analytic/operator/SDP/negative-control checks: {'PASS' if v['passed'] else 'FAIL'}, plus independent block-update, simulation and baseline checks
- Original Fig8 dimensions M=N=16, PSD dimension 257, one declared Scenario1/BER=.02 seed: source-rho .05 exact-block ADMM converges after {orig['previous_iterations']+orig['iterations']} iterations and {orig['previous_runtime_seconds']+orig['runtime_seconds']:.3f} s total measured wall time
- Original-size ADMM objective {orig['objective']:.12f}; independent SCS {scs['objective']:.12f}, absolute difference {abs(orig['objective']-scs['objective']):.3g}; SCS {scs['iterations']} iterations and {scs['runtime_seconds']:.3f} s
- Original ADMM primal residual {orig['primal']:.3g}, dual residual {orig['dual']:.3g}, minimum lifted eigenvalue {orig['min_eigenvalue']:.3g}. The first 300 s timeout remains unchanged in its own checkpoint
- Separate conservative numerical finite-SDP bound interval [{cert['feasible_dual_lower']:.12f}, {cert['feasible_primal_upper']:.12f}], gap {cert['certified_numeric_gap']:.6g}. Cross-solver agreement is not that gap and is not exact arithmetic certification

## Reduced-size measured costs

Same source objective, rho=.05, atol=1e-9, rtol=1e-8; two off-grid paths, two signal-dependent QPSK errors, sigma=.02; three fresh solves each. Cloud Python on reported AMD EPYC 9V74, single BLAS thread, concurrent cloud work possible. These are not browser measurements.

| M×N | complex PSD | iterations | median s | max s | independent objective difference |
|---|---:|---:|---:|---:|---:|
| 4×4 | 17 | {b['4']['runs'][0]['iterations']} | {b['4']['runtime_median_seconds']:.6f} | {b['4']['runtime_max_seconds']:.6f} | {b['4']['objective_difference']:.3g} |
| 8×8 | 65 | {b['8']['runs'][0]['iterations']} | {b['8']['runtime_median_seconds']:.6f} | {b['8']['runtime_max_seconds']:.6f} | {b['8']['objective_difference']:.3g} |

## Baselines and limitations retained

- CS-AN is exactly e=0, not mu=0 with a free error vector. The original-size paired ablation stopped at its declared 450 s budget after {csan['iterations']} iterations (status {csan['status']}); do not use it to claim a validated performance advantage
- Discrete CS-L1 solves the original Cartesian-grid objective, checked by independent Clarabel. Original 16×16 paired solve converged; its objective is a different penalty problem and is not directly comparable as a performance score to atomic objectives
- MUSIC source smoothing/projector is implemented, but the paper omits model-order and detection rules. No true K is injected. K=84 in the dense scenario exceeds the 64-dimensional smoothed aperture, so oracle K is not even admissible there
- Declared dual extraction of the converged robust checkpoint returns {diag['fixed_rho_resume']['matched']['all_estimated_paths']} candidates and identifies {diag['fixed_rho_resume']['matched']['identified']}/3 moving targets in this seed. This is an exploratory candidate protocol with extra paths and error-support false positives, not the original detector or reproduced conditional-RMSE curve
- No unconditional 2-D atomic-norm equivalence is asserted. The finite moment optimum's numerical rank exceeds the rank<16 sufficient decomposition condition
- The experiment simulates Eq6's post-FFT observations. At the source velocity endpoint, fD Tbar=.312 and fD/Delta_f=.208; time-domain intrablock Doppler/ICI accuracy is not established

## Still open

1. Validated complete detection/extraction rule, support threshold, root grid/refinement, false-alarm scoring and MUSIC rank selection, with all declared implementation choices separated from unavailable author settings
2. The complete Fig8 100-realization ×11-BER ×2-scenario comparison and all methods, including retained failures and denominators
3. Original M=16,N=64 Figs6–7; time-domain OFDM/ICI extension is separate
4. Unconditional atomic-norm/decomposition certification beyond this finite SDP is not established
5. Browser core independent cross-check, actual desktop latency, Worker cancellation/stale handling, UI learning gates and all deployment checks

## Recommended next bounded step

Port only the genuine 4×4 solver into an isolated Worker-ready numerical module, validate fresh common observations against the unchanged Python/SDP reference, and obtain independent review before any lesson UI. Keep 8×8/16×16 as labelled offline evidence until actual target-platform measurements support a larger live cap. See BROWSER-PORT-PROPOSAL.md.
'''
(p/'NUMERICAL-GATE-REPORT.md').write_text(text)
files=[f for f in p.rglob('*') if f.is_file() and not any(q in f.parts for q in ['.venv','source','__pycache__','js-port']) and f.name not in ['REFERENCE-FREEZE.json','atomic-receiver-reference-v1.zip']]
freeze={'scope':'source and independent Python Eq27 gate; before JS port','created_utc':'2026-10-12T11:51:00Z','files':{str(f):hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(files)},'all_reduced_checks_passed':v['passed'],'original16_robust_status':orig['status'],'original16_CSAN_status':csan['status'],'full_Fig8_reproduced':False,'browser_validated':False}
(p/'REFERENCE-FREEZE.json').write_text(json.dumps(freeze,indent=2))
with zipfile.ZipFile(p/'atomic-receiver-reference-v1.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in files+[p/'REFERENCE-FREEZE.json']:z.write(f,arcname=f'atomic-receiver-reference/{f}')
print('files',len(files),'zip_bytes',(p/'atomic-receiver-reference-v1.zip').stat().st_size,'zip_sha256',hashlib.sha256((p/'atomic-receiver-reference-v1.zip').read_bytes()).hexdigest())
