"""Conservative finite-SDP primal/dual feasibility repair, no grid certificate."""
import json,numpy as np
from pathlib import Path
from receiver import Toeplitz2D,objective
stem='results/original16_s1_b0.02_161004218_';i=np.load(stem+'exact_block_inputs.npz');x=np.load(stem+'fixed_rho_resume_solution.npz');meta=json.load(open(stem+'fixed_rho_resume.json'));p=meta['parameters'];M=N=16;D=M*N;lam,mu=p['lambda_value'],p['mu'];op=Toeplitz2D(M,N)
r,s,z,e,T=i['r'],i['s'],x['z'],x['e'],x['T'];t=meta['t'];B=np.block([[T,z[:,None]],[z.conj()[None,:],np.array([[t]])]])
# Add the same diagonal to T and t; this preserves both Toeplitz structure and z/e.
primal_shift=max(0,-float(np.linalg.eigvalsh((B+B.conj().T)/2)[0]))+1e-10
upper=objective(r,s,z,e,T+primal_shift*np.eye(D),t+primal_shift,lam,mu)
delta=r-s*z-e
# L-infinity dual feasibility is exact up to the explicit floating margin.
delta*=min(1.,mu*(1-1e-12)/max(abs(delta)))
nu=s.conj()*delta
G=np.array(x['multiplier'],copy=True);target=np.zeros(op.L,complex);target[op.center]=lam/2
correction=(target-op.adjoint(G[:D,:D]))/op.count;G[:D,:D]+=op.lift(correction);G[D,D]=lam/2;G[:D,D]=-nu/2;G[D,:D]=-nu.conj()/2;G=(G+G.conj().T)/2
mineig=float(np.linalg.eigvalsh(G)[0]);base=np.diag(np.r_[np.full(D,lam/(2*D)),lam/2]).astype(complex);margin=1e-12
eta=max(0,(-mineig+margin)/(lam/(2*D)-mineig)) if mineig<margin else 0.
G=(1-eta)*G+eta*base;delta*=(1-eta)
lower=float(np.vdot(delta,r).real-.5*np.linalg.norm(delta)**2)
report=dict(scope='finite Eq27 SDP numerical certificate, not continuous atomic norm equivalence',primal_diagonal_repair=primal_shift,feasible_primal_upper=upper,dual_psd_mix_fraction=eta,feasible_dual_lower=lower,certified_numeric_gap=upper-lower,relative_gap=(upper-lower)/max(1,abs(upper)),primal_min_eigenvalue_after_repair=float(np.linalg.eigvalsh(B+primal_shift*np.eye(D+1))[0]),dual_min_eigenvalue_after_repair=float(np.linalg.eigvalsh(G)[0]),dual_moment_residual=float(np.linalg.norm(op.adjoint(G[:D,:D])-target)),dual_scalar_residual=float(abs(G[D,D]-lam/2)),dual_error_inf=float(abs(delta).max()),mu=mu,float_roundoff_qualification='PSD/equality checks remain finite-precision numerical evidence, not exact rational/interval certification')
Path('results/original16-sdp-certificate.json').write_text(json.dumps(report,indent=2));np.savez_compressed('results/original16-certificate.npz',dual_matrix=G,dual_residual=delta);print(json.dumps(report,indent=2))
