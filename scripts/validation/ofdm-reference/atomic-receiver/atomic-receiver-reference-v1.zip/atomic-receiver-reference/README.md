# Independent CS-ANL1 receiver reference

This package implements the real continuous two-level-Toeplitz SDP in equation (27) of arXiv:1610.04218v2. It is a numerical/source gate, not a deployed lesson and not a full-paper reproduction.

Read `SOURCE-MODEL-ALGORITHM-AUDIT.md` first. The finite multidimensional SDP is not unconditionally identical to the continuous atomic norm; certificate limits and fixed-source inconsistencies are explicit. There is no proxy frequency grid in the optimizer. Grid CS is an explicitly separate baseline.

## Reproduce

An isolated environment was created under this directory from official PyPI, with no system-wide installation. Existing NumPy/SciPy were reused. Tested Python 3.12, NumPy 2.3.5, SciPy 1.17.0, CVXPY 1.9.3, SCS 3.3.1, Clarabel 0.11.1.

```sh
python -m venv --system-site-packages .venv
.venv/bin/python -m pip install --index-url https://pypi.org/simple -r requirements.txt
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
.venv/bin/python validate_reference.py
.venv/bin/python validate_block_update.py
.venv/bin/python run_original_dimension.py
.venv/bin/python run_original_dimension.py --cvx
.venv/bin/python continue_original.py
.venv/bin/python continue_original.py --adaptive
.venv/bin/python continue_original.py --adaptive --fixed-error
.venv/bin/python analyze_original.py
```

The original-size commands may take minutes; their run caps are part of the metadata, not success guarantees. The `continue_original.py` default resumes the recorded fixed-rho checkpoint without changing rho or convergence tolerances. The adaptive switch is an explicitly non-paper-default variant. Original stopped-run evidence is preserved separately. Run on an unloaded machine for a standalone runtime benchmark; the recorded cloud runs overlapped independent numerical jobs and are not browser latency.

## Files and gates

- `receiver.py`: NumPy ADMM, centered 2-D Toeplitz map, independent full-matrix CVXPY SDP
- `experiment.py`: original Fig8 dimensions and stated powers, with documented replacement randomness
- `baselines.py`: exact grid-CS objective/FISTA, explicit-rank spatial MUSIC operator, declared dual-peak extraction and evaluation-only target matching
- `validate_reference.py`: 62 reduced genuine SDP, analytic, operator, normalization and negative-control checks
- `validate_block_update.py`: exact joint block independently checked against Clarabel; adaptive reduced-size validation
- `results/`: complete traces, inputs, estimates, solver statuses and failed/time-limited runs
- `VALIDATION-PLAN.json`: numerical acceptance thresholds fixed before full tests, disclosed extraction choices
- `SOURCE-MANIFEST.json`: fixed PDF identifiers/hashes and runtime metadata
- `SOURCE-MODEL-ALGORITHM-AUDIT.md`: full source/observation/update/baseline audit and unresolved original experimental settings

### Interpretation

A small-instance pass establishes implementation/objective agreement, not parameter-recovery guarantees. Original 16×16 SCS solving establishes that the requested PSD size is actually exercised. The stochastic diagnostic uses one declared seed and source settings, not the paper's unavailable exact scene. Peak extraction, support thresholds, MUSIC rank selection and the 100-realization BER sweep are distinct gates. The named complete Figure8 experiment remains open. No runtime result should be called live browser execution.

Source PDFs/text and .venv are local research inputs, excluded from a portable deliverable. They must not be copied into the website repository or distributed as original code.
