"""Reproducible simulation choices, explicitly not unavailable author randomness."""
import numpy as np
from receiver import atoms

def fig8_scene(seed=161004218,scenario=1,ber=.02):
    if scenario not in (1,2):raise ValueError('scenario')
    rng=np.random.default_rng(seed);M=N=16;D=M*N;C=5 if scenario==1 else 80
    # Draw the same positions, gains, symbols, noise and per-bit uniforms at all BERs.
    ranges=np.r_[0.,rng.uniform(1000,30000,C+3)]
    speeds=np.r_[0.,rng.uniform(-3,3,C),rng.uniform(-156,156,3)]
    gains=np.r_[np.sqrt(.1),np.sqrt(.1/2)*(rng.normal(size=C)+1j*rng.normal(size=C)),.01*np.exp(2j*np.pi*rng.random(3))]
    c=3e8;fc=2e9;deltaf=5000.;Tbar=.0003
    phi=(speeds*fc/c*Tbar)%1;psi=ranges/c*deltaf
    z=atoms(M,N,phi,psi)@gains
    bits=rng.integers(2,size=(D,2));u=rng.random((D,2));err=u<ber;decoded=bits^err
    s=((1-2*bits[:,0])+1j*(1-2*bits[:,1]))/np.sqrt(2)
    shat=((1-2*decoded[:,0])+1j*(1-2*decoded[:,1]))/np.sqrt(2)
    noise=.01/np.sqrt(2)*(rng.normal(size=D)+1j*rng.normal(size=D))
    r=s*z+noise;e=(s-shat)*z
    observation=dict(r=r,s=shat,M=M,N=N)
    truth=dict(z=z,e=e,bits=bits,bit_errors=err,ranges=ranges,speeds=speeds,gains=gains,phi=phi,psi=psi,target_indices=np.arange(C+1,C+4),noise=noise)
    params=dict(seed=seed,scenario=scenario,ber=ber,actual_bit_errors=int(err.sum()),actual_symbol_errors=int(np.any(err,axis=1).sum()),M=M,N=N,lambda_value=float(.01*np.sqrt(D*np.log(D))),mu=float(.01*np.sqrt(np.log(D))),rho=.05,bandwidth_hz=N*deltaf,collection_seconds=M*Tbar,range_match_strict_metres=c/(4*N*deltaf),velocity_match_strict_mps=c/(4*M*Tbar*fc))
    return observation,truth,params
