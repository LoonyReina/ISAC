from experiment import fig8_scene
from receiver import solve_admm,atoms
from baselines import match_targets
import numpy as np,json
checks={}
for ber in (0,.02,.1,1):
 o,t,p=fig8_scene(161004218,1,ber);checks[f'identity_ber_{ber}']=float(np.linalg.norm(o['r']-o['s']*t['z']-t['e']-t['noise']))
 checks[f'unit_QPSK_ber_{ber}']=float(np.max(abs(abs(o['s'])-1)))
 checks[f'bit_count_ber_{ber}']=p['actual_bit_errors'];checks[f'symbol_count_ber_{ber}']=p['actual_symbol_errors']
 if ber==0:checks['error_free_error_norm']=float(np.linalg.norm(t['e']))
 if ber==1:checks['all_flipped_error_norm_identity']=float(np.linalg.norm(t['e']+2*o['s']*t['z']))
 try:solve_admm(**o,lam=p['lambda_value'],mu=p['mu'],truth=t)
 except TypeError:checks['truth_kwargs_rejected']=True
 o2,t2,p2=fig8_scene(161004218,1,ber/2)
 checks[f'paired_r_identity_{ber}']=float(np.linalg.norm(o['r']-o2['r']))
checks['delay_at_30km_equals_CP']=bool(abs(30000/3e8-100e-6)<1e-15)
checks['Fig8_bandwidth']=p['bandwidth_hz'];checks['Fig8_observation_duration']=p['collection_seconds'];checks['range_gate']=p['range_match_strict_metres'];checks['velocity_gate']=p['velocity_match_strict_mps']
phi=(-100*2e9/3e8*.0003)%1;psi=10000/3e8*5000
matched=match_targets([{'frequencies':np.array([phi,psi])}],np.array([10000.]),np.array([-100.]));checks['negative_velocity_exact_match']=matched['identified']==1 and matched['conditional_velocity_rmse']<1e-10
# Boundary is strict: exactly the published gate must not be counted.
matched=match_targets([{'frequencies':np.array([0.,(10000+p['range_match_strict_metres'])/3e8*5000])}],np.array([10000.]),np.array([0.]));checks['strict_gate_boundary_unmatched']=matched['identified']==0
checks['passed']=all(v<1e-10 for k,v in checks.items() if k.startswith(('identity_','unit_','paired_','error_free','all_flipped')) ) and checks['truth_kwargs_rejected'] and checks['negative_velocity_exact_match'] and checks['strict_gate_boundary_unmatched']
open('results/simulation-checks.json','w').write(json.dumps(checks,indent=2));print(json.dumps(checks,indent=2))
