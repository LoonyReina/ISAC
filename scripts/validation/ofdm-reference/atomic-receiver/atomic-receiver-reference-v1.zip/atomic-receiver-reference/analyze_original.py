import json,numpy as np
from pathlib import Path
from baselines import *
from receiver import Toeplitz2D
base='results/original16_s1_b0.02_161004218_';i=np.load(base+'exact_block_inputs.npz');r,s=i['r'],i['s'];params=json.load(open(base+'scs.json'))['parameters'];lam,mu=params['lambda_value'],params['mu'];reports={}
for name in ['scs','exact_block','fixed_rho_resume','adaptive_resume','CSAN_adaptive_fresh']:
    path=Path(base+name+'_solution.npz')
    if not path.exists():continue
    x=np.load(path);meta=json.load(open(base+name+'.json'));delta=r-x['e']-s*x['z'];nu=np.conj(s)*delta;pk=dual_peaks(nu,16,16,lam);gains=estimate_amplitudes(r,s,x['e'],16,16,pk['peaks']);f=np.array([p['frequencies'] for p in pk['peaks']]).reshape(-1,2)
    matched=match_targets(pk['peaks'],i['truth_ranges'][i['truth_target_indices']],i['truth_speeds'][i['truth_target_indices']])
    entry=dict(status=meta['status'],objective=meta['objective'],extraction=pk,matched=matched,gains=gains,range_metres=f[:,1]/5000*3e8,velocity_mps=((f[:,0]+.5)%1-.5)/.0003*3e8/2e9,error_residual_inf=float(abs(delta).max()),mu=mu,extraction_status='diagnostic_only_not_validated_detector')
    support=[]
    for th in [1e-6,1e-4,1e-3]:
        estimated=abs(x['e'])>th;true=abs(i['truth_e'])>1e-12
        support.append(dict(amplitude_threshold=th,true_positives=int(np.sum(estimated&true)),false_positives=int(np.sum(estimated&~true)),false_negatives=int(np.sum(~estimated&true))))
    entry['error_support_sensitivity_not_source_threshold']=support
    entry['all_physical_paths_matching']=match_targets(pk['peaks'],i['truth_ranges'],i['truth_speeds'])
    if 'multiplier' in x:
        G=x['multiplier'];op=Toeplitz2D(16,16);mom=op.adjoint(G[:-1,:-1]);target=np.zeros(op.L);target[op.center]=lam/2
        entry['dual_stationarity']={'moment_residual':float(np.linalg.norm(mom-target)),'scalar_residual':float(abs(G[-1,-1]-lam/2)),'z_residual':float(np.linalg.norm(nu+2*G[:-1,-1])),'PSD_min_eigenvalue':float(np.linalg.eigvalsh(G)[0]),'formal_primal_minus_residual_dual':float(meta['objective']-(np.vdot(delta,r).real-.5*np.linalg.norm(delta)**2)),'gap_is_not_certified_until_all_dual_constraints_hold':True}
    reports[name]=entry
fista=solve_cs_l1(r,s,16,16,max_iter=50000,rtol=1e-6);np.savez_compressed(base+'CSL1_solution.npz',coefficients=fista.pop('coefficients'),estimate=fista.pop('estimate'));reports['CSL1']=fista
# Rank selection is absent from source: preserve singular values but do not publish invented detection/RMSE.
music=smooth_music(r,s,16,16,rank=0);reports['MUSIC_unresolved']={'singular_values':music['singular_values'],'snapshot_shape':music['snapshot_shape'],'missing_source_parameter':'signal rank / model order and detection threshold','status':'baseline_operator_only_no_detector_result'}
def encoder(x):
    if isinstance(x,np.ndarray):return x.tolist() if not np.iscomplexobj(x) else {'real':x.real.tolist(),'imag':x.imag.tolist()}
    if isinstance(x,np.generic):return x.item()
    raise TypeError(type(x).__name__)
Path('results/original16-analysis.json').write_text(json.dumps(reports,default=encoder,indent=2))
for name,v in reports.items():print(name,{k:v[k] for k in ['status','objective','matched','runtime_seconds'] if k in v})
