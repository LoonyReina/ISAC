from pathlib import Path
import inspect,json,time
import numpy as np
from receiver import *
R=[]

def check(name,value,bound,relation='le',extra=None):
    ok=bool(value<=bound) if relation=='le' else bool(value>=bound)
    row=dict(name=name,value=float(value),bound=float(bound),relation=relation,passed=ok)
    if extra:row.update(extra)
    R.append(row)

def comparison(name,r,s,M,N,lam,mu,fixed_error=False,mode='exact_block'):
    ad=solve_admm(r,s,M,N,lam,mu,rho=.05,atol=1e-9,rtol=1e-8,max_iter=30000,mode=mode,fixed_error=fixed_error)
    cv=solve_cvx(r,s,M,N,lam,mu,fixed_error=fixed_error,eps=1e-8,max_iter=100000)
    pred=np.linalg.norm(s*(ad['z']-cv['z'])+ad['e']-cv['e'])/max(1,np.linalg.norm(r))
    d=abs(ad['objective']-cv['objective']);allow=1e-5+1e-4*abs(cv['objective'])
    check(name+'_objective',d,allow,extra=dict(admm_status=ad['status'],cvx_status=cv['status'],admm_objective=ad['objective'],cvx_objective=float(cv['objective']),admm_iterations=ad['iterations'],admm_runtime=ad['runtime_seconds'],cvx_runtime=cv['runtime_seconds']))
    check(name+'_prediction',pred,2e-4)
    check(name+'_PSD',ad['min_eigenvalue']/max(1,np.linalg.norm(ad['T'],2)), -2e-5,'ge')
    check(name+'_status',int(ad['status']=='converged' and cv['status']=='optimal'),1,'ge')
    np.savez_compressed('results/'+name+'_checkpoint.npz',r=r,s=s,admm_z=ad['z'],admm_e=ad['e'],admm_T=ad['T'],admm_nu=ad['nu'],admm_multiplier=ad['multiplier'],cvx_z=cv['z'],cvx_e=cv['e'],cvx_T=cv['T'])
    Path('results/'+name+'_trace.json').write_text(json.dumps(ad['trace'],indent=2))
    return ad,cv

start=time.perf_counter();rng=np.random.default_rng(161004218)
M,N=3,4;op=Toeplitz2D(M,N)
u=rng.normal(size=op.L)+1j*rng.normal(size=op.L);P=rng.normal(size=(M*N,M*N))+1j*rng.normal(size=(M*N,M*N))
check('true_adjoint_inner_product',abs(np.vdot(op.lift(u),P)-np.vdot(u,op.adjoint(P))),1e-10)
check('lag_average_left_inverse',np.linalg.norm(op.average(op.lift(u))-u),1e-12)
check('center_multiplicity',abs(op.count[op.center]-M*N),0)
a=atoms(M,N,[.173],[.291])[:,0];T=np.outer(a,a.conj());check('rank1_atom_Toeplitz_lift',np.linalg.norm(op.lift(op.average(T))-T),1e-12)
# 1x1, e-only counterexample exercises non-unit S and printed Eq30.
ad,cv=comparison('scalar_robust',np.array([1.+0j]),np.array([2.+0j]),1,1,1.,.2)
check('scalar_robust_z_zero',np.linalg.norm(ad['z']),1e-6);check('scalar_robust_e_soft',abs(ad['e'][0]-.8),1e-6)
check('nonunit_symbol_correct_dual',abs(ad['nu'][0]-.4),1e-6)
check('Eq30_inverse_symbol_counterexample',abs(ad['nu'][0]-.1),.29,'ge')
ad,cv=comparison('scalar_CSAN',np.array([1.+1j]),np.array([1.+0j]),1,1,.4,.2,True)
check('scalar_CSAN_soft',abs(ad['z'][0]-shrink(np.array([1+1j]),.4)[0]),1e-6)
# Analytic one off-grid atom, constant-modulus QPSK observation.
M,N=4,3;D=M*N;s=np.exp(.5j*np.pi*rng.integers(4,size=D));a=atoms(M,N,[.173],[.381])[:,0];alpha=1.2+.6j;lam=.3
ad,cv=comparison('single_atom_CSAN',s*a*alpha,s,M,N,lam,.1,True)
expected=a*alpha*(1-lam/(D*abs(alpha)))
check('single_atom_analytic_shrink',np.linalg.norm(ad['z']-expected)/np.linalg.norm(expected),3e-6)
check('single_atom_dual_modulus',abs(abs(np.vdot(a,ad['nu']))-lam),1e-6)
check('correct_multiplier_scaling',np.linalg.norm(ad['nu']+2*ad['multiplier'][:-1,-1]),1e-6)
check('printed_multiplier_scaling_fails',np.linalg.norm(ad['nu']+ad['multiplier'][:-1,-1]/2),.01,'ge')
check('table_I_squared_threshold_counterexample',abs(lam-abs(np.vdot(a,ad['nu']))**2),.2,'ge')
# QPSK plus sparse corruption, paired true convex references.
M=N=4;D=M*N;s=np.exp(.5j*np.pi*rng.integers(4,size=D));z=atoms(M,N,[.173,.641],[.281,.731])@np.array([1,.45j]);e=np.zeros(D,complex);e[[2,11]]=[2,-3j];r=s*z+e+.02*(rng.normal(size=D)+1j*rng.normal(size=D))/2**.5
ad,cv=comparison('QPSK_sparse',r,s,M,N,.3,.12)
ad_j,cv_j=comparison('QPSK_paper_jacobi',r,s,M,N,.3,.12,mode='paper_jacobi')
bad=solve_admm(r,s,M,N,.3,.12,mode='literal_s_rhs',max_iter=10000,atol=1e-9,rtol=1e-8)
check('Eq43_literal_conjugation_counterexample',bad['objective']-cv['objective'],.05,'ge',dict(status=bad['status'],objective=bad['objective'],stationarity=bad['z_stationarity']))
# QAM, low SNR, close frequencies, dense contamination and a muted cell.
for name,spacing,noise,dense in [('QAM',.4,.05,False),('low_SNR',.4,1.,False),('close_paths',.003,.05,False),('dense_errors',.4,.05,True),('missing_sample_extension',.4,.05,False)]:
    M,N=3,4;D=M*N;s=(rng.choice([-3,-1,1,3],D)+1j*rng.choice([-3,-1,1,3],D))/np.sqrt(10)
    if name=='missing_sample_extension':s[3]=0
    z=atoms(M,N,[.172,.172+spacing],[.321,.321+spacing])@np.array([1,.5j]);e=np.zeros(D,complex);idx=np.arange(D) if dense else [1,8];e[idx]=2*(rng.normal(size=len(idx))+1j*rng.normal(size=len(idx)))
    r=s*z+e+noise/np.sqrt(2)*(rng.normal(size=D)+1j*rng.normal(size=D));comparison(name,r,s,M,N,.4,.15)
ad,cv=comparison('zero_observation',np.zeros(6,complex),np.ones(6,complex),2,3,.4,.15)
short=solve_admm(r,s,M,N,.4,.15,max_iter=1)
check('interrupted_solve_not_success',int(short['status']=='max_iter'),1,'ge')
try:solve_admm(r,s,M,N,.4,0);reject=0
except ValueError:reject=1
check('mu_zero_free_error_rejected',reject,1,'ge')
check('receiver_has_no_truth_or_seed_input',int(not any(k in inspect.signature(solve_admm).parameters for k in ('seed','truth','ranges','speeds','gains','phi','psi'))),1,'ge')
report=dict(passed=all(r['passed'] for r in R),checks=len(R),runtime_seconds=time.perf_counter()-start,results=R)
Path('results/validation.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2));raise SystemExit(0 if report['passed'] else 1)
