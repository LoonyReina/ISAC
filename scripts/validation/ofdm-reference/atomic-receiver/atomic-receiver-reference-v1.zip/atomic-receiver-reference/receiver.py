"""Independent NumPy implementation of arXiv:1610.04218v2 Eq (27).
No frequency dictionary enters optimization. All vectors use column-major vec.
Print-sensitive Table I defects are documented separately; exact_block implements
Eq (35)'s JOINT minimization, while paper_jacobi uses printed old-z/old-e ordering.
"""
from dataclasses import dataclass
import time
import numpy as np
from scipy.linalg import eigh


def shrink(x, threshold):
    a=np.abs(x)
    return x*np.maximum(0,1-threshold/np.maximum(a,np.finfo(float).tiny))

class Toeplitz2D:
    def __init__(self,M,N):
        self.M,self.N,self.D=M,N,M*N
        m=np.tile(np.arange(M),N); n=np.repeat(np.arange(N),M)
        self.index=(m[:,None]-m[None,:]+M-1)+(2*M-1)*(n[:,None]-n[None,:]+N-1)
        self.flat=self.index.ravel(); self.L=(2*M-1)*(2*N-1)
        self.count=np.bincount(self.flat,minlength=self.L)
        self.center=M-1+(2*M-1)*(N-1)
    def lift(self,u):return np.asarray(u)[self.index]
    def adjoint(self,X):
        return np.bincount(self.flat,weights=X.real.ravel(),minlength=self.L)+1j*np.bincount(self.flat,weights=X.imag.ravel(),minlength=self.L)
    def average(self,X):return self.adjoint(X)/self.count

def atoms(M,N,phi,psi):
    m=np.tile(np.arange(M),N);n=np.repeat(np.arange(N),M)
    return np.exp(2j*np.pi*(m[:,None]*np.atleast_1d(phi)-n[:,None]*np.atleast_1d(psi)))

def objective(r,s,z,e,T,t,lam,mu):
    return float(.5*np.linalg.norm(r-e-s*z)**2+lam*(np.trace(T).real/len(z)+t)/2+mu*np.sum(np.abs(e)))

def solve_admm(r,s,M,N,lam,mu,rho=.05,max_iter=20000,atol=1e-7,rtol=1e-6,mode='exact_block',fixed_error=False,record_every=10,deadline_seconds=None,initial_state=None,adaptive_rho=False):
    r=np.asarray(r,dtype=complex).reshape(-1);s=np.asarray(s,dtype=complex).reshape(-1)
    D=M*N
    if r.shape!=(D,) or s.shape!=(D,) or np.any(~np.isfinite(r)) or np.any(~np.isfinite(s)):raise ValueError('invalid observations')
    if min(M,N)<1 or lam<=0 or mu<0 or rho<=0:raise ValueError('invalid settings')
    if not fixed_error and mu==0:raise ValueError('mu=0 with free e is degenerate; CS-AN requires e fixed to zero')
    if mode not in ('exact_block','paper_jacobi','sequential','literal_s_rhs'):raise ValueError('invalid update mode')
    op=Toeplitz2D(M,N);z=np.zeros(D,complex);e=z.copy();Theta=np.zeros((D+1,D+1),complex);G=Theta.copy()
    if initial_state is not None:
        z=np.array(initial_state['z'],copy=True);e=np.array(initial_state['e'],copy=True)
        Theta=np.array(initial_state['Theta'],copy=True);G=np.array(initial_state['multiplier'],copy=True)
        if z.shape!=(D,) or e.shape!=(D,) or Theta.shape!=(D+1,D+1) or G.shape!=(D+1,D+1):raise ValueError('invalid warm start')
    q=np.abs(s)**2; beta=2*rho; trace=[]; start=time.perf_counter(); status='max_iter'; eig_time=0
    for it in range(1,max_iter+1):
        beta=2*rho
        A=Theta[:D,D]+G[:D,D]/rho
        if fixed_error:
            e_new=np.zeros(D,complex)
            z_new=(np.conj(s)*r+beta*A)/(q+beta)
        elif mode=='exact_block':
            weight=beta/(q+beta)
            e_new=shrink(r-s*A,mu/weight)
            z_new=(np.conj(s)*(r-e_new)+beta*A)/(q+beta)
        else:
            sr=s if mode=='literal_s_rhs' else np.conj(s)
            z_new=(sr*(r-e)+beta*A)/(q+beta)
            e_new=shrink(r-s*(z_new if mode=='sequential' else z),mu)
        u=op.average(Theta[:D,:D]+G[:D,:D]/rho)
        u[op.center]-=lam/(2*D*rho)
        T=op.lift(u); t=float((Theta[D,D]+G[D,D]/rho).real-lam/(2*rho))
        B=np.empty_like(Theta);B[:D,:D]=T;B[:D,D]=z_new;B[D,:D]=z_new.conj();B[D,D]=t
        H=B-G/rho; H=(H+H.conj().T)/2
        tic=time.perf_counter(); vals,V=eigh(H,check_finite=False,driver='evr');newTheta=(V*np.maximum(vals,0))@V.conj().T;eig_time+=time.perf_counter()-tic
        primal=np.linalg.norm(newTheta-B);dual=rho*np.linalg.norm(newTheta-Theta)
        G+=rho*(newTheta-B);Theta=newTheta;z,e=z_new,e_new
        scale=max(np.linalg.norm(B),np.linalg.norm(Theta),1.)
        # Scaled Frobenius residual thresholds, plus independent stationarity checks.
        epsp=atol*(D+1)+rtol*scale;epsd=atol*(D+1)+rtol*max(np.linalg.norm(G),1.)
        residual=r-s*z-e; nu=np.conj(s)*residual
        zstat=np.linalg.norm(nu+2*G[:D,D])
        estat=0. if fixed_error else np.linalg.norm(e-shrink(r-s*z,mu))
        if it==1 or it%record_every==0 or (primal<=epsp and dual<=epsd):
            trace.append(dict(iteration=it,objective=objective(r,s,z,e,T,t,lam,mu),primal=float(primal),dual=float(dual),primal_tolerance=float(epsp),dual_tolerance=float(epsd),z_stationarity=float(zstat),e_stationarity=float(estat),rho=float(rho),elapsed_seconds=time.perf_counter()-start))
        if primal<=epsp and dual<=epsd and max(zstat,estat)<=max(10*epsd,1e-8):status='converged';break
        if deadline_seconds and time.perf_counter()-start>=deadline_seconds:status='time_limit';break
        if adaptive_rho and it%25==0:
            if primal>10*dual:rho=min(rho*2,10.)
            elif dual>10*primal:rho=max(rho/2,1e-5)
    eigs=eigh((B+B.conj().T)/2,eigvals_only=True,check_finite=False)
    return dict(z=z,e=e,T=T,t=t,Theta=Theta,multiplier=G,nu=nu,status=status,iterations=it,objective=objective(r,s,z,e,T,t,lam,mu),min_eigenvalue=float(eigs[0]),primal=float(primal),dual=float(dual),z_stationarity=float(zstat),e_stationarity=float(estat),runtime_seconds=time.perf_counter()-start,eigendecomposition_seconds=eig_time,trace=trace,mode=mode,final_rho=float(rho),adaptive_rho=adaptive_rho)

def solve_cvx(r,s,M,N,lam,mu,fixed_error=False,solver='SCS',eps=1e-7,max_iter=100000,verbose=False):
    """Independent matrix-variable formulation; no lag operator/ADMM shared."""
    import cvxpy as cp
    D=M*N;T=cp.Variable((D,D),hermitian=True);t=cp.Variable();z=cp.Variable(D,complex=True)
    e=cp.Constant(np.zeros(D,complex)) if fixed_error else cp.Variable(D,complex=True)
    # Enforce two independent shift invariances, not a generated lag dictionary.
    constraints=[]
    if N>1:constraints += [T[M:,M:]==T[:-M,:-M]]
    if M>1:
        upper=np.array([n*M+m for n in range(N) for m in range(1,M)])
        lower=upper-1
        constraints += [T[np.ix_(upper,upper)]==T[np.ix_(lower,lower)]]
    B=cp.bmat([[T,cp.reshape(z,(D,1),order='F')],[cp.reshape(cp.conj(z),(1,D),order='F'),cp.reshape(t,(1,1),order='F')]])
    constraints += [B >> 0]
    obj=.5*cp.sum_squares(cp.abs(r-e-cp.multiply(s,z)))+lam*(cp.real(cp.trace(T))/D+t)/2+mu*cp.sum(cp.abs(e))
    problem=cp.Problem(cp.Minimize(obj),constraints);start=time.perf_counter()
    opts=dict(eps=eps,max_iters=max_iter) if solver=='SCS' else dict(tol_gap_abs=eps,tol_feas=eps,tol_gap_rel=eps,max_iter=max_iter)
    problem.solve(solver=solver,verbose=verbose,**opts)
    out=dict(status=problem.status,objective=problem.value,runtime_seconds=time.perf_counter()-start,iterations=problem.solver_stats.num_iters,solver=solver,eps=eps)
    if z.value is not None:
        out.update(z=z.value,e=e.value,T=T.value,t=float(t.value),min_eigenvalue=float(np.linalg.eigvalsh(B.value)[0]),nu=np.conj(s)*(r-e.value-s*z.value))
    return out
