import argparse,json,numpy as np
from pathlib import Path
from receiver import solve_admm
p=argparse.ArgumentParser();p.add_argument('--adaptive',action='store_true');p.add_argument('--fixed-error',action='store_true');a=p.parse_args()
stem='results/original16_s1_b0.02_161004218_';i=np.load(stem+'exact_block_inputs.npz');old=np.load(stem+'exact_block_solution.npz');meta=json.load(open(stem+'exact_block.json'));par=meta['parameters']
name=stem+('CSAN_adaptive_fresh' if a.fixed_error else ('adaptive_resume' if a.adaptive else 'fixed_rho_resume'))
x=solve_admm(i['r'],i['s'],16,16,par['lambda_value'],par['mu'],rho=.05,max_iter=20000,atol=1e-8,rtol=1e-7,record_every=50,deadline_seconds=450,initial_state=None if a.fixed_error else old,adaptive_rho=a.adaptive,fixed_error=a.fixed_error)
np.savez_compressed(name+'_solution.npz',**{k:v for k,v in x.items() if isinstance(v,np.ndarray)});out={k:v for k,v in x.items() if not isinstance(v,np.ndarray)};out['parameters']=par;out['previous_iterations']=0 if a.fixed_error else meta['iterations'];out['previous_runtime_seconds']=0 if a.fixed_error else meta['runtime_seconds'];out['z_relative_error']=float(np.linalg.norm(x['z']-i['truth_z'])/np.linalg.norm(i['truth_z']));out['error_relative_error']=float(np.linalg.norm(x['e']-i['truth_e'])/np.linalg.norm(i['truth_e']));Path(name+'.json').write_text(json.dumps(out,indent=2));print(json.dumps({k:v for k,v in out.items() if k!='trace'},indent=2),flush=True)
