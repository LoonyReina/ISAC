"""Exact paper baseline objectives/operators; extraction choices remain explicit."""
import time
import numpy as np
from scipy.ndimage import maximum_filter
from scipy.optimize import minimize,linear_sum_assignment
from receiver import atoms,shrink

class FourierGrid:
    def __init__(self,M,N,kappa=4):self.M,self.N,self.P,self.Q=M,N,kappa*M,kappa*N
    def forward(self,x):
        X=np.asarray(x).reshape((self.P,self.Q),order='F')
        return np.fft.fft(np.fft.ifft(X,axis=0)*self.P,axis=1)[:self.M,:self.N].reshape(-1,order='F')
    def adjoint(self,y):
        Z=np.zeros((self.P,self.Q),complex);Z[:self.M,:self.N]=np.asarray(y).reshape((self.M,self.N),order='F')
        return (np.fft.ifft(np.fft.fft(Z,axis=0),axis=1)*self.Q).reshape(-1,order='F')

def solve_cs_l1(r,s,M,N,sigma=.01,kappa=4,max_iter=50000,rtol=1e-6):
    grid=FourierGrid(M,N,kappa);L=grid.P*grid.Q;gamma=2*sigma*np.sqrt(2*np.log(L));lip=L*np.max(np.abs(s)**2)
    x=np.zeros(L,complex);y=x.copy();t=1.;start=time.perf_counter();trace=[];status='max_iter'
    for it in range(1,max_iter+1):
        grad=grid.adjoint(np.conj(s)*(s*grid.forward(y)-r));xn=shrink(y-grad/lip,gamma/lip)
        tn=(1+np.sqrt(1+4*t*t))/2;y=xn+(t-1)/tn*(xn-x);x,t=xn,tn
        if it==1 or it%100==0:
            residual=r-s*grid.forward(x);g=grid.adjoint(np.conj(s)*residual)
            # Proximal stationarity, reported in gradient units.
            kkt=lip*np.linalg.norm(x-shrink(x+g/lip,gamma/lip),np.inf)
            obj=.5*np.linalg.norm(residual)**2+gamma*np.sum(abs(x));trace.append(dict(iteration=it,objective=float(obj),kkt_inf=float(kkt)))
            if kkt<=rtol*max(1,gamma):status='converged';break
    return dict(coefficients=x,estimate=grid.forward(x),status=status,iterations=it,objective=float(obj),kkt_inf=float(kkt),gamma=float(gamma),kappa=kappa,runtime_seconds=time.perf_counter()-start,trace=trace)

def dual_peaks(nu,M,N,lam,oversampling=16,candidate_ratio=.8,accept_ratio=.995,max_candidates=128):
    P,Q=oversampling*M,oversampling*N
    Z=nu.reshape((M,N),order='F')
    spectrum=np.abs(np.fft.ifft(np.fft.fft(Z,n=P,axis=0),n=Q,axis=1)*Q)
    mask=(spectrum==maximum_filter(spectrum,size=3,mode='wrap'))&(spectrum>=candidate_ratio*lam)
    ij=np.argwhere(mask);ij=ij[np.argsort(spectrum[mask])[::-1]][:max_candidates]
    peaks=[]
    for i,j in ij:
        def fun(v):
            a=atoms(M,N,[v[0]],[v[1]])[:,0]
            return -float(abs(np.vdot(a,nu))**2/lam**2)
        opt=minimize(fun,[i/P,j/Q],method='L-BFGS-B',bounds=[((i-1)/P,(i+1)/P),((j-1)/Q,(j+1)/Q)],options=dict(ftol=1e-14,gtol=1e-10,maxiter=200))
        point=opt.x%1;ratio=np.sqrt(-opt.fun)
        if ratio>=accept_ratio and all(np.linalg.norm((point-q['frequencies']+.5)%1-.5)>1e-5 for q in peaks):peaks.append(dict(frequencies=point,dual_ratio=float(ratio),optimizer_success=bool(opt.success)))
    return dict(peaks=peaks,grid_shape=[P,Q],max_grid_dual_ratio=float(spectrum.max()/lam),candidate_count=len(ij),thresholds=dict(candidate_ratio=candidate_ratio,accept_ratio=accept_ratio),global_dual_certificate=False)

def estimate_amplitudes(r,s,e,M,N,peaks):
    if not peaks:return np.array([],complex)
    f=np.array([p['frequencies'] for p in peaks]);C=atoms(M,N,f[:,0],f[:,1]);return np.linalg.lstsq(s[:,None]*C,r-e,rcond=None)[0]

def smooth_music(r,s,M,N,rank):
    """Source Eqs12-16, corrected conformable projector; rank is explicit input.
    Source does not give rank selection, so this is not a closed detector.
    """
    if np.any(s==0):raise ValueError('MUSIC demodulation division requires nonzero symbols')
    M0,N0=M//2,N//2;Z=(r/s).reshape((M,N),order='F')
    Y=np.column_stack([Z[m:m+M0,n:n+N0].reshape(-1,order='F') for n in range(N-N0+1) for m in range(M-M0+1)])
    if not 0<=rank<min(Y.shape):raise ValueError('explicit signal rank must leave a nonempty noise subspace')
    U,svals,_=np.linalg.svd(Y,full_matrices=True)
    return dict(noise_projector=U[:,rank:]@U[:,rank:].conj().T,singular_values=svals,snapshot_shape=list(Y.shape),rank=rank,M0=M0,N0=N0)

def match_targets(peaks,true_ranges,true_speeds,M=16,N=16,df=5000,Tbar=.0003,fc=2e9,c=3e8):
    """One-to-one post-solver evaluation only; truth never enters extraction."""
    f=np.array([p['frequencies'] for p in peaks]).reshape(-1,2)
    ranges=f[:,1]/df*c; speeds=((f[:,0]+.5)%1-.5)/Tbar*c/fc
    rg=c/(4*N*df);vg=c/(4*M*Tbar*fc)
    cost=((true_ranges[:,None]-ranges[None,:])/rg)**2+((true_speeds[:,None]-speeds[None,:])/vg)**2
    eligible=(np.abs(true_ranges[:,None]-ranges[None,:])<rg)&(np.abs(true_speeds[:,None]-speeds[None,:])<vg)
    # Dummy misses make cardinality dominate distance. No reuse of one path for two targets.
    augmented=np.column_stack([np.where(eligible,cost,1e6),np.full((len(true_ranges),len(true_ranges)),1e3)])
    a,b=linear_sum_assignment(augmented);matched=[(i,j) for i,j in zip(a,b) if j<len(peaks) and eligible[i,j]]
    dr=[float(ranges[j]-true_ranges[i]) for i,j in matched];dv=[float(speeds[j]-true_speeds[i]) for i,j in matched]
    return dict(target_count=len(true_ranges),identified=len(matched),missed=len(true_ranges)-len(matched),all_estimated_paths=len(peaks),unmatched_estimated_paths=len(peaks)-len(matched),unmatched_paths_include_clutter=True,range_errors_metres=dr,velocity_errors_mps=dv,conditional_range_rmse=None if not dr else float(np.sqrt(np.mean(np.square(dr)))),conditional_velocity_rmse=None if not dv else float(np.sqrt(np.mean(np.square(dv)))),range_gate=rg,velocity_gate=vg)
