import json, numpy as np
from receiver import solve_admm,solve_cvx
from experiment import fig8_scene
from pathlib import Path
import argparse
p=argparse.ArgumentParser();p.add_argument('--cvx',action='store_true');p.add_argument('--scenario',type=int,default=1);p.add_argument('--ber',type=float,default=.02);p.add_argument('--seed',type=int,default=161004218);p.add_argument('--mode',default='exact_block');p.add_argument('--fixed-error',action='store_true');a=p.parse_args()
obs,truth,params=fig8_scene(a.seed,a.scenario,a.ber)
name=f"original16_s{a.scenario}_b{a.ber:g}_{a.seed}_"+('scs' if a.cvx else a.mode)+('_CSAN' if a.fixed_error else '')
np.savez_compressed('results/'+name+'_inputs.npz',**obs,**{f'truth_{k}':v for k,v in truth.items()})
if a.cvx:
    x=solve_cvx(**obs,lam=params['lambda_value'],mu=params['mu'],fixed_error=a.fixed_error,eps=1e-6,max_iter=15000)
else:
    x=solve_admm(**obs,lam=params['lambda_value'],mu=params['mu'],rho=params['rho'],mode=a.mode,fixed_error=a.fixed_error,max_iter=15000,atol=1e-8,rtol=1e-7,record_every=50,deadline_seconds=300)
np.savez_compressed('results/'+name+'_solution.npz',**{k:v for k,v in x.items() if isinstance(v,np.ndarray)})
y={k:v for k,v in x.items() if not isinstance(v,np.ndarray)};y['parameters']=params
y['z_relative_error']=float(np.linalg.norm(x['z']-truth['z'])/np.linalg.norm(truth['z']));y['error_relative_error']=float(np.linalg.norm(x['e']-truth['e'])/max(np.linalg.norm(truth['e']),1e-15));y['toeplitz_eigenvalues']=np.linalg.eigvalsh(x['T']).tolist();y['atomic_exactness_rank_tolerance']=1e-5;y['rank_above_relative_threshold']=int((np.linalg.eigvalsh(x['T'])>1e-5*np.linalg.norm(x['T'],2)).sum())
Path('results/'+name+'.json').write_text(json.dumps(y,indent=2));print(name,json.dumps({k:v for k,v in y.items() if k not in ['trace','toeplitz_eigenvalues']},indent=2),flush=True)
