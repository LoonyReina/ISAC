from baselines import *
import cvxpy as cp,json
rng=np.random.default_rng(17);M,N=3,2;g=FourierGrid(M,N,4);phi=np.tile(np.arange(g.P)/g.P,g.Q);psi=np.repeat(np.arange(g.Q)/g.Q,g.P);C=atoms(M,N,phi,psi);x=rng.normal(size=g.P*g.Q)+1j*rng.normal(size=g.P*g.Q);y=rng.normal(size=M*N)+1j*rng.normal(size=M*N)
checks={'forward_error':float(np.linalg.norm(C@x-g.forward(x))),'adjoint_error':float(np.linalg.norm(C.conj().T@y-g.adjoint(y)))}
s=np.exp(.5j*np.pi*rng.integers(4,size=M*N));f=solve_cs_l1(y,s,M,N,sigma=.1,rtol=1e-8);v=cp.Variable(len(x),complex=True);prob=cp.Problem(cp.Minimize(.5*cp.sum_squares(cp.abs(y-cp.multiply(s,C@v)))+f['gamma']*cp.sum(cp.abs(v))));prob.solve(solver='CLARABEL',tol_gap_abs=1e-9,tol_feas=1e-9,tol_gap_rel=1e-9)
checks.update(fista_objective=f['objective'],clarabel_objective=prob.value,objective_error=abs(f['objective']-prob.value),fista_status=f['status'],clarabel_status=prob.status)
nu=atoms(8,8,[.173],[.391])[:,0]/64;pk=dual_peaks(nu,8,8,1);checks['dual_peak_error']=float(np.linalg.norm(pk['peaks'][0]['frequencies']-[.173,.391]));checks['dual_peak_modulus_error']=abs(pk['peaks'][0]['dual_ratio']-1)
checks['passed']=max(checks[k] for k in ['forward_error','adjoint_error','objective_error','dual_peak_error','dual_peak_modulus_error'])<1e-6
open('results/baseline-checks.json','w').write(json.dumps(checks,indent=2));print(checks);assert checks['passed']
