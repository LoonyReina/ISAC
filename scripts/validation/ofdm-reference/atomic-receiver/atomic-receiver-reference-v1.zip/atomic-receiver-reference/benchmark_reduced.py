import time,json,numpy as np
from pathlib import Path
from receiver import *
results={}
for side in [4,8]:
 rng=np.random.default_rng(161004218+side);D=side*side;bits=rng.integers(2,size=(D,2));dec=bits.copy();dec[[2,D-5],0]^=1
 s=((1-2*bits[:,0])+1j*(1-2*bits[:,1]))/np.sqrt(2);shat=((1-2*dec[:,0])+1j*(1-2*dec[:,1]))/np.sqrt(2)
 truth=atoms(side,side,[.173,.641],[.281,.731])@np.array([1,.45j]);noise=.02/np.sqrt(2)*(rng.normal(size=D)+1j*rng.normal(size=D));r=s*truth+noise;lam=.02*np.sqrt(D*np.log(D));mu=.02*np.sqrt(np.log(D))
 runs=[]
 for rep in range(3):
  a=solve_admm(r,shat,side,side,lam,mu,rho=.05,atol=1e-9,rtol=1e-8,max_iter=30000,record_every=100)
  runs.append({k:a[k] for k in ['status','iterations','runtime_seconds','eigendecomposition_seconds','objective','primal','dual','min_eigenvalue']})
 b=solve_cvx(r,shat,side,side,lam,mu,eps=1e-8,max_iter=100000)
 results[str(side)]={'source_formulation':'Eq27','scene':'two continuous off-grid paths, two signal-dependent QPSK decision errors, sigma .02','seed':161004218+side,'M':side,'N':side,'PSD_complex_dimension':D+1,'lambda':float(lam),'mu':float(mu),'rho':.05,'atol':1e-9,'rtol':1e-8,'runs':runs,'runtime_median_seconds':float(np.median([v['runtime_seconds'] for v in runs])),'runtime_max_seconds':max(v['runtime_seconds'] for v in runs),'sample_count':3,'independent_scs':{k:b[k] for k in ['status','objective','runtime_seconds','iterations','eps']},'objective_difference':float(abs(a['objective']-b['objective'])),'relative_predicted_observation_difference':float(np.linalg.norm(shat*(a['z']-b['z'])+a['e']-b['e'])/max(1,np.linalg.norm(r)))}
 np.savez_compressed(f'results/benchmark_{side}_checkpoint.npz',r=r,s=shat,admm_z=a['z'],admm_e=a['e'],admm_T=a['T'],admm_nu=a['nu'],cvx_z=b['z'],cvx_e=b['e'],cvx_T=b['T'])
 Path('results/reduced-benchmark.json').write_text(json.dumps(results,indent=2));print(side,json.dumps(results[str(side)]),flush=True)
