/* Numerical-only Worker protocol. No DOM, network or simulation truth. */
'use strict';
importScripts('core.js');
const core=self.AtomicReceiverCore;
let active=null,lastAcceptedId=-1;
const send=(value)=>self.postMessage(value);
send({type:'ready',version:core.VERSION});
self.onmessage=({data:m})=>{
 if(!m||typeof m!=='object')return send({type:'error',requestId:null,error:'Invalid message'});
 if(m.type==='cancel'){
  if(active&&active.id===m.requestId){const token=active;token.solver.cancel();active=null;send({type:'cancelled',requestId:token.id,version:core.VERSION,iterations:token.solver.iterations,reason:'requested'});}
  return;
 }
 if(m.type!=='solve')return send({type:'error',requestId:m.requestId??null,error:'Unsupported message type'});
 const id=m.requestId;
 if(!Number.isSafeInteger(id)||id<0||id<=lastAcceptedId)return send({type:'error',requestId:id??null,error:'Solve requestId must be a fresh increasing nonnegative safe integer'});
 if(m.expectedVersion!==core.VERSION)return send({type:'error',requestId:id,error:'Core version mismatch',version:core.VERSION});
 let solver;
 try{solver=core.createSolver(m.input,m.settings||{});}catch(e){return send({type:'error',requestId:id,error:String(e.message),version:core.VERSION});}
 if(active){const old=active;old.solver.cancel();send({type:'cancelled',requestId:old.id,version:core.VERSION,iterations:old.solver.iterations,reason:'superseded'});}
 const token={id,solver,lastProgress:0};active=token;lastAcceptedId=id;
 send({type:'started',requestId:id,version:core.VERSION});
 const pump=()=>{
  if(active!==token||solver.status!=='running')return;
  try{
   const state=solver.step(4),time=performance.now();
   if(active!==token)return;
   if(state.status==='running'){
    if(time-token.lastProgress>=100){send({type:'progress',requestId:id,version:core.VERSION,iterations:state.iterations,last:state.last});token.lastProgress=time;}
    setTimeout(pump,0);
   }else{const result=solver.snapshot(true);if(active===token){active=null;send({type:'result',requestId:id,version:core.VERSION,result});}}
  }catch(e){if(active===token){active=null;send({type:'error',requestId:id,version:core.VERSION,error:String(e.message)});}}
 };
 setTimeout(pump,0);
};
