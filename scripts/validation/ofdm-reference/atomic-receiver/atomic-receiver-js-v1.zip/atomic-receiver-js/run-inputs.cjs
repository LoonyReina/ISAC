const fs=require('node:fs'),core=require('./core.js');
const input=JSON.parse(fs.readFileSync(process.argv[2],'utf8'));const cases=Array.isArray(input)?input:input.cases;const out=[];
for(const c of cases){const solver=core.createSolver(c.input,c.settings||{});while(solver.status==='running')solver.step(100);const result=solver.snapshot(true);out.push({id:c.id||c.name,result});console.error(c.id||c.name,result.status,result.iterations,result.runtimeMs,result.last.objective);}
fs.writeFileSync(process.argv[3],JSON.stringify({coreVersion:core.VERSION,results:out},null,2));
