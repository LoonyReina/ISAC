import json,sys,numpy as np
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]));from receiver import atoms,solve_admm,solve_cvx
rng=np.random.default_rng(16100421855)
def c(x):return {'re':np.asarray(x).real.ravel().tolist(),'im':np.asarray(x).imag.ravel().tolist()}
fixtures=[]
for name,side,phi,psi in [('close_paths_QPSK',4,[.173,.176],[.281,.284]),('dense_errors_QPSK',4,[.173,.641],[.281,.731])]:
 D=side**2;truth=atoms(side,side,phi,psi)@np.array([1,.45j]);bits=rng.integers(2,size=(D,2));dec=bits.copy();dec[[2,11] if name.startswith('close') else np.arange(D),0]^=1
 s=((1-2*bits[:,0])+1j*(1-2*bits[:,1]))/np.sqrt(2);shat=((1-2*dec[:,0])+1j*(1-2*dec[:,1]))/np.sqrt(2);r=s*truth+.02/np.sqrt(2)*(rng.normal(size=D)+1j*rng.normal(size=D));lam=.02*np.sqrt(D*np.log(D));mu=.02*np.sqrt(np.log(D))
 a=solve_admm(r,shat,side,side,lam,mu,rho=.05,atol=1e-9,rtol=1e-8);v=solve_cvx(r,shat,side,side,lam,mu,eps=1e-8)
 fixtures.append({'name':name,'input':dict(M=side,N=side,r=c(r),s=c(shat),**{'lambda':lam,'mu':mu}),'settings':{'rho':.05,'atol':1e-9,'rtol':1e-8},'python':{'z':c(a['z']),'e':c(a['e']),'T':c(a['T']),'iterations':a['iterations'],'objective':a['objective'],'status':a['status']},'cvx':{'z':c(v['z']),'e':c(v['e']),'T':c(v['T']),'objective':v['objective'],'status':v['status']}})
Path('js-port/fixtures.json').write_text(json.dumps(fixtures,indent=2))
matrices=[]
for size in [1,2,5,17]:
 for name in ['zero','rank1','repeated','indefinite','near_PSD']:
  A=rng.normal(size=(size,size))+1j*rng.normal(size=(size,size));Q,_=np.linalg.qr(A)
  if name=='zero':values=np.zeros(size)
  elif name=='rank1':values=np.r_[np.ones(1),np.zeros(size-1)]
  elif name=='repeated':values=np.ones(size)*.3
  elif name=='indefinite':values=np.linspace(-2,3,size)
  else:values=np.geomspace(1e-12,10,size);values[0]=-1e-10
  H=(Q*values)@Q.conj().T;expected=(Q*np.maximum(values,0))@Q.conj().T
  matrices.append(dict(name=f'{name}_{size}',size=size,input=c(H),expected=c(expected)))
Path('js-port/psd-fixtures.json').write_text(json.dumps(matrices,indent=2))
print('created',len(fixtures),'solver and',len(matrices),'PSD fixtures')
