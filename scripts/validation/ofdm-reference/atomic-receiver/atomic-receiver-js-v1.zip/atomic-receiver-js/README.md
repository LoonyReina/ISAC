# Genuine bounded CS-ANL1 numerical port

Numerical-only, no lesson UI. The unchanged Python reference is frozen one directory above. `core.js` solves the paper's finite two-level Toeplitz SDP (Eq27) with exact joint block minimization of Eq35, the documented conjugation/index/dual corrections, and a complex Hermitian PSD projection. It contains no frequency grid or simulation truth.

## Contract

`createSolver({M,N,r:{re,im},s:{re,im},lambda,mu}, settings)` accepts column-major complex observation/symbol vectors of length D=MN, positive integer dimensions with D≤16. No seed, target count, frequencies or truth are accepted. `step(count)` performs at most count genuine ADMM iterations. `snapshot(true)` adds row-major complex T/Theta/multiplier matrices. `cancel()` is terminal. The initial browser scope is 4×4; 8×8/16×16 are unsupported in this port, not silently replaced by a proxy.

Default settings: rho=.05, maxIter=30000, atol=1e−9, rtol=1e−8, recordEvery=50, eigMaxSweeps=80, fixedError=false. `fixedError=true` is CS-AN with e=0. Setting mu=0 with a free e is rejected. The eigensolver tolerance is fixed at 1e−12, not a user-adjustable approximation knob.

The PSD projection embeds the complex Hermitian matrix as a doubled real-symmetric matrix, uses cyclic Jacobi, clips negative eigenvalues, and reconstructs the Hermitian complex result. Convergence additionally requires the measured Jacobi off-diagonal residual ≤0.1 min(primal tolerance, dual tolerance/rho). An incomplete eigensolve throws. Nonfinite metrics and unresolvable numerical scales throw and leave a terminal `numerical_failure` status. Intermediate affine iterates can violate PSD; their objective trace is not a feasible-bound or monotone-descent claim.

`worker.js` imports the core and yields every four iterations:

- Initial `ready` reports the exact core VERSION string
- Solve message: `{type:'solve',requestId,expectedVersion,input,settings}`; request IDs must be fresh increasing nonnegative safe integers
- Replies: `started`, periodic `progress`, and `result` with full snapshot, or `error`
- Cancel message: `{type:'cancel',requestId}`; valid superseding solves cancel the prior request
- Cancellation takes effect at processed chunk boundaries; an already completed result can win a message race. No old final result is sent after that cancellation/supersession has been processed
- Invalid/version-mismatched requests leave a previously accepted solve intact; the future controller must still ignore results whose IDs do not match its current requested input

Pure numerical runtimes measure time since solver creation, including any manual pauses/Worker yields. They are not control-to-result desktop measurements. No browser was launched for this package; Worker checks use actual Node worker threads via the adapter.

## Reproduce

From the parent reference directory:

```sh
node js-port/run-inputs.cjs js-port/reference/reviewer-fresh-inputs.json js-port/results/reviewer-fresh-js.json
node js-port/run-inputs.cjs js-port/fixtures.json js-port/results/own-fresh-js.json
OPENBLAS_NUM_THREADS=1 .venv/bin/python js-port/validate-comparison.py
node js-port/test-core.cjs
node js-port/test-worker.cjs
```

The independent reviewer supplied the copied `reference/reviewer-fresh-*` observations and separately parameterized SDP outputs; these copies are unchanged. `create-fixtures.py` creates the additional close-path/dense-error cases and PSD fixtures with the frozen Python reference. Numerical thresholds precede verdicts in `validate-comparison.py`. No eigenvalue or phase outputs were imported into the JavaScript solver.

## Review discoveries retained

1. Pre-fix hash ad113658's predecessor accepted eigTol=1 and could call a poor PSD projection converged (analytic atom objective 4.7464 versus correct .369924). This control is now rejected, and projection accuracy is independently included in stopping
2. Pre-fix hash ad113658 accepted enormous finite data such as r=1e160 with fixedError=true and could compare Infinity≤Infinity. Finite-scale/metric guards now reject this numerical failure instead of reporting success

Final-hash independent review and exact hashes are recorded in the adjacent JS-PORT-FREEZE.json/JS-PORT-REPORT.md when finalized. Neither source solver agreement nor this port establishes an original-paper detector, full Figure8 BER sweep, unrestricted 2-D atomic-norm equivalence, desktop browser latency or lesson UI acceptance.
