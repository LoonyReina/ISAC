import json,hashlib,numpy as np
from pathlib import Path
base=Path(__file__).resolve().parent
unpack=lambda x:np.array(x['re'])+1j*np.array(x['im'])
ref=json.loads((base/'reference/reviewer-fresh-python-results.json').read_text())['results'];inp=json.loads((base/'reference/reviewer-fresh-inputs.json').read_text());js=json.loads((base/'results/reviewer-fresh-js.json').read_text())['results'];out=[]
for r,i,j in zip(ref,inp,js):
 j=j['result'];s=unpack(i['input']['s']);obs=unpack(i['input']['r']);row=dict(name=r['name'],javascript_status=j['status'],python_status=r['admm_status'],SCS_status=r['cvx_status'],same_iteration_count=j['iterations']==r['admm_iterations'],iterations=j['iterations'],JS_runtime_ms=j['runtimeMs'],objective_difference_JS_Python=abs(j['last']['objective']-r['admm_objective']),objective_difference_JS_SCS=abs(j['last']['objective']-r['cvx_objective']),z_relative_difference_JS_Python=float(np.linalg.norm(unpack(j['z'])-unpack(r['python']['z']))/max(1,np.linalg.norm(unpack(r['python']['z'])))),projection_accurate=j['last']['projectionAccurate'])
 row['passed']=row['javascript_status']=='converged' and row['same_iteration_count'] and row['objective_difference_JS_Python']<1e-9 and row['objective_difference_JS_SCS']<1e-5 and row['z_relative_difference_JS_Python']<1e-8 and row['projection_accurate'];out.append(row)
ref2=json.loads((base/'fixtures.json').read_text());js2=json.loads((base/'results/own-fresh-js.json').read_text())['results']
for r,j in zip(ref2,js2):
 j=j['result'];row=dict(name=r['name'],javascript_status=j['status'],python_status=r['python']['status'],SCS_status=r['cvx']['status'],same_iteration_count=j['iterations']==r['python']['iterations'],iterations=j['iterations'],JS_runtime_ms=j['runtimeMs'],objective_difference_JS_Python=abs(j['last']['objective']-r['python']['objective']),objective_difference_JS_SCS=abs(j['last']['objective']-r['cvx']['objective']),z_relative_difference_JS_Python=float(np.linalg.norm(unpack(j['z'])-unpack(r['python']['z']))/max(1,np.linalg.norm(unpack(r['python']['z'])))),projection_accurate=j['last']['projectionAccurate'])
 row['passed']=row['javascript_status']=='converged' and row['same_iteration_count'] and row['objective_difference_JS_Python']<1e-9 and row['objective_difference_JS_SCS']<1e-5 and row['z_relative_difference_JS_Python']<1e-8 and row['projection_accurate'];out.append(row)
report=dict(core_sha256=hashlib.sha256((base/'core.js').read_bytes()).hexdigest(),all_passed=all(r['passed'] for r in out),cases=len(out),checks=out,scope='kernel numerical parity; no original Figure8 detector or browser/desktop acceptance')
(base/'results/comparison.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2));assert report['all_passed']
