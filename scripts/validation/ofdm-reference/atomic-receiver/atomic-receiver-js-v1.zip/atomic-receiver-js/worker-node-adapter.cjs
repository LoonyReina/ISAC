// Test adapter only: actual worker.js runs unchanged on a real Node worker thread.
const {parentPort}=require('node:worker_threads');const fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');
global.self=globalThis;self.postMessage=x=>parentPort.postMessage(x);global.importScripts=(name)=>{if(name!=='core.js')throw Error('Unexpected script');self.AtomicReceiverCore=require('./core.js');};
vm.runInThisContext(fs.readFileSync(path.join(__dirname,'worker.js'),'utf8'),{filename:'worker.js'});
parentPort.on('message',x=>self.onmessage({data:x}));
