# Bounded receiver, Worker and evidence contract

## 1. Public kernel API

`createTemplateOperator(frame,x,model).apply(q,a)` returns the actual complex template; the operator owns copied frame/x and cannot be mutated through the supplied arrays. `literalEq14` and `exactRectFinite` are separately named convenience actions. `isfft` returns a unitary TF vector with time n fastest. `physicalCoordinates` and `frameLedger` expose units/conventions.

`evaluateCandidate(observation,q,a)` takes exactly `{frame,x,y,model,noiseVariance}` and returns actual s, fitted y, complex residual, template energy, inner product, gain, score, residual norm, likelihood and physical coordinates. No candidate is initialized from a truth object.

`createGridSearch(receiver)` owns a copied validated receiver and returns `step()`, `stop('cancelled'|'superseded')`, `result()`, and read-only status/copied receiver. `step()` executes at most the declared chunk. `solveSync(receiver)` runs it to a terminal method status.

Receiver fields, all required:

```json
{
  "frame":{"N":4,"M":8,"T":0.0000064,"fc":5890000000},
  "x":[{"re":1,"im":0}],
  "y":[{"re":0.7,"im":0.2}],
  "model":"eq14_literal",
  "noiseVariance":0.03,
  "bounds":[[0.05,3.8],[-1.4,1.4]],
  "gridShape":[65,65],
  "settings":{"maxEvaluations":16641,"maxElapsedMs":30000,"chunkCandidates":64}
}
```

The one-entry x/y above only illustrate scalar encoding: an actual N4M8 request requires exactly32 entries in each. Unknown keys anywhere in frame, vectors, receiver or settings are rejected. Field names T/fc correspond to teaching proposal T_s/fc_hz; an eventual adapter must map them explicitly, not silently change units.

## 2. Exact admitted implementation limits

| Item | Final implementation limit |
|---|---|
| Frame | Integer1≤N≤4,1≤M≤8, NM≤32 |
| Physical scales | 1e−9≤T≤1 second;1e6≤fc≤1e12 Hz |
| Candidate/domain | 0≤q<M, −N<a<N; each search interval strictly increasing |
| Raw complex components | |Re x|,|Im x|≤16; |Re y|,|Im y|≤64; finite numbers |
| Transmit energy | ||x||²≥1e−20 |
| Template cutoff | sᴴs≤1e−25 → uninformative-template, no fake gain/score/residual |
| Declared variance | 1e−8≤E|w|²≤1e4 |
| Grid |2…129 points per axis, endpoint inclusive,≤16,641 candidates |
| Evaluation budget |1…16,641; a lower budget yields a recorded finite prefix |
| Wall budget |1…30,000 ms, checked before each candidate; initialization/result serialization and one candidate can exceed it |
| Worker chunk |1…64 actual candidates; genuine macrotask yield after each chunk |
| Worker request identity | Unique1…80 safe characters, at most1000 requests per Worker session |
| Evidence bytes |16,777,216 UTF-8 bytes, identical writer/reader ceiling; minimal JSON output |

These are numerical/resource restrictions, not claims that other values are physically impossible. q/a model domain does not imply unique identification. All-zero y is allowed and yields score ties with an explicit zero-observation information status; it is not a target detection claim. N1M1 and other unidentifiable conditions do not receive a uniqueness certificate.

## 3. Search and status semantics

Grid axes use explicit `lo+i*((hi-lo)/(n-1))`, with the final value set to hi. No silent snapping to integer branches occurs; exported binary64 axis values are authoritative. Every exact integer q on the grid uses the printed ceiling branch. Traversal is q outer/a inner. Largest finite computed score wins; exact ties retain the first. Candidate energy/gain are recomputed for every point.

Method status is one of running, grid-exhausted, evaluation-cap, time-cap, cancelled, superseded, or no-informative-candidate. Every candidate is computed or uninformative-template. Counts, invalid count, actual prefix, selection and best inspection are retained. `globalOnDeclaredGrid` is true only after complete exhaustion with a computed candidate and no invalid candidates; `globalOnContinuum` is always false. Selected estimate is null with explicit failure/unavailable status when no finite candidate exists. EqualBestScoreCount counts exact numerical ties at the final best score; it is not a robust uniqueness test.

The score has normalized squared-observation units. `negativeLogLikelihoodUpToConstant=residual/v` and `logLikelihood=−D log(πv)−residual/v`. No factor-two ambiguity is carried from the printed source. Signal and residual components are complex; magnitude plots cannot be added to reconstruct the complex equation.

## 4. Worker protocol and current-result protection

Run message: `{type:'run',requestId,receiver}`. Cancel: `{type:'cancel',requestId}`. Responses are progress, terminal, protocol-error or cancel-ignored. Progress first confirms validation and then includes actual candidate batches, evaluation count and current best. Every accepted run gets exactly one terminal. A new valid-identity request supersedes the preceding job; even an invalid new receiver represents a newer request and prevents use of the old result as current.

Transport terminal `completed` means the computation returned; inspect `result.status` before calling the grid exhausted. Caps remain incomplete results. Cancellation and supersession have their own transport terminals, never completion badges. Cancellation is cooperative between bounded chunks; it does not erase already recorded candidates. A cancellation arriving after the final compute chunk but before result delivery still suppresses successful delivery; the prefix may happen to contain all candidates but its current-run acceptance is cancelled.

SHA-256 covers recursively sorted-key UTF-8 JSON of the validated receiver, without whitespace. Arrays retain order. Result acceptance requires both request ID and digest. `createResultGate().invalidate()` must be called immediately on input edits; `expect(id,digest)` registers the next submitted request. It only accepts matching completed transport responses, and does not relabel a capped algorithm as converged/exhausted. The caller must inspect the method status too.

No UI exists here; these helpers require independent UI wiring tests before integration. Repeated Run, stale-input behavior, Close/navigation, download and rendering are not claimed browser-verified.

## 5. Portable evidence and replay

`createEvidence(result,{generationModel,evaluation})` creates a complete or partial numerical record. Optional evaluation contains only trueDelayBin/trueDopplerBin/trueGain and never enters a solver call. Generation and fitted model are recorded separately. `serializeEvidence` emits minified JSON and actual UTF-8 byte length; output over16 MiB is rejected. `parseEvidence` checks the **same**16 MiB cap before JSON parsing, validates the structural limits and recomputes the receiver digest. It returns `unverified-import`, never a trusted answer.

`replayEvidence` reruns exactly the exported candidate prefix from raw x/y, declared axes/model and counts. It compares candidate scores/gains/likelihood/energy, selected inspection, axes and numerical counts at a declared tolerance. It deliberately disables timing-based stopping for the replayed prefix. Imported truth, selected estimate and candidate scores do not initialize the recomputation. No recomputation can authenticate source provenance, generation truth, time, historical cancel cause or user interaction. A full grid and a partial prefix are reported separately.

The serializer/parser operate on one run at a time. Combining arbitrary numbers of full histories into a single file is outside this schema; do not reuse its byte ceiling for an unbounded multi-run bundle. Retaining progress plus an identical terminal history duplicates memory: an eventual UI should append the real progress records and replace/reconcile them with the terminal array, not retain unlimited copies. Per-candidate complex templates are not retained for all candidates; the selected inspection is retained and other manual candidates are genuinely recomputed on demand.

See `results/evidence-size-memory.json` for maximum measured complete UTF-8 size across six max-grid cases and fresh-process Node parsing/replay memory/time. The16 MiB ceiling is the enforced universal transport limit; the largest measured record is not presented as a universal maximum. Any browser importer must use the shared byte constant and logical limits or require a separate acceptance test. Browser heap/click-to-result/download costs remain unmeasured.

## 6. Teaching contract mapping and gates

The sibling `otfs-effectiveness-teaching/INTERFACE-DATA-CONTRACT.md` is a design proposal. This branch concretely supports known/unknown receiver ledgers, actual x→unitary ISFFT inspection, actual complex observation/candidate fitting, exact finite-grid scores and recorded progress, and evaluation-only truth separation. It does not expose generation truth to search, a generic FFT radar map, or fictitious iterates.

The plan's continuous-search stage must show unavailable/disabled for this gate. No continuum optimizer has been substituted for source-style grid enumeration, and no continuous refinement is implied by fractional candidate q/a. Local CRB is unavailable at every point in this branch, including delay boundaries and singular states; adding it requires separate model-specific derivative/FIM validation. Batch RMSE, automatic model-comparison interpretation, radar/communication observation sharing, full-size source radar figures and OFDM/FMCW comparisons are not implemented.

No website, repository or publication changes are authorized by this numerical result. Browser tests and a teaching/UI review remain required before any live acceptance claim.
