# Isolated OTFS single-path sensing grid port

Fixed source: Gaudio et al., [arXiv:1910.01896v1](https://arxiv.org/pdf/1910.01896v1), 2019-10-04. Frozen accepted Python core SHA-256: `92b997201493a3187b5ddb37026672ef44e163131e422bdf8618f11b17aa235f`.

This is an independently implemented, bounded JavaScript numerical/Node Worker prototype. It is **not a UI, deployed site, original-figure reproduction, continuous optimizer, or browser-performance approval**. No repository integration/publication/browser use occurred. No source PDF or extracted copyrighted source text is bundled.

## What actually runs

- `literalEq14` / model `eq14_literal`: exact finite exponential sums, printed ceiling/ICI/ISI branches and effective-gain phase. The implementation uses an exactly equivalent separable algebraic action, not an FFT proxy. Its explicit sampled convention is cyclic prehistory, right-endpoint quadrature, negative carriers, one-sample shifted DD origins, and the audit's gain phase
- `exactRectFinite` / model `exact_rect_finite`: positive-frequency, unit-energy rectangular pulse synthesis/projection, finite zero-extended transmitted frame and receive window `[0,NT)`. It computes the analytic overlap integral and the unitary `Uᴴ H_TF U` action. Precomputed `Ux` is reused; candidate-dependent template energy is recomputed
- P=1 unknown complex effective gain h′ is profiled for every candidate: ĥ′=(sᴴy)/(sᴴs), score=|sᴴy|²/(sᴴs), residual=||y−ĥ′s||²
- Exhaustive, endpoint-inclusive **declared finite grid**. The paper's numeric fine-grid Γ is unspecified. Every candidate is actually evaluated, in q-outer/a-inner order; exact score ties keep the first. Exhaustion certifies only the implemented declared grid, subject to no uninformative candidates, never the continuum or unique identification
- Real candidate scores, gains, template energies, residuals and proper-complex likelihood values are recorded. Candidate inspection returns s, fitted y and the complex residual. Progress consists of actual newly evaluated candidate records
- Actual Node Worker cancellation, supersession and current-input ID/digest gate, evaluation/time caps, unavailable/invalid outcomes and bounded evidence serialization/replay

Continuous refinement and FIM/local CRB are explicitly **unavailable** in every output. There are no fabricated optimizer iterates, probability movies, derivative curves or CRB values.

## Receiver information boundary

Only frame `{N,M,T,fc}`, known complex x, actual complex y, explicitly named fitted model, positive proper-complex noise variance, search bounds, grid shape and budget enter a search. Simulation truth, seeds, noiseless samples and oracle answers are rejected as unknown fields. Bounds must be supplied independently of truth; the implementation has no generator and cannot tighten them around truth. Tests and examples keep evaluation-only truth outside the receiver.

Changing fitted model or budgets can reuse byte-identical x/y. That does not establish equality of the two models' physical conventions or authorize relabelling one the corrected other. The noise variance scales likelihood reporting only; it does not alter the profiled gain/score or search selection.

## Coordinates and units

Vectors contain `{re,im}` pairs in `d=k+N*l` order. k is DD Doppler-basis index, l DD delay-basis index. q and a are continuous channel parameters, not basis indices. `T` is seconds, `fc` is Hz; Δf=1/T, B=M/T, useful duration NT, q=τB, a=νNT. Monostatic R=cτ/2 and v=cν/(2fc), c=299792458 m/s, positive Doppler gives positive reported velocity. All operators multiply h′=h exp(j2πντ). Normalized frame energy is ||x||², not calibrated joules. Noise v=E|w|²; each I/Q variance is v/2, log likelihood = −D log(πv)−residual/v.

The literal operator jumps at ceiling-cell boundaries. The exact finite operator is continuous there. No interpolation/smoothing across literal jumps is performed. Finite-window template energy need not equal ||x||²; no hidden renormalization removes that loss.

## Bounded numerical contract

See `CONTRACT.md` for the exact API, bounds, status meanings, current-result gate, byte limits and teaching-stage mapping. Recommended profiling configuration: N=4, M=8, bounds q∈[.05,3.8], a∈[−1.4,1.4], declared65×65 grid (4225 candidates), chunk64. This is an implementation example, not an original paper grid or a browser-certified default.

Admitted maximum: N≤4, M≤8, D≤32, each grid axis≤129 and total≤16,641. Full candidate history is retained. The rejected exploratory257×257 study is clearly labelled pre-cap evidence: it produced about27.7 MB terminal JSON and took several seconds; it is not available through the final validator.

## Run and inspect

No npm dependencies. Tested with Node24.19.0, Python3.12/NumPy2.3.5/SciPy1.17.0.

```sh
npm run fixtures
npm test
npm run profile
npm run profile:evidence
```

- `src/operators.mjs`: standalone named operator actions, unitary ISFFT and physical conversions
- `src/kernel.mjs`: manual candidate inspector, profile complex gain, incremental grid search and synchronous solve
- `src/node-worker.mjs`, `src/browser-worker.mjs`: endpoints using the identical shared protocol. The browser endpoint is provided but **has not been exercised in a browser**
- `src/evidence.mjs`: UTF-8-bounded serializer/parser and exact-prefix numerical replay. Imported results are historical unverified claims until replay; replay does not authenticate generation truth, timestamps, timing or cancellation history
- `fixtures/oracles.json`:196 frozen/fresh operator and basis cases plus12 entire grids, with raw inputs
- `tests/make_oracles.py`: independently authored scalar formula and direct Gauss–Legendre waveform checks against frozen dense Python
- `results/`: actual author tests, Node runtime records, complete histories, evidence byte/memory measurements and exploratory rejected-cap evidence
- `review/`: separate reviewer scripts, fresh oracles and findings when available
- `FREEZE.json`: final gate status and hash manifest when review completes

Author test precision uses `abs(error) <= 2e-10*(1+abs(expected))`. A near-vanishing finite template can produce a large fitted gain; the report gives both absolute and scaled error instead of hiding that conditioning. Template energy≤1e−25 is explicitly unavailable. Transmit energy<1e−20 is rejected.

## Remaining gates

Browser control-to-visible-result latency, browser memory, accessibility/narrow layout, UI freshness wiring, actual downloaded-file recovery/replay, model-comparison pedagogy, continuous per-cell refinement, model-specific derivatives/FIM, repeated-estimation statistics, full-size paper experiments, OFDM/FMCW comparisons, multipath sensing, and publication remain open. Node timings do not close these gates.
