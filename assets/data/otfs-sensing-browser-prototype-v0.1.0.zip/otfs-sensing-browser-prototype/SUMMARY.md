# Bounded sensing port result

The isolated P=1 JavaScript source-grid sensing branch implements **both named operators**, actual unknown-complex-gain profile likelihood, and exhaustive endpoint-inclusive declared-grid search. It does not implement continuous refinement or FIM/CRB. Browser/UI/repository/publication work is absent.

## Evidence

- Author checks:196 operator/basis/profile cases,12 full grids, strict raw-input boundaries and actual Node Worker lifecycle tests
- Independent review:586 new operator/basis/phase/scaling cases,12 new grids,8 direct profiles,35,432 independently replayed candidate records and398,571 numeric comparisons, including both16,641-candidate maximum exports
- Independent actual Worker tests: real candidate progress, immediate/mid-run cancellation,30-request supersession burst, caps/failures,1,000-request session limit, exactly one terminal, current request-ID/digest gate
- Independent Python dense Eq14 and continuous-waveform quadrature/FFT oracles; no import of author Python reference/oracle arrays into the fresh oracle
- Cross-port interoperability:72 complex-gain/boundary/random cases against independently accepted communication kernel SHA`80fad52c681d19eaa5d82a6b1d20dd329a6cf40d39c08cd92774f88118d8f1e7`; maximum component difference4.44e−16
- Independent evidence replay checks all candidate scores/gains/likelihoods and selected template/fitted/residual/units; a recomputed input digest cannot excuse more candidates than the declared evaluation budget

See `review/JUDGEMENT.md` and `FREEZE.json` for final exact hashes/status. No private source PDF/text is included.

## Measured numerical/Node domain

Admitted frame:1≤N≤4,1≤M≤8,D≤32. Recommended N4M8 grid65×65; hard cap129×129=16,641 candidates. Bounds are explicit receiver inputs within0≤q<M and|a|<N, never set from truth. Raw x/y are authoritative and truth fields are rejected.

Three fresh-Worker repetitions per model/grid on Node24.19.0, AMD EPYC9V74 shared environment:

| Grid | Literal median / worst roundtrip | Finite median / worst roundtrip |
|---|---:|---:|
|65×65,4225 candidates|279 /280 ms|312 /336 ms|
|129×129,16,641 candidates|893 /893 ms|1037 /1134 ms|

The exploratory257² grid was rejected from the final domain after measured multi-second runs and~27.7 MB terminal records. All timings include the stated Node Worker/transport boundary, not browser rendering or control-to-result latency.

## Full-history export cost

The largest of six measured maximum-grid complete evidence records is **7,142,969 UTF-8 bytes**. Serializer and parser share one enforced **16,777,216-byte** limit. In fresh Node processes, parsing took~103–105 ms, prefix replay~541–700 ms, and observed process high-water RSS~168–169 MB. These are measurements, not universal memory bounds; browser memory/recovery remains untested.

Imports are unverified historical claims until numerical replay. Replay authenticates neither source provenance, generation truth, time nor cancellation history. Partial prefixes remain partial, and a full declared-grid maximum is never a continuum optimum or uniqueness/target-detection proof.

## Important semantics

Both operators preserve their distinct audited conventions and effective h′ phase. Finite-window attenuation remains in the data/template energy. The literal ceiling discontinuity is genuine. All-zero y gives recorded ties; zero/near-zero template energy gives typed unavailability. Candidates, progress and selected inspections are actually computed. No synthetic history, hidden truth initialization, FFT peak proxy, or fabricated CRB is present.

Browser endpoint code exists but has not run in a browser. UI integration, downloaded-file recovery, teaching acceptance, browser latency/memory, continuous refinement, model-specific FIM, multipath sensing, repeated-estimation statistics, full paper figures and radar comparators remain open.
