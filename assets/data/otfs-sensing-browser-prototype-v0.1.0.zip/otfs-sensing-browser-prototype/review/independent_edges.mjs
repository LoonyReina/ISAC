import fs from 'node:fs';import assert from 'node:assert/strict';
import {validateReceiver,solveSync,evaluateCandidate,profileComplexGain,LIMITS} from '../src/kernel.mjs';
const fresh=JSON.parse(fs.readFileSync(new URL('./fresh-inputs.json',import.meta.url))),base=fresh.grids.find(x=>x.id==='grid_exact_rect_finite_4_8').receiver;
const tests=[];
for(const mutate of [r=>delete r.x[0],r=>delete r.y[8],r=>delete r.bounds[0],r=>delete r.bounds[1][1],r=>delete r.gridShape[0]]){const r=structuredClone(base);mutate(r);assert.throws(()=>validateReceiver(r),e=>e.code==='invalid-input');}
tests.push('Sparse x/y, outer/inner bounds and grid shape all rejected');
for(const mutate of [r=>r.gridShape=[130,129],r=>r.settings.maxEvaluations=16642,r=>r.frame.N=5,r=>r.frame.M=9,r=>r.x[0].im=Infinity,r=>r.y[0].re=NaN,r=>r.noiseVariance=0]){const r=structuredClone(base);mutate(r);assert.throws(()=>validateReceiver(r),e=>e.code==='invalid-input');}
tests.push('Final129-axis16641-evaluation and dimension/finite/variance caps enforced');
for(const model of ['eq14_literal','exact_rect_finite']){
 const a=solveSync({...base,model,noiseVariance:1e-8});const b=solveSync({...base,model,noiseVariance:1e4});assert.equal(a.selected.index,b.selected.index);
 for(let i=0;i<a.candidates.length;i++){assert.deepEqual(a.candidates[i].gain,b.candidates[i].gain);assert.equal(a.candidates[i].score,b.candidates[i].score);assert.equal(a.candidates[i].residual,b.candidates[i].residual);assert(Math.abs(a.candidates[i].negativeLogLikelihoodUpToConstant/b.candidates[i].negativeLogLikelihoodUpToConstant/1e12-1)<1e-15);}
}
tests.push('Noise variance alone leaves every gain/score/residual and selected point unchanged; likelihood scaling is correct');
const threshold=Math.sqrt(LIMITS.minTemplateEnergy);
const below=profileComplexGain([{re:threshold*(1-1e-12),im:0}],[{re:1,im:1}],.7),above=profileComplexGain([{re:threshold*(1+1e-12),im:0}],[{re:1,im:1}],.7);
assert.equal(below.status,'uninformative-template');assert.equal(above.status,'computed');assert(Number.isFinite(above.gain.re));assert.equal(profileComplexGain([{re:0,im:0}],[{re:0,im:0}],.7).status,'uninformative-template');
tests.push('Actual template-energy cutoff crossed on either side; zero template stays uninformative');
const report={status:'passed',tests};fs.writeFileSync(new URL('./independent-edge-results.json',import.meta.url),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report,null,2));
