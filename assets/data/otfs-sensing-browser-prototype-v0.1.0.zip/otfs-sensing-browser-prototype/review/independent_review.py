"""Fresh reviewer-owned formula/waveform oracles. Imports no author reference/tests.
Run: OPENBLAS_NUM_THREADS=1 python review/independent_review.py
"""
import json, math, hashlib, subprocess
from pathlib import Path
import numpy as np
from numpy.polynomial.legendre import leggauss
ROOT=Path(__file__).resolve().parents[1]; OUT=ROOT/'review'
rng=np.random.default_rng(867530991)
quad_nodes,quad_weights=leggauss(48)
checks=0; maxima={}; failures=[]
def pair(z): return {'re':float(np.real(z)), 'im':float(np.imag(z))}
def pairs(z): return [pair(v) for v in np.ravel(z)]
def unpair(z): return np.array([v['re']+1j*v['im'] for v in z])
def energy(z): return float(np.vdot(z,z).real)
def tf(x,N,M): return np.fft.fft(np.fft.ifft(x.reshape((N,M),order='F'),axis=0,norm='ortho'),axis=1,norm='ortho')
def dd(X): return np.fft.ifft(np.fft.fft(X,axis=0,norm='ortho'),axis=1,norm='ortho').ravel(order='F')
def literal(x,N,M,q,a):
    # One direct four-index kernel, summing both printed finite exponent sums
    # together, rather than porting the factorized application.
    k=np.tile(np.arange(N),M); l=np.repeat(np.arange(M),N)
    n=np.arange(N)[None,None,:,None]; m=np.arange(M)[None,None,None,:]
    phase=(k[None,:,None,None]-k[:,None,None,None]+a)*n/N
    phase=phase+(l[None,:,None,None]-l[:,None,None,None]+q)*m/M
    phase=phase+a*l[None,:,None,None]/(N*M)
    phase=phase-(l[None,:,None,None]>=M-math.ceil(q))*(k[None,:,None,None]+a)/N
    H=np.exp(2j*np.pi*phase).sum(axis=(2,3))/(N*M)
    return H@x

def finite(x,N,M,q,a):
    # Continuous transmitted waveform projected onto rectangular receive atoms.
    # Dimensionless u=t/T; integrate only actual finite-frame transmitted atoms.
    X=tf(x,N,M); Y=np.zeros_like(X); delay=q/M; doppler=a/N
    for n in range(N):
        for np_ in range(N):
            lo=max(float(n),np_+delay); hi=min(float(n+1),np_+1+delay)
            if hi<=lo: continue
            t=(lo+hi)/2+(hi-lo)/2*quad_nodes
            wave=X[np_]@np.exp(2j*np.pi*np.arange(M)[:,None]*(t-np_-delay))
            physical=wave*np.exp(2j*np.pi*doppler*t)
            projected=np.exp(-2j*np.pi*np.arange(M)[:,None]*(t-n))@(quad_weights*physical)*(hi-lo)/2
            Y[n]+=projected
    return dd(Y)*np.exp(-2j*np.pi*doppler*delay)

def template(obs,q,a):
    f=obs['frame']; return (literal if obs['model']=='eq14_literal' else finite)(unpair(obs['x']),f['N'],f['M'],q,a)
def profile(s,y,v):
    den=energy(s)
    if den<=1e-25: return {'status':'uninformative-template','templateEnergy':den}
    h=np.linalg.lstsq(s[:,None],y,rcond=None)[0][0]
    fitted=h*s; res=y-fitted; rss=energy(res); inner=np.vdot(s,y)
    return {'status':'computed','templateEnergy':den,'innerProduct':pair(inner),'gain':pair(h),'score':float(abs(inner)**2/den),'residual':rss,'negativeLogLikelihoodUpToConstant':rss/v,'logLikelihood':-len(y)*math.log(math.pi*v)-rss/v,'template':pairs(s),'fitted':pairs(fitted),'residualVector':pairs(res)}
def near(got,expected,label,rtol=2e-10,atol=1e-10):
    global checks
    checks+=1
    if not math.isfinite(float(got)): raise AssertionError((label,'nonfinite',got))
    err=abs(got-expected); scaled=err/(atol+rtol*abs(expected))
    maxima[label]=max(maxima.get(label,0),err)
    if scaled>1: raise AssertionError((label,got,expected,err,scaled))
def compare(got,expected,label):
    if isinstance(expected,dict):
        for k,v in expected.items(): compare(got[k],v,label+'.'+k)
    elif isinstance(expected,list):
        assert len(got)==len(expected),(label,'length')
        for a,b in zip(got,expected):compare(a,b,label)
    elif isinstance(expected,str): assert got==expected,(label,got,expected)
    else: near(got,expected,label)
def makeobs(N,M,model,x=None,y=None):
    D=N*M
    return {'frame':{'N':N,'M':M,'T':7.3e-6,'fc':24.125e9},'x':pairs(x if x is not None else rng.normal(size=D)+1j*rng.normal(size=D)), 'y':pairs(y if y is not None else rng.normal(size=D)+1j*rng.normal(size=D)), 'model':model,'noiseVariance':0.37}
def receiver(obs,bounds,shape): return {**obs,'bounds':bounds,'gridShape':shape,'settings':{'maxEvaluations':16641,'maxElapsedMs':30000,'chunkCandidates':17}}
operators=[]; grids=[]; profiles=[]
for N,M in [(1,1),(1,8),(2,3),(3,4),(4,8)]:
    qs=[0,np.nextafter(0.,1.),M*.237,M-.13,np.nextafter(float(M),0.)]
    if M>1:qs += [np.nextafter(1.,0.),1.,np.nextafter(1.,2.),1.-1e-8,1.+1e-8]
    aa=[-.731*N,0,.419*N,np.nextafter(float(N),0.),np.nextafter(-float(N),0.)]
    for model in ['eq14_literal','exact_rect_finite']:
        obs=makeobs(N,M,model)
        for q in qs:
            for a in aa: operators.append({'id':f'{model}_{N}_{M}_{len(operators)}','observation':obs,'q':float(q),'a':float(a)})
        for basis in range(N*M):
            x=np.zeros(N*M,complex); x[basis]=1
            operators.append({'id':f'basis_{model}_{N}_{M}_{basis}','observation':makeobs(N,M,model,x=x),'q':.315*M,'a':-.419*N})
        grids.append({'id':f'grid_{model}_{N}_{M}','receiver':receiver(obs,[[0,M-.1],[-N+.13,N-.17]],[7,9])})
        # Unknown physical h becomes hprime through exp(+j2pi nu tau)
        obsphase=makeobs(N,M,model); q=.427*M;a=-.537*N
        s=template(obsphase,q,a);hphysical=.19-.73j;hp=hphysical*np.exp(2j*np.pi*(a/N)*(q/M))
        obsphase['y']=pairs(hp*s)
        operators.append({'id':f'gainphase_{model}_{N}_{M}','observation':obsphase,'q':q,'a':a,'expectedHprime':pair(hp)})
# Known-x amplitude and receive complex phase scaling, very low x and bounded maxima.
for model in ['eq14_literal','exact_rect_finite']:
    base=makeobs(4,8,model)
    for sx,sy,v in [(1e-10,1,.37),(3,2,1e-8),(.13,1j,1e4)]:
        o={**base,'x':pairs(unpair(base['x'])*sx),'y':pairs(unpair(base['y'])*sy),'noiseVariance':v}
        operators.append({'id':f'scale_{model}_{sx}_{sy}','observation':o,'q':2.718,'a':-.827})
    o=makeobs(4,8,model,x=np.full(32,16+16j),y=np.full(32,64-64j));o['noiseVariance']=1e-8
    o['frame']['T']=1e-9;o['frame']['fc']=1e12
    operators.append({'id':f'limits_{model}','observation':o,'q':7.91,'a':3.87})
# Explicit zero observation ties and uninformative grid with changing attenuation.
z=makeobs(2,3,'eq14_literal',y=np.zeros(6));grids.append({'id':'zero-y-ties','receiver':receiver(z,[[0,2.8],[-1.9,1.8]],[5,7])})
tiny=makeobs(1,1,'exact_rect_finite',x=np.array([1.1e-10]),y=np.array([1+.2j]));grids.append({'id':'all-uninformative','receiver':receiver(tiny,[[.999,.9999],[-.7,.7]],[5,7])})
for norm in [0,1e-14,1e-13,math.sqrt(1e-25)*.999,math.sqrt(1e-25)*1.001,1e-10,1,1e4]:
    profiles.append({'id':f'profile-{norm}','s':pairs(np.array([norm+0j,-norm*.37j])),'y':pairs(np.array([31-29j,17+23j])),'v':1e-8})
fresh={'schema':'reviewer-fresh-input-v1','seed':867530991,'operators':operators,'grids':grids,'profiles':profiles}
(OUT/'fresh-inputs.json').write_text(json.dumps(fresh,allow_nan=False))
subprocess.run(['node',str(OUT/'node_evaluate.mjs'),str(OUT/'fresh-inputs.json'),str(OUT/'fresh-js-results.json')],check=True,cwd=ROOT)
actual=json.loads((OUT/'fresh-js-results.json').read_text())
# Cases validate tiny templates relatively separately: generic diagnostics use guarded absolute tolerance.
for c,res in zip(operators,actual['operators']):
    o=c['observation'];s=template(o,c['q'],c['a']); y=unpair(o['y']); out=res['result'];exp=profile(s,y,o['noiseVariance'])
    try:
        compare(out,exp,'operator')
        compare(res['isfft'],pairs(tf(unpair(o['x']),o['frame']['N'],o['frame']['M']).ravel(order='F')),'isfft')
        if out['status']=='computed':
            serr=np.linalg.norm(unpair(out['template'])-s)
            near(serr,0,'operator_relative_vector_error',rtol=0,atol=2e-11*max(np.linalg.norm(s),1e-30))
        if 'expectedHprime' in c:compare(out['gain'],c['expectedHprime'],'physical_gain_phase')
        f=o['frame'];delay=c['q']*f['T']/f['M'];freq=c['a']/(f['N']*f['T'])
        compare(out['physical'],{'delayS':delay,'dopplerHz':freq,'monostaticRangeM':299792458*delay/2,'monostaticVelocityMps':299792458*freq/(2*f['fc'])},'physical')
        if o['model']=='eq14_literal':near(out['templateEnergy'],energy(unpair(o['x'])),'unitary_energy')
        else:assert out['templateEnergy']<=energy(unpair(o['x']))*(1+1e-11)
    except Exception as e: failures.append({'id':c['id'],'error':repr(e)})

def replay_grid(rec,label):
    o=rec['receiver']; out=rec['result']; qaxis=out['grid']['qAxis'];aaxis=out['grid']['aAxis']
    assert qaxis[0]==o['bounds'][0][0] and qaxis[-1]==o['bounds'][0][1]
    assert aaxis[0]==o['bounds'][1][0] and aaxis[-1]==o['bounds'][1][1]
    assert len(out['candidates'])==len(qaxis)*len(aaxis)
    scores=[];valid=[]
    for idx,c in enumerate(out['candidates']):
        qi,ai=divmod(idx,len(aaxis));q=qaxis[qi];a=aaxis[ai]
        assert c['index']==idx and c['qIndex']==qi and c['aIndex']==ai and c['delayBin']==q and c['dopplerBin']==a
        s=template(o,q,a);p=profile(s,unpair(o['y']),o['noiseVariance'])
        for key in ['template','fitted','residualVector']:p.pop(key,None)
        compare(c,p,label+'.candidate');scores.append(p.get('score',None));valid.append(p['status']=='computed')
    good=[i for i,v in enumerate(valid) if v]
    assert out['globalOnContinuum'] is False and out['continuousRefinement']['status']=='unavailable' and out['localCRB']['status']=='unavailable'
    assert out['invalidCandidates']==len(valid)-len(good)
    if not good:
        assert out['selected'] is None and out['status']=='no-informative-candidate' and out['globalOnDeclaredGrid'] is False
    else:
        # Numerical near-ties are not made into a false exact argmax assertion.
        imax=max(good,key=lambda i:scores[i]);selected=out['selected']['index']
        near(scores[selected],scores[imax],label+'.selected_max_score')
        compare(out['selected']['inspection'],profile(template(o,out['selected']['delayBin'],out['selected']['dopplerBin']),unpair(o['y']),o['noiseVariance']),label+'.inspection')
        assert out['status']=='grid-exhausted' and out['partial'] is False
        if len(good)==len(valid):assert out['globalOnDeclaredGrid'] is True
    if label=='zero-y-ties':assert out['selected']['index']==0 and out['equalBestScoreCount']==len(valid)
    return {'label':label,'candidates':len(valid),'invalid':len(valid)-len(good),'selected':None if not good else out['selected']['index']}
grid_reports=[]
for c,res in zip(grids,actual['grids']):
    try:grid_reports.append(replay_grid({'receiver':c['receiver'],'result':res['result']},c['id']))
    except Exception as e:failures.append({'id':c['id'],'error':repr(e)})
for c,res in zip(profiles,actual['profiles']):
    try: compare(res['result'],profile(unpair(c['s']),unpair(c['y']),c['v']),'direct_profile')
    except Exception as e:failures.append({'id':c['id'],'error':repr(e)})
export_reports=[]
for path in sorted((ROOT/'results').glob('worker-export-*.json')):
    rec=json.loads(path.read_text())
    try:
        report=replay_grid(rec,path.name)
        assert rec['receiver']==rec['result']['receiver']
        report['sha256']=hashlib.sha256(path.read_bytes()).hexdigest();export_reports.append(report)
    except Exception as e:failures.append({'id':path.name,'error':repr(e)})
report={'status':'passed' if not failures else 'hold','operatorCases':len(operators),'gridCases':len(grids),'profileCases':len(profiles),'numericalChecks':checks,'failures':failures,'maxAbsoluteErrors':maxima,'gridReports':grid_reports,'exportReports':export_reports,'independentMethods':['Dense Eq14 direct double exponential sum','48-node Gaussian quadrature of continuous finite physical waveform; independent FFT transforms','numpy.linalg.lstsq complex gain','All candidate and selected-inspection replay from raw arrays'],'sourceHashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((ROOT/'src').glob('*.mjs'))}}
(OUT/'independent-numerical-results.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ['maxAbsoluteErrors','gridReports','sourceHashes']},indent=2))
