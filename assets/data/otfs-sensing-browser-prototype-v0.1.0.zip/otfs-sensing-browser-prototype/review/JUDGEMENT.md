# Independent sensing-port judgement

2026-10-12. **PASS for the isolated, bounded P=1 JavaScript numerical core, actual Node Worker protocol, and numerical evidence replay. HOLD for browser/UI/live-release claims.** No blocking defect remains within the reviewed numerical/Node scope. No browser, repository integration, cloud task, publication, or deployment was used in this review.

## Exact reviewed code

The accepted Python reference remains SHA-256 `92b997201493a3187b5ddb37026672ef44e163131e422bdf8618f11b17aa235f`.

The exact seven-module source set is listed in `SOURCE-SHA256SUMS.txt`. SHA-256 of that file's UTF-8 bytes is:

`479454a109641429c1a62bf2cb5308e4b3dfc85ad198b6e8db564bce31c48d63`

Individual critical hashes:

- `src/operators.mjs`: `1092109d0e5f28cfa5dbf0fca78f4474b72a19e80b98bac29b0151581f06ff19`
- `src/kernel.mjs`: `dfb81ee33bb55f8f11cbfec234a058e9711ac8ce226f756b4d96cd6b435e880e`
- `src/validation.mjs`: `752935c5e77d4d898c51ce5105453c2d3b80742735642a5adb46ae51102e729b`
- `src/protocol.mjs`: `02d335ff4c9659645631e22d27f5d178735056dd5653c0c9299020c8c63c3e67`
- `src/evidence.mjs`: `565a546db239af2fe2a077b54b068a980444c49e6610ad424738c3bfff1a76a6`

The final source set includes the tightened 129-by-129 grid cap, sparse-array rejection, and the evidence count-versus-original-budget invariant. All final author suites and reviewer suites were rerun against this set. Mathematical modules did not change during review; maximum saved exports were independently replayed against their raw inputs and again through the final JavaScript source.

## Independent evidence

The reviewer did not import the accepted Python reference, author fixture generator, or author oracle arrays into the independent numerical oracle. `independent_review.py` constructs a direct dense four-index Eq.14 kernel with a joint double exponential sum. Its finite-model oracle separately synthesizes the continuous physical waveform, integrates rectangular receive projections using 48-point Gauss–Legendre quadrature, and transforms with independent NumPy FFT calls. Complex gain is checked with `numpy.linalg.lstsq`, including the physical h-to-h′ phase.

Passed coverage:

- 586 newly constructed raw-input operator/basis/complex-phase/scaling cases across N1M1, N1M8, N2M3, N3M4 and N4M8; arbitrary x and y, not solely channel-generated observations
- Exact/fractional delays, zero, next-representable endpoints, integer ceiling boundaries on both sides, signed Doppler approaching validity endpoints, individual vector-order basis probes, maximum admitted component magnitudes, tiny transmit signals, and extreme admitted physical scales
- 12 independent complete grids and 8 direct profile cases; explicit endpoint inclusion, candidate order, all computed scores/gains/residuals/likelihoods, selected profile inspection, zero-y exact ties, zero/near-zero-template information, no fabricated gain, and no uniqueness/continuum certificate
- Every candidate in both `results/worker-export-*.json` records (725 each), checked with the independent Python oracles
- Every candidate in both maximum-cap evidence records (16,641 each), also checked with the independent Python oracles; 35,432 grid candidate records checked overall and 398,571 numerical comparisons including operator/profile tests
- Actual Node Worker execution on independent inputs: exact progress-prefix reconciliation, immediate/mid-run cancellation, a 30-request supersession burst, evaluation/time caps, no-informative-candidate outcomes, truth-field rejection, duplicate IDs, late cancellation, recovery, exactly one terminal per accepted request, current request-ID plus digest gate, and the 1,000-request session ceiling
- Evidence round trips and prefix replays at zero/one/partial/full counts; mutation detection for candidate scores, coordinates, selected template/fitted signal/complex gain/physical units, axes and numerical counts; raw-input digest mismatch, invalid continuum/grid claims, nonfinite/unsafe/deep/oversize data, and ASCII/multibyte UTF-8 byte limits
- Independent Python digest encoding agrees with all eight checked exported receiver digests
- Final sparse x/y, outer/inner bounds, and grid-shape rejection; final dimension/candidate limits; variance-only changes leave every fit/score/residual and selected candidate unchanged while likelihood scales correctly
- Final `npm test` passes; its run log is `final-author-suites.log`. Reviewer checks remain separate and do not rely solely on those tests

Independent numeric tolerance is `1e-10 + 2e-10*abs(expected)` for scalar diagnostics. Computed template vectors also have a separate relative norm check at 2e-11, including tiny x. The mixed absolute tolerance accommodates cancellation in near-zero matched products at the largest admitted amplitudes. Large absolute errors in extremely large fitted gains or likelihoods must be interpreted with their scale; they are not suppressed. Largest checked template-component difference was below 5e-13, and synthetic h-to-h′ phase checks differed by less than 2.5e-15.

## Resolved pre-freeze issue

A claimed replay prefix could previously exceed the receiver’s declared hard evaluation budget if an edited input digest was recomputed. The author added a deterministic structural check, and the reviewer independently confirmed that both serializer and parser now reject this contradiction even with a matching digest. This does not authenticate historical timing or cancellation, but it prevents an impossible numerical count from being accepted. No mathematical operator change was needed.

## Material conditions and open gates

1. **Model scope remains distinct.** Literal Eq.14 is the fixed audit's sampled cyclic/right-endpoint/negative-carrier/shifted-DD convention. The exact rectangular operator uses the finite zero-extended frame and positive-carrier continuous waveform. One is not silently identified with the other; finite-window attenuation is retained. Literal integer-delay jumps are preserved, while the finite waveform is continuous.
2. **Only the declared binary64 finite grid is exhausted.** Source numeric Γ is unspecified. Endpoint-inclusive axes and strict exact-tie-first ordering are explicit implementation choices. Exhaustion is a floating-point finite-grid result, not a continuum optimum, proof of unique identification, or target detection. Continuous refinement and local FIM/CRB remain typed unavailable everywhere.
3. **Low-information behavior is intentional.** Transmit energy below 1e-20 is rejected; template energy at or below 1e-25 is unavailable. Zero y produces exact ties. Near-zero admitted templates can have very large profiled gains. There is no automatic claim that the whole normalized model domain is unambiguous.
4. **Resource bounds are implementation bounds.** Final N≤4, M≤8, D≤32, axes≤129, candidates≤16,641, chunk≤64. The 257² study is exploratory pre-cap evidence and is rejected by the final validator. Time/cancellation checks are cooperative; result construction/transport and a candidate can overrun the algorithm wall budget. Completed transport may contain a capped/partial method result; callers must inspect method status.
5. **Evidence size is bounded; portable memory is not proved.** The shared writer/reader limit is 16,777,216 UTF-8 bytes. The largest of six measured maximum-grid complete records is 7,142,969 bytes, not a universal size maximum. Fresh-process Node evidence profiling observed roughly 168–169 MB high-water RSS. Those are environment measurements, not browser or portable heap guarantees. Retaining duplicate progress/terminal histories adds memory. An eventual browser importer must enforce file/byte limits before large allocations and needs its own memory and responsiveness tests.
6. **Replay has a narrow verified scope.** It recomputes numerical candidate prefixes, selection/inspection, axes and counts. It does not authenticate source provenance, generation truth, elapsed time, cancellation history, or other unverified metadata. Imported records remain historical claims outside the verified fields. The same digest binds receiver inputs, not an authenticated author or executable. A future UI must not treat all imported metadata as verified merely because numerical replay passes.
7. **Teaching compatibility is bounded.** The sibling teaching contract is a proposal. This port supplies real templates, fits, grid surfaces, histories, receiver boundaries and physical/energy ledgers; its T/fc naming is explicitly mapped to the proposed T_s/fc_hz fields. Full observation/comparison identities, display-state export, UI freshness wiring, pedagogical review, downloaded-file recovery, browser performance, accessibility and narrow-layout tests remain absent. Continuous-search/CRB stages must remain unavailable. This is not approval of the complete teaching API or UI.
8. **Further scientific/release scope remains open.** No multipath sensing, source-scale radar figures, batch Monte Carlo statistics, OFDM/FMCW comparison, browser endpoint execution, browser latency, UI implementation, repository integration, publication or deployment was validated here.

## Review artifacts

- `independent-numerical-results.json`: fresh operator/profile/grid checks plus both Worker export replays
- `maximum-independent-reference-replay.json`: every candidate of both maximum-cap records, file hashes and independent replay duration
- `independent-worker-results.json`: actual Worker lifecycle findings
- `independent-evidence-results.json`: serialization/replay/adversarial evidence checks
- `independent-digest-results.json`: cross-language receiver digests
- `independent-edge-results.json`: final input-hardening and variance/threshold checks
- `fresh-inputs.json`, `fresh-js-results.json`: the complete fresh reviewer-owned numerical input/output artifact
- `SOURCE-SHA256SUMS.txt`: exact reviewed executable manifest

The reviewer wrote only `review/` deliverables. Running the requested author suites also refreshed their normal `results/` test/export outputs; author source and test code were not edited.
