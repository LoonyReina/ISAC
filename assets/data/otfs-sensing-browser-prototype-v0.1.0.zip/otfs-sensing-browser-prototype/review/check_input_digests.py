"""Independent Python digest encoding of the actual JSON receiver values."""
import json,hashlib,re,decimal
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def number(x):
 if x==0:return '0'
 s=repr(x).lower()
 if 1e-6<=abs(x)<1e21:
  return format(decimal.Decimal(s),'f').rstrip('0').rstrip('.') if '.' in format(decimal.Decimal(s),'f') else format(decimal.Decimal(s),'f')
 if 'e' in s:
  m,e=s.split('e');m=m.removesuffix('.0');ei=int(e)
  return m+'e'+('+' if ei>=0 else '-')+str(abs(ei))
 return s

def encode(x):
 if x is None:return 'null'
 if x is True:return 'true'
 if x is False:return 'false'
 if isinstance(x,int):return str(x)
 if isinstance(x,float):return number(x)
 if isinstance(x,str):return json.dumps(x,ensure_ascii=False,separators=(',',':'))
 if isinstance(x,list):return '['+','.join(map(encode,x))+']'
 return '{'+','.join(encode(k)+':'+encode(x[k]) for k in sorted(x))+'}'
rows=[]
for path in list((ROOT/'results').glob('worker-export-*.json'))+list((ROOT/'results').glob('evidence-*.json'))+list((ROOT/'results').glob('maximum-evidence-*.json'))+list((ROOT/'review').glob('independent-worker-export-*.json')):
 r=json.loads(path.read_text())
 if 'inputDigest' not in r:continue
 receiver=r.get('receiver',r['result']['receiver']);actual='sha256:'+hashlib.sha256(encode(receiver).encode()).hexdigest()
 assert actual==r['inputDigest'],(path.name,actual,r['inputDigest'])
 rows.append({'path':str(path.relative_to(ROOT)),'digest':actual})
report={'status':'passed','method':'Independent Python ECMAScript-compatible shortest-decimal encoding for fixture values, sorted object keys, SHA256','rows':rows}
(ROOT/'review'/'independent-digest-results.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
