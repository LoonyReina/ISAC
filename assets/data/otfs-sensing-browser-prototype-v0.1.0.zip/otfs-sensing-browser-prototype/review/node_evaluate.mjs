import fs from 'node:fs';
import {evaluateCandidate,solveSync,profileComplexGain,inputDigest,canonicalJSON} from '../src/kernel.mjs';
import {isfft} from '../src/operators.mjs';
const input=JSON.parse(fs.readFileSync(process.argv[2],'utf8'));
const result={operators:input.operators.map(c=>({id:c.id,result:evaluateCandidate(c.observation,c.q,c.a),isfft:isfft(c.observation.frame,c.observation.x)})),grids:input.grids.map(c=>({id:c.id,result:solveSync(c.receiver)})),profiles:input.profiles.map(c=>({id:c.id,result:profileComplexGain(c.s,c.y,c.v)}))};
fs.writeFileSync(process.argv[3],JSON.stringify(result));
