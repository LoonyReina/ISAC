import {Worker} from 'node:worker_threads';
import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {createResultGate} from '../src/protocol.mjs';
const fresh=JSON.parse(fs.readFileSync(new URL('./fresh-inputs.json',import.meta.url)));
const prior=JSON.parse(fs.readFileSync(new URL('./fresh-js-results.json',import.meta.url)));
const make=()=>{
  const worker=new Worker(new URL('../src/node-worker.mjs',import.meta.url));const records=[];const waiters=[];
  worker.on('message',m=>{records.push(m);for(const w of [...waiters])if(w.test(m)){waiters.splice(waiters.indexOf(w),1);clearTimeout(w.timer);w.resolve(m);}});
  function wait(test){const found=records.find(test);if(found)return Promise.resolve(found);return new Promise((resolve,reject)=>{const w={test,resolve,timer:setTimeout(()=>reject(Error('Timeout')),30000)};waiters.push(w);});}
  return {worker,records,wait,terminal:id=>wait(m=>m.type==='terminal'&&m.requestId===id),post:(id,receiver)=>worker.postMessage({type:'run',requestId:id,receiver})};
};
function canonical(v){if(v===null||typeof v!=='object')return JSON.stringify(v);if(Array.isArray(v))return `[${v.map(canonical)}]`;return `{${Object.keys(v).sort().map(k=>JSON.stringify(k)+':'+canonical(v[k])).join(',')}}`;}
function digest(v){return 'sha256:'+createHash('sha256').update(canonical(v)).digest('hex');}
const report={tests:[],measurements:[],status:'running'};const session=make();const {worker,records,wait,terminal,post}=session;
try{
  for(const model of ['eq14_literal','exact_rect_finite']){
    const i=fresh.grids.findIndex(x=>x.id===`grid_${model}_4_8`);const input=fresh.grids[i].receiver;const id='replay-'+model;
    post(id,input);const out=await terminal(id);assert.equal(out.status,'completed');assert.deepEqual(out.result.candidates,prior.grids[i].result.candidates);assert.equal(out.inputDigest,digest(input));
    const deltas=records.filter(r=>r.requestId===id&&r.phase==='grid');assert.deepEqual(deltas.flatMap(r=>r.newCandidates),out.result.candidates);
    assert.equal(new Set(deltas.flatMap(r=>r.newCandidates.map(c=>c.index))).size,63);
    fs.writeFileSync(new URL(`./independent-worker-export-${model}.json`,import.meta.url),JSON.stringify(out,null,2));
    report.tests.push(`Fresh independent arbitrary x/y ${model} Worker full-grid and exact progress replay`);
  }
  const base=structuredClone(fresh.grids.find(c=>c.id==='grid_exact_rect_finite_4_8').receiver);
  const large={...base,gridShape:[129,129],settings:{...base.settings,chunkCandidates:1}};
  post('before-first',large);worker.postMessage({type:'cancel',requestId:'before-first'});const early=await terminal('before-first');assert.equal(early.status,'cancelled');assert(!early.result||early.result.operatorEvaluations===0);report.tests.push('Immediate cancellation before first evaluation yields no invented partial results');
  post('during',large);await wait(r=>r.requestId==='during'&&r.phase==='grid');const when=performance.now();worker.postMessage({type:'cancel',requestId:'during'});const during=await terminal('during');
  assert.equal(during.status,'cancelled');assert(during.result.operatorEvaluations>0&&during.result.operatorEvaluations<16641);assert.equal(during.result.partial,true);assert.equal(during.result.globalOnDeclaredGrid,false);assert.deepEqual(records.filter(r=>r.requestId==='during'&&r.phase==='grid').flatMap(r=>r.newCandidates),during.result.candidates);
  report.measurements.push({test:'cancel',candidateCount:during.result.operatorEvaluations,cancelToTerminalMs:performance.now()-when});report.tests.push('Cancellation retains exactly the actual progress prefix');
  // Burst probes hash-await/yield races, beyond the author's single old/new case.
  for(let i=0;i<30;i++)post('burst-'+i,i===29?{...base,gridShape:[2,3]}:large);
  const burst=await Promise.all(Array.from({length:30},(_,i)=>terminal('burst-'+i)));
  for(let i=0;i<29;i++)assert.equal(burst[i].status,'superseded');assert.equal(burst[29].status,'completed');assert.equal(burst[29].result.operatorEvaluations,6);
  report.tests.push('30-request burst: 29 superseded, only newest completed; hash/yield races safe');
  post('cap',{...base,settings:{...base.settings,maxEvaluations:1}});const cap=await terminal('cap');assert.equal(cap.status,'completed');assert.equal(cap.result.status,'evaluation-cap');assert.equal(cap.result.operatorEvaluations,1);assert.equal(cap.result.partial,true);
  post('time',{...large,settings:{...large.settings,maxElapsedMs:1}});const timed=await terminal('time');assert.equal(timed.status,'completed');assert.equal(timed.result.status,'time-cap');assert(timed.result.operatorEvaluations<16641);assert.equal(timed.result.globalOnDeclaredGrid,false);report.tests.push('Actual Worker evaluation/time caps are typed partial algorithm outcomes');
  post('no-info',fresh.grids.find(x=>x.id==='all-uninformative').receiver);const none=await terminal('no-info');assert.equal(none.status,'completed');assert.equal(none.result.status,'no-informative-candidate');assert.equal(none.result.selected,null);assert.equal(none.result.partial,false);report.tests.push('No-informative-candidate Worker outcome preserved with no gain or parameter estimate');
  for(const [k,extra] of [['truth',{q:1}],['seed',123],['noiselessY',base.y],['trueGain',{re:1,im:0}],['correctEstimatorResult',{q:1}]]){
    post('deny-'+k,{...base,[k]:extra});assert.equal((await terminal('deny-'+k)).status,'invalid-input');
  }
  report.tests.push('Worker rejects truth/seed/noiseless/true-gain/answer leakage fields');
  worker.postMessage({type:'run',requestId:'bad-envelope',receiver:base,truth:1});const envelope=await wait(m=>m.requestId==='bad-envelope');assert.equal(envelope.type,'protocol-error');
  post('cap',base);const duplicate=await wait(m=>m.requestId==='cap'&&m.type==='protocol-error');assert.equal(duplicate.status,'invalid-input');worker.postMessage({type:'cancel',requestId:'cap'});assert.equal((await wait(m=>m.requestId==='cap'&&m.type==='cancel-ignored')).status,'not-active');
  post('recovery',{...base,gridShape:[2,2]});const recovered=await terminal('recovery');assert.equal(recovered.status,'completed');
  const gate=createResultGate();gate.expect('recovery',recovered.inputDigest);assert(gate.accepts(recovered));assert(!gate.accepts(burst[29]));assert(!gate.accepts({...recovered,inputDigest:digest({...base,model:'eq14_literal'})}));gate.invalidate();assert(!gate.accepts(recovered));
  report.tests.push('Invalid requests, duplicate IDs, late cancel, recovery and current-ID-plus-digest gate checked');
  for(const id of new Set(records.filter(r=>r.type==='terminal').map(r=>r.requestId)))assert.equal(records.filter(r=>r.type==='terminal'&&r.requestId===id).length,1);
  report.tests.push('Exactly one terminal for every accepted request in all tested races');
}finally{await worker.terminate();}
const capSession=make();try{
  for(let i=0;i<1000;i++)capSession.post('limit-'+i,{});
  const thousand=await capSession.terminal('limit-999');assert.equal(thousand.status,'invalid-input');capSession.post('limit-1000',fresh.grids[0].receiver);
  const blocked=await capSession.wait(m=>m.requestId==='limit-1000');assert.equal(blocked.type,'protocol-error');assert(blocked.error.message.includes('1000'));
  assert.equal(capSession.records.filter(r=>r.type==='terminal').length,1000);report.tests.push('1000-request Worker session ceiling rejects request1001 without unbounded ID history');
}finally{await capSession.worker.terminate();}
report.status='passed';report.finishedAt=new Date().toISOString();fs.writeFileSync(new URL('./independent-worker-results.json',import.meta.url),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report,null,2));
