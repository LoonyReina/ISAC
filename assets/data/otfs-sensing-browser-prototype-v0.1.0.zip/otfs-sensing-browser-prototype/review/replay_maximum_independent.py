"""Independent formula/waveform replay of every candidate in max-cap exports."""
import json,hashlib,time
import independent_review as oracle
start=time.monotonic();rows=[];fail=[]
for model in ['eq14_literal','exact_rect_finite']:
 p=oracle.ROOT/'results'/f'maximum-evidence-{model}.json';record=json.loads(p.read_text()); t=time.monotonic()
 try:
  row=oracle.replay_grid({'receiver':record['result']['receiver'],'result':record['result']},'maximum-'+model)
  row.update(seconds=time.monotonic()-t,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size);rows.append(row)
 except Exception as e:fail.append({'model':model,'error':repr(e)})
out={'status':'passed' if not fail else 'hold','rows':rows,'failures':fail,'seconds':time.monotonic()-start,'numericChecksCumulative':oracle.checks,'maxAbsoluteErrors':oracle.maxima}
(oracle.OUT/'maximum-independent-reference-replay.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k!='maxAbsoluteErrors'},indent=2))
