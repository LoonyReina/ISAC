import fs from 'node:fs';import assert from 'node:assert/strict';
import {solveSync,createGridSearch,inputDigest} from '../src/kernel.mjs';
import {createEvidence,serializeEvidence,parseEvidence,replayEvidence,MAX_EVIDENCE_UTF8_BYTES} from '../src/evidence.mjs';
const own=JSON.parse(fs.readFileSync(new URL('./fresh-inputs.json',import.meta.url)));const report={status:'running',tests:[],records:[]};
for(const grid of own.grids){
  const raw=solveSync(grid.receiver),record=await createEvidence(raw,{generationModel:grid.receiver.model}),encoded=serializeEvidence(record),parsed=await parseEvidence(encoded.text),replay=replayEvidence(parsed);assert.equal(parsed.status,'unverified-import');assert.equal(replay.status,'numerical-prefix-replayed');
  report.records.push({id:grid.id,bytes:encoded.utf8Bytes,comparisons:replay.comparisons,candidates:replay.candidateCount});
}
report.tests.push('All12 independent-input grids export/parse/replay including zero-y ties and all-uninformative candidates');
const receiver=own.grids.find(c=>c.id==='grid_exact_rect_finite_4_8').receiver;
for(const cap of [0,1,16,62,63]){
  const s=createGridSearch({...receiver,settings:{...receiver.settings,maxEvaluations:Math.max(1,cap)}});if(cap===0)s.stop('cancelled');else while(s.status==='running')s.step();
  const record=await createEvidence(s.result(),{generationModel:receiver.model});const parsed=await parseEvidence(serializeEvidence(record).text);const replay=replayEvidence(parsed);assert.equal(replay.status,'numerical-prefix-replayed');assert.equal(replay.candidateCount,cap);assert.equal(replay.completeGrid,cap===63);
}
report.tests.push('Independent deterministic prefix replay at0/1/16/62/63 evaluations');
const good=await createEvidence(solveSync(receiver),{generationModel:receiver.model,evaluation:{trueDelayBin:.5,trueDopplerBin:.7,trueGain:{re:.1,im:.8}}});
for(const [name,mutate]of [
 ['template',r=>r.result.selected.inspection.template[0].re+=.1],
 ['physicalUnits',r=>r.result.selected.physical.monostaticRangeM+=1],
 ['gainPhase',r=>r.result.selected.gain.im+=.1],
 ['fittedVector',r=>r.result.selected.inspection.fitted[0].im+=.1],
 ['gridAxis',r=>r.result.grid.qAxis[0]+=.1],
 ['score',r=>r.result.candidates[13].score+=1],
 ['tieCount',r=>r.result.equalBestScoreCount+=1],
 ['invalidCount',r=>{r.result.globalOnDeclaredGrid=false;r.result.invalidCandidates+=1;}],
 ['candidateIndexCoordinates',r=>r.result.candidates[9].aIndex+=1],
]){
  const bad=structuredClone(good);mutate(bad);const p=await parseEvidence(JSON.stringify(bad));assert.equal(replayEvidence(p).status,'replay-mismatch',name);
}
report.tests.push('Replay detects independent corruption of template, fitted vector, physical units, complex phase, every-score state, axes, tie count, invalid count and candidate coordinates');
for(const [name,mutate]of [
 ['rawInput',r=>r.result.receiver.y[0].re+=1],
 ['missingDigest',r=>delete r.inputDigest],
 ['continuumClaim',r=>r.result.globalOnContinuum=true],
 ['partialGlobalClaim',r=>{r.result.status='cancelled';r.result.globalOnDeclaredGrid=true;}],
 ['nonfinite',r=>r.result.selected.score=Infinity],
 ['unsafeKey',r=>r.result.constructor='bad'],
 ['overdeep',r=>{let t={};r.result.padding=t;for(let i=0;i<20;i++){t.child={};t=t.child;}}],
 ['oversizeArray',r=>r.result.padding=Array(16642).fill(0)],
]){
  const bad=structuredClone(good);mutate(bad);
  // JSON.stringify converts Infinity to null; raw writer must reject before that.
  if(name==='nonfinite')assert.throws(()=>serializeEvidence(bad),/Nonfinite/);else await assert.rejects(()=>parseEvidence(JSON.stringify(bad)),undefined,name);
}
report.tests.push('Malformed/unsafe/deep/oversize/nonfinite data and false global claims rejected');
// Evaluation is expressly untrusted and must have no effect on replay.
const altered=structuredClone(good);altered.evaluation={trueDelayBin:7.9,trueDopplerBin:-3.9,trueGain:{re:999,im:-999}};
assert.deepEqual(replayEvidence(await parseEvidence(JSON.stringify(altered))),replayEvidence(await parseEvidence(JSON.stringify(good))));
report.tests.push('Changed generator truth leaves numerical replay identical');
const impossible=structuredClone(good);impossible.result.receiver.settings.maxEvaluations=1;impossible.inputDigest=await inputDigest(impossible.result.receiver);
assert.throws(()=>serializeEvidence(impossible),/candidate|evaluation|count|budget/i);await assert.rejects(()=>parseEvidence(JSON.stringify(impossible)),/candidate|evaluation|count|budget/i);
report.tests.push('Prefix exceeding original hard evaluation budget rejected even with matching recomputed digest');
// UTF-8 byte admission independent from JS UTF-16 character count.
const ascii=' '.repeat(MAX_EVIDENCE_UTF8_BYTES+1);await assert.rejects(()=>parseEvidence(ascii),/byte limit/);
const multibyte='😀'.repeat(MAX_EVIDENCE_UTF8_BYTES/4+1);await assert.rejects(()=>parseEvidence(multibyte),/byte limit/);
report.tests.push('Shared byte ceiling checked for ASCII and4-byte UTF-8 input');
for(const model of ['eq14_literal','exact_rect_finite']){
 const text=fs.readFileSync(new URL(`../results/maximum-evidence-${model}.json`,import.meta.url),'utf8');const parsed=await parseEvidence(text);const replay=replayEvidence(parsed);assert.equal(replay.status,'numerical-prefix-replayed');assert.equal(replay.candidateCount,16641);report.records.push({id:'maximum-'+model,bytes:Buffer.byteLength(text),comparisons:replay.comparisons,candidates:replay.candidateCount});
}
report.tests.push('Both maximum129² exported records fit shared cap and replay');
report.status='passed';report.finishedAt=new Date().toISOString();fs.writeFileSync(new URL('./independent-evidence-results.json',import.meta.url),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report,null,2));
