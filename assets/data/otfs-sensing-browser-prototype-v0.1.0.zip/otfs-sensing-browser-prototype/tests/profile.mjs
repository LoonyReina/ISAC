import {Worker} from 'node:worker_threads';
import fs from 'node:fs';
import os from 'node:os';
import {performance} from 'node:perf_hooks';
import {solveSync} from '../src/kernel.mjs';
const oracle=JSON.parse(fs.readFileSync(new URL('../fixtures/oracles.json',import.meta.url))),base=structuredClone(oracle.grids[0].receiver),rows=[];
for(const model of ['eq14_literal','exact_rect_finite'])for(const size of [17,65,129]){
  const receiver={...base,model,gridShape:[size,size],settings:{maxEvaluations:16641,maxElapsedMs:30000,chunkCandidates:64}};
  const t=performance.now(),out=solveSync(receiver);rows.push({runtime:'Node synchronous core',model,shape:[size,size],candidateCount:out.operatorEvaluations,status:out.status,outerWallMs:performance.now()-t,...out.timing});
  console.log(JSON.stringify(rows.at(-1)));
}
const workerRows=[];
for(const model of ['eq14_literal','exact_rect_finite'])for(const size of [65,129])for(let repetition=0;repetition<3;repetition++){
  const receiver={...base,model,gridShape:[size,size],settings:{maxEvaluations:16641,maxElapsedMs:30000,chunkCandidates:64}},worker=new Worker(new URL('../src/node-worker.mjs',import.meta.url));
  const rssStart=process.memoryUsage().rss;let peakRss=rssStart,progressCount=0,actualCandidates=0,largestChunkMs=0,previous=0;const started=performance.now(),interval=setInterval(()=>peakRss=Math.max(peakRss,process.memoryUsage().rss),5);
  const result=await new Promise((resolve,reject)=>{worker.on('error',reject);worker.on('message',m=>{peakRss=Math.max(peakRss,process.memoryUsage().rss);if(m.phase==='grid'){progressCount++;actualCandidates+=m.newCandidates.length;largestChunkMs=Math.max(largestChunkMs,m.elapsedMs-previous);previous=m.elapsedMs;}if(m.type==='terminal')resolve(m);});worker.postMessage({type:'run',requestId:'profile',receiver});});
  const roundTripMs=performance.now()-started;clearInterval(interval);await worker.terminate();
  const r={runtime:'actual Node Worker',model,shape:[size,size],repetition,candidateCount:result.result?.operatorEvaluations,reportedProgressCandidates:actualCandidates,progressCount,transportStatus:result.status,status:result.result?.status,workerWallMs:result.workerWallMs,roundTripMs,core:result.result?.timing,rssStartBytes:rssStart,peakProcessRssBytes:peakRss,peakProcessRssDeltaBytes:peakRss-rssStart,maxObservedProgressIntervalMs:largestChunkMs,outputJSONBytes:Buffer.byteLength(JSON.stringify(result))};workerRows.push(r);console.log(JSON.stringify(r));
}
const aggregates=[];for(const model of ['eq14_literal','exact_rect_finite'])for(const n of [65,129]){const cases=workerRows.filter(r=>r.model===model&&r.shape[0]===n),times=cases.map(r=>r.roundTripMs).sort((a,b)=>a-b);aggregates.push({model,shape:[n,n],candidateCount:n*n,repetitions:times.length,medianRoundTripMs:times[1],worstRoundTripMs:times.at(-1),maxProcessRssBytes:Math.max(...cases.map(r=>r.peakProcessRssBytes)),maxOutputJSONBytes:Math.max(...cases.map(r=>r.outputJSONBytes))});}
const out={schema:'otfs-sensing-node-profile-v1',createdAt:new Date().toISOString(),environment:{node:process.version,platform:process.platform,arch:process.arch,cpu:os.cpus()[0].model,logicalCpus:os.cpus().length,sharedEnvironment:true},boundaries:{sync:'Function start through returned copied result; no Worker transport or browser rendering',worker:'Fresh Worker creation through full terminal receipt; progress structured-clone traffic included',rss:'Whole-process RSS sampled every 5 ms; includes parent and Worker, not isolated peak Worker heap',browser:'Not measured; no browser or UI was used'},rows,workerRows,aggregates};
fs.writeFileSync(new URL('../results/node-performance.json',import.meta.url),JSON.stringify(out,null,2)+'\n');
