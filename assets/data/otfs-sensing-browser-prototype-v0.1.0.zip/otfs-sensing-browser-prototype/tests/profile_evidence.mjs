import fs from 'node:fs';import {spawnSync}from 'node:child_process';import {performance}from 'node:perf_hooks';import os from 'node:os';
import {solveSync}from '../src/kernel.mjs';import {createEvidence,serializeEvidence,parseEvidence,replayEvidence,MAX_EVIDENCE_UTF8_BYTES}from '../src/evidence.mjs';
if(process.argv[2]==='child'){
  global.gc?.();const baseline=process.memoryUsage(),t0=performance.now(),text=fs.readFileSync(process.argv[3],'utf8'),readMs=performance.now()-t0,afterRead=process.memoryUsage();const t1=performance.now(),parsed=await parseEvidence(text),parseMs=performance.now()-t1,afterParse=process.memoryUsage();const t2=performance.now(),replay=replayEvidence(parsed),replayMs=performance.now()-t2,afterReplay=process.memoryUsage();
  console.log(JSON.stringify({file:process.argv[3].split('/').at(-1),utf8Bytes:Buffer.byteLength(text),readMs,parseMs,replayMs,baseline,afterRead,afterParse,afterReplay,maxRssBytes:process.resourceUsage().maxRSS*1024,replay,scope:'Fresh Node process with --expose-gc; point-in-time heap samples and process high-water RSS include file/read/parse/replay'}));
}else{
  const oracle=JSON.parse(fs.readFileSync(new URL('../fixtures/oracles.json',import.meta.url))),base=oracle.grids[0].receiver,rows=[],files=[];
  for(const model of ['eq14_literal','exact_rect_finite']){
    let largest=null;
    for(const scenario of ['ordinary','max-components-min-variance','tiny-x-large-y']){
      const receiver=structuredClone(base);Object.assign(receiver,{model,gridShape:[129,129],bounds:[[0,7.99999],[-3.9999,3.9999]],settings:{maxEvaluations:16641,maxElapsedMs:30000,chunkCandidates:64}});
      if(scenario!=='ordinary'){receiver.noiseVariance=1e-8;receiver.y=receiver.y.map(z=>({re:64*Math.sign(z.re),im:64*Math.sign(z.im)}));receiver.x=receiver.x.map(z=>({re:(scenario==='tiny-x-large-y'?1e-10:16)*Math.sign(z.re),im:(scenario==='tiny-x-large-y'?1e-10:16)*Math.sign(z.im)}));}
      const result=solveSync(receiver),t=performance.now(),record=await createEvidence(result,{generationModel:base.model}),serialized=serializeEvidence(record),serializationMs=performance.now()-t,row={model,scenario,candidates:result.operatorEvaluations,status:result.status,utf8Bytes:serialized.utf8Bytes,serializationAndDigestMs:serializationMs};rows.push(row);console.log(JSON.stringify(row));if(!largest||serialized.utf8Bytes>largest.utf8Bytes)largest={...serialized,scenario};
    }
    const path=new URL(`../results/maximum-evidence-${model}.json`,import.meta.url);fs.writeFileSync(path,largest.text);files.push(path.pathname);
  }
  const memory=files.map(file=>{const child=spawnSync(process.execPath,['--expose-gc',new URL(import.meta.url).pathname,'child',file],{encoding:'utf8',maxBuffer:1024*1024});if(child.status!==0)throw new Error(child.stderr);return JSON.parse(child.stdout);});
  const out={schema:'otfs-sensing-evidence-profile-v1',createdAt:new Date().toISOString(),node:process.version,cpu:os.cpus()[0].model,sharedEnvironment:true,sharedWriterReaderLimitBytes:MAX_EVIDENCE_UTF8_BYTES,largestMeasuredCompleteUTF8Bytes:Math.max(...rows.map(r=>r.utf8Bytes)),sizeBoundary:'Largest among six measured cases at N4M8,129² with full numeric histories; not a universal worst-case number. Serializer rejects over16 MiB; parser has the identical ceiling.',rows,memory};fs.writeFileSync(new URL('../results/evidence-size-memory.json',import.meta.url),JSON.stringify(out,null,2)+'\n');console.log(JSON.stringify(out,null,2));
}
