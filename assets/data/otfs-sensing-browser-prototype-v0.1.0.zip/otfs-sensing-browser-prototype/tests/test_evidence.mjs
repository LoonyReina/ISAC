import assert from 'node:assert/strict';import fs from 'node:fs';
import {solveSync,createGridSearch,inputDigest} from '../src/kernel.mjs';
import {createEvidence,serializeEvidence,parseEvidence,replayEvidence,MAX_EVIDENCE_UTF8_BYTES} from '../src/evidence.mjs';
const oracle=JSON.parse(fs.readFileSync(new URL('../fixtures/oracles.json',import.meta.url))),base=oracle.grids[0].receiver,rows=[];
for(const model of ['eq14_literal','exact_rect_finite'])for(const count of [0,7,221]){
  const input={...base,model},search=createGridSearch({...input,settings:{...input.settings,maxEvaluations:Math.max(1,count)}});if(count)while(search.status==='running')search.step();else search.stop('cancelled');const result=search.result(),record=await createEvidence(result,{generationModel:base.model}),serialized=serializeEvidence(record),parsed=await parseEvidence(serialized.text),replay=replayEvidence(parsed);assert.equal(parsed.status,'unverified-import');assert.equal(replay.status,'numerical-prefix-replayed');assert.equal(replay.candidateCount,count);rows.push({model,count,bytes:serialized.utf8Bytes,replay});
  if(count){const corrupted=JSON.parse(serialized.text);corrupted.result.candidates[0].score+=1;const p=await parseEvidence(JSON.stringify(corrupted));assert.equal(replayEvidence(p).status,'replay-mismatch');}
  const changed=JSON.parse(serialized.text);changed.result.receiver.x[0].re+=.001;await assert.rejects(()=>parseEvidence(JSON.stringify(changed)),/digest/);
  if(count===221)fs.writeFileSync(new URL(`../results/evidence-${model}.json`,import.meta.url),serialized.text+'\n');
}
await assert.rejects(()=>parseEvidence(' '.repeat(MAX_EVIDENCE_UTF8_BYTES+1)),/byte limit/);
await assert.rejects(()=>parseEvidence('{invalid json'),/Malformed/);
const contradictory=await createEvidence(solveSync(base),{generationModel:base.model});contradictory.result.receiver.settings.maxEvaluations=7;contradictory.inputDigest=await inputDigest(contradictory.result.receiver);await assert.rejects(()=>parseEvidence(JSON.stringify(contradictory)),/evaluation budget/);
const full=await createEvidence(solveSync(base),{generationModel:base.model});full.result.globalOnContinuum=true;assert.throws(()=>serializeEvidence(full),/continuum/);
const out={status:'passed',sharedExportImportByteLimit:MAX_EVIDENCE_UTF8_BYTES,rows,tests:['Full and partial numerical prefix replay','Zero evaluated candidate cancellation export','Imported evidence remains unverified until replay','Tampered candidate score caught by replay','Mutated raw input rejected by digest','Identical writer/reader UTF-8 limit','Malformed JSON rejected','False continuum certification rejected','Candidate count cannot exceed declared deterministic evaluation budget even with a recomputed digest']};fs.writeFileSync(new URL('../results/author-evidence-tests.json',import.meta.url),JSON.stringify(out,null,2)+'\n');console.log(JSON.stringify(out,null,2));
