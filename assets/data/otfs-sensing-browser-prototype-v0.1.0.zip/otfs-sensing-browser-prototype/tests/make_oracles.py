"""Fresh author-oracle generator. Frozen dense Python reference and separately
coded quadrature/formula oracles. No JavaScript import and no source PDFs.
"""
import sys,json,hashlib,platform
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'reference'))
import otfs_reference as frozen
SHA='92b997201493a3187b5ddb37026672ef44e163131e422bdf8618f11b17aa235f'
assert hashlib.sha256((ROOT/'reference/otfs_reference.py').read_bytes()).hexdigest()==SHA
rng=np.random.default_rng(202610121638)
def pack(x):
    a=np.asarray(x)
    if a.ndim==0:
        if np.iscomplexobj(a):return {'re':float(a.real),'im':float(a.imag)}
        return a.item()
    return [pack(z) for z in a]
def transform(N,M):
    # Explicit scalar coefficients rather than reshape/broadcast implementation.
    return np.array([[np.exp(2j*np.pi*((r%N)*(c%N)/N-(r//N)*(c//N)/M))/np.sqrt(N*M) for c in range(N*M)] for r in range(N*M)])
def literal(N,M,q,a):
    C=np.empty((N*M,N*M),complex)
    for r in range(N*M):
        for c in range(N*M):
            k,l=r%N,r//N;kp,lp=c%N,c//N
            dop=sum(np.exp(2j*np.pi*(kp-k+a)*n/N) for n in range(N))/N
            delay=sum(np.exp(2j*np.pi*(lp-l+q)*m/M) for m in range(M))/M
            phase=np.exp(2j*np.pi*a*lp/(N*M))
            if lp>=M-np.ceil(q):phase*=np.exp(-2j*np.pi*(kp+a)/N)
            C[r,c]=dop*delay*phase
    return C
nodes,weights=np.polynomial.legendre.leggauss(64)
def direct_waveform(N,M,q,a,x):
    U=transform(N,M);X=(U@x).reshape((N,M),order='F');Z=np.zeros((N,M),complex);d=q/M;v=a/N
    for n in range(N):
        for lo,hi,nt in ((0,d,n-1),(d,1,n)):
            if nt<0 or hi<=lo:continue
            t=n+(lo+hi)/2+(hi-lo)/2*nodes
            local=t-d-nt
            waveform=np.exp(2j*np.pi*local[:,None]*np.arange(M))@X[nt]
            received=waveform*np.exp(2j*np.pi*v*(t-d))
            Z[n]+=((hi-lo)/2*weights*received)@np.exp(-2j*np.pi*t[:,None]*np.arange(M))
    return U.conj().T@Z.reshape(-1,order='F')
def prof(s,y,v):
    h,score,res=frozen.profile_gain(s,y)
    return {'gain':pack(h),'templateEnergy':float(np.vdot(s,s).real),'innerProduct':pack(np.vdot(s,y)),'score':score,'residual':res,'negativeLogLikelihoodUpToConstant':res/v,'logLikelihood':-len(y)*np.log(np.pi*v)-res/v,'template':pack(s),'fitted':pack(h*s),'residualVector':pack(y-h*s)}
ops=[];max_independent_error={'eq14_literal':0.,'exact_rect_finite':0.}
for N,M in ((1,1),(1,4),(2,3),(3,4),(4,8)):
    f=frozen.Frame(N,M,T=6.4e-6,fc=5.89e9)
    params=[(0,0),(M-1e-7,N-1e-7),(1e-8,-N+1e-7)]+[(float(rng.uniform(0,M)),float(rng.uniform(-.95*N,.95*N))) for _ in range(7)]
    if M>1:params += [(1.,.37),(1.-1e-8,.37),(1.+1e-8,.37),(float(M-1),-.63)]
    for q,a in params:
        x=(rng.normal(size=N*M)+1j*rng.normal(size=N*M))/np.sqrt(2)
        y=rng.normal(size=N*M)+1j*rng.normal(size=N*M);v=float(10**rng.uniform(-3,2))
        for model in ('eq14_literal','exact_rect_finite'):
            s=frozen.path_operator(f,q,a,model)@x
            oracle=literal(N,M,q,a)@x if model=='eq14_literal' else direct_waveform(N,M,q,a,x)
            err=float(np.max(abs(s-oracle)));max_independent_error[model]=max(err,max_independent_error[model]);assert err<2e-11,(N,M,q,a,model,err)
            ops.append({'id':f'op-{len(ops)}','observation':{'frame':f.__dict__,'x':pack(x),'y':pack(y),'noiseVariance':v,'model':model},'candidate':[q,a],'expected':prof(s,y,v),'independentTemplate':pack(oracle),'isfft':pack(frozen.isfft_matrix(f)@x),'physical':f.physical(q,a)})
# Explicit input basis columns verify vector order, not just random superpositions.
for model in ('eq14_literal','exact_rect_finite'):
    f=frozen.Frame(4,8);q,a=2.31,-1.21;C=frozen.path_operator(f,q,a,model)
    for j in range(f.size):
        x=np.eye(f.size,dtype=complex)[:,j];y=(rng.normal(size=f.size)+1j*rng.normal(size=f.size))*.1
        ops.append({'id':f'basis-{model}-{j}','observation':{'frame':f.__dict__,'x':pack(x),'y':pack(y),'noiseVariance':.7,'model':model},'candidate':[q,a],'expected':prof(C[:,j],y,.7)})
grids=[]
for idx,(model,N,M,shape) in enumerate([(m,4,8,[13,17]) for m in ('eq14_literal','exact_rect_finite') for _ in range(4)]+[(m,3,4,[9,11]) for m in ('eq14_literal','exact_rect_finite') for _ in range(2)]):
    f=frozen.Frame(N,M);x=(rng.normal(size=f.size)+1j*rng.normal(size=f.size))/np.sqrt(2)
    bounds=[[0.,min(M-.1,3.8)],[-min(N-.1,1.4),min(N-.1,1.4)]]
    qa=np.linspace(*bounds[0],shape[0]);aa=np.linspace(*bounds[1],shape[1]);q=float(qa[4]);a=float(aa[3]);h=.71-.83j;v=.03
    y=h*frozen.path_operator(f,q,a,model)@x
    noiseless=idx%2==0
    if not noiseless:y+=np.sqrt(v/2)*(rng.normal(size=f.size)+1j*rng.normal(size=f.size))
    records=[]
    for qi,qc in enumerate(qa):
        for ai,ac in enumerate(aa):
            s=frozen.path_operator(f,qc,ac,model)@x;p=prof(s,y,v)
            records.append({'index':len(records),'qIndex':qi,'aIndex':ai,'delayBin':float(qc),'dopplerBin':float(ac),**{k:p[k] for k in ['templateEnergy','innerProduct','gain','score','residual','negativeLogLikelihoodUpToConstant','logLikelihood']}})
    best=max(records,key=lambda r:r['score'])
    grids.append({'id':f'grid-{idx}','receiver':{'frame':f.__dict__,'x':pack(x),'y':pack(y),'noiseVariance':v,'model':model,'bounds':bounds,'gridShape':shape,'settings':{'maxEvaluations':16641,'maxElapsedMs':30000,'chunkCandidates':32}},'expected':{'candidates':records,'selected':best},'evaluationOnly':{'truthDelayBin':q,'truthDopplerBin':a,'trueGain':pack(h),'noiseless':noiseless}})
out={'schema':'otfs-sensing-author-oracles-v1','coreSha256':SHA,'seed':202610121638,'numpyVersion':np.__version__,'pythonVersion':platform.python_version(),'maxIndependentTemplateError':max_independent_error,'operators':ops,'grids':grids}
(ROOT/'fixtures/oracles.json').write_text(json.dumps(out,separators=(',',':'),allow_nan=False)+'\n')
print(json.dumps({'operatorCases':len(ops),'gridCases':len(grids),'maxIndependentTemplateError':max_independent_error},indent=2))
