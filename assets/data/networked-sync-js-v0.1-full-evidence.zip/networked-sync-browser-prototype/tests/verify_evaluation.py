#!/usr/bin/env python3
"""Independent NumPy check of evaluation-only label/error/source-geometry math.
Receiver truth firewall is tested separately; no evaluator input reaches fitting.
"""
import itertools,json,subprocess
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1];rng=np.random.default_rng(629917)
cases=[]
for rank in (1,2,3):
 for j in range(30):
  cfg={'shape':[6,12,8],'rank':rank,'bandwidthHz':1e7,'carrierHz':28e9}
  truth={'delay_s':rng.uniform(1e-8,1e-6,rank).tolist(),'doppler_hz':rng.uniform(-20000,20000,rank).tolist(),'angles1_rad':rng.uniform(-1,1,rank).tolist(),'angles2_rad':rng.uniform(-1,1,rank).tolist(),'offset2_s':float(rng.normal()*1e-8),'cfo2_hz':float(rng.normal()*500),'bs_separation_m':float(rng.uniform(10,100))}
  pair={'delay_s':rng.uniform(-1e-7,1e-6,rank).tolist(),'doppler_hz':rng.uniform(-20000,20000,rank).tolist(),'angles1_rad':rng.uniform(-1,1,rank).tolist(),'angles2_rad':rng.uniform(-1,1,rank).tolist(),'offset2_s':float(rng.normal()*1e-8),'cfo2_hz':float(rng.normal()*500)}
  cases.append({'cfg':cfg,'truth':truth,'pair':pair})
js="const fs=require('node:fs'),K=require('./js/receiver.js');const x=JSON.parse(fs.readFileSync(0,'utf8'));process.stdout.write(JSON.stringify(x.map(c=>K.evaluate(c.pair,c.truth,c.cfg))));"
out=json.loads(subprocess.run(['node','-e',js],cwd=ROOT,input=json.dumps(cases),text=True,capture_output=True,check=True).stdout)
maxerr=0
for c,result in zip(cases,out):
 t,e,cfg=c['truth'],c['pair'],c['cfg'];rank=cfg['rank'];df=cfg['bandwidthHz']/(cfg['shape'][1]-1);ts=1.5/df
 def vector(p):return np.r_[(np.array(e['delay_s'])[list(p)]-t['delay_s'])*2*np.pi*df,(np.array(e['doppler_hz'])[list(p)]-t['doppler_hz'])*2*np.pi*ts,np.array(e['angles1_rad'])[list(p)]-t['angles1_rad'],np.array(e['angles2_rad'])[list(p)]-t['angles2_rad']]
 p=min(itertools.permutations(range(rank)),key=lambda p:np.dot(vector(p),vector(p)));assert list(p)==result['evaluation_permutation']
 for name,field in [('delay_s','delay_errors_s'),('doppler_hz','doppler_errors_hz'),('angles1_rad','angle1_errors_rad'),('angles2_rad','angle2_errors_rad')]:
  expected=np.array(e[name])[list(p)]-t[name];err=float(max(abs(expected-result[field])));maxerr=max(maxerr,err);assert err<1e-12
 assert result['source_geometry_success']==bool(np.all(np.array(e['delay_s'])*299792458>=t['bs_separation_m']))
 assert result['gross_error_diagnostic']==bool(abs(e['cfo2_hz']-t['cfo2_hz'])>500 or max(abs(np.array(result['delay_errors_s'])))>1e-7 or max(abs(np.r_[result['angle1_errors_rad'],result['angle2_errors_rad']]))>np.pi/18)
report={'passed':len(cases),'failed':0,'max_absolute_error':maxerr,'claim':'Independent evaluation-only permutation, SI errors, source geometry filter and separately named gross errors; no receiver input'}
(ROOT/'reports/evaluation-oracle.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
