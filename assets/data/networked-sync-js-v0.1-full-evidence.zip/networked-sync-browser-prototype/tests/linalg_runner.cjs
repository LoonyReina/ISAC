'use strict';
const fs=require('node:fs'),L=require('../js/linalg.js');
const items=JSON.parse(fs.readFileSync(0,'utf8'));
function m(x){return L.mat(x.rows,x.cols,x.data)}
const out=items.map(t=>{const start=performance.now();try{let r;
  if(t.op==='svd')r=L.svd(m(t.A),t.options);
  if(t.op==='ls')r=L.leastSquares(m(t.A),m(t.B),t.options);
  if(t.op==='herm')r=L.hermitianEigen(m(t.A),t.rank);
  if(t.op==='eig')r=L.eigen(m(t.A),t.options);
  if(t.op==='adj')r=L.adjoint(m(t.A));
  if(t.op==='product')r=L.multiply(m(t.A),m(t.B));
  if(t.op==='rank1')r=L.rankOneSVD(m(t.A));
  return {name:t.name,op:t.op,result:r,elapsedMs:performance.now()-start};
}catch(e){return {name:t.name,op:t.op,error:e.message,code:e.code,diagnostics:e.diagnostics,elapsedMs:performance.now()-start}}});
process.stdout.write(JSON.stringify(out,(k,v)=>ArrayBuffer.isView(v)?Array.from(v):v));
