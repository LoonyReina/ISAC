'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const L=require('../js/linalg.js'); const results=[];
function test(name,fn){try{fn();results.push({name,passed:true})}catch(e){results.push({name,passed:false,error:e.stack});}}
function norm(x){return Math.hypot(...x)}
function relative(a,b){return norm(Array.from(a,(v,i)=>v-b[i]))/Math.max(norm(b),1)}
const A=L.mat(3,2,[1,2,3,-1,-2,1,4,3,0,1,-1,2]),saved=Array.from(A.data);
test('matrix copies input',()=>{const a=[1,2];const m=L.mat(1,1,a);a[0]=9;assert.equal(m.data[0],1)});
test('complex double adjoint',()=>assert.deepEqual(Array.from(L.adjoint(L.adjoint(A)).data),saved));
test('adjoint product reversal',()=>{const B=L.mat(2,2,[1,2,3,4,-1,2,7,3]);assert(relative(L.adjoint(L.multiply(A,B)).data,L.multiply(L.adjoint(B),L.adjoint(A)).data)<1e-14)});
test('no mutation after SVD LS eigen',()=>{L.svd(A);L.leastSquares(A,L.mat(3,1,[1,0,2,1,3,-1]));L.hermitianEigen(L.multiply(A,L.adjoint(A)),2);assert.deepEqual(Array.from(A.data),saved)});
test('nonfinite data rejected',()=>assert.throws(()=>L.mat(1,1,[NaN,0]),/finite/));
test('noninteger shape rejected',()=>assert.throws(()=>L.mat(1.5,2),/integer/));
test('wrong data length rejected',()=>assert.throws(()=>L.mat(1,1,[1]),/exact-length/));
test('dimension cap enforced',()=>assert.throws(()=>L.mat(8193,1),/integer/));
test('product dimension mismatch rejected',()=>assert.throws(()=>L.multiply(A,A),/Incompatible/));
test('non-Hermitian rejected',()=>assert.throws(()=>L.hermitianEigen(L.mat(2,2,[1,0,1,1,1,1,2,0]),1),/Hermitian/));
test('general eigen cap enforced',()=>assert.throws(()=>L.eigen(L.mat(4,4)),/1–3/));
test('negative rcond rejected',()=>assert.throws(()=>L.svd(A,{rcond:-1}),/rcond/));
test('SVD convergence budget enforced',()=>assert.throws(()=>L.svd(A,{maxSweeps:0}),/maxSweeps/));
test('explicit SVD nonconvergence throws',()=>{const M=L.mat(3,3,[1,1,2,3,4,1,-1,1,5,2,6,1,3,3,2,1,3,2]);assert.throws(()=>L.svd(M,{maxSweeps:1}),/convergence/)});
test('Hermitian nonconvergence throws',()=>{const H=L.multiply(A,L.adjoint(A));assert.throws(()=>L.hermitianEigen(H,{rank:2,maxSweeps:1}),/convergence/)});
test('zero least-squares design has rank zero',()=>{const d=L.leastSquares(L.mat(3,2),L.mat(3,1,[1,1,2,-1,3,1]));assert.equal(d.rank,0);assert.equal(norm(d.solution.data),0);assert.equal(d.residualRelative,1)});
test('rank-loss explicit hard-error option',()=>assert.throws(()=>L.leastSquares(L.mat(3,2),L.mat(3,1),{requireFullRank:true}),/rank deficient/));
test('zero rank-one split rejected',()=>assert.throws(()=>L.rankOneSVD(L.mat(2,2)),/nonzero/));
test('nonunique rank-one split rejected',()=>assert.throws(()=>L.rankOneSVD(L.mat(2,2,[1,0,0,0,0,0,1,0])),/non-unique/));
test('defective eigensystem rejected',()=>assert.throws(()=>L.eigen(L.mat(2,2,[1,0,1,0,0,0,1,0])),/defective/));
test('tiny and huge scale least-squares stable',()=>{
  const B=L.mat(3,1,[1,0,2,1,3,-1]),reference=L.leastSquares(A,B).solution.data;
  for(const s of [1e-200,1e200]){const AS=L.mat(3,2,A.data.map(v=>v*s)),BS=L.mat(3,1,B.data.map(v=>v*s)),d=L.leastSquares(AS,BS);assert(relative(d.solution.data,reference)<1e-14);assert(d.normalResidualRelative<1e-14);}
});
test('exact rank-one complex conjugation',()=>{
  const u=L.mat(4,1,[1,2,2,-1,3,1,1,0]),h=L.mat(1,5,[3,1,1,-1,2,2,1,-3,4,1]),X=L.multiply(u,h),d=L.rankOneSVD(X);
  const rec=L.multiply(L.mat(4,1,d.left.map(x=>x*d.sigma)),L.mat(1,5,d.rightH));assert(relative(rec.data,X.data)<1e-13);assert(d.residual<1e-13);
});
test('original source 7200 by 3 complex least-squares design',()=>{
  const m=10,n=36,k=20,D=L.mat(m*n*k,3);
  const phases=[[.31,-.27,.83],[-.42,.73,.19],[.55,-.62,.47]];
  for(let a=0;a<m;a++)for(let b=0;b<n;b++)for(let c=0;c<k;c++)for(let j=0;j<3;j++) {
    const phase=a*phases[0][j]+b*phases[1][j]+c*phases[2][j],p=2*(((a*n+b)*k+c)*3+j);
    D.data[p]=Math.cos(phase);D.data[p+1]=Math.sin(phase);
  }
  const X=L.mat(3,2,[1,.4,-2,.3,.6,-.8,.4,1.2,-.7,.2,1.3,-.9]);
  const Y=L.multiply(D,X),r=L.leastSquares(D,Y,{requireFullRank:true});
  assert.equal(r.rank,3);assert(relative(r.solution.data,X.data)<2e-13);
  assert(r.residualRelative<2e-13);assert(r.normalResidualRelative<2e-13);
});
test('element cap remains enforced',()=>assert.throws(()=>L.mat(8192,129),/element cap/));
test('browser UMD no Node global needed',()=>{const context=vm.createContext({});vm.runInContext(fs.readFileSync(require.resolve('../js/linalg.js'),'utf8'),context);assert.equal(typeof context.SyncLinalg.mat,'function');assert(vm.runInContext('SyncLinalg.svd(SyncLinalg.mat(1,1,[3,4])).values[0]',context)===5);});
const report={total:results.length,passed:results.filter(x=>x.passed).length,results};fs.writeFileSync(require('node:path').join(__dirname,'linalg_contract_report.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report,null,2));if(report.passed!==report.total)process.exitCode=1;
