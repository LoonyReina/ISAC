#!/usr/bin/env node
'use strict';
/* Recompute the JS receiver from raw held tensors. Nothing in expected or
 * evaluationOnly is passed to run(). Stored fixtures are regression oracles,
 * never evidence that an imported record was freshly executed in a browser. */
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const ROOT = path.resolve(__dirname, '..');
const argv = process.argv.slice(2);
const getArg = name => { const i = argv.indexOf(name); return i >= 0 ? argv[i + 1] : null; };
const directory = path.resolve(getArg('--oracle') || path.join(ROOT, 'oracle'));
const reportPath = path.resolve(getArg('--report') || path.join(ROOT, 'reports', 'oracle-parity.json'));
const selected = getArg('--case');
const tol = Object.freeze({phaseRad: 1e-6, factorsRelative: 2e-5, residualRelative: 5e-6,
  gridRelative: 2e-6, scalarRelative: 5e-6, primitiveRelative: 2e-7, primitivePhaseRad: 3e-7,
  normalizedPair: 3e-6});
const report = {schemaVersion: 1, startedAt: new Date().toISOString(), runtime: process.version,
  claim: 'Fresh Node execution of JavaScript receiver on freshly generated held-observation Python regression fixtures; not browser latency evidence',
  tolerances: tol, cases: [], primitives: [], checks: 0, passed: 0, failures: [], maxima: {}, warnings: []};
const hash = x => crypto.createHash('sha256').update(x).digest('hex');
function check(ok, label, details) {
  report.checks++;
  if (ok) report.passed++;
  else report.failures.push({label, ...details});
  return ok;
}
function measure(category, actual, limit, label) {
  if (Number.isFinite(actual)) report.maxima[category] = Math.max(report.maxima[category] || 0, actual);
  return check(Number.isFinite(actual) && actual <= limit, label, {metric: category, actual, limit});
}
const candidateIndices = peaks => Array.from(peaks || [], p => typeof p === 'number' ? p : p.grid_index).sort((a,b)=>a-b);
const wrap = p => ((p + Math.PI) % (2 * Math.PI) + 2 * Math.PI) % (2 * Math.PI) - Math.PI;
const norm = a => Math.sqrt(Array.from(a).reduce((s, x) => s + x * x, 0));
const rel = (a, b) => norm(a.map((v, i) => v - b[i])) / Math.max(norm(b), 1e-14);
const srel = (a, b) => Math.abs(a - b) / Math.max(Math.abs(b), 1e-12);
function data(A) { return Array.from(A.data || A); }
function copyMatrix(A) { return {rows: A.rows, cols: A.cols, data: data(A)}; }
function permute(A, perm) {
  const z = new Array(A.data.length);
  for (let i=0;i<A.rows;i++) for(let l=0;l<A.cols;l++) {
    z[2*(i*A.cols+l)] = A.data[2*(i*A.cols+perm[l])];
    z[2*(i*A.cols+l)+1] = A.data[2*(i*A.cols+perm[l])+1];
  }
  return {rows:A.rows,cols:A.cols,data:z};
}
function normalize(factors) {
  const F = factors.map(copyMatrix), L = F[0].cols;
  for(const axis of [1,2]) for(let l=0;l<L;l++) {
    const sr=F[axis].data[2*l], si=F[axis].data[2*l+1], den=sr*sr+si*si;
    if (den < 1e-28) throw new Error('Cannot normalize vanishing factor');
    for(let i=0;i<F[axis].rows;i++) {
      const p=2*(i*L+l), r=F[axis].data[p], im=F[axis].data[p+1];
      F[axis].data[p]=(r*sr+im*si)/den; F[axis].data[p+1]=(im*sr-r*si)/den;
    }
    for(let i=0;i<F[0].rows;i++) {
      const p=2*(i*L+l),r=F[0].data[p],im=F[0].data[p+1];
      F[0].data[p]=r*sr-im*si;F[0].data[p+1]=r*si+im*sr;
    }
  }
  return F;
}
function permutations(L) {
  if(L===0)return [[]];
  return permutations(L-1).flatMap(p=>Array.from({length:L},(_,i)=>[...p.slice(0,i),L-1,...p.slice(i)]));
}
function matching(actual, expected) {
  const L=expected.phases[0].length;
  const choices=permutations(L).map(p=>({p,cost:expected.phases.reduce((sum,row,a)=>sum+row.reduce((s,x,l)=>s+wrap(actual.phases[a][p[l]]-x)**2,0),0)}));
  choices.sort((a,b)=>a.cost-b.cost);return choices[0].p;
}
function compareFactors(actual, expected, permutation, label, limit=tol.factorsRelative) {
  check(Array.isArray(actual)&&actual.length===3,label+'.factorPresence');
  if(!actual||actual.length!==3)return;
  let a,b;
  try{a=normalize(actual).map(x=>permute(x,permutation));b=normalize(expected);}catch(e){check(false,label+'.normalization',{error:e.message});return;}
  for(let axis=0;axis<3;axis++)measure('normalizedFactorRelative',rel(a[axis].data,b[axis].data),limit,label+'.axis'+axis);
}
function comparePhases(actual,expected,p,label) {
  for(let axis=0;axis<3;axis++)for(let l=0;l<p.length;l++)measure('phaseRad',Math.abs(wrap(actual[axis][p[l]]-expected[axis][l])),tol.phaseRad,`${label}.${axis}.${l}`);
}
function column(A,l){const x=[];for(let i=0;i<A.rows;i++)x.push(A.data[2*(i*A.cols+l)],A.data[2*(i*A.cols+l)+1]);return x;}
function alignedColumnError(actual,expected) {
  let zr=0,zi=0,den=0;
  for(let i=0;i<actual.length;i+=2){zr+=actual[i]*expected[i]+actual[i+1]*expected[i+1];zi+=actual[i]*expected[i+1]-actual[i+1]*expected[i];den+=actual[i]**2+actual[i+1]**2;}
  if(den<1e-28)return norm(expected)<1e-14?0:Infinity;
  zr/=den;zi/=den;const out=[];
  for(let i=0;i<actual.length;i+=2)out.push(actual[i]*zr-actual[i+1]*zi,actual[i]*zi+actual[i+1]*zr);
  return rel(out,expected);
}
function compareTrace(actual,expected,p,label) {
  check(actual.length===expected.length,label+'.traceLength',{actual:actual.length,expected:expected.length});
  for(let t=0;t<Math.min(actual.length,expected.length);t++) {
    const a=actual[t],e=expected[t],base=label+'.iteration'+t;
    check(a.iteration===e.iteration,base+'.iteration');
    measure('traceResidualRelative',srel(a.residual_norm,e.residual_norm),tol.residualRelative,base+'.residual');
    if(!t)continue;
    measure('relativeChangeAbsolute',Math.abs(a.relative_change-e.relative_change),2e-6,base+'.relativeChange');
    check(Array.isArray(a.substeps)&&a.substeps.length===3,base+'.threeSubsteps');
    if(!a.substeps)continue;
    for(let axis=0;axis<3;axis++){
      const sa=a.substeps[axis],se=e.substeps[axis],sub=base+'.axis'+axis;
      if(!sa){check(false,sub+'.missing');continue;}
      check(sa.axis===axis,sub+'.updateOrder');
      check(sa.design_rank===se.design_rank,sub+'.designRank');
      measure('designConditionRelative',srel(sa.design_condition,se.design_condition),2e-5,sub+'.designCondition');
      measure('substepResidualRelative',srel(sa.residual_norm,se.residual_norm),tol.residualRelative,sub+'.residual');
      compareFactors(sa.factors,se.factors,p,sub+'.factors');
      check(!!sa.unconstrained,sub+'.unconstrainedPresent');
      if(sa.unconstrained)for(let l=0;l<p.length;l++)measure('unconstrainedColumnShapeRelative',alignedColumnError(column(sa.unconstrained,p[l]),column(se.unconstrained,l)),tol.factorsRelative,sub+'.LS'+l);
      if(se.projections){
        check(Array.isArray(sa.projections)&&sa.projections.length===p.length,sub+'.projections');
        if(!sa.projections)continue;
        for(let l=0;l<p.length;l++){
          const ap=sa.projections[p[l]],ep=se.projections[l],pr=sub+'.projection'+l;
          if(!ap){check(false,pr+'.missing');continue;}
          check(ap.candidate_count===ep.candidate_count,pr+'.candidateCount');
          check(ap.optimizer_success===ep.optimizer_success,pr+'.optimizerSuccess');
          if(ep.runner_up_power!==null)measure('projectionRunnerUpRatioAbsolute',Math.abs(ap.runner_up_power/ap.peak_power-ep.runner_up_power/ep.peak_power),2e-6,pr+'.runnerUpRatio');
          measure('projectionPhaseRad',Math.abs(wrap(ap.phase_rad-ep.phase_rad)),tol.phaseRad,pr+'.phase');
          const ac=ap.candidates,ec=ep.candidates;
          check(Array.isArray(ac)||ArrayBuffer.isView(ac),pr+'.candidatesPresent');
          if(ac)check(JSON.stringify(candidateIndices(ac))===JSON.stringify(ec),pr+'.candidateGridIndices',{actual:Array.from(ac),expected:ec});
          const ag=ap.grid_power,eg=ep.grid_power;
          check(!!ag&&ag.length===eg.length,pr+'.gridPresent');
          if(ag&&ag.length===eg.length){const am=Math.max(...ag),em=Math.max(...eg);measure('projectionGridShapeRelative',rel(Array.from(ag,x=>x/am),eg.map(x=>x/em)),tol.gridRelative,pr+'.gridPower');}
          if(ap.grid_phase_rad)measure('projectionGridPhaseRad',Math.max(...ep.grid_phase_rad.map((x,i)=>Math.abs(ap.grid_phase_rad[i]-x))),1e-13,pr+'.gridPhase');
        }
      }
    }
  }
}
function comparePair(actual,expected,p1,p2,cfg,label) {
  const df=cfg.bandwidthHz/(cfg.shape[1]-1),ts=1.5/df;
  measure('pairOffsetNormalized',Math.abs(actual.offset2_s-expected.offset2_s)*4*Math.PI*df,tol.normalizedPair,label+'.offset');
  measure('pairCFONormalized',Math.abs(actual.cfo2_hz-expected.cfo2_hz)*4*Math.PI*ts,tol.normalizedPair,label+'.cfo');
  for(const [key,scale]of [['delay_s',4*Math.PI*df],['doppler_hz',4*Math.PI*ts],['angles1_rad',1],['angles2_rad',1]])for(let l=0;l<p1.length;l++)measure('pairParameterNormalized',Math.abs(actual[key][p1[l]]-expected[key][l])*scale,tol.normalizedPair,`${label}.${key}.${l}`);
  measure('associationScoreScaled',Math.abs(actual.association_score-expected.association_score)/(1+Math.abs(expected.association_score)),2e-6,label+'.associationScore');
  if(expected.association_gap!==null)measure('associationGapScaled',Math.abs(actual.association_gap-expected.association_gap)/(1+Math.abs(expected.association_gap)),2e-6,label+'.associationGap');
  check(actual.principal_interval_only===true,label+'.principalInterval');
  check(actual.ambiguous_association===expected.ambiguous_association,label+'.ambiguity');
  if(!expected.ambiguous_association)for(let l=0;l<p1.length;l++)check(actual.permutation[p1[l]]===p2[expected.permutation[l]],`${label}.association.${l}`,{actual:actual.permutation,expected:expected.permutation,linkPermutations:[p1,p2]});
}
function compareLink(a,e,label) {
  check(a.method===e.method,label+'.methodIdentity',{actual:a.method,expected:e.method});
  const p=matching(a,e);
  comparePhases(a.phases,e.phases,p,label+'.phases');
  compareFactors(a.factors,e.factors,p,label+'.finalFactors');
  measure('finalResidualRelative',srel(a.residual_norm,e.residual_norm),tol.residualRelative,label+'.residual');
  if(e.trace){
    check(a.iterations===e.iterations,label+'.iterationCount',{actual:a.iterations,expected:e.iterations});
    check(a.stopping_condition_met===e.stopping_condition_met,label+'.stoppingCondition');
    check(Array.isArray(a.trace),label+'.tracePresent');
    if(a.trace)compareTrace(a.trace,e.trace,p,label);
  }
  if(e.subspace_eigenvalues&&a.subspace_eigenvalues)measure('initializerEigenvalueRelative',rel(Array.from(a.subspace_eigenvalues),e.subspace_eigenvalues),1e-7,label+'.subspaceEigenvalues');
  return p;
}
async function primitives(api,la,all) {
  for(const c of all.leastSquares){
    const before=report.failures.length;
    try{
      const r=la.leastSquares(la.mat(c.design.rows,c.design.cols,c.design.data),la.mat(c.rhs.rows,c.rhs.cols,c.rhs.data),{rcond:1e-12});
      measure('LSPrimitiveRelative',rel(data(r.solution),c.expected.solution.data),c.id==='ill-conditioned'?2e-5:2e-8,'LS.'+c.id+'.solution');
      check(r.rank===c.expected.rank,'LS.'+c.id+'.rank',{actual:r.rank,expected:c.expected.rank});
      check(r.converged===true,'LS.'+c.id+'.converged');
    }catch(e){check(false,'LS.'+c.id,{error:e.stack});}
    report.primitives.push({id:'LS.'+c.id,passed:report.failures.length===before});
  }
  for(const c of all.projection){
    const before=report.failures.length;
    try{
      const a=await api.projectColumn(Float64Array.from(c.input),c.oversampling,true);
      const phase=a.phase_rad??a.phase;
      const col=a.column??a.projected;
      measure('projectionPrimitivePhaseRad',Math.abs(wrap(phase-c.expected.phase_rad)),tol.primitivePhaseRad,'projection.'+c.id+'.phase');
      check(!!col,'projection.'+c.id+'.column');
      if(col)measure('projectionPrimitiveColumnRelative',rel(data(col),c.expected.column),2e-6,'projection.'+c.id+'.column');
      const meta=a.evidence??a.meta??a;
      measure('projectionPrimitivePeakRelative',srel(meta.peak_power,c.expected.peak_power),tol.primitiveRelative,'projection.'+c.id+'.power');
      check(JSON.stringify(candidateIndices(meta.candidates))===JSON.stringify(c.expected.candidates),'projection.'+c.id+'.candidates',{actual:meta.candidates,expected:c.expected.candidates});
      if(meta.grid_power)measure('projectionPrimitiveGridRelative',rel(Array.from(meta.grid_power),c.expected.grid_power),2e-12,'projection.'+c.id+'.grid');
      else check(false,'projection.'+c.id+'.gridMissing');
    }catch(e){check(false,'projection.'+c.id,{error:e.stack});}
    report.primitives.push({id:'projection.'+c.id,passed:report.failures.length===before});
  }
  for(const c of all.pairing) {
    const cfg=api.validateConfig({shape:[6,12,8],rank:2});
    const a=api.pairParameters({phases:c.phases1},{phases:c.phases2},cfg);
    comparePair(a,c.expected,[0,1],[0,1],cfg,'pairPrimitive.'+c.id);
    check(JSON.stringify(a.permutation)===JSON.stringify(c.expected.permutation),'pairPrimitive.'+c.id+'.tieOrder');
  }
  for(const c of all.invalid.filter(x=>x.input)){
    let rejected=false;try{await api.projectColumn(Float64Array.from(c.input));}catch(e){rejected=true;}
    check(rejected,'invalid.'+c.id);report.primitives.push({id:c.id,passed:rejected});
  }
}
async function main(){
  const manifest=JSON.parse(fs.readFileSync(path.join(directory,'manifest.json'),'utf8'));
  report.acceptedReferenceSha256=manifest.acceptedReferenceSha256;
  report.oracleGeneratedAt=manifest.generatedAt;
  report.receiverSha256=hash(fs.readFileSync(path.join(ROOT,'js','receiver.js')));
  report.linalgSha256=hash(fs.readFileSync(path.join(ROOT,'js','linalg.js')));
  const api=require(path.join(ROOT,'js','receiver.js')),la=require(path.join(ROOT,'js','linalg.js'));
  if(argv.includes('--emit-generated')) {
    const specs=[['compact-l1',310001,[6,12,8],1,'ordinary',15],['compact-l3',310002,[6,12,8],3,'ordinary',5],['original-l2',310003,[10,36,20],2,'ordinary',-10],['phasewrap-l2',310004,[6,12,8],2,'phasewrap',20],['close-l2',310005,[6,12,8],2,'close',30],['zero',310006,[6,12,8],2,'zero',20]];
    const cases=specs.map(([id,seed,shape,rank,scenario,snrDb])=>{const config=api.validateConfig({seed,shape,rank,scenario,snrDb,trace:'full'});return {id,config,...api.generate(config)};});
    fs.writeFileSync(path.join(directory,'js-generated-inputs.json'),JSON.stringify({generatedAt:new Date().toISOString(),receiverSha256:report.receiverSha256,cases})+'\n');
    console.log('Saved '+cases.length+' real JavaScript-generated reciprocal observation pairs');return;
  }
  const primitiveFile=fs.readFileSync(path.join(directory,manifest.primitives.file));
  check(hash(primitiveFile)===manifest.primitives.sha256,'primitives.fixtureHash');
  await primitives(api,la,JSON.parse(primitiveFile));
  for(const entry of manifest.cases){
    if(selected&&entry.id!==selected)continue;
    const bytes=fs.readFileSync(path.join(directory,entry.file));
    check(hash(bytes)===entry.sha256,entry.id+'.fixtureHash');
    const c=JSON.parse(bytes),before=report.failures.length,start=performance.now();
    const item={id:c.id,shape:c.request.config.shape,rank:c.request.config.rank,seed:c.seed,pathology:c.pathology};
    try{
      // Fresh computation receives ONLY the request. Truth and oracle outputs stay here.
      const request=structuredClone(c.request),saved=JSON.stringify(request);
      const actual=await api.run(request);
      check(JSON.stringify(request)===saved,c.id+'.inputNotMutated');
      check(actual.status==='fresh-execution',c.id+'.freshComputationStatus');
      check(!('truth' in actual)&&!('evaluation' in actual),c.id+'.heldTruthBoundary');
      check(Array.isArray(actual.pilot_divided)&&actual.pilot_divided.length===2,c.id+'.pilotDivisionPresent');
      if(actual.pilot_divided)for(let link=0;link<2;link++){
        const raw=request.observation.observations[link],pilot=request.observation.pilots[link],expected=[];
        for(let i=0;i<raw.length;i+=2){const j=i%pilot.length,den=pilot[j]**2+pilot[j+1]**2;expected.push((raw[i]*pilot[j]+raw[i+1]*pilot[j+1])/den,(raw[i+1]*pilot[j]-raw[i]*pilot[j+1])/den);}
        measure('pilotDivisionRelative',rel(actual.pilot_divided[link].data,expected),2e-15,c.id+'.pilotDivision'+link);
      }
      if(c.pathology==='exact-degenerate'){
        const methods=actual.methods||{};
        const failures=Object.entries(methods).filter(([,v])=>v.error||(v.errors||[]).length||(v.links||[]).some(l=>!l||l.error));
        check(failures.length>0||actual.identifiable===false,c.id+'.nonidentifiableNotClaimedAsSuccess');
        item.classification='Exact rank-deficient input: null-space factors are not numerically unique. Require rejection or explicit method-failure diagnostics.';
      }else{
        for(const method of ['smooth','scpd','esprit','als']){
          const a=actual.methods?.[method],e=c.expected.methods[method];
          check(!!a&&!a.error,c.id+'.'+method+'.present',{error:a?.error});
          if(!a||a.error)continue;
          const pp=[];
          for(let link=0;link<2;link++){
            if(!a.links?.[link]||a.links[link].error){check(false,`${c.id}.${method}.link${link}`,{error:a.links?.[link]?.error,methodErrors:a.errors});continue;}
            pp[link]=compareLink(a.links[link],e.links[link],`${c.id}.${method}.link${link}`);
          }
          if(pp.length===2&&pp.every(Boolean)&&a.pair&&!a.pair.error)comparePair(a.pair,e.pair,...pp,c.request.config,c.id+'.'+method+'.pair');
          else check(false,c.id+'.'+method+'.pairMissing');
        }
      }
    }catch(e){
      if(c.pathology==='exact-degenerate'&&/rank|unidentif|vanishing|slope/i.test(e.message)){check(true,c.id+'.degenerateRejected');item.classification='Exact rank-deficient input rejected';item.error=e.message;}
      else check(false,c.id+'.runtime',{error:e.stack});
    }
    item.elapsedMs=performance.now()-start;item.passed=report.failures.length===before;
    item.failures=report.failures.length-before;report.cases.push(item);
    console.log(`${item.passed?'PASS':'FAIL'} ${c.id}: ${item.elapsedMs.toFixed(1)} ms, ${item.failures} failures`);
  }
  if(!selected){
    const baseline=JSON.parse(fs.readFileSync(path.join(directory,manifest.cases[0].file))).request;
    for(const [name,mutate] of [
      ['nonunit-pilot',r=>{r.observation.pilots[0][0]*=1.5;r.observation.pilots[0][1]*=1.5;}],
      ['zero-pilot',r=>{r.observation.pilots[0][0]=r.observation.pilots[0][1]=0;}],
      ['nonfinite-observation',r=>{r.observation.observations[0][2]=Infinity;}],
      ['shape-mismatch',r=>{r.observation.shape[0]++;}],
      ['hidden-truth',r=>{r.truth={delay_s:[1]};}],
    ]){
      const r=structuredClone(baseline);mutate(r);let rejected=false;
      try{await api.run(r);}catch(e){rejected=true;}
      check(rejected,'requestValidation.'+name);
    }
  }
  report.finishedAt=new Date().toISOString();report.success=report.failures.length===0;
  fs.mkdirSync(path.dirname(reportPath),{recursive:true});fs.writeFileSync(reportPath,JSON.stringify(report,null,2)+'\n');
  console.log(`${report.passed}/${report.checks} checks passed; ${report.failures.length} failures; ${reportPath}`);
  if(report.failures.length){console.log(JSON.stringify(report.failures.slice(0,12),null,2));process.exitCode=1;}
}
main().catch(e=>{report.fatal=e.stack;report.success=false;fs.mkdirSync(path.dirname(reportPath),{recursive:true});fs.writeFileSync(reportPath,JSON.stringify(report,null,2)+'\n');console.error(e);process.exitCode=1;});
