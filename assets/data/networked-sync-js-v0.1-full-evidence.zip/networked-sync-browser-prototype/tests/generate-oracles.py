#!/usr/bin/env python3
"""Generate NEW seeded parity inputs using the pinned accepted Python reference.

The bundled tests/reference/sync_core.py is original implementation code from
the accepted source-free reference package, not paper text or author software.
No paper PDF, extracted text, image, or author CP-VDM source is bundled.
Raw requests contain observations, known pilots/rank and public sampling
settings; truth is only in the separate evaluationOnly object.
"""
from __future__ import annotations
import os
for name in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[name] = '1'
import argparse
import cmath
from dataclasses import asdict
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import sys
import time
import numpy as np
import scipy

ROOT = Path(__file__).resolve().parents[1]
ACCEPTED_SHA256 = '88a161d7d7d55ad4a2e703b0afb590c69644b0c61eaf370c2f6f519fc650f10e'


def serial(x):
    if isinstance(x, np.ndarray):
        if np.iscomplexobj(x):
            if x.ndim == 2:
                return matrix(x)
            return {'shape': list(x.shape), 'data': interleaved(x)}
        return serial(x.tolist())
    if isinstance(x, np.generic): return serial(x.item())
    if isinstance(x, complex): return [x.real, x.imag]
    if isinstance(x, dict): return {str(k): serial(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)): return [serial(v) for v in x]
    if isinstance(x, float) and not np.isfinite(x): return None
    return x


def interleaved(x):
    return np.asarray(x, dtype='<c16').ravel(order='C').view('<f8').tolist()


def matrix(x):
    a = np.asarray(x)
    return {'rows': a.shape[0], 'cols': a.shape[1], 'data': interleaved(a)}


def digest(x):
    return hashlib.sha256(np.asarray(x, dtype='<c16').tobytes(order='C')).hexdigest()


def grid_evidence(x, oversampling):
    size = oversampling * (1 << int(np.ceil(np.log2(len(x)))))
    powers = abs(np.fft.fft(x, n=size)) ** 2
    peaks = np.flatnonzero((powers >= np.roll(powers, 1)) & (powers >= np.roll(powers, -1)))
    return {'grid_phase_rad': (2*np.pi*np.arange(size)/size).tolist(),
            'grid_power': powers.tolist(), 'candidates': peaks.tolist()}


def attempt(fn):
    try: return serial(fn())
    except Exception as exc:
        return {'error': {'type': type(exc).__name__, 'message': str(exc)}}


def trace_scpd(core, y, rank, cfg, initial, structured):
    """Capture accepted routine outputs without changing its numerical work."""
    original = core.mode_update
    steps = []
    def capture(y_, factors, axis, structured=True, oversampling=16):
        # Separate unconstrained call is observational and does not mutate factors.
        unconstrained, _ = original(y_, factors, axis, False, oversampling)
        result, diagnostic = original(y_, factors, axis, structured, oversampling)
        fs = [a.copy() for a in factors]
        fs[axis] = result.copy()
        extra = {'unconstrained': matrix(unconstrained), 'factors': [matrix(f) for f in fs]}
        if structured:
            for column, evidence in zip(unconstrained.T, diagnostic['projections']):
                evidence.update(grid_evidence(column, oversampling))
        steps.append(extra)
        return result, diagnostic
    core.mode_update = capture
    try:
        answer = core.scpd(y, rank, cfg, initial=initial, structured=structured)
    finally:
        core.mode_update = original
    for step, extra in zip((s for t in answer['trace'][1:] for s in t['substeps']), steps):
        step.update(extra)
    return answer


def make_case(core, name, seed, shape, rank, snr_db, pathology=None):
    rng = np.random.default_rng(seed)
    cfg = core.Config(M=shape[0], N=shape[1], K=shape[2], iterations=20,
                      tolerance=1e-4, projection_oversampling=16)
    phase_b = np.linspace(-.61, -2.36, rank) + rng.uniform(-.025, .025, rank)
    phase_c = np.linspace(-.43, .88, rank) + rng.uniform(-.025, .025, rank)
    angles = np.array([np.linspace(-.53, .48, rank), np.linspace(.39, -.58, rank)])
    angles += rng.uniform(-.02, .02, angles.shape)
    offset_phase, cfo_phase = .049, -.083
    if pathology == 'phasewrap':
        phase_b = np.array([-np.pi+.04, -.85])
        phase_c = np.array([np.pi-.035, -.57])
        offset_phase, cfo_phase = .11, .12
    if pathology == 'near-collision':
        phase_b = np.array([-.83, -.813])
        phase_c = np.array([.37, .391])
        angles = np.array([[-.19, -.171], [.27, .289]])
    if pathology == 'exact-degenerate':
        phase_b[:] = -.83
        phase_c[:] = .37
        angles[:, :] = np.array([[-.19], [.27]])
    delay = -phase_b/(2*np.pi*cfg.df)
    doppler = phase_c/(2*np.pi*cfg.symbol_s)
    offset = offset_phase/(2*np.pi*cfg.df)
    cfo = cfo_phase/(2*np.pi*cfg.symbol_s)
    # Browser v0.1 declares unit-modulus-only pilots; preserve iid noise fairness.
    pilots = np.exp(.5j*np.pi*rng.integers(0,4,(2,cfg.N,cfg.K)))
    raw, normalized, gains, noise_variances = [], [], [], []
    for link, sign in enumerate((-1, 1)):
        alpha = (0.8+rng.uniform(0,.5,rank))*np.exp(1j*rng.uniform(-np.pi,np.pi,rank))
        beam = np.exp(1j*rng.uniform(-np.pi,np.pi,cfg.M))/np.sqrt(cfg.M)
        txangles = angles[1-link]
        effective = alpha*(core.vandermonde(cfg.M,2*np.pi*cfg.spacing_wavelengths*np.sin(txangles)).T@beam)
        gains.append(effective)
        args = (cfg, delay, doppler, angles[link], txangles, alpha, beam, pilots[link], sign*offset, sign*cfo)
        clean = core.observed_link(*args, np.zeros(cfg.shape, complex))
        variance = float(np.mean(abs(clean)**2)/10**(snr_db/10)) if snr_db is not None else 0.
        noise = np.sqrt(variance/2)*(rng.normal(size=cfg.shape)+1j*rng.normal(size=cfg.shape))
        observed = core.observed_link(*args, noise)
        raw.append(observed)
        normalized.append(core.remove_pilots(observed, pilots[link]))
        noise_variances.append(variance)
    request = {'operation': 'held', 'config': {
        'shape': list(shape), 'rank': rank, 'iterations': cfg.iterations,
        'tolerance': cfg.tolerance, 'projectionOversampling': cfg.projection_oversampling,
        'bandwidthHz': cfg.bandwidth_hz, 'carrierHz': cfg.carrier_hz,
        'spacingWavelengths': cfg.spacing_wavelengths, 'trace': 'full'},
        'observation': {'shape': list(shape), 'observations': [interleaved(y) for y in raw],
                        'pilots': [interleaved(p) for p in pilots]}}
    expected = {'normalizedObservationHashes': [digest(y) for y in normalized], 'methods': {}}
    results = {}
    for method in ('smooth', 'scpd', 'esprit', 'als'):
        links=[]
        for y in normalized:
            if method == 'smooth': fn = lambda y=y: core.cpvdm_smooth(y, rank)
            elif method == 'esprit': fn = lambda y=y: core.esprit_ls(y, rank)
            else:
                fn = lambda y=y, method=method: trace_scpd(core, y, rank, cfg, core.cpvdm_smooth(y, rank), method=='scpd')
            try:
                result=fn(); links.append(result)
            except Exception as exc:
                links.append({'error': {'type':type(exc).__name__, 'message':str(exc)}})
        pair = attempt(lambda: core.pair_parameters(*links, cfg)) if all('error' not in a for a in links) else {'error': {'type':'DependentFailure','message':'A link estimator failed'}}
        results[method]={'links':links,'pair':pair}
    expected['methods']=serial(results)
    # Truth has no route into the estimator request or expected computation.
    truth = {'delay_s':delay,'doppler_hz':doppler,'angles_rad':angles,
             'offset2_s':offset,'cfo2_hz':cfo,'effective_gains':gains,
             'variance_before_pilot_division':noise_variances}
    return {'id':name,'seed':seed,'snrDb':snr_db,'pathology':pathology,
            'request':request,'expected':expected,'evaluationOnly':serial(truth),
            'rawObservationHashes':[digest(y) for y in raw], 'pilotHashes':[digest(p) for p in pilots]}


def make_primitives(core, seed):
    rng=np.random.default_rng(seed)
    projection=[]
    for q in (4,6,8,10,12,20,36):
        x=rng.normal(size=q)+1j*rng.normal(size=q)
        projected,phase,meta=core.project_column(x)
        projection.append({'id':f'arbitrary-q{q}','input':interleaved(x),'oversampling':16,
                           'expected':{'column':interleaved(projected),'phase_rad':phase,**meta,**grid_evidence(x,16)}})
    for phase in (-np.pi+1e-6,-.731,0.,.593,np.pi-1e-6):
        x=(.43-.81j)*np.exp(1j*np.arange(19)*phase)
        projected,p,meta=core.project_column(x)
        projection.append({'id':f'wrap-tone-{phase:.7f}','input':interleaved(x),'oversampling':16,
                           'expected':{'column':interleaved(projected),'phase_rad':p,**meta,**grid_evidence(x,16)}})
    # Every primitive input exercises all supported FFT oversampling settings.
    extras=[]
    for case in projection:
        x=np.array(case['input'],dtype='<f8').view('<c16')
        for oversampling in (8,32):
            projected,phase,meta=core.project_column(x,oversampling)
            extras.append({'id':case['id']+f'-os{oversampling}','input':case['input'],
                           'oversampling':oversampling,'expected':{'column':interleaved(projected),
                           'phase_rad':phase,**meta,**grid_evidence(x,oversampling)}})
    projection.extend(extras)
    ls=[]
    for name, rows, cols, rhs in [('overdetermined',23,3,7),('complex-small',7,2,4),('square',4,4,2),('rank-deficient',13,3,4),('ill-conditioned',18,3,2),('underdetermined',3,5,2)]:
        d=rng.normal(size=(rows,cols))+1j*rng.normal(size=(rows,cols))
        e=rng.normal(size=(rows,rhs))+1j*rng.normal(size=(rows,rhs))
        if name=='rank-deficient':d[:,2]=d[:,0]*(.71+.22j)+d[:,1]*(-.3+.63j)
        if name=='ill-conditioned':d[:,2]=d[:,0]+1e-5*d[:,2]
        solution=np.linalg.lstsq(d,e,rcond=1e-12)[0]
        ls.append({'id':name,'design':matrix(d),'rhs':matrix(e),'expected':{
            'solution':matrix(solution),'rank':int(np.linalg.matrix_rank(d)),
            'condition':float(np.linalg.cond(d)),'residual_norm':float(np.linalg.norm(d@solution-e))}})
    p=np.array([[.2,-.3],[-.1,-.1],[.05,.05]])
    pairs=[{'id':'tied-association','phases1':p.tolist(),'phases2':p.tolist(),
            'expected':serial(core.pair_parameters({'phases':p},{'phases':p},core.Config(M=6,N=12,K=8)))}]
    return {'seed':seed,'projection':projection,'leastSquares':ls,'pairing':pairs,
            'invalid':[
                {'id':'zero-projection','input':[0.]*12,'pythonError':attempt(lambda:core.project_column(np.zeros(6)))},
                {'id':'one-sample-projection','input':[1.,0.],'pythonError':attempt(lambda:core.project_column(np.ones(1)))},
                {'id':'zero-pilot','expected':'reject'}, {'id':'nonfinite-observation','expected':'reject'},
                {'id':'shape-mismatch','expected':'reject'}]}


def decode(values, shape):
    return np.array(values, dtype='<f8').view('<c16').reshape(shape)


def verify_js_generated(core, filename):
    data=json.loads(filename.read_text())
    records=[]
    for case in data['cases']:
        c=case['config']; shape=c['shape']; rank=c['rank']
        cfg=core.Config(M=shape[0],N=shape[1],K=shape[2],bandwidth_hz=c['bandwidthHz'],
                        carrier_hz=c['carrierHz'],spacing_wavelengths=c['spacingWavelengths'])
        truth=case['truth']; generation=case['generation']; rows=[]
        tau=np.array(truth['delay_s']);nu=np.array(truth['doppler_hz'])
        for link,sign in enumerate((-1,1)):
            raw=decode(case['observation']['observations'][link],shape)
            pilot=decode(case['observation']['pilots'][link],(cfg.N,cfg.K))
            noise=decode(generation['unitNoise'][link],shape)*np.sqrt(generation['sourceNoiseVariance'][link]/2)
            alpha=decode(generation['alphas'][link],(rank,))
            beam=decode(generation['beams'][link],(cfg.M,))
            rx=np.array(truth[f'angles{link+1}_rad']);tx=np.array(generation['txAngles'][link])
            offset=sign*truth['offset2_s'];cfo=sign*truth['cfo2_hz']
            accepted=core.observed_link(cfg,tau,nu,rx,tx,alpha,beam,pilot,offset,cfo,noise)
            # Independent full scalar Eq1/2 implementation: no CP or production model helpers.
            literal=noise.copy()
            for m,n,k in np.ndindex(cfg.shape):
                total=0j
                for l in range(rank):
                    for t in range(cfg.M):
                        phase=(2*np.pi*cfg.spacing_wavelengths*(m*np.sin(rx[l])+t*np.sin(tx[l]))
                               -2*np.pi*cfg.df*n*(tau[l]+offset)
                               +2*np.pi*cfg.symbol_s*k*(nu[l]+cfo))
                        total+=alpha[l]*beam[t]*cmath.exp(1j*phase)
                literal[m,n,k]+=total*pilot[n,k]
            effective=alpha*(core.vandermonde(cfg.M,2*np.pi*cfg.spacing_wavelengths*np.sin(tx)).T@beam)
            clean=accepted-noise
            variance=float(np.sum(abs(alpha)**2)/10**(c['snrDb']/10))
            expected_snr=float(10*np.log10(np.mean(abs(clean)**2)/variance)) if variance else None
            row={'link':link,'accepted_max_abs_error':float(np.max(abs(accepted-raw))),
                 'scalar_equation_max_abs_error':float(np.max(abs(literal-raw))),
                 'effective_gain_max_abs_error':float(np.max(abs(effective-decode(generation['effectiveGains'][link],(rank,))))),
                 'noise_variance_abs_error':abs(variance-generation['sourceNoiseVariance'][link]),
                 'received_snr_abs_error':abs(expected_snr-generation['receivedSNR'][link]) if variance else 0.}
            row['passed']=all(v<2e-11 for k,v in row.items() if k.endswith('error'))
            rows.append(row)
        records.append({'id':case['id'],'shape':shape,'rank':rank,'links':rows,'passed':all(r['passed'] for r in rows),
                        'principal_interval_valid':generation['principal_interval_valid']})
    report={'generatedAt':datetime.now(timezone.utc).isoformat(),'acceptedReferenceSha256':ACCEPTED_SHA256,
            'receiverSha256':data['receiverSha256'],'sourceFile':filename.name,'sourceSha256':hashlib.sha256(filename.read_bytes()).hexdigest(),
            'claim':'Independent complete scalar Eq1/2 and accepted Python checks of actual seeded JavaScript-generated raw observations',
            'cases':records,'success':all(r['passed'] for r in records)}
    dest=ROOT/'reports'/'oracle-js-generation.json';dest.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))
    if not report['success']:raise SystemExit(1)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--reference',type=Path,default=ROOT/'tests'/'reference'/'sync_core.py')
    parser.add_argument('--output',type=Path,default=ROOT/'oracle')
    parser.add_argument('--case',action='append',help='Regenerate only named case(s)')
    parser.add_argument('--verify-js-generated',type=Path,help='Check persisted actual JS generator outputs against scalar equations and accepted Python')
    args=parser.parse_args()
    actual=hashlib.sha256(args.reference.read_bytes()).hexdigest()
    if actual!=ACCEPTED_SHA256:raise SystemExit(f'Refusing reference hash mismatch: {actual}')
    spec=importlib.util.spec_from_file_location('accepted_sync_core',args.reference)
    core=importlib.util.module_from_spec(spec);sys.modules[spec.name]=core;spec.loader.exec_module(core)
    if args.verify_js_generated:
        verify_js_generated(core,args.verify_js_generated)
        return
    args.output.mkdir(parents=True,exist_ok=True)
    cases=[
        ('compact-l1',202610120101,(6,12,8),1,24,None),
        ('compact-l2',202610120102,(6,12,8),2,24,None),
        ('compact-l3',202610120103,(6,12,8),3,24,None),
        ('original-l1',202610120104,(10,36,20),1,15,None),
        ('original-l2',202610120105,(10,36,20),2,15,None),
        ('original-l3',202610120111,(10,36,20),3,15,None),
        ('original-l2-low-snr',202610120106,(10,36,20),2,-20,None),
        ('compact-l3-low-snr',202610120107,(6,12,8),3,-16,None),
        ('compact-l2-phasewrap',202610120108,(6,12,8),2,25,'phasewrap'),
        ('compact-l2-near-collision',202610120109,(6,12,8),2,30,'near-collision'),
        ('compact-l2-degenerate',202610120110,(6,12,8),2,None,'exact-degenerate')]
    manifest={'schemaVersion':1,'generatedAt':datetime.now(timezone.utc).isoformat(),
              'acceptedReferenceSha256':actual,'generator':'tests/generate-oracles.py',
              'generatorSha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__,
              'claim':'Freshly generated held-observation regression fixtures, not a fresh browser runtime execution',
              'truthBoundary':'Only request is passed to JS. evaluationOnly is never an estimator input.',
              'boundedPortScope':'Known unit-modulus pilots only; accepted Python also supports non-unit pilots, intentionally outside v0.1 scope.',
              'cases':[]}
    for case in cases:
        filename=case[0]+'.json';dest=args.output/filename
        if not args.case or case[0] in args.case:
            started=time.perf_counter();out=make_case(core,*case)
            dest.write_text(json.dumps(out,separators=(',',':'),allow_nan=False)+'\n')
            print(f'{case[0]} generated in {time.perf_counter()-started:.2f}s ({dest.stat().st_size} bytes)',flush=True)
        if dest.exists():
            manifest['cases'].append({'id':case[0],'file':filename,'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),
                                      'shape':case[2],'rank':case[3],'seed':case[1]})
    primitives=args.output/'primitives.json'
    primitives.write_text(json.dumps(make_primitives(core,202610120199),separators=(',',':'),allow_nan=False)+'\n')
    manifest['primitives']={'file':primitives.name,'sha256':hashlib.sha256(primitives.read_bytes()).hexdigest()}
    (args.output/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')

if __name__=='__main__':main()
