#!/usr/bin/env python3
"""Freeze and verify original source-free numerical runtime/evidence archives."""
import hashlib,json,zipfile,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT.parent
sha=lambda b:hashlib.sha256(b).hexdigest()
read=lambda p:p.read_bytes()
runtime=sorted([*ROOT.glob('js/*.js'),*ROOT.glob('worker/*.js')])
source={'schema':'networked-sync-js-source-freeze-v1','date_utc':'2026-10-12','runtime':[{'path':p.relative_to(ROOT).as_posix(),'bytes':p.stat().st_size,'sha256':sha(read(p))} for p in runtime], 'accepted_python_sha256':'88a161d7d7d55ad4a2e703b0afb590c69644b0c61eaf370c2f6f519fc650f10e','reference_freeze_sha256':'94f0c92acb978981a0fe5d4891fe95acb5d8ce557f5b92ca6a84dc9d2637e3ab','reference_independent_review_freeze_sha256':'5a67ab96fb867c6a1412c7d4cb7a6982184d880fa328572b13621318ba32ddd1','claim':'Fresh source-derived JS numerical kernel and actual Node Worker; browser branch VM only; no UI/repository/publishing/full-paper claim'}
(ROOT/'SOURCE-FREEZE.json').write_text(json.dumps(source,indent=2)+'\n')
excluded={'ARTIFACT-MANIFEST.json','ARCHIVE-VERIFICATION.json'}
files=sorted(p for p in ROOT.rglob('*') if p.is_file() and p.name not in excluded and '__pycache__' not in p.parts and not p.name.endswith('.pyc'))
manifest={'schema':'networked-sync-js-artifact-manifest-v1','files':[{'path':p.relative_to(ROOT).as_posix(),'bytes':p.stat().st_size,'sha256':sha(read(p))}for p in files], 'excluded':['ARTIFACT-MANIFEST.json','ARCHIVE-VERIFICATION.json','__pycache__','*.pyc']}
(ROOT/'ARTIFACT-MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
files.append(ROOT/'ARTIFACT-MANIFEST.json')
rt_names={p.relative_to(ROOT).as_posix() for p in runtime}|{'README.md','HANDOFF.md','package.json','SOURCE-FREEZE.json','worker/README.md','worker/FORMAT.md'}
archives=[]
for name,selected in [('networked-sync-js-v0.1-runtime.zip',[p for p in files if p.relative_to(ROOT).as_posix() in rt_names]),('networked-sync-js-v0.1-full-evidence.zip',files)]:
    dest=OUT/name
    with zipfile.ZipFile(dest,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
        for p in sorted(selected):
            rel=p.relative_to(ROOT).as_posix();info=zipfile.ZipInfo('networked-sync-browser-prototype/'+rel,date_time=(2026,10,12,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=(0o100755 if p.name=='run_all.sh' else 0o100644)<<16;z.writestr(info,read(p))
    with zipfile.ZipFile(dest)as z:
        assert z.testzip() is None
        assert len(z.namelist())==len(selected)
        for p in selected:assert z.read('networked-sync-browser-prototype/'+p.relative_to(ROOT).as_posix())==read(p)
        assert not any(n.lower().endswith(('.pdf','.png','.jpg','.html')) for n in z.namelist())
    archives.append({'name':name,'path':str(dest),'bytes':dest.stat().st_size,'sha256':sha(read(dest)),'files':len(selected),'verified_bytes':True,'under_9MB':dest.stat().st_size<=9000000})
result={'schema':'networked-sync-js-archive-verification-v1','source_freeze_sha256':sha(read(ROOT/'SOURCE-FREEZE.json')),'artifact_manifest_sha256':sha(read(ROOT/'ARTIFACT-MANIFEST.json')),'archive_members_byte_checked':True,'paper_source_files_included':False,'archives':archives}
(ROOT/'ARCHIVE-VERIFICATION.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
