# SyncLinalg implementation and numerical evidence

`js/linalg.js` is dependency-free CommonJS and browser UMD (`globalThis.SyncLinalg`). All public matrices use `{rows, cols, data: Float64Array}` in row-major interleaved complex order. Inputs are not mutated. Scalar row/column dimensions are capped at 8192, and matrix allocation remains capped at 1,048,576 complex elements.

## API

- `mat(rows, cols, data?)`: allocate or copy a matrix; optional data is already interleaved
- `adjoint(A)`, `multiply(A, B)`, `norm(A)`: complex conjugate transpose, product and Frobenius norm; norm also accepts Float64Array
- `svd(A, {rcond=1e-12, maxSweeps=100}?)`: economy `U`, descending real `values` (also `singularValues`), `Vh`, `rank`, `condition`, `converged`, `diagnostics`
- `leastSquares(A, B, {rcond=1e-12, requireFullRank=false}?)`: `solution` (also `x`), `rank`, `condition`, `singularValues`, `residualRelative`, `residualNorm`, `normalResidualRelative`, `converged`, `diagnostics`
- `hermitianEigen(A, rank)` or `hermitianEigen(A, {rank, maxSweeps})`: descending real `values`, `vectors` by column, per-column `residuals`, `converged`, `diagnostics`
- `eigen(A, {maxIterations=2000}?)`: rank-1/2/3 general complex matrix; `values` are arrays `[re, im]`, `vectors` by column, `residuals`, eigenvector `condition`, `converged`, `diagnostics`
- `rankOneSVD(A)`: interleaved unit `left`, scalar `sigma`, interleaved `rightH`, relative approximation `residual` (also `residualRelative`), `converged`, `diagnostics`. Reconstruct as `(left*sigma)*rightH`; do not conjugate rightH again.

## Algorithms and failure policy

SVD is one-sided complex Jacobi. It operates on A directly, not A^H A. Least squares uses the SVD pseudoinverse and exactly the requested relative singular-value cutoff. Rank-deficient least squares is permitted, matching NumPy lstsq semantics; `requireFullRank: true` converts rank loss to an error. Independently normalized A and B keep certificates valid for tiny/huge common scales.

Hermitian eigensystems use full complex cyclic Jacobi with reconstruction-residual and orthogonality certificates. The cap is 192, covering the source's 160-dimensional smoothed covariance. Full eigenanalysis avoids an uncertified power-method or missing subspace. Leading rank extraction is descending.

General eigenvalues use complex shifted QR and direct one-sided SVD for eigenvectors, with residual and mixing-condition checks. Dimensions above 3 are rejected. Defective mixing (`condition >= 1e10`) or a failed residual certificate throws `NUMERICAL_DEGENERACY`. Rank-one separation rejects zero input and a numerically nonunique leading singular vector. SVD and Hermitian convergence failures throw with diagnostics; they never silently report success.

The reviewed original project Householder/Jacobi primitives were adapted from `ofdm-ici-browser-prototype/js/linalg.js`, SHA-256 `c7e21dadbac282314c504c5f1b73a4de18964c18ee1d06cc34eedcce1d81509a`. Their previous Hermitian source provenance is preserved in the implementation header. The new object API, vector-producing SVD, pseudoinverse and general eigenpair code are original implementation, with no third-party source copied.

## Reproducible evidence

Run from the prototype directory:

    OPENBLAS_NUM_THREADS=1 python tests/linalg_oracle.py
    node tests/linalg_contract.cjs
    node tests/linalg_stress.cjs

- 145/145 independent NumPy comparisons: arbitrary complex adjoint/product, tall/wide SVD and LS, controlled small singular values, exact rank loss, 90 random general eigenproblems, close eigenvalues, defective rejection, rank-one separation, and Hermitian matrices through 160×160
- 25/25 contract tests: input validation, no mutation, UMD global, forced nonconvergence, rank/degeneracy failures, right-vector conjugation, shared scale factors 1e-200 and 1e200, and the original 10×36×20 = 7200 row complex Khatri-Rao least-squares design
- 500/500 exact-rank-two stress matrices: correct SVD rank and successful reconstruction certification
- Worst oracle SVD reconstruction residual: 1.65e-15; normal-equation residual certificate: 2.69e-16; Hermitian projector error: 5.83e-14; general eigenvalue spectrum discrepancy: 1.48e-14
- The 1e-11 singular value is resolved to 4.11e-7 relative error, consistent with binary64 conditioning. All comparisons use dimension/condition-aware forward bounds and strict backward errors.
- Representative Node timing: low-rank 160×160 Hermitian about 70 ms; fully dense 160×160 about 330 ms. Timings are diagnostic, not browser latency guarantees.

Raw reports are `linalg_oracle_report.json`, `linalg_contract_report.json`, and `linalg_stress_report.json` alongside these tests.
