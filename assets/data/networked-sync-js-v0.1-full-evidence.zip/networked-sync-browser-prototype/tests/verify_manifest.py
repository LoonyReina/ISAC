#!/usr/bin/env python3
"""Verify delivered original bytes before rerunning tests that update reports."""
from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parents[1]
m=json.loads((root/'ARTIFACT-MANIFEST.json').read_text())
seen=set()
for item in m['files']:
 rel=item['path'];p=(root/rel).resolve();assert p.is_relative_to(root),rel;assert rel not in seen,rel;seen.add(rel)
 b=p.read_bytes();assert len(b)==item['bytes'],rel;assert hashlib.sha256(b).hexdigest()==item['sha256'],rel
s=json.loads((root/'SOURCE-FREEZE.json').read_text())
for item in s['runtime']:
 p=root/item['path'];assert hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256'],item['path']
print(json.dumps({'verified_files':len(seen),'verified_runtime_files':len(s['runtime']),'status':'PASS'}))
