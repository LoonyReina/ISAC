# Accepted reference implementation provenance

`sync_core.py` is the original implementation code from the accepted source-free networked synchronization reference package. It is copied byte-for-byte from the accepted reference, not transcribed paper text, paper artwork, or author-provided software.

Pinned SHA-256:

`88a161d7d7d55ad4a2e703b0afb590c69644b0c61eaf370c2f6f519fc650f10e`

The test generator checks this hash before importing any reference routine. An external file can be selected using `--reference`, but the same hash is required. This makes the artifact independently regenerable without the original sibling workspace.

This Python implementation is an offline test dependency only. The browser receiver imports no Python, fixtures, reference results, paper content, or evaluator truth.

Source attribution: arXiv:2607.18680v1, the accepted source-derived bounded implementation of Eqs. 1–5, 16–27, 29–35 and the Appendix-B ESPRIT baseline. The three-axis smoothed initializer is explicitly an adapted CP variant, not the unverified exact author CP-VDM configuration used in the paper's figures. The original reference also includes evaluation-only routines that are not part of this JS port.
