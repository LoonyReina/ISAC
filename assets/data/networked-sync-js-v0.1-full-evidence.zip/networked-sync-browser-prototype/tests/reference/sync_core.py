"""Source-derived, bounded reciprocal ISAC reference. No truth enters estimators.

Fixed source: arXiv:2607.18680v1, Eqs. 1-5,16-27,29-35,61-66.
All internal frequencies are radians/sample: exp(+1j * index * phase).
This declares an operational convention for the source Eq.19/20 parameterization.
"""
from __future__ import annotations

from dataclasses import dataclass
from itertools import permutations, product
import numpy as np
from scipy.optimize import minimize_scalar
from scipy.linalg import eigh


@dataclass(frozen=True)
class Config:
    M: int = 10
    N: int = 36
    K: int = 20
    carrier_hz: float = 28e9
    bandwidth_hz: float = 10e6
    light_mps: float = 299792458.0
    spacing_wavelengths: float = .5
    iterations: int = 20
    tolerance: float = 1e-4
    projection_oversampling: int = 16

    @property
    def df(self): return self.bandwidth_hz / (self.N - 1)
    @property
    def symbol_s(self): return 1.5 / self.df
    @property
    def wavelength_m(self): return self.light_mps / self.carrier_hz
    @property
    def shape(self): return (self.M, self.N, self.K)


def wrap(x):
    return (np.asarray(x) + np.pi) % (2*np.pi) - np.pi


def vandermonde(length, phase):
    return np.exp(1j*np.arange(length)[:, None]*np.atleast_1d(phase)[None, :])


def khatri_rao(*factors):
    out = factors[0]
    for factor in factors[1:]:
        out = np.einsum('il,jl->ijl', out, factor).reshape(-1, out.shape[1])
    return out


def reconstruct(factors):
    return np.einsum('ml,nl,kl->mnk', *factors, optimize=True)


def model_factors(cfg, delay_s, doppler_hz, angles_rad, gains, offset_s, cfo_hz):
    return [vandermonde(cfg.M, 2*np.pi*cfg.spacing_wavelengths*np.sin(angles_rad))*gains,
            vandermonde(cfg.N, -2*np.pi*cfg.df*(np.asarray(delay_s)+offset_s)),
            vandermonde(cfg.K, 2*np.pi*cfg.symbol_s*(np.asarray(doppler_hz)+cfo_hz))]


def observed_link(cfg, delay_s, doppler_hz, rx_angles_rad, tx_angles_rad,
                  alpha, beamformer, pilot, offset_s, cfo_hz, noise):
    """Eqs.1-4: antenna channel and beamforming retained as effective gain.

    pilot is [N,K]; noise is pre-pilot-division [M,N,K].
    """
    at = vandermonde(cfg.M, 2*np.pi*cfg.spacing_wavelengths*np.sin(tx_angles_rad))
    effective = np.asarray(alpha) * (at.T @ np.asarray(beamformer))  # transpose, not H
    fs = model_factors(cfg, delay_s, doppler_hz, rx_angles_rad, effective, offset_s, cfo_hz)
    return reconstruct(fs)*pilot[None, :, :] + noise


def remove_pilots(observation, pilot):
    pilot = np.asarray(pilot)
    if not np.all(np.isfinite(pilot)) or np.any(np.abs(pilot) < 1e-12):
        raise ValueError('Known nonzero pilots are required')
    if observation.shape[1:] != pilot.shape: raise ValueError('Pilot shape mismatch')
    return observation / pilot[None, :, :]


def project_column(x, oversampling=16):
    """Eqs.24-25 correlation search; refine every sampled local maximum.

    The dense FFT brackets and bounded scalar minimizers are an explicit
    numerical choice. A continuous global optimum is not formally certified.
    """
    q = len(x)
    if q < 2 or not np.all(np.isfinite(x)) or np.linalg.norm(x) < 1e-14:
        raise ValueError('Unidentifiable or nonfinite factor column')
    size = oversampling * (1 << int(np.ceil(np.log2(q))))
    power = np.abs(np.fft.fft(x, n=size))**2
    candidates = np.flatnonzero((power >= np.roll(power, 1)) & (power >= np.roll(power, -1)))
    n = np.arange(q)
    def objective(p): return -abs(np.vdot(np.exp(1j*n*p), x))**2
    step = 2*np.pi/size
    peaks = []
    for j in candidates:
        p0 = j*step
        opt = minimize_scalar(objective, bounds=(p0-step, p0+step),
                              method='bounded', options={'xatol': 1e-12, 'maxiter': 80})
        peaks.append((float(opt.fun), float(wrap(opt.x)), bool(opt.success)))
    peaks.sort()
    if not peaks: raise RuntimeError('No projection bracket found')
    value, phase, successful = peaks[0]
    v = np.exp(1j*n*phase)
    amplitude = np.vdot(v, x)/q
    return amplitude*v, phase, {'candidate_count': len(peaks),
        'optimizer_success': successful, 'peak_power': -value,
        'runner_up_power': -peaks[1][0] if len(peaks)>1 else None}


def column_phase(x):
    if len(x)<2 or np.linalg.norm(x[:-1]) < 1e-14: raise ValueError('No factor slope')
    return float(np.angle(np.vdot(x[:-1], x[1:])))


def factor_phases(factors):
    return np.array([[column_phase(f[:, l]) for l in range(f.shape[1])] for f in factors])


def normalize_scales(factors):
    fs = [f.copy() for f in factors]
    for axis in (1, 2):
        scale = fs[axis][0].copy()
        if np.any(np.abs(scale)<1e-14): raise ValueError('Vanishing CP column')
        fs[axis] /= scale
        fs[0] *= scale
    return fs


def factors_from_phases(y, phases):
    fs = [vandermonde(q, p) for q, p in zip(y.shape, phases)]
    d = khatri_rao(*fs)
    gain = np.linalg.lstsq(d, y.reshape(-1), rcond=1e-12)[0]
    fs[0] *= gain
    return fs


def mode_update(y, factors, axis, structured=True, oversampling=16):
    other = [a for a in range(3) if a != axis]
    d = khatri_rao(*(factors[a] for a in other))
    e = np.moveaxis(y, axis, -1).reshape(-1, y.shape[axis])
    unconstrained = np.linalg.lstsq(d, e, rcond=1e-12)[0].T
    meta = {'design_rank': int(np.linalg.matrix_rank(d)),
            'design_condition': float(np.linalg.cond(d))}
    if not structured: return unconstrained, meta
    columns, projections = [], []
    for column in unconstrained.T:
        projected, phase, evidence = project_column(column, oversampling)
        columns.append(projected)
        projections.append({'phase_rad': phase, 'amplitude_real': float(projected[0].real),
                            'amplitude_imag': float(projected[0].imag), **evidence})
    meta['projections'] = projections
    return np.column_stack(columns), meta


def scpd(y, rank, cfg=Config(), initial=None, structured=True):
    """Algorithm1 update order A,B,C; retains nonmonotone steps and failures.

    No best-iterate restoration and no truth-assisted restart are performed.
    """
    if y.ndim!=3 or min(y.shape)<2 or not np.all(np.isfinite(y)):
        raise ValueError('A finite three-dimensional tensor is required')
    if rank < 1 or rank > 4: raise ValueError('Bounded reference supports known L=1..4')
    init = cpvdm_smooth(y, rank) if initial is None else initial
    factors = [f.copy() for f in init['factors']]
    residual = float(np.linalg.norm(reconstruct(factors)-y))
    trace = [{'iteration': 0, 'residual_norm': residual}]
    converged = False
    for iteration in range(1, cfg.iterations+1):
        substeps = []
        for axis in range(3):
            factors[axis], diagnostic = mode_update(y, factors, axis, structured, cfg.projection_oversampling)
            substeps.append({'axis': axis, 'residual_norm': float(np.linalg.norm(reconstruct(factors)-y)), **diagnostic})
        factors = normalize_scales(factors)
        new = float(np.linalg.norm(reconstruct(factors)-y))
        relative = abs(new-residual)/max(residual, np.finfo(float).tiny)
        trace.append({'iteration': iteration, 'residual_norm': new,
                      'relative_change': relative, 'substeps': substeps})
        residual = new
        if relative < cfg.tolerance:
            converged = True
            break
    return {'factors': factors, 'phases': factor_phases(factors), 'trace': trace,
            'stopping_condition_met': converged, 'iterations': iteration,
            'residual_norm': residual, 'initializer': init['method'],
            'method': 'SCPD-Algorithm1' if structured else 'unstructured-ALS-diagnostic'}


def cpvdm_smooth(y, rank, window=None):
    """Three-axis smoothed algebraic CP variant from main-paper Eqs.29-35.

    This is explicitly NOT certified to match the unspecified CP-VDM settings
    used in the paper figures. It uses one jointly paired spatial eigensystem.
    """
    shape = y.shape
    p = tuple(min(q, v) for q,v in zip(shape, (4,8,5))) if window is None else tuple(window)
    if min(p)<2 or any(a>b for a,b in zip(p,shape)): raise ValueError('Invalid smoothing window')
    q = tuple(a-b+1 for a,b in zip(shape,p))
    if min(np.prod(p), np.prod(q)) < rank: raise ValueError('Insufficient smoothing dimensions')
    # Exact selection/window matrix is implicit, preserving source C-order vec.
    hankel = np.lib.stride_tricks.sliding_window_view(y, p).reshape(np.prod(q), np.prod(p)).T.copy()
    covariance = hankel @ hankel.conj().T
    eigenvalues, u = eigh(covariance, subset_by_index=[len(covariance)-rank, len(covariance)-1])
    u = u[:, ::-1]
    grid = np.arange(np.prod(p)).reshape(p)
    lo = grid[:-1,:,:].ravel(); hi = grid[1:,:,:].ravel()
    shift = np.linalg.lstsq(u[lo], u[hi], rcond=1e-12)[0]
    generators, mixing = np.linalg.eig(shift)
    paired = u @ mixing
    phase = np.empty((3,rank))
    phase[0] = np.angle(generators)
    for l in range(rank):
        cube = paired[:,l].reshape(p)
        # Rank-one contraction over all known spatial entries, then first rows.
        av = np.exp(1j*np.arange(p[0])*phase[0,l])
        bc = np.einsum('m,mnk->nk', av.conj(), cube)/p[0]
        phase[1,l] = column_phase(bc[:,0])
        phase[2,l] = column_phase(bc[0,:])
    fs = factors_from_phases(y, phase)
    return {'factors': fs, 'phases': phase, 'method': 'three-axis-smoothed-CP-variant',
            'window': p, 'shifts': q, 'subspace_eigenvalues': eigenvalues[::-1].tolist(),
            'shift_condition': float(np.linalg.cond(u[lo])),
            'residual_norm': float(np.linalg.norm(reconstruct(fs)-y))}


def esprit_ls(y, rank):
    """Appendix B: delay-unfolding ESPRIT, LS, rank-one SVD separation.

    Explicit right-vector conjugation handles X=u*s*v^H rather than u*s*v^T.
    """
    m,n,k = y.shape
    unfold = y.transpose(1,0,2).reshape(n,m*k)
    covariance = unfold @ unfold.conj().T
    _, u = eigh(covariance, subset_by_index=[n-rank,n-1])
    generators = np.linalg.eigvals(np.linalg.lstsq(u[:-1],u[1:],rcond=1e-12)[0])
    b = vandermonde(n,np.angle(generators))
    ac = np.linalg.lstsq(b,unfold,rcond=1e-12)[0]
    phases = np.empty((3,rank)); phases[1] = np.angle(generators)
    fs = [np.empty((m,rank),complex),b,np.empty((k,rank),complex)]
    for l in range(rank):
        left,s,right_h = np.linalg.svd(ac[l].reshape(m,k),full_matrices=False)
        fs[0][:,l] = left[:,0]*s[0]
        fs[2][:,l] = right_h[0,:] # equals conjugate of conventional right vector
        phases[0,l] = column_phase(fs[0][:,l])
        phases[2,l] = column_phase(fs[2][:,l])
    return {'factors': fs, 'phases': phases, 'method': 'ESPRIT-LS-AppendixB',
            'residual_norm': float(np.linalg.norm(reconstruct(fs)-y))}


def pair_parameters(result1, result2, cfg=Config()):
    """Eq26-27 with principal interval; never unwrap using truth.

    Bounds must ensure each composite phase lies strictly in (-pi,pi).
    Means are permutation-invariant; association minimizes phase variances.
    """
    p1,p2 = np.asarray(result1['phases']),np.asarray(result2['phases'])
    if p1.shape!=p2.shape or p1.shape[0]!=3: raise ValueError('Incompatible ranks')
    rank = p1.shape[1]
    choices = []
    for perm in permutations(range(rank)):
        difference = p1[1:]-p2[1:,perm]
        score = float(np.var(difference,axis=1).sum())
        choices.append((score,perm))
    choices.sort()
    score, perm = choices[0]
    pp2 = p2[:,perm]
    angles1 = np.arcsin(np.clip(p1[0]/(2*np.pi*cfg.spacing_wavelengths),-1,1))
    angles2 = np.arcsin(np.clip(pp2[0]/(2*np.pi*cfg.spacing_wavelengths),-1,1))
    return {'offset2_s': float(np.mean(p1[1]-p2[1])/(4*np.pi*cfg.df)),
            'cfo2_hz': float(np.mean(p2[2]-p1[2])/(4*np.pi*cfg.symbol_s)),
            'delay_s': -(p1[1]+pp2[1])/(4*np.pi*cfg.df),
            'doppler_hz': (p1[2]+pp2[2])/(4*np.pi*cfg.symbol_s),
            'angles1_rad': angles1, 'angles2_rad': angles2,
            'permutation': list(perm), 'association_score': score,
            'association_gap': choices[1][0]-score if len(choices)>1 else None,
            'association_scores': [{'permutation':list(p),'score':s} for s,p in choices],
            'ambiguous_association': len(choices)>1 and choices[1][0]-score<1e-10,
            'principal_interval_only': True}


def identifiability(factors, window):
    """Numerical check of sufficient source Eq28, not noisy performance proof."""
    p = window; q = tuple(len(f)-x+1 for f,x in zip(factors,p))
    lhs = khatri_rao(factors[0][:p[0]-1],factors[1][:p[1]],factors[2][:p[2]])
    rhs = khatri_rao(*(f[:k] for f,k in zip(factors,q)))
    singular = [np.linalg.svd(x,compute_uv=False) for x in (lhs,rhs)]
    rank = factors[0].shape[1]
    phases = factor_phases(factors)
    separations = [min([abs(wrap(a-b)) for a,b in permutations(row,2)] or [np.inf]) for row in phases]
    return {'rank_L': rank, 'ranks': [int(np.linalg.matrix_rank(x)) for x in (lhs,rhs)],
            'min_singular_values': [float(s[-1]) for s in singular],
            'distinct_generator_margins_rad': separations,
            'sufficient_condition_numerically_met': bool(all(np.linalg.matrix_rank(x)==rank for x in (lhs,rhs)) and min(separations)>1e-10)}


def nuisance_fim(cfg, delay_s, doppler_hz, angles, gains, offset2_s, cfo2_hz, variances):
    """Evaluation-only Fisher matrix, unknown complex effective gains retained.

    Parameters are normalized phases [b_l,c_l,a1_l,a2_l,b_offset,c_offset,
    Re(g1_l),Im(g1_l),Re(g2_l),Im(g2_l)]. Phase normalization avoids SI-unit
    ill-conditioning. Its inverse is NOT a claim that CALS reaches the CRB.
    """
    rank = len(delay_s); count=8*rank+2
    jacobians=[]
    for link,sign in enumerate((-1,1)):
        fs=model_factors(cfg,delay_s,doppler_hz,angles[link],gains[link],
                         sign*offset2_s,sign*cfo2_hz)
        j=np.zeros((np.prod(cfg.shape),count),complex)
        for l in range(rank):
            component=np.einsum('m,n,k->mnk',fs[0][:,l],fs[1][:,l],fs[2][:,l])
            bder=1j*np.arange(cfg.N)[None,:,None]*component
            cder=1j*np.arange(cfg.K)[None,None,:]*component
            ader=1j*np.arange(cfg.M)[:,None,None]*component
            j[:,l]=bder.ravel();j[:,rank+l]=cder.ravel()
            j[:,(2+link)*rank+l]=ader.ravel()
            j[:,4*rank]+=sign*bder.ravel();j[:,4*rank+1]+=sign*cder.ravel()
            unit=np.einsum('m,n,k->mnk',vandermonde(cfg.M,2*np.pi*cfg.spacing_wavelengths*np.sin(angles[link][l]))[:,0],fs[1][:,l],fs[2][:,l])
            j[:,4*rank+2+2*link*rank+l]=unit.ravel()
            j[:,4*rank+2+(2*link+1)*rank+l]=1j*unit.ravel()
        jacobians.append(j/np.sqrt(variances[link]))
    j=np.vstack(jacobians)
    fim=2*np.real(j.conj().T@j)
    eigen=np.linalg.eigvalsh(fim)
    numerical_rank=int(np.linalg.matrix_rank(fim,tol=max(eigen[-1],1)*1e-11))
    return {'matrix':fim,'rank':numerical_rank,'parameter_count':count,
            'eigenvalues':eigen,'covariance':np.linalg.inv(fim) if numerical_rank==count else None}
