'use strict';
const fs=require('node:fs'),path=require('node:path'),L=require('../js/linalg.js');
let seed=47121;
function random(){seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296-.5}
const failures=[];let maxResidual=0;
for(let t=0;t<500;t++){
  const m=3+t%10,n=3+t%11,A=L.mat(m,2),B=L.mat(2,n);
  for(let i=0;i<A.data.length;i++)A.data[i]=random();for(let i=0;i<B.data.length;i++)B.data[i]=random();
  const X=L.multiply(A,B);
  try{const d=L.svd(X);maxResidual=Math.max(maxResidual,d.diagnostics.residualRelative);if(d.rank!==2)failures.push({case:t,rank:d.rank});}
  catch(e){failures.push({case:t,error:e.message,diagnostics:e.diagnostics})}
}
const report={seed:47121,cases:500,description:'Fresh complex exact-rank-two tall and wide matrices from random products; SVD rank and reconstruction certificates',failures,maxReconstructionResidual:maxResidual};
fs.writeFileSync(path.join(__dirname,'linalg_stress_report.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report,null,2));if(failures.length)process.exitCode=1;
