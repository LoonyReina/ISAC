"""Fresh NumPy oracle against actual dependency-free JavaScript implementation."""
import json, subprocess, itertools, time
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
rng=np.random.default_rng(10222026)
def rand(m,n): return (rng.normal(size=(m,n))+1j*rng.normal(size=(m,n)))/np.sqrt(2)
def ser(A): return {'rows':A.shape[0],'cols':A.shape[1],'data':np.stack([A.real,A.imag],axis=-1).ravel().tolist()}
def des(A):
    x=np.asarray(A['data']).reshape(A['rows'],A['cols'],2)
    return x[:,:,0]+1j*x[:,:,1]
def qr(m,n): return np.linalg.qr(rand(m,n))[0]
tasks=[];expected={}
def add(op,name,A,**kwargs):
    spec=dict(op=op,name=name,A=ser(A));expected[name]=dict(A=A,**kwargs)
    for k,v in kwargs.items(): spec[k]=ser(v) if isinstance(v,np.ndarray) and v.ndim==2 else v
    tasks.append(spec)
for m,n in [(1,1),(8,3),(3,8),(36,3),(8,12),(12,8),(3,3),(12,12)]:
    A=rand(m,n);add('svd',f'svd-{m}-{n}',A);add('adj',f'adj-{m}-{n}',A)
    add('ls',f'ls-{m}-{n}',A,B=rand(m,4))
for singular in [[1,1e-3,1e-8],[1,1e-6,1e-11],[1,1e-3,1e-13],[1,1e-5,0]]:
    A=qr(25,3)@np.diag(singular)@qr(3,3).conj().T
    add('ls',f'ls-controlled-{singular[-1]}',A,B=rand(25,3))
    add('svd',f'svd-controlled-{singular[-1]}',A)
A=rand(23,3);A[:,2]=A[:,0]+(2+3j)*A[:,1]
add('ls','ls-exact-rank-loss',A,B=rand(23,2));add('ls','ls-rank-throws',A,B=rand(23,2),options={'requireFullRank':True})
for n in [1,2,3,8,36,160]:
    A=rand(n,n);A=A+A.conj().T
    add('herm',f'herm-dense-{n}',A,rank=min(n,3))
    Z=rand(n,min(n,3));A=Z@Z.conj().T+1e-6*np.eye(n)
    add('herm',f'herm-lowrank-{n}',A,rank=min(n,3))
for n in [1,2,3]:
    for t in range(30):add('eig',f'eig-{n}-{t}',rand(n,n))
for sep in [1e-3,1e-6,1e-8]:
    V=rand(3,3);A=V@np.diag([1,1+1j*sep,-.2+.3j])@np.linalg.inv(V)
    add('eig',f'eig-close-{sep}',A)
add('eig','eig-defective',np.array([[1,1,0],[0,1,1],[0,0,1]],complex))
for m,n in [(8,12),(12,8),(1,12),(12,1)]:
    A=rand(m,1)@rand(1,n)+.01*rand(m,n);add('rank1',f'rank1-{m}-{n}',A)
add('product','complex-adjoint-product',rand(17,3),B=rand(3,11))
start=time.time();out=json.loads(subprocess.run(['node',str(ROOT/'tests/linalg_runner.cjs')],input=json.dumps(tasks),capture_output=True,text=True,check=True).stdout)
results=[]
for item in out:
    name,op=item['name'],item['op'];e=expected[name];A=e['A'];metrics={};passed=True
    if name in ['eig-defective','ls-rank-throws']:
        passed='error' in item
        results.append(dict(name=name,passed=passed,expectedError=item.get('error'),elapsedMs=item['elapsedMs']));continue
    if 'error' in item:
        results.append(dict(name=name,passed=False,error=item['error'],diagnostics=item.get('diagnostics')));continue
    r=item['result'];tol=1e-10
    if op=='adj':metrics['relative']=float(np.linalg.norm(des(r)-A.conj().T)/np.linalg.norm(A))
    elif op=='product':metrics['relative']=float(np.linalg.norm(des(r)-A@e['B'])/np.linalg.norm(A@e['B']))
    elif op=='svd':
        U,Vh,s=des(r['U']),des(r['Vh']),np.array(r['values']);truth=np.linalg.svd(A,compute_uv=False)
        metrics['reconstruction']=float(np.linalg.norm((U*s)@Vh-A)/np.linalg.norm(A))
        metrics['spectrumNormwise']=float(np.linalg.norm(s-truth)/np.linalg.norm(truth))
        retained=truth>1e-12*truth[0]
        metrics['retainedRelativeSV']=float(np.max(np.abs(s[retained]-truth[retained])/truth[retained]))
        passed=metrics['reconstruction']<tol and metrics['spectrumNormwise']<tol and metrics['retainedRelativeSV']<1e-4
    elif op=='ls':
        x,s=des(r['solution']),np.array(r['singularValues']);truth,_,rank,st=np.linalg.lstsq(A,e['B'],rcond=1e-12)
        metrics['relativeSolution']=float(np.linalg.norm(x-truth)/max(np.linalg.norm(truth),1e-300))
        metrics['rank']=r['rank'];metrics['numpyRank']=int(rank)
        metrics['residualNormDifference']=float(abs(np.linalg.norm(A@x-e['B'])-np.linalg.norm(A@truth-e['B']))/np.linalg.norm(e['B']))
        metrics['normalResidual']=r['normalResidualRelative']
        # Forward error may grow as kappa*eps; compare against dimension-aware bound.
        kappa=st[0]/st[rank-1] if rank else 1; bound=max(1e-10,200*np.finfo(float).eps*kappa)
        metrics['forwardBound']=float(bound)
        passed=metrics['relativeSolution']<bound and r['rank']==int(rank) and metrics['normalResidual']<1e-10
    elif op=='herm':
        values,vectors=np.array(r['values']),des(r['vectors']);truth,U=np.linalg.eigh(A);rank=e['rank'];truth=truth[::-1][:rank];U=U[:,::-1][:,:rank]
        metrics['spectrumRelative']=float(np.linalg.norm(values-truth)/max(np.linalg.norm(truth),1e-300))
        metrics['residual']=float(np.linalg.norm(A@vectors-vectors*values)/max(np.linalg.norm(A),1e-300))
        metrics['projector']=float(np.linalg.norm(vectors@vectors.conj().T-U@U.conj().T))
        passed=max(metrics.values())<tol
    elif op=='eig':
        values=np.array([complex(*z) for z in r['values']]);v=des(r['vectors']);truth=np.linalg.eigvals(A)
        metrics['spectrumRelative']=float(min(np.linalg.norm(values-truth[list(p)]) for p in itertools.permutations(range(len(truth))))/max(np.linalg.norm(truth),1e-300))
        metrics['residual']=float(np.linalg.norm(A@v-v*values)/max(np.linalg.norm(A),1e-300))
        tol=1e-7 if 'close' in name else 1e-10;passed=max(metrics.values())<tol
    elif op=='rank1':
        left=np.array(r['left']).reshape(-1,2);left=left[:,0]+1j*left[:,1]
        right=np.array(r['rightH']).reshape(-1,2);right=right[:,0]+1j*right[:,1]
        u,s,vh=np.linalg.svd(A,full_matrices=False)
        metrics['rank1Relative']=float(np.linalg.norm(r['sigma']*left[:,None]*right[None,:]-s[0]*u[:,0,None]*vh[0,None,:])/s[0])
        metrics['residualError']=float(abs(r['residual']-np.linalg.norm(s[1:])/np.linalg.norm(s)))
        passed=max(metrics.values())<tol
    if op in ['adj','product']:passed=max(metrics.values())<tol
    results.append(dict(name=name,passed=bool(passed),metrics=metrics,elapsedMs=item['elapsedMs']))
report=dict(seed=10222026,method='Fresh NumPy matrices; actual Node JS module with independent NumPy linalg comparisons',total=len(results),passed=sum(x['passed'] for x in results),elapsedSeconds=time.time()-start,results=results)
(ROOT/'tests/linalg_oracle_report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='results'},indent=2))
for r in results:
    if not r['passed']:print('FAIL',json.dumps(r))
print('Hermitian timings',[(r['name'],round(r.get('elapsedMs',0),2)) for r in results if r['name'].startswith('herm-')])
assert report['passed']==report['total']
