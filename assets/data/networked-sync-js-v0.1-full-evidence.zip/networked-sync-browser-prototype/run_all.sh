#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
mkdir -p reports
node tests/test-kernel.cjs | tee reports/kernel-tests.log
python tests/verify_evaluation.py | tee reports/evaluation-oracle.log
node tests/linalg_contract.cjs | tee reports/linalg-contract.log
node tests/linalg_stress.cjs | tee reports/linalg-stress.log
python tests/linalg_oracle.py > reports/linalg-oracle.log
node tests/test-codec.cjs | tee reports/codec-tests.log
node tests/test-worker.cjs | tee reports/worker-tests.log
node tests/verify-oracles.cjs | tee reports/oracle-parity.log
node tests/verify-oracles.cjs --emit-generated > reports/oracle-js-generation-export.log
python tests/generate-oracles.py --verify-js-generated oracle/js-generated-inputs.json > reports/oracle-js-generation.log
node tests/benchmark.cjs | tee reports/resource-benchmark.log
printf '\nAll owner verification commands passed. This does not certify an actual browser.\n'
