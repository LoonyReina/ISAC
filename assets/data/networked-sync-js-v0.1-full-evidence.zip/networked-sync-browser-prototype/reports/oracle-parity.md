# Fresh receiver oracle audit

Result: **11,121/11,121 checks passed**, no failed checks. Run completed 2026-10-12T22:20:30.382Z.

## What was actually executed

- Newly generated, independently seeded raw reciprocal tensors, not reused accepted experiment observations
- Ten complete numerical parity cases: original 10×36×20, L=1/L=2 and engineering-bound L=3; original L=2 at −20 dB; compact 6×12×8, L=1/2/3; compact L=3 at −16 dB; compact L=2 principal-phase wrapping and near-collision stress cases
- One exact rank-one tensor requested with L=2, checked for explicit failure rather than invented identifiable factors
- The same held observations and known unit-modulus pilots are given to accepted Python and freshly run JavaScript
- All four methods: source-derived structured CP refinement, declared three-axis-smoothed CP variant, Appendix-B ESPRIT/LS/SVD separation, and unstructured ALS diagnostic
- 132 structured substeps and 354 unstructured substeps, with every unconstrained LS column, intermediate factor set, residual, rank, condition estimate, and stopping decision checked
- 288 actual structured projection grids and candidate-index sets, including wrapped phases, peak/runner-up ratios, and optimizer success
- Final and intermediate factors normalized for CP scale gauge and matched by exhaustive component permutation; reciprocal pairing is checked in the corresponding component coordinates
- Thirty-six projection primitive cases: twelve separate arbitrary-complex or single-tone inputs, each at all supported oversampling settings 8/16/32; six complex LS systems including exact rank deficiency, ill conditioning, and an underdetermined minimum-norm solve
- Tied association, invalid zero/short columns, nonunit/zero pilots, nonfinite observations, shape mismatch, and hidden-truth request rejection

The verifier passes only each fixture's `request` to the receiver. `expected` and `evaluationOnly` never enter its API. The held result must have no truth or evaluator output. Source-like clean-scene accuracy and geometry success are not inferred from parity.

## Observed maximum differences

| Quantity | Maximum observed | Acceptance limit |
|---|---:|---:|
| Final factor phases, radians | 8.634e-08 | 1.0e-06 |
| Intermediate/final normalized factor relative error | 1.053e-06 | 2.0e-05 |
| Final residual relative error | 3.539e-09 | 5.0e-06 |
| Every substep residual relative error | 1.933e-06 | 5.0e-06 |
| Structured projection phase, radians | 1.052e-07 | 1.0e-06 |
| Projection grid normalized shape relative error | 4.436e-07 | 2.0e-06 |
| Arbitrary complex LS primitive relative error | 3.198e-11 | 2e-8 (2e-5 ill-conditioned) |

Exact grid indices match, including all sampled local maxima. Grid shape comparisons and LS-column shape comparisons remove the mathematically irrelevant per-column scaling accumulated in CP. Independent primitive tests additionally compare absolute raw LS solutions and full absolute projection powers. Numerical traces retain their nonmonotone steps; the harness does not replace iterates with a best fit.

## Independent actual JavaScript generator check

Six actual JavaScript-generated observation pairs were saved and recomputed by both accepted `observed_link` and a full independent scalar Eq. 1/2 sum over receive antenna, subcarrier, symbol, target, and transmit antenna. All twelve directional tensors passed. Maximum scalar-equation raw observation error: **1.417e-14**.

Coverage includes compact L=1/L=3, original L=2 at low SNR, principal-phase wrapping, close targets, and zero gain/noise. Effective beamformed gain uses the required ordinary transpose, not a conjugate transpose. Source alpha-energy noise variance and received SNR metadata are checked separately. The intentionally wrapped case reports `principal_interval_valid: false`; ordinary sampled cases report true.

The arbitrary Python parity fixtures choose their noise from received clean power for stress-test construction. This is not a claim to reproduce the paper's source SNR sweep. The actual JS generator uses the declared source alpha-energy variance convention, which is independently verified.

## Deliberate boundaries and implementation differences

- Browser v0.1 supports known **unit-modulus** pilots only. The accepted Python routine also accepts nonunit nonzero pilots; that wider domain is intentionally outside this port's scope
- The browser continuous projection solver uses golden-section refinement of the same FFT local-maximum brackets and objective. Python uses SciPy bounded minimization. Their small measured differences are retained, not hidden
- For an exact rank-deficient observation, the browser rejects an observed rank loss at the initializer. Accepted Python can return arbitrary null-space initializer directions and fail in later routines. This test is an explicit honest-failure safety check, not equality of non-unique factors
- The shared initializer is an adapted three-axis-smoothed CP variant, not certified as the exact author CP-VDM configuration
- These are fresh **Node** calculations from raw data. Stored fixtures and reports are regression evidence, not a fresh browser execution, browser latency measurement, Monte Carlo curve reproduction, global-optimum certificate, or full-paper reproduction

## Reproduce from the source-free artifact

Python dependencies: NumPy and SciPy. Generation used Python 3.12.14, NumPy 2.3.5, SciPy 1.17.0. JavaScript verification used v24.19.0. From the artifact root:

```sh
python tests/generate-oracles.py
node tests/verify-oracles.cjs
node tests/verify-oracles.cjs --emit-generated
python tests/generate-oracles.py --verify-js-generated oracle/js-generated-inputs.json
```

`node tests/verify-oracles.cjs --case original-l2` selects one case. The projection/LS primitives still run. `--oracle` and `--report` select alternative fixture/report locations. An external accepted Python file can be supplied using `--reference`; any hash other than the pin is rejected.

The bundled `tests/reference/sync_core.py` is original accepted implementation code, not paper source or author software. It preserves the exact accepted bytes so this artifact does not require a sibling workspace. No paper PDF, extracted paper text, artwork, or author CP-VDM source is included.

## Pinned provenance

- Accepted Python: `88a161d7d7d55ad4a2e703b0afb590c69644b0c61eaf370c2f6f519fc650f10e`
- JavaScript receiver: `473e7739d35a7dcde7807edb0627a9f0058a4d193518a6c8cfa6745a6218de98`
- JavaScript linear algebra: `7d5983a18f3bf1b54db5076944bc12e84c9489059dc66481fcba277f65bdaafc`
- Generator: `315c58bde35dc30ec7d9f2e774c4202ee89fcb85200ccdba4e67135f464e42d9`

The fixture manifest independently hashes every stored case. Machine-readable details: `oracle-parity.json`, `oracle-js-generation.json`, and `../oracle/manifest.json`.
