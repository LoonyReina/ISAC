#!/usr/bin/env bash
# Portable launcher; review mathematics/scripts are unchanged.
set -euo pipefail
cd "$(dirname "$0")/independent-review"
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 BLIS_NUM_THREADS=1
PY="${CRB_PYTHON:-python3}"
"$PY" review.py --prepare
node driver.js > execution.log
node probe_rank.js > rank-probe.log
node browser_mode_vm.js > browser-mode-vm.log
"$PY" review.py --check ../results/conditioned/nt*.json ../results/held-channel/*.js.json > check.log
"$PY" check_drs.py > drs.log
"$PY" summarize.py
