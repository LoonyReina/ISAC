# Genuine multiuser CRB point-target JavaScript prototype

This standalone package executes journal Eq.(33) as a real covariance SDP from editable complex H. It contains no stored-solution lookup, single-user substitute or interpolation. No production, UI, GitHub or browser execution was performed.

Read `PORT-PLAN.md`, `API.md` and `independent-review/` before integration. Extended-target optimization remains a distinct unimplemented browser gate.

## Run

Node24:

```sh
node js/run-one.cjs oracle/routine/nt4-k2-g10-theta0-seed290102.input.json result.json
node js/run-conditioned.cjs
node js/test-lifecycle.cjs
```

Browser-capable scripts are `js/hermitian.js`, `js/linalg.js`, `js/core.js`, and `js/worker.js`. The Node worker adapter is testing-only. These runtime files have no external package dependencies.

Pinned scientific packages are in `python-reference/requirements.txt`. The embedded reference.py is an exact hash-verified copy of the independently reviewed frozen Python implementation; JavaScript never reads it or its solutions. Oracle regeneration is portable:

```sh
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python oracle/generate_oracles.py
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python run_held_channel_sweep.py
```

For a fresh independent audit in a working copy, run `CRB_PYTHON=/path/to/scientific/python bash run_independent_review.sh` (defaults to python3). The original reviewer launcher retains its recorded environment-relative path; this top-level wrapper is portable.

`CRB_REFERENCE_DIR` can explicitly select another unpacked reference directory for oracle generation. No author PDF/code or unrecognized executable download is bundled.

## Evidence

- `oracle/`: fresh Python results, all warnings/failures, source hash and474 validation checks
- `results/default/`: initial rho1 outcomes, including feasible-but-capped cases
- `results/conditioning/`: explicit numerical-conditioning experiments
- `results/conditioned-v02/`: pre-hardening conditioned results retained
- `results/conditioned/`: final reviewed-runtime fresh results
- `results/lifecycle/`: caps, snapshot safety, cancel/replacement and input rejection
- `results/held-channel/`: newly solved common-H threshold comparison, no resource changes
- `independent-review/`: separate actual-JS replay, physical/Fisher/dual checks, retained defect probes and corrections
- `teaching/`: design notes only; no UI implementation

Node wall times are not browser control-to-result latency. A result is usable as an accepted design only if status is `converged` and physicalGate.passed is true. Inspect all residuals/rank/SINRs and preserve rejected outputs.
