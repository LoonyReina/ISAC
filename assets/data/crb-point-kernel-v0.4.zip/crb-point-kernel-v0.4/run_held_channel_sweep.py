"""Five fresh solves at one fixed H and unchanged resources; not oracle interpolation."""
from pathlib import Path
import os,sys,json,subprocess,hashlib
for key in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS']:os.environ[key]='1'
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'python-reference'));sys.dont_write_bytecode=True
import reference as r
import numpy as np
base=json.loads((ROOT/'oracle/routine/nt4-k2-g10-theta0-seed290102.input.json').read_text());H=np.array(base['H']['real'])+1j*np.array(base['H']['imag']);c=r.Config(nt=base['Nt'],nr=base['Nr'],snapshots=base['L'],power_mw=base['powerMw'],communication_noise_mw=base['communicationNoiseMw'],radar_noise_mw=base['radarNoiseMw'],theta_degrees=base['thetaDegrees'],alpha=complex(**{'real':base['alpha']['real'],'imag':base['alpha']['imag']}));out=ROOT/'results/held-channel';out.mkdir(exist_ok=True,parents=True);rows=[]
for db in [0,5,10,15,20]:
 inp={**base,'gammaDb':db};name=f'held-channel-g{db}';infile=out/(name+'.input.json');infile.write_text(json.dumps(inp,indent=2)+'\n')
 solver=r.finalize_solution(r.solve_sdr(H,np.full(c.nt//2,10**(db/10)),c,'point'),c);python_report=solver['report'];
 (out/(name+'.python.json')).write_text(json.dumps(python_report,indent=2,default=lambda x:x.item())+'\n')
 node=subprocess.run(['node',str(ROOT/'js/run-one.cjs'),str(infile),str(out/(name+'.js.json'))],check=True,text=True,capture_output=True);js=json.loads((out/(name+'.js.json')).read_text());rows.append({'gammaDb':db,'inputFile':infile.name,'pythonStatus':python_report['status'],'pythonAccepted':python_report['accepted'],'jsStatus':js['status'],'jsPassed':js['physicalGate']['passed'],'pythonNormalizedInformation':python_report['certificate']['feasible_objective_normalized'],'jsNormalizedInformation':js.get('metrics',{}).get('radar',{}).get('normalizedInformation'),'jsRootCrbDegrees':js.get('metrics',{}).get('radar',{}).get('rootCrbDegrees'),'nodeWallMs':js['outerWallMs']});print(node.stdout.strip(),flush=True)
values=[v['jsNormalizedInformation'] for v in rows];monotone=all(values[i+1]<=values[i]+1e-7 for i in range(len(values)-1));agreement=max(abs(v['pythonNormalizedInformation']-v['jsNormalizedInformation']) for v in rows)
summary={'description':'held-channel threshold sweep; every value comes from a fresh optimizer call; source units, reduced array','H_sha256':hashlib.sha256(np.ascontiguousarray(H,dtype='<c16').tobytes()).hexdigest(),'input_resources_unchanged_except_gamma':True,'monotone_within_1e-7':monotone,'max_js_python_information_difference':agreement,'passed':all(x['pythonAccepted'] and x['jsPassed'] for x in rows) and monotone and agreement<1e-5,'rows':rows}
(out/'index.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
