# Prospective point-target kernel API

## Entry points

CommonJS: `require('./js/core.js')`; browser global: `CrbMultiuserOptimizer`. Browser worker imports the three numerical scripts from its own folder.

`createSolver(input,options)` returns `step(count)`, `result(includeState)`, `cancel()` and read-only `status`. Inputs are deep-snapshotted; editing the caller's H or threshold during execution cannot change an existing run.

Input fields, all required:

- Nt, Nr, K, L: integer transmit/receive antennas, user count, snapshots
- powerMw, communicationNoiseMw, radarNoiseMw: linear mW, **not dBm**
- thetaDegrees: target direction used by the designer; receiver-estimation experiment is separate
- alpha: finite `{real,imag}`, nonzero finite squared magnitude; evaluation reflectivity
- H: `{real: K×Nt array, imag: K×Nt array}`; rows are h_k^H
- gammaDb: one common per-user SINR threshold, linear Gamma=10^(gammaDb/10)

Current mathematical prototype guard domain: Nt4..16; K2..4 with K<Nt; Nt<Nr<=24; Nt<L<=4096; positive finite power/noises, P<=1e6mW, communication-noise/P in[1e−5,1]; gammaDb−5..30, theta−60..60degrees; each complex H entry magnitude<=10. Passing these guards is **not** evidence that all such inputs have been benchmarked or converge within budget. Unknown top-level input/option keys are rejected. Finite nonzero output CRB is also an acceptance gate to fail closed on arithmetic overflow/underflow.

Recommended first teaching surface is narrower: Nt4/6/8, Nr=Nt+4, K2, L30, P1000mW, both noises1mW, alpha1, theta0, gamma0..20dB and editable H. Theta23degrees is covered in routine oracle tests; additional angles andK3 are independent-review stress evidence, not permission to claim exhaustive coverage.

## Options and stepping

Defaults: rho=clamp(Gamma,1,100), linearWeight10, relaxation1.6, memory10, safeguard1, maxIterations20000, tolerance1e−9, recordEvery100. Scalars are positive; relaxation<2, rho<=1000, linearWeight<=100, safeguard<=1, tolerance1e−11..1e−6. Integers: memory0..10, maxIterations1..50000, recordEvery>=1. `step(count)` accepts1..1000. memory0 runs the unaccelerated method. Options are exported with results.

These are resource budgets/conditioning, not model parameters or convergence guarantees. Source-size scaling batch explicitly caps5000iterations; its initial20k rho1 cap remains in evidence.

## Results and acceptance

Every terminal result includes version, original input/options, status, iterations, rankCondition, trace, timing, failureReason and physicalGate. Numerical states include Wks (physical mW), relaxedR, relaxedInformation, residuals and certificate. Recovered candidates include Wc (Nt×K, sqrt-mW), recovery eigen/rank residuals, and:

- metrics.powerMw and powerFraction
- metrics.users: desiredMw, interferenceMw, sinr, sinrDb, ratioToThreshold
- metrics.radar: s0/s1/s2, unknown-alpha-adjusted effectiveInformationWithoutScale, crbRad2, rootCrbDegrees, normalizedInformation

normalizedInformation=effectiveInformationWithoutScale/(P·||dA/dtheta||F²). It is not old single-user g. CRB is a local theoretical bound, not measured estimator error.

Only `status==='converged' && physicalGate.passed===true` is accepted. Gates include the theorem rank condition, per-beam relative rank-one residual<=1e−4, power/P<=1+2e−6, all recovered SINR/threshold>=1−2e−5, regular/finite positive CRB and numerical dual-information gap<=max(1e−7,1e−4×information), with a small negative gap tolerance2e−7. Certificate epigraph coefficient residual<=1e−9. Numerical tolerances do not constitute exact proofs.

Other states: running, iteration_limit, numerical_rejection, numerical_failure, infeasible_bound, infeasible_certificate, rank_condition_not_met, cancelled. A capped iterate is not an infeasibility finding. A feasible relaxation lacking the theorem premise/rank recovery is not an accepted original beam design. Never display absent recovered metrics from an old run.

`result(true)` additionally exports complete x,z,w,rho for independent replay. Output timings are cloud Node measurements unless a real browser session separately measures them.

## Worker contract

Send `{type:'run',id,input,options?}` with nonnegative safe-integer id; cancel using `{type:'cancel',id}`. Worker emits progress, result, cancelled or error, always tagged withid. New run cancels the previous one. Chunks are16iterations; progress is rate-limited around100ms. Cancellation is handled between chunks, after the current initialization/step; this is not a hard real-time guarantee.

The caller must independently reject older IDs, immediately invalidate old results on input edits, and keep progress, cap, rank failure, mathematical infeasibility and numerical failure distinct. Importing saved output is historical data until the input is rerun and checked with the current frozen kernel. Node worker_threads and VM branch tests are not actual-browser acceptance.
