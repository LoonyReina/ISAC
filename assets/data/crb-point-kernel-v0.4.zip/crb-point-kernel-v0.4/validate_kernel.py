"""Read-only exact-artifact checks; optional fresh Node smoke writes to /tmp only."""
from pathlib import Path
import json,hashlib,subprocess,tempfile,sys
ROOT=Path(__file__).resolve().parent
checks=[]
def ck(name,value):
 checks.append((name,bool(value)))
 if not value:print('FAILED',name)
manifest=ROOT/'ARTIFACT-MANIFEST.json'
if manifest.exists():
 data=json.loads(manifest.read_text())
 for f in data['files']:
  p=ROOT/f['path'];ck('exists '+f['path'],p.is_file())
  if p.is_file():ck('hash '+f['path'],p.stat().st_size==f['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==f['sha256'])
ck('no paper PDF',not list(ROOT.rglob('*.pdf')))
review=json.loads((ROOT/'independent-review/REVIEW.json').read_text());corehash=hashlib.sha256((ROOT/'js/core.js').read_bytes()).hexdigest();ck('reviewed current core',corehash=='208f4d91db12d5c24d8bff921a1f31806cea846cb3f1a3a6101f7520f2e335c1')
report=json.loads((ROOT/'KERNEL-REPORT.json').read_text());ck('13accepted bounded batch',report['accepted']==13);ck('five held-H passes',report['held_channel']['passed'] and report['held_channel']['points']==5);ck('lifecycle passes',report['worker_lifecycle']['passed'])
ck('review assertion count recorded', '194' in json.dumps(review))
for row in json.loads((ROOT/'results/conditioned/index.json').read_text()):
 r=json.loads((ROOT/row['outputFile']).read_text());ck(row['id']+' final version',r['version']=='crb-point-drs-v0.4-feasibility');ck(row['id']+' status consistent',(r['status']=='converged')==r['physicalGate']['passed'])
if '--smoke' in sys.argv:
 with tempfile.TemporaryDirectory(prefix='crb-js-smoke-') as temp:
  out=Path(temp)/'result.json';run=subprocess.run(['node',str(ROOT/'js/run-one.cjs'),str(ROOT/'oracle/routine/nt4-k2-g10-theta0-seed290102.input.json'),str(out)],check=True,text=True,capture_output=True);r=json.loads(out.read_text());ck('actual fresh Node smoke',r['status']=='converged' and r['physicalGate']['passed']);print('Smoke:',run.stdout.strip())
print(json.dumps({'passed':all(v for _,v in checks),'checks':len(checks),'failed':[n for n,v in checks if not v]},indent=2))
if not all(v for _,v in checks):raise SystemExit(1)
