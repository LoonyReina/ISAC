"""Independent NumPy/CVXPY reference for IEEE TSP 70 (2022) 240–253.
Physical powers are in mW. Internal V_k=W_k/P is a reversible scaling.
No author code, PDF redistribution, browser kernels, or production writes.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
import time, warnings
import numpy as np
import cvxpy as cp

@dataclass(frozen=True)
class Config:
    nt: int = 16
    nr: int = 20
    snapshots: int = 30
    power_mw: float = 1000.
    communication_noise_mw: float = 1.
    radar_noise_mw: float = 1.
    theta_degrees: float = 0.
    alpha: complex = 1.+0j

def herm(a): return (a+a.conj().T)/2

def real_embed(M): return cp.bmat([[cp.real(M),-cp.imag(M)],[cp.imag(M),cp.real(M)]])

def dual_unembed(D):
    n=D.shape[0]//2
    return herm(D[:n,:n]+D[n:,n:]+1j*(D[n:,:n]-D[:n,n:]))

def steering(n,theta):
    p=np.arange(n)-(n-1)/2
    a=np.exp(1j*np.pi*p*np.sin(theta))
    return a,1j*np.pi*p*np.cos(theta)*a

def matrices(c):
    a,ad=steering(c.nt,np.deg2rad(c.theta_degrees)); b,bd=steering(c.nr,np.deg2rad(c.theta_degrees))
    A=np.outer(b,a.conj()); D=np.outer(bd,a.conj())+np.outer(b,ad.conj())
    return A,D

def rayleigh(seed,k,n):
    r=np.random.default_rng(seed)
    return (r.normal(size=(k,n))+1j*r.normal(size=(k,n)))/np.sqrt(2)

def validate(c,H,gamma):
    H=np.asarray(H,complex); gamma=np.broadcast_to(np.asarray(gamma,float),(len(H),)).copy()
    if H.ndim!=2 or H.shape[1]!=c.nt or not np.isfinite(H).all() or not 1<=len(H)<=c.nt: raise ValueError('Invalid H')
    if any(not isinstance(x,(int,np.integer)) for x in [c.nt,c.nr,c.snapshots]) or not np.isfinite([c.power_mw,c.communication_noise_mw,c.radar_noise_mw,c.theta_degrees,complex(c.alpha).real,complex(c.alpha).imag]).all() or c.nt<2 or c.nr<=c.nt or c.snapshots<=c.nt or min(c.power_mw,c.communication_noise_mw,c.radar_noise_mw)<=0: raise ValueError('Invalid source-domain resources')
    if not np.isfinite(gamma).all() or np.any(gamma<=0): raise ValueError('Strictly positive SINR thresholds required')
    if np.any(np.linalg.norm(H,axis=1)==0): raise ValueError('Zero channel: positive SINR infeasible')
    return H,gamma

def point_metrics(R,c):
    A,D=matrices(c)
    s0=float(np.trace(A.conj().T@A@R).real)
    s1=complex(np.trace(D.conj().T@A@R))
    s2=float(np.trace(D.conj().T@D@R).real)
    effective=s2-abs(s1)**2/s0 if s0>0 else None
    out={'s0':s0,'s1_real':s1.real,'s1_imag':s1.imag,'s2':s2,'effective_information_without_scale':effective}
    regular=s0>1e-12*c.power_mw and effective is not None and effective>1e-12*max(s2,1) and abs(c.alpha)>0 and abs(c.theta_degrees)<90
    crb=c.radar_noise_mw/(2*abs(c.alpha)**2*c.snapshots*effective) if regular else None
    out.update(status='regular' if regular else 'singular',crb_rad2=crb,root_crb_degrees=np.rad2deg(np.sqrt(crb)) if crb is not None else None)
    return out

def extended_metrics(R,c):
    ev=np.linalg.eigvalsh(herm(R))
    finite=ev.min()>1e-10*c.power_mw
    obj=float(np.sum(1/ev)) if finite else None
    return {'eigenvalues_mw':ev.tolist(),'condition':float(ev.max()/ev.min()) if finite else None,'trace_inverse_per_mw':obj,'crb_G_frobenius_mse':c.radar_noise_mw*c.nr/c.snapshots*obj if finite else None,'status':'regular' if finite else 'singular'}

def beam_metrics(Wc,Wa,H,gamma,c):
    W=np.column_stack((Wc,Wa)); powers=abs(H@W)**2
    desired=np.diag(powers[:,:len(H)]).copy(); interf=powers.sum(axis=1)-desired
    sinr=desired/(interf+c.communication_noise_mw)
    p=float(np.sum(abs(W)**2)); ratios=sinr/gamma
    return {'power_mw':p,'power_fraction':p/c.power_mw,'desired_mw':desired.tolist(),'interference_mw':interf.tolist(),'sinr':sinr.tolist(),'sinr_db':(10*np.log10(sinr)).tolist(),'sinr_to_requirement':ratios.tolist(),'feasible_at_2e-5':bool(p<=c.power_mw*(1+2e-5) and np.min(ratios)>=1-2e-5)}

def factor_psd(R,relative_tolerance=2e-6):
    ev,U=np.linalg.eigh(herm(R)); scale=max(np.linalg.norm(R,2),1.)
    if ev.min()<-relative_tolerance*scale: raise ValueError(f'Non-PSD remainder {ev.min()}')
    B=U*np.sqrt(np.maximum(ev,0))[None,:]
    return B,{'min_eigenvalue_before_clip':float(ev.min()),'negative_mass_clipped':float(-np.minimum(ev,0).sum()),'factor_relative_residual':float(np.linalg.norm(B@B.conj().T-R)/scale)}

def recover_point(Wks):
    ws=[]; defects=[]; evals=[]
    for Q in Wks:
        ev,U=np.linalg.eigh(herm(Q)); evals.append(ev.tolist()); w=U[:,-1]*np.sqrt(max(ev[-1],0)); ws.append(w)
        defects.append(float(np.linalg.norm(Q-np.outer(w,w.conj()))/max(np.linalg.norm(Q),1e-30)))
    return np.column_stack(ws),{'method':'dominant eigenpair; accepted only after numerical rank and feasibility checks','rank_one_relative_residuals':defects,'eigenvalues':evals,'rank_one_at_2e-5':bool(max(defects)<2e-5)}

def recover_extended(R,Wks,H):
    ws=[]; desired_before=[]; removed=[]
    for k,Q in enumerate(Wks):
        h=H[k].conj(); d=float(np.vdot(h,Q@h).real)
        if d<=0: raise ValueError('Nonpositive desired power prevents Eq. (48) recovery')
        w=Q@h/np.sqrt(d); ws.append(w); desired_before.append(d)
        removed.append(float(np.linalg.eigvalsh(herm(Q-np.outer(w,w.conj()))).min()))
    Wc=np.column_stack(ws); Wa,report=factor_psd(R-Wc@Wc.conj().T)
    report.update(method='Eqs. (48)–(49)',desired_before=desired_before,removed_covariance_min_eigenvalues=removed,covariance_relative_residual=float(np.linalg.norm(R-Wc@Wc.conj().T-Wa@Wa.conj().T)/np.linalg.norm(R)))
    return Wc,Wa,report

def _solve(prob,solver,tol):
    opts={'CLARABEL':dict(tol_gap_abs=tol,tol_gap_rel=tol,tol_feas=tol,max_iter=300),'SCS':dict(eps=tol,max_iters=200000)}[solver]
    start=time.perf_counter()
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter('always')
        try: prob.solve(solver=solver,**opts); error=None
        except Exception as ex: error=repr(ex)
    return {'solver':solver,'tolerance':tol,'status':prob.status,'objective':prob.value,'wall_seconds':time.perf_counter()-start,'solver_seconds':prob.solver_stats.solve_time if prob.solver_stats else None,'iterations':prob.solver_stats.num_iters if prob.solver_stats else None,'warnings':[str(x.message) for x in w],'error':error}

def solve_sdr(H,gamma,c=Config(),kind='point',solver='CLARABEL',tol=1e-9):
    H,gamma=validate(c,H,gamma); k,n=H.shape
    if kind not in ('point','extended'): raise ValueError('Unknown target kind')
    if kind=='point' and abs(c.theta_degrees)>=90: raise ValueError('Point angular design requires an interior angle; endfire is singular')
    if kind=='point' and abs(c.alpha)==0: raise ValueError('Zero reflectivity gives no angular information')
    count=k+(kind=='extended'); Vs=[cp.Variable((n,n),hermitian=True) for _ in range(count)]; R=sum(Vs)
    Qs=[np.outer(h.conj(),h)/np.vdot(h,h).real for h in H]
    eta=c.communication_noise_mw/(c.power_mw*np.sum(abs(H)**2,axis=1))
    cons=[real_embed(v)>>0 for v in Vs]; power=cp.real(cp.trace(R))<=1; cons.append(power)
    sinr=[]
    for j in range(k):
        q=Qs[j]; constraint=(cp.real(cp.trace(q@Vs[j]))/gamma[j]-cp.real(cp.trace(q@(R-Vs[j]))))/eta[j]>=1
        cons.append(constraint); sinr.append(constraint)
    if kind=='point':
        A,D=matrices(c); sA=np.linalg.norm(A,'fro')**2; sD=np.linalg.norm(D,'fro')**2
        B0=A.conj().T@A/sA; B2=D.conj().T@D/sD; B1=D.conj().T@A/np.sqrt(sA*sD)
        t=cp.Variable(); u0=cp.real(cp.trace(B0@R)); u2=cp.real(cp.trace(B2@R)); u1=cp.trace(B1@R)
        L=cp.bmat([[u2-t,cp.reshape(u1,(1,1),order='F')],[cp.reshape(cp.conj(u1),(1,1),order='F'),u0]])
        lmi=real_embed(L)>>0; cons.append(lmi); prob=cp.Problem(cp.Maximize(t),cons)
    else:
        T=cp.Variable((n,n),hermitian=True); L=cp.bmat([[n*R,np.eye(n)],[np.eye(n),T]])
        lmi=real_embed(L)>>0; cons.append(lmi); prob=cp.Problem(cp.Minimize(cp.real(cp.trace(T))/n),cons)
    report=_solve(prob,solver,tol); report.update(kind=kind,normalization='V_k=W_k/P; trace(sum V)<=1',gamma=gamma.tolist())
    if not all(v.value is not None for v in Vs): return {'report':report,'H':H,'gamma':gamma}
    Wks=np.array([herm(v.value)*c.power_mw for v in Vs]); Rx=Wks.sum(axis=0)
    lam=np.array([x.dual_value for x in sinr])/eta; mu=float(power.dual_value); Z=dual_unembed(np.asarray(lmi.dual_value))
    # Explicit real cone embedding gives an unambiguous complex trace-pairing dual.
    if kind=='point':
        F=(Z[0,0].real*B2+Z[1,1].real*B0+Z[1,0]*B1+Z[0,1]*B1.conj().T)
        stationarity=[herm(mu*np.eye(n)-F+sum(lam[i]*Qs[i] for i in range(k))-lam[j]*(1+1/gamma[j])*Qs[j]) for j in range(k)]
        dual_raw=mu-float(lam@eta); coeff_error=abs(Z[0,0].real-1)
        obj_exact=point_metrics(Rx,c)['effective_information_without_scale']/(c.power_mw*sD)
    else:
        F=n*Z[:n,:n]
        stationarity=[herm(mu*np.eye(n)-F+sum(lam[i]*Qs[i] for i in range(k))-(lam[j]*(1+1/gamma[j])*Qs[j] if j<k else 0)) for j in range(count)]
        dual_raw=float(lam@eta)-mu-2*np.trace(Z[:n,n:]).real
        coeff_error=np.linalg.norm(Z[n:,n:]-np.eye(n)/n,'fro')
        obj_exact=c.power_mw/(n*n)*extended_metrics(Rx,c)['trace_inverse_per_mw'] if extended_metrics(Rx,c)['trace_inverse_per_mw'] else None
    report['diagnostics']={'covariance_min_eigenvalues_normalized':[float(np.linalg.eigvalsh(x/c.power_mw).min()) for x in Wks],'lmi_min_eigenvalue':float(np.linalg.eigvalsh(herm(L.value)).min()),'power_fraction':float(np.trace(Rx).real/c.power_mw),'sinr_slacks_normalized':[float(np.trace(Qs[j]@Wks[j]).real/c.power_mw/gamma[j]-np.trace(Qs[j]@(Rx-Wks[j])).real/c.power_mw-eta[j]) for j in range(k)],'dual_stationarity_min_eigenvalues':[float(np.linalg.eigvalsh(x).min()) for x in stationarity],'dual_lmi_min_eigenvalue':float(np.linalg.eigvalsh(herm(Z)).min()),'dual_multiplier_min':float(min(lam.min(),mu)),'dual_coefficient_residual':float(coeff_error),'dual_objective_raw':float(dual_raw),'recomputed_objective':obj_exact,'primal_dual_gap_raw':float(abs(obj_exact-dual_raw)) if obj_exact is not None else None}
    result={'report':report,'H':H,'gamma':gamma,'R':Rx,'Wks':Wks,'dual_sinr':lam,'dual_power':np.array(mu),'dual_lmi':Z,'lmi':L.value}
    try:
        if kind=='point':
            Wc,recovery=recover_point(Wks); Wa=np.empty((n,0),complex)
            a,ad=steering(n,np.deg2rad(c.theta_degrees)); singular=np.linalg.svd(H@np.column_stack((a,ad)),compute_uv=False)
            recovery['theorem2_H_Abar_singular_values']=singular.tolist(); recovery['theorem2_rank_condition']=bool(len(singular)>=2 and singular[-1]>1e-10*singular[0])
        else: Wc,Wa,recovery=recover_extended(Rx,Wks[:k],H)
        Rrec=Wc@Wc.conj().T+Wa@Wa.conj().T
        report.update(recovery=recovery,communication=beam_metrics(Wc,Wa,H,gamma,c),radar=(point_metrics(Rrec,c) if kind=='point' else extended_metrics(Rrec,c)))
        report['accepted']=bool(report['status'] in ('optimal','optimal_inaccurate') and report['communication']['feasible_at_2e-5'] and (kind=='extended' or recovery['rank_one_at_2e-5']) and report['diagnostics']['primal_dual_gap_raw'] is not None and report['diagnostics']['primal_dual_gap_raw']<2e-5 and report['diagnostics']['dual_coefficient_residual']<2e-5)
        result.update(Wc=Wc,Wa=Wa,R_recovered=Rrec)
    except Exception as ex: report.update(recovery_error=repr(ex),accepted=False)
    return result

def eigen_baseline(solution,c):
    """Declared convention: replace data Wks by principal eigenpairs, keep W_aux.
    No power renormalization, feasibility censoring, or replacement channel.
    """
    H=solution['H']; Wc,rank=recover_point(solution['Wks'][:len(H)])
    Wa,fac=factor_psd(solution['Wks'][-1]); R=Wc@Wc.conj().T+Wa@Wa.conj().T
    return {'Wc':Wc,'Wa':Wa,'R':R,'report':{'communication':beam_metrics(Wc,Wa,H,solution['gamma'],c),'radar':extended_metrics(R,c),'factor':fac,'method':'principal eigenpair per data covariance; original auxiliary covariance retained'}}

def single_point(h,gamma,c):
    h=np.asarray(h,complex); hn=np.linalg.norm(h); a,_=steering(c.nt,np.deg2rad(c.theta_degrees)); required=gamma*c.communication_noise_mw
    if required>c.power_mw*hn**2*(1+1e-13): return None
    if c.power_mw*abs(np.vdot(h,a))**2/c.nt>=required: return np.sqrt(c.power_mw/c.nt)*a
    u=h/hn; z=np.vdot(u,a); aperp=a-u*z; norm=np.linalg.norm(aperp)
    if norm<1e-12: return np.sqrt(c.power_mw)*u
    au=aperp/norm; p=required/hn**2
    phase=z/abs(z) if abs(z)>1e-14 else 1
    return np.sqrt(p)*phase*u+np.sqrt(max(0,c.power_mw-p))*au

def single_extended(h,gamma,c):
    u=h/np.linalg.norm(h); p=max(c.power_mw/c.nt,gamma*c.communication_noise_mw/np.linalg.norm(h)**2)
    if p>=c.power_mw: return None
    v=(c.power_mw-p)/(c.nt-1); R=v*np.eye(c.nt)+(p-v)*np.outer(u,u.conj())
    return R,np.sqrt(p)*u

def exact_streams(count,L):
    if count>L: raise ValueError('Exact orthogonality requires stream count <= snapshots')
    return np.exp(2j*np.pi*np.arange(count)[:,None]*np.arange(L)[None,:]/L)

def minpower_diagnostic(H,gamma,c,solver='CLARABEL'):
    """Own same-resource communication-oriented diagnostic, NOT paper [11]/[12]."""
    k,n=H.shape; V=cp.Variable((n,k),complex=True); C=H@V; con=[]
    for j in range(k):
        interference=cp.hstack([C[j,i] for i in range(k) if i!=j]+[np.sqrt(c.communication_noise_mw/c.power_mw)])
        con += [cp.imag(C[j,j])==0,cp.real(C[j,j])>=np.sqrt(gamma[j])*cp.norm(interference)]
    p=cp.Problem(cp.Minimize(cp.sum_squares(cp.abs(V))),con); rep=_solve(p,solver,1e-9)
    if V.value is None: return {'report':rep}
    W=np.sqrt(c.power_mw)*V.value; minimum=float(np.sum(abs(W)**2)); W*=np.sqrt(c.power_mw/minimum)
    rep.update(minimum_power_mw=minimum,communication=beam_metrics(W,np.empty((n,0)),H,gamma,c),radar=point_metrics(W@W.conj().T,c),method='minimum communication power directions, uniformly scaled to same total power')
    return {'Wc':W,'R':W@W.conj().T,'report':rep}

def repair_powers(Wc,Wa,H,gamma,c):
    """A-posteriori feasible scalar-power correction; never overwrites raw beams.
    Fixed unit-norm beam directions; solve a small QP under the ORIGINAL limits.
    Its radar objective is re-evaluated and compared with the SDR dual objective.
    """
    W=np.column_stack((Wc,Wa)); powers=np.sum(abs(W)**2,axis=0)/c.power_mw
    alive=powers>1e-14; U=W[:,alive]/np.sqrt(c.power_mw*powers[alive])[None,:]
    if not np.all(alive[:len(H)]): raise ValueError('Data column missing')
    gains=abs(H@U)**2; x=cp.Variable(U.shape[1],nonneg=True)
    cons=[cp.sum(x)<=1]
    # Divide by noise and Gamma so each RHS is exactly one: no 1e-5 eta RHS.
    for j in range(len(H)):
        coeff=-c.power_mw*gains[j]/c.communication_noise_mw
        coeff[j]+=c.power_mw*gains[j,j]*(1+1/gamma[j])/c.communication_noise_mw
        cons.append(coeff@x>=1)
    prob=cp.Problem(cp.Minimize(cp.sum_squares(x-powers[alive])),cons)
    report=_solve(prob,'CLARABEL',1e-11)
    if x.value is None: return None,None,report
    B=U*np.sqrt(c.power_mw*np.maximum(x.value,0))[None,:]
    report['max_absolute_normalized_power_change']=float(np.max(abs(x.value-powers[alive])))
    return B[:,:len(H)],B[:,len(H):],report

def numerical_certificate(solution,c):
    """Repair a dual point into PSD cones and fix its coefficient equality.
    Shift the power multiplier upward until all matrix stationarity inequalities
    are PSD. This is a floating-point weak-duality certificate, not interval proof.
    """
    r=solution['report']; H=solution['H']; gamma=solution['gamma']; k,n=H.shape; kind=r['kind']
    Q=[np.outer(h.conj(),h)/np.vdot(h,h).real for h in H]
    eta=c.communication_noise_mw/(c.power_mw*np.sum(abs(H)**2,axis=1))
    lam=np.maximum(solution['dual_sinr'],0); mu=max(float(solution['dual_power']),0)
    Z=herm(solution['dual_lmi']); ev,U=np.linalg.eigh(Z); Z=(U*np.maximum(ev,0))@U.conj().T
    if kind=='point':
        Z/=Z[0,0].real
        A,D=matrices(c); sA=np.linalg.norm(A,'fro')**2; sD=np.linalg.norm(D,'fro')**2
        B0=A.conj().T@A/sA; B2=D.conj().T@D/sD; B1=D.conj().T@A/np.sqrt(sA*sD)
        F=Z[0,0].real*B2+Z[1,1].real*B0+Z[1,0]*B1+Z[0,1]*B1.conj().T
        count=k
    else:
        vals,vec=np.linalg.eigh(herm(Z[n:,n:])); C=(vec/np.sqrt(n*vals)[None,:])@vec.conj().T
        transform=np.block([[np.eye(n),np.zeros((n,n))],[np.zeros((n,n)),C]])
        Z=herm(transform@Z@transform); F=n*Z[:n,:n]; count=k+1
    S=[herm(mu*np.eye(n)-F+sum(lam[i]*Q[i] for i in range(k))-(lam[j]*(1+1/gamma[j])*Q[j] if j<k else 0)) for j in range(count)]
    minimum=min(np.linalg.eigvalsh(x).min() for x in S); shift=max(0,-minimum)+1e-11*max(1,mu,np.linalg.norm(F,2)); mu+=shift
    bound=mu-float(lam@eta) if kind=='point' else float(lam@eta)-mu-2*np.trace(Z[:n,n:]).real
    obj=(point_metrics(solution['R_recovered'],c)['effective_information_without_scale']/(c.power_mw*sD) if kind=='point' else c.power_mw/n**2*extended_metrics(solution['R_recovered'],c)['trace_inverse_per_mw'])
    gap=bound-obj if kind=='point' else obj-bound
    out={'type':'floating-point repaired dual weak-duality check; not interval arithmetic','bound_direction':'upper_information' if kind=='point' else 'lower_trace_inverse','bound_normalized':float(bound),'feasible_objective_normalized':float(obj),'absolute_gap':float(gap),'relative_gap':float(gap/max(abs(obj),1e-15)),'dual_power_shift':float(shift),'dual_cone_min_eigenvalue':float(np.linalg.eigvalsh(Z).min()),'stationarity_min_eigenvalue_after_shift':float(minimum+shift),'dual_coefficient_residual':float(abs(Z[0,0]-1) if kind=='point' else np.linalg.norm(Z[n:,n:]-np.eye(n)/n))}
    return out,{'cert_dual_sinr':lam,'cert_dual_power':np.array(mu),'cert_dual_lmi':Z}

def finalize_solution(s,c):
    r=s['report']
    if 'Wc' not in s: r['accepted']=False; return s
    s['Wc_raw']=s['Wc'].copy();s['Wa_raw']=s['Wa'].copy();r['raw_recovered_communication']=r['communication'].copy();r['raw_recovered_radar']=r['radar'].copy()
    if not r['communication']['feasible_at_2e-5']:
        wc,wa,rep=repair_powers(s['Wc'],s['Wa'],s['H'],s['gamma'],c);r['power_repair']=rep
        if wc is not None:
            s['Wc']=wc;s['Wa']=wa;s['R_recovered']=wc@wc.conj().T+wa@wa.conj().T
            r['communication']=beam_metrics(wc,wa,s['H'],s['gamma'],c)
            r['radar']=point_metrics(s['R_recovered'],c) if r['kind']=='point' else extended_metrics(s['R_recovered'],c)
    try:
        cert,data=numerical_certificate(s,c);r['certificate']=cert;s.update(data)
        r['accepted']=bool(r['communication']['feasible_at_2e-5'] and -2e-5<=cert['relative_gap']<=1e-4 and cert['dual_coefficient_residual']<1e-7 and cert['dual_cone_min_eigenvalue']>=-1e-7)
    except Exception as ex: r['certificate_error']=repr(ex);r['accepted']=False
    return s

def solve_single_point_sdp(h,gamma,c,solver='CLARABEL'):
    """Eq. (25) lifted linear objective, distinct from rank-relaxed Eq. (33)."""
    h=np.asarray(h);a,_=steering(c.nt,np.deg2rad(c.theta_degrees)); V=cp.Variable((c.nt,c.nt),hermitian=True)
    q=np.outer(h,h.conj());aa=np.outer(a,a.conj())/c.nt
    p=cp.Problem(cp.Maximize(cp.real(cp.trace(aa@V))),[real_embed(V)>>0,cp.real(cp.trace(V))<=1,cp.real(cp.trace(q@V))>=gamma*c.communication_noise_mw/c.power_mw])
    rep=_solve(p,solver,1e-9)
    if V.value is None:return {'report':rep}
    W=herm(V.value)*c.power_mw;w,rank=recover_point([W]);rep.update(recovery=rank,radar=point_metrics(w@w.conj().T,c),communication=beam_metrics(w,np.empty((c.nt,0)),h.conj()[None,:],np.array([gamma]),c))
    return {'report':rep,'R':W,'Wc':w,'H':h.conj()[None,:],'gamma':np.array([gamma])}
