# Point-target JavaScript feasibility verdict

Current runtime: `crb-point-drs-v0.4-feasibility`. Exact core SHA256: `208f4d91db12d5c24d8bff921a1f31806cea846cb3f1a3a6101f7520f2e335c1`.

## Actual optimization established

Fresh complex H drives the Eq.(33) SDP, rank-one extraction and unknown-alpha CRB. Neither a single-user theorem nor a stored curve supplies the answer. The extended-target optimizer is not ported.

All12 fresh reduced feasible cases and the separate original-size case pass current numerical gates. The17 saved attempts comprise16 unique inputs: the duplicated-channel input appears twice to retain the separate Python solver retry. Stress cases produce checked infeasibility/bound outcomes, never accepted beams.

Reduced Node wall time: min 25.26ms; median 57.81ms; max 730.25ms. Original-size Nt16/Nr20/K4/Gamma15: 5.674s, 1014 iterations. Node timing is not browser control-to-result latency.

Largest accepted relative numerical information gap: 2.59968356e-08; minimum actual SINR/threshold: 0.999999762874. These are tolerance-qualified floating-point checks, not exact/global interval proofs.

Case | status | iterations | Node ms | recovered relative gap
--- | --- | ---: | ---: | ---:
nt4-k2-g0-theta0-seed290101 | converged | 35 | 35.11 | 2.412925545580552e-11
nt4-k2-g10-theta0-seed290102 | converged | 108 | 30.01 | 2.80488494028849e-09
nt4-k2-g20-theta0-seed290103 | converged | 6311 | 455.65 | -2.2304162756377024e-09
nt4-k2-g10-theta23-seed290104 | converged | 90 | 25.26 | 1.0258398089269195e-09
nt6-k2-g0-theta0-seed290105 | converged | 33 | 27.90 | 3.655173001835169e-09
nt6-k2-g10-theta0-seed290106 | converged | 101 | 60.96 | 1.9412841928999124e-09
nt6-k2-g20-theta0-seed290107 | converged | 3400 | 529.48 | 1.3499374163309369e-09
nt6-k2-g10-theta23-seed290108 | converged | 118 | 54.67 | 3.1408419256763917e-09
nt8-k2-g0-theta0-seed290109 | converged | 26 | 46.10 | 2.2729890996976644e-09
nt8-k2-g10-theta0-seed290110 | converged | 117 | 88.43 | 3.6597830578939013e-09
nt8-k2-g20-theta0-seed290111 | converged | 2569 | 730.25 | 6.906682507148839e-09
nt8-k2-g10-theta23-seed290112 | converged | 207 | 93.57 | 4.65767476850594e-09
nt16-k4-g15-theta0-seed290113 | converged | 1014 | 5674.16 | 2.5996835609569198e-08
nt4-k2-duplicate-g10-seed290114 | infeasible_certificate | 1000 | 107.88 | not accepted
nt4-k2-zero-g0-seed290115 | infeasible_bound | 0 | 1.35 | not accepted
nt4-k2-near-collinear-g10-seed290116 | infeasible_certificate | 1000 | 102.74 | not accepted
nt4-k2-duplicate-g10-seed290114-scs-check | infeasible_certificate | 1000 | 107.97 | not accepted

## Failures and fixes retained

Initial rho1 conditioning capped all three reduced Gamma20 cases and the source-size case. The latter used20,000iterations and80.69seconds. Explicit rho10/100 tests informed the deterministic final rho=clamp(Gamma,1,100) rule; the model/resources did not change. Original capped outputs remain visible. Old runtime versions were experimental records, not acceptance evidence for the final byte hash; final accepted cases were rerun with the current runtime.

Independent review caught two edge defects: finite alpha components could overflow their squared magnitude or the CRB denominator; subtractive Gram arithmetic could falsely mark duplicated H full rank. The final runtime rejects/flags nonfinite or zero CRB and uses reorthogonalized two-column QR residuals for the small singular value. Pre-fix probes and post-fix regressions are retained by the reviewer.

Lifecycle testing: 14 checks pass, including caps, input snapshots, cancel, replacement, invalid messages and stale-result exclusion. Measured Node cancellation reply: 4.072ms. The reviewer also exercised browser UMD/importScripts branches in a Node VM; neither is actual browser acceptance.

## Fair comparison surface

Five new same-H solves at Gamma0/5/10/15/20dB pass; information is monotone within1e−7 and max JS/Python difference is 2.91009277e-07. Different-seed routine fixtures must not be joined into a frontier. No author beampattern baseline is implemented in this JS.

## Recommended next gate

First lesson scope: Nt4/6/8, Nr=Nt+4, K2, L30, P1000mW, both noises1mW, alpha1, editable H, common Gamma0–20dB, theta0 default. Explicit Run/Cancel and a strict accepted-output gate are mandatory. Keep original-size execution a separately labeled scaling experiment until broader numerical/latency evidence exists. Root owns any later UI authorization.

Point and extended gates, exact equations and recovery conditions are in PORT-PLAN.md; prospective contract is in API.md. Hosted-browser testing, production/UI work and full-paper reproduction remain open.
