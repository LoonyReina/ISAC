from pathlib import Path
import json,hashlib,zipfile
ROOT=Path(__file__).resolve().parent
runtime=['js/hermitian.js','js/linalg.js','js/core.js','js/worker.js']
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
km={'artifact':'crb-point-kernel-v0.4','runtimeVersion':'crb-point-drs-v0.4-feasibility','sourcePaperSha256':'3bb9519855b92a8cca870caf603efe0d05dc1d9369cadad0fb7de20750a61e6d','pythonReferenceSha256':digest(ROOT/'python-reference/reference.py'),'sourceEquations':'journal Eq7,Eq30–33,Theorem2; extended Eq46–49 remain unported','runtime':[{'path':p,'sha256':digest(ROOT/p),'bytes':(ROOT/p).stat().st_size} for p in runtime],'numericalScope':'bounded actual multiuser point-target solver only','browserExecuted':False,'uiModified':False,'productionModified':False,'fullPaperReproduction':False,'review':'independent-review/REVIEW.md','api':'API.md','plan':'PORT-PLAN.md','results':'KERNEL-REPORT.json'}
(ROOT/'KERNEL-MANIFEST.json').write_text(json.dumps(km,indent=2)+'\n')
files=[]
for p in sorted(ROOT.rglob('*')):
 if not p.is_file() or '__pycache__' in p.parts or p.suffix in ['.pyc','.pdf','.zip'] or p.name=='ARTIFACT-MANIFEST.json':continue
 files.append({'path':p.relative_to(ROOT).as_posix(),'bytes':p.stat().st_size,'sha256':digest(p)})
m={'schemaVersion':1,'artifact':'crb-point-kernel-v0.4','dateUtc':'2026-10-12','files':files,'selfExcluded':True,'scope':'standalone numerical/worker feasibility prototype; no source PDF redistribution'}
(ROOT/'ARTIFACT-MANIFEST.json').write_text(json.dumps(m,indent=2)+'\n');zip_path=ROOT.parent/'crb-point-kernel-v0.4.zip'
with zipfile.ZipFile(zip_path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name in [x['path'] for x in files]+['ARTIFACT-MANIFEST.json']:
  item=zipfile.ZipInfo('crb-point-kernel-v0.4/'+name,date_time=(2026,10,12,0,0,0));item.compress_type=zipfile.ZIP_DEFLATED;item.external_attr=0o100644<<16;z.writestr(item,(ROOT/name).read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
r={'artifact':str(zip_path),'sha256':digest(zip_path),'bytes':zip_path.stat().st_size,'manifest':str(ROOT/'ARTIFACT-MANIFEST.json'),'manifestSha256':digest(ROOT/'ARTIFACT-MANIFEST.json'),'fileCount':len(files),'coreSha256':digest(ROOT/'js/core.js'),'kernelManifestSha256':digest(ROOT/'KERNEL-MANIFEST.json'),'independentReviewSha256':digest(ROOT/'independent-review/REVIEW.md'),'pointNumericalGate':'passed for documented bounded scope','extendedBrowserGate':'not started','actualBrowserGate':'not tested','uiGate':'not started'}
(ROOT.parent/'CRB-POINT-KERNEL-HANDOFF.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
