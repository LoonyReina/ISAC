"""Independent source/NumPy/CVXPY review, no imports from reference or JS math code.
Run --prepare, node driver.js, then --check. Writes only independent-review/.
"""
import os
for key in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','VECLIB_MAXIMUM_THREADS','BLIS_NUM_THREADS']: os.environ[key]='1'
import sys,json,hashlib,time,copy,warnings
from pathlib import Path
import numpy as np
import cvxpy as cp
HERE=Path(__file__).resolve().parent; ROOT=HERE.parent

def pack(z):return {'real':np.asarray(z).real.tolist(),'imag':np.asarray(z).imag.tolist()}
def unpack(z):return np.asarray(z['real'])+1j*np.asarray(z['imag'])
def coord(M):
 n=len(M);return np.r_[M.diagonal().real,[np.sqrt(2)*M[i,j].real for i in range(n) for j in range(i+1,n)],[np.sqrt(2)*M[i,j].imag for i in range(n) for j in range(i+1,n)]]
def mat(v,n):
 M=np.diag(np.asarray(v[:n],complex));p=n
 for i in range(n):
  for j in range(i+1,n):M[i,j]=M[j,i]=v[p]/np.sqrt(2);p+=1
 for i in range(n):
  for j in range(i+1,n):M[i,j]+=1j*v[p]/np.sqrt(2);M[j,i]-=1j*v[p]/np.sqrt(2);p+=1
 return M

def model(x):
 th=np.deg2rad(x['thetaDegrees'])
 def a(n):
  p=np.arange(n)-(n-1)/2;v=np.exp(1j*np.pi*p*np.sin(th));return v,1j*np.pi*p*np.cos(th)*v
 a,ad=a(x['Nt']);b,bd=(lambda n:(np.exp(1j*np.pi*(np.arange(n)-(n-1)/2)*np.sin(th)),1j*np.pi*(np.arange(n)-(n-1)/2)*np.cos(th)*np.exp(1j*np.pi*(np.arange(n)-(n-1)/2)*np.sin(th))))(x['Nr'])
 A=b[:,None]*a.conj()[None,:];D=bd[:,None]*a.conj()[None,:]+b[:,None]*ad.conj()[None,:]
 sA=np.linalg.norm(A)**2;sD=np.linalg.norm(D)**2
 return {'A':A,'D':D,'a':a,'ad':ad,'sA':sA,'sD':sD,'B0':A.conj().T@A/sA,'B2':D.conj().T@D/sD,'B1':D.conj().T@A/np.sqrt(sA*sD)}
def metrics(R,x):
 m=model(x);A=m['A'];D=m['D'];s0=np.trace(A.conj().T@A@R).real;s1=np.trace(D.conj().T@A@R);s2=np.trace(D.conj().T@D@R).real;eff=s2-abs(s1)**2/s0 if s0>0 else np.nan
 alpha=complex(x['alpha']['real'],x['alpha']['imag']);crb=x['radarNoiseMw']/(2*abs(alpha)**2*x['L']*eff)
 return dict(s0=float(s0),s1_real=float(s1.real),s1_imag=float(s1.imag),s2=float(s2),eff=float(eff),information=float(eff/(x['powerMw']*m['sD'])),crb=float(crb),root=float(np.sqrt(crb)*180/np.pi))
def input_case(n,k,seed,gamma,theta,nr=None):
 rng=np.random.default_rng(seed);H=(rng.standard_normal((k,n))+1j*rng.standard_normal((k,n)))/np.sqrt(2)
 return dict(Nt=n,Nr=nr or n+2,K=k,L=30,powerMw=1000.,communicationNoiseMw=1.,radarNoiseMw=1.,thetaDegrees=theta,alpha=dict(real=.7,imag=.3),H=pack(H),gammaDb=gamma)
def solve_oracle(x):
 n=x['Nt'];k=x['K'];H=unpack(x['H']);P=x['powerMw'];gamma=10**(x['gammaDb']/10);m=model(x)
 V=[cp.Variable((n,n),hermitian=True) for _ in range(k)];R=sum(V);t=cp.Variable();u0=cp.real(cp.trace(m['B0']@R));u2=cp.real(cp.trace(m['B2']@R));u1=cp.trace(m['B1']@R)
 S=cp.bmat([[cp.reshape(u2-t,(1,1),order='F'),cp.reshape(u1,(1,1),order='F')],[cp.reshape(cp.conj(u1),(1,1),order='F'),cp.reshape(u0,(1,1),order='F')]])
 constraints=[v>>0 for v in V]+[cp.real(cp.trace(R))<=1,S>>0]
 for j,h in enumerate(H):
  Q=np.outer(h.conj(),h);constraints+=[cp.real(cp.trace(Q@V[j]))/gamma-cp.real(cp.trace(Q@(R-V[j])))>=x['communicationNoiseMw']/P]
 prob=cp.Problem(cp.Maximize(t),constraints);start=time.perf_counter()
 with warnings.catch_warnings(record=True) as w:
  warnings.simplefilter('always');prob.solve(solver='CLARABEL',tol_gap_abs=1e-10,tol_gap_rel=1e-10,tol_feas=1e-10,max_iter=500)
 out=dict(status=prob.status,value=prob.value,wallSeconds=time.perf_counter()-start,warnings=[str(a.message) for a in w])
 if V[0].value is not None:out['Wks']=[pack(v.value*P) for v in V];out['metrics']=metrics(sum(v.value for v in V)*P,x)
 return out

def prepare():
 cases=[]
 for n,k,seed,g,theta in [(4,2,812733,7,-37),(4,2,812734,-5,60),(6,3,812735,10,19)]:
  x=input_case(n,k,seed,g,theta);ident=f'fresh-nt{n}-k{k}-seed{seed}';cases.append(dict(id=ident,input=x,oracle=True));o=solve_oracle(x);(HERE/(ident+'.oracle.json')).write_text(json.dumps(o,indent=2));print(ident,o['status'],o['value'],flush=True)
 base=input_case(4,2,812733,7,-37)
 cases.extend([dict(id='one-iteration-cap',input=base,options={'maxIterations':1}),dict(id='cancel-after-step',input=base,cancel=True)])
 dup=copy.deepcopy(base);H=unpack(dup['H']);H[1]=H[0];dup['H']=pack(H);dup['gammaDb']=10;cases.append(dict(id='duplicate-infeasible',input=dup))
 weak=copy.deepcopy(base);H=unpack(weak['H'])*1e-5;weak['H']=pack(H);cases.append(dict(id='necessary-bound-infeasible',input=weak))
 zero=copy.deepcopy(base);H=unpack(zero['H']);H[0]=0;zero['H']=pack(H);cases.append(dict(id='zero-channel-infeasible',input=zero))
 deg=copy.deepcopy(base);deg['thetaDegrees']=0;deg['gammaDb']=-5;deg['H']=pack(np.ones((2,4),complex));cases.append(dict(id='rank-one-channel-feasible',input=deg))
 for key,val in [('Nt',3),('K',1),('Nr',4),('L',4),('gammaDb',31),('thetaDegrees',61),('powerMw',1e7),('communicationNoiseMw',.001),('alpha',dict(real=0,imag=0))]:
  x=copy.deepcopy(base);x[key]=val;cases.append(dict(id='reject-'+key,input=x,expect='input_rejection'))
 # alpha is finite componentwise but its squared magnitude overflows. Keep as an explicit edge defect probe.
 x=copy.deepcopy(base);x['alpha']=dict(real=1e200,imag=0);cases.append(dict(id='alpha-overflow-probe',input=x))
 x=copy.deepcopy(base);x['alpha']=dict(real=1e-200,imag=0);cases.append(dict(id='alpha-underflow-probe',input=x))
 for op,val in [('maxIterations',50001),('memory',11),('tolerance',1e-12),('rho',1001),('relaxation',2),('linearWeight',101),('safeguard',1.1)]:cases.append(dict(id='reject-option-'+op,input=base,options={op:val},expect='input_rejection'))
 for name,key,val in [('large-L','L',1e308),('alpha-product-overflow','alpha',dict(real=1e151,imag=0)),('radar-noise-overflow','radarNoiseMw',1e308),('radar-noise-underflow','radarNoiseMw',5e-324)]:
  x=copy.deepcopy(base);x[key]=val
  if name=='radar-noise-overflow':x['alpha']=dict(real=1e-150,imag=0)
  cases.append(dict(id=name+'-probe',input=x))
 unit=copy.deepcopy(base)
 for key in ['powerMw','communicationNoiseMw','radarNoiseMw']:unit[key]*=.001
 cases.append(dict(id='unit-rescaling-mw-to-w',input=unit))
 models=[];rng=np.random.default_rng(289361)
 for n,nr,th in [(4,6,0),(4,7,-37),(6,8,23),(8,10,60),(16,20,-60)]:
  x=input_case(n,2,99,10,th,nr);Z=rng.normal(size=(n,n))+1j*rng.normal(size=(n,n));R=Z@Z.conj().T;R*=1000/np.trace(R).real;models.append(dict(id=f'model-{n}-{nr}-{th}',Nt=n,Nr=nr,thetaDegrees=th,input=x,R=pack(R)))
 (HERE/'plan.json').write_text(json.dumps(dict(cases=cases,models=models),indent=2));(HERE/'source-hashes.json').write_text(json.dumps({str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [ROOT/'js/core.js',ROOT/'js/linalg.js',ROOT/'js/hermitian.js']},indent=2))

def affine(x,options):
 n=x['Nt'];k=x['K'];d=n*n;vlen=k*d+1;m=model(x);basis=[mat(np.eye(d)[i],n) for i in range(d)];rows=[];lower=[]
 for idx,B in enumerate([m['B2'],m['B0'],m['B1'],m['B1']]):
  vals=np.array([np.trace(B@b).real if idx!=3 else np.trace(B@b).imag for b in basis]);row=np.r_[np.tile(vals,k),0.];
  if idx>=2:row*=np.sqrt(2)
  if idx==0:row[-1]=-1
  rows.append(row)
 weight=options.get('linearWeight',10.)
 def linear(row,rhs):
  scale=np.linalg.norm(row);rows.append(row*weight/scale);lower.append(rhs*weight/scale)
 power=np.zeros(vlen)
 for j in range(k):power[j*d:j*d+n]=-1
 linear(power,-1)
 H=unpack(x['H']);gamma=10**(x['gammaDb']/10)
 for j,h in enumerate(H):
  hn=np.linalg.norm(h)**2;q=np.outer(h.conj(),h)/hn;qc=coord(q);row=np.r_[np.concatenate([qc*(1/gamma if j==b else -1) for b in range(k)]),0.];linear(row,x['communicationNoiseMw']/(x['powerMw']*hn))
 A=np.vstack([np.column_stack((np.eye(k*d),np.zeros(k*d))),rows]);return A,np.array(lower)

def cert_check(c,x,options):
 n=x['Nt'];k=x['K'];d=n*n;off=k*d;A,lower=affine(x,options);y=np.array(c['dual']);E=A.T@y;objective=c['kind']=='normalized_information_upper_bound'
 if objective:E[-1]-=1
 eigs=[np.linalg.eigvalsh(mat(E[j*d:(j+1)*d],n)).min() for j in range(k)];minimum=min([0.]+eigs);support=y[off+4:]@lower;lowerBound=-support+minimum
 cones=[float(np.linalg.eigvalsh(mat(y[j*d:(j+1)*d],n)).max()) for j in range(k)]+[float(np.linalg.eigvalsh(mat(y[off:off+4],2)).max())]
 claimed=np.array(c['stationarityMinimumEigenvalues']);bound=c['informationUpperBound'] if objective else c['minimizationLowerBound']
 checks={'dualConeMaxEigenvalues':cones,'linearDualMax':float(max(y[off+4:])),'tStationarityResidual':float(abs(E[-1])),'stationarityMinEigenvalues':list(map(float,eigs)),'claimedMinIsConservative':bool(np.all(claimed<=np.array(eigs)+1e-12)),'supportDifference':float(support-c['support']),'replayedBound':float(-lowerBound if objective else lowerBound),'reportedBound':bound,'reportedMinusReplay':float(bound-(-lowerBound if objective else lowerBound))}
 checks['passed']=bool(max(cones)<=1e-10 and max(y[off+4:])<=1e-12 and abs(E[-1])<=1e-12 and checks['claimedMinIsConservative'] and abs(checks['supportDifference'])<=1e-10 and (bound>=-lowerBound-1e-10 if objective else bound<=lowerBound+1e-10))
 return checks

def output_check(r,oracle=None):
 x=r.get('input');out={'status':r['status'],'iterations':r.get('iterations'),'wallMs':r.get('kernelWallMs'),'gate':r.get('physicalGate')}
 if not x or 'Wks' not in r:return out
 if 'invalid_CRB' in r.get('physicalGate',{}).get('failures',[]):
  out['invalidCRBRejected']=True;out['reportedRadar']=r.get('metrics',{}).get('radar');return out
 n=x['Nt'];k=x['K'];P=x['powerMw'];H=unpack(x['H']);V=[unpack(w) for w in r['Wks']];R=sum(V);gamma=10**(x['gammaDb']/10);m=model(x);t=r['relaxedInformation'];u0=np.trace(m['B0']@R/P).real;u2=np.trace(m['B2']@R/P).real;u1=np.trace(m['B1']@R/P);S=np.array([[u2-t,u1],[u1.conjugate(),u0]])
 out['relaxed']={'covarianceSumError':float(np.linalg.norm(R-unpack(r['relaxedR']))),'powerFraction':float(np.trace(R).real/P),'minimumWkEigenvalueNormalized':float(min(np.linalg.eigvalsh(v/P).min() for v in V)),'minimumSchurEigenvalue':float(np.linalg.eigvalsh(S).min()),'sinrRatios':[float((H[j]@V[j]@H[j].conj()).real/((H[j]@(R-V[j])@H[j].conj()).real+x['communicationNoiseMw'])/gamma) for j in range(k)],'information':metrics(R,x)['information']}
 D=H@np.column_stack((m['a'],m['ad']));sv=np.linalg.svd(D,compute_uv=False);out['rankCondition']={'matrixError':float(np.linalg.norm(D-unpack(r['rankCondition']['matrix']))),'singularValueError':float(np.max(abs(sv-np.array(r['rankCondition']['singularValues'])))),'sv':sv.tolist(),'reportedFullRank':r['rankCondition']['fullColumnRank']}
 if r.get('certificate'):out['certificate']=cert_check(r['certificate'],x,r['options'])
 if r.get('infeasibilityCertificate'):out['infeasibilityCertificate']=cert_check(r['infeasibilityCertificate'],x,r['options'])
 if r.get('Wc'):
  W=unpack(r['Wc']);Rrec=W@W.conj().T;gain=abs(H@W)**2;desired=gain.diagonal();interference=gain.sum(1)-desired;sinr=desired/(interference+x['communicationNoiseMw']);met=metrics(Rrec,x);js=r['metrics'];rankres=[np.linalg.norm(v-np.outer(W[:,j],W[:,j].conj()))/np.linalg.norm(v) for j,v in enumerate(V)]
  out['recovery']={'powerMw':float(np.linalg.norm(W)**2),'powerFraction':float(np.linalg.norm(W)**2/P),'sinr':sinr.tolist(),'sinrRatio':(sinr/gamma).tolist(),'rankOneResidual':list(map(float,rankres)),'information':met['information'],'powerError':float(abs(np.linalg.norm(W)**2-js['powerMw'])),'sinrError':float(np.max(abs(sinr-np.array([z['sinr'] for z in js['users']])))),'informationError':float(abs(met['information']-js['radar']['normalizedInformation'])),'CRBError':float(abs(met['crb']-js['radar']['crbRad2'])),'s1Error':float(abs(complex(met['s1_real'],met['s1_imag'])-complex(js['radar']['s1']['real'],js['radar']['s1']['imag']))),'rankResidualError':float(np.max(abs(np.array(rankres)-[v['relativeRankOneResidual'] for v in r['recovery']])))}
  alpha=complex(x['alpha']['real'],x['alpha']['imag']);jac=[alpha*m['D'],m['A'],1j*m['A']];F=2*x['L']/x['radarNoiseMw']*np.array([[np.trace(a.conj().T@b@Rrec).real for b in jac] for a in jac]);schur=F[0,0]-F[0,1:]@np.linalg.solve(F[1:,1:],F[1:,0]);out['recovery']['independentFisherCRBRelativeError']=float(abs(1/schur-met['crb'])/met['crb'])
  if oracle and oracle.get('value') is not None:out['oracleComparison']={'oracleInformation':oracle['value'],'informationDifference':met['information']-oracle['value'],'certificateMarginAboveOracle':r['certificate']['informationUpperBound']-oracle['value']}
 return out

def check(extra=[]):
 plan=json.loads((HERE/'plan.json').read_text());res={'models':[],'cases':[],'parentResults':[]}
 actual=json.loads((HERE/'models.js.json').read_text())
 for p,q in zip(plan['models'],actual):
  x=p['input'];n=x['Nt'];M=model(x);js=q['model'];R=unpack(p['R']);basis=[mat(np.eye(n*n)[i],n) for i in range(n*n)];expected=[np.array([np.trace(B@b) for b in basis]) for B in [M['B0'],M['B2'],M['B1']]];errs={key:float(np.max(abs(np.array(js[key])-value))) for key,value in zip(['b0','b2','b1r','b1i'],[expected[0].real,expected[1].real,expected[2].real,expected[2].imag])};errs.update(sA=abs(js['sA']-M['sA']),sD=abs(js['sD']-M['sD']),roundtrip=float(np.max(abs(R-unpack(q['roundtrip'])))))
  av=np.array(q['steering']['a'])[::2]+1j*np.array(q['steering']['a'])[1::2];ad=np.array(q['steering']['ad'])[::2]+1j*np.array(q['steering']['ad'])[1::2];errs['steering']=float(np.max(abs(av-M['a'].conj())));errs['derivative']=float(np.max(abs(ad-M['ad'].conj())));h=1e-6;xp=copy.deepcopy(x);xm=copy.deepcopy(x);xp['thetaDegrees']+=np.rad2deg(h);xm['thetaDegrees']-=np.rad2deg(h);fd=(model(xp)['a'].conj()-model(xm)['a'].conj())/(2*h);errs['finiteDifferenceDerivative']=float(np.max(abs(ad-fd)));v=metrics(R,x);errs['physicalInformation']=abs(v['information']-q['metrics']['normalizedInformation']);errs['physicalS1']=float(abs(complex(v['s1_real'],v['s1_imag'])-complex(q['metrics']['s1']['real'],q['metrics']['s1']['imag'])));res['models'].append({'id':p['id'],'errors':errs})
 for item in plan['cases']:
  r=json.loads((HERE/(item['id']+'.js.json')).read_text());o=json.loads((HERE/(item['id']+'.oracle.json')).read_text()) if item.get('oracle') else None
  try:a=output_check(r,o)
  except OverflowError as e:a={'status':r['status'],'gate':r.get('physicalGate'),'reportedCRB':r.get('metrics',{}).get('radar',{}).get('crbRad2'),'issue':'Accepted finite alpha components overflow their squared magnitude; nonphysical zero CRB'}
  except Exception as e:a={'status':r['status'],'reviewError':repr(e)}
  a['id']=item['id'];a['expected']=item.get('expect');res['cases'].append(a)
 for path in extra:
  r=json.loads(Path(path).read_text())
  if isinstance(r,list):entries=r
  elif 'results' in r:entries=r['results']
  else:entries=[r]
  for row in entries:
   rr=row.get('result',row);a=output_check(rr);a['id']=row.get('id',Path(path).name);
   oi=next((z for z in json.loads((ROOT/'oracle/index.json').read_text())['cases'] if z['id']==Path(path).stem),None)
   if oi and a.get('recovery'):
    oraw=json.loads((ROOT/'oracle'/oi['resultFile']).read_text());ar=np.load(ROOT/'oracle'/oi['npzFile']);om=metrics(ar['R_recovered'],rr['input']);upper=oraw['report']['certificate']['bound_normalized'];a['oracleComparison']={'oracleRecoveredInformation':om['information'],'oracleUpperInformation':upper,'jsRecoveredInformation':a['recovery']['information'],'jsUpperInformation':rr['certificate']['informationUpperBound'],'informationDifference':a['recovery']['information']-om['information'],'jsMinusOracleIntervalUpper':a['recovery']['information']-upper,'oracleMinusJsIntervalUpper':om['information']-rr['certificate']['informationUpperBound']}
   hp=Path(str(path).replace('.js.json','.python.json'))
   if hp!=Path(path) and hp.exists() and a.get('recovery'):
    oraw=json.loads(hp.read_text());om=oraw['certificate']['feasible_objective_normalized'];upper=oraw['certificate']['bound_normalized'];a['oracleComparison']={'oracleRecoveredInformation':om,'oracleUpperInformation':upper,'jsRecoveredInformation':a['recovery']['information'],'jsUpperInformation':rr['certificate']['informationUpperBound'],'informationDifference':a['recovery']['information']-om,'jsMinusOracleIntervalUpper':a['recovery']['information']-upper,'oracleMinusJsIntervalUpper':om-rr['certificate']['informationUpperBound'],'oracleScope':'Compared saved Python certificate summary; Python matrix arrays not emitted for this sweep'}
   res['parentResults'].append(a)
 (HERE/'review-results.json').write_text(json.dumps(res,indent=2,allow_nan=False));print(json.dumps(res,indent=2,allow_nan=False))
if __name__=='__main__':
 if '--prepare' in sys.argv:prepare()
 elif '--check' in sys.argv:check(sys.argv[sys.argv.index('--check')+1:])
