import review as r
import numpy as np,json
p=r.HERE;x=json.loads((p/'one-iteration-cap.js.json').read_text());inp=x['input'];n=inp['Nt'];k=inp['K'];d=n*n;A,low=r.affine(inp,x['options']);v=np.zeros(k*d+1)
for j in range(k):v[j*d:j*d+n]=1/(k*n)
w=A@v;z=w.copy()
for off,m in [(j*d,n) for j in range(k)]+[(k*d,2)]:
 M=r.mat(w[off:off+m*m],m);ev,U=np.linalg.eigh(M);z[off:off+m*m]=r.coord((U*np.maximum(ev,0))@U.conj().T)
z[k*d+4:]=np.maximum(z[k*d+4:],low);rho=x['options']['rho'];rhs=rho*A.T@(2*z-w);rhs[-1]+=1;y=np.linalg.solve(rho*A.T@A,rhs);st=x['finalState'];err={'initialWMaxError':float(np.max(abs(w-st['w']))),'projectedZMaxError':float(np.max(abs(z-st['z']))),'proximalXMaxError':float(np.max(abs(y-st['x']))),'linearObjectiveCoefficient':-1,'status':x['status']};err['passed']=max(err[q] for q in ['initialWMaxError','projectedZMaxError','proximalXMaxError'])<1e-11;(p/'drs-one-step-check.json').write_text(json.dumps(err,indent=2));print(json.dumps(err,indent=2))
