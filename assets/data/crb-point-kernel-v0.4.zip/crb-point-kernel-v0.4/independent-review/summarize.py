import review as r,json,hashlib,platform,datetime
import numpy as np
p=r.HERE;a=json.loads((p/'review-results.json').read_text());rows=a['cases']+a['parentResults'];by={z['id']:z for z in a['cases']};checks=[]
def check(name,test,detail=None):checks.append({'name':name,'passed':bool(test),'detail':detail})
for z in a['models']:
 e=z['errors'];check(z['id']+' exact model',max(e[k] for k in ['b0','b2','b1r','b1i','steering','derivative','physicalInformation'])<1e-12,e);check(z['id']+' derivative finite difference',e['finiteDifferenceDerivative']<2e-8)
for z in rows:
 check(z['id']+' review replay',not z.get('reviewError'),z.get('reviewError'))
 if z.get('certificate'):check(z['id']+' certificate',z['certificate']['passed'])
 if z.get('infeasibilityCertificate'):check(z['id']+' separator',z['infeasibilityCertificate']['passed'])
 if z.get('recovery'):
  v=z['recovery'];check(z['id']+' physical replay',v['powerError']<1e-8 and v['sinrError']<1e-8 and v['informationError']<1e-10 and v['rankResidualError']<1e-10 and v['independentFisherCRBRelativeError']<1e-10)
  if z['status']=='converged':check(z['id']+' independent physical gates',v['powerFraction']<=1+2e-6 and min(v['sinrRatio'])>=1-2e-5 and max(v['rankOneResidual'])<=1e-4)
 if z.get('expected'):check(z['id']+' expected rejection',z['status']==z['expected'])
 if z.get('oracleComparison') and 'jsMinusOracleIntervalUpper' in z['oracleComparison']:
  o=z['oracleComparison'];check(z['id']+' oracle intervals consistent',o['jsMinusOracleIntervalUpper']<=1e-8 and o['oracleMinusJsIntervalUpper']<=1e-8)
for ident,status in {'one-iteration-cap':'iteration_limit','cancel-after-step':'cancelled','duplicate-infeasible':'infeasible_certificate','necessary-bound-infeasible':'infeasible_bound','zero-channel-infeasible':'infeasible_bound','rank-one-channel-feasible':'rank_condition_not_met','alpha-overflow-probe':'input_rejection','alpha-underflow-probe':'input_rejection','large-L-probe':'input_rejection','alpha-product-overflow-probe':'numerical_rejection','radar-noise-overflow-probe':'numerical_rejection','radar-noise-underflow-probe':'numerical_rejection'}.items():check(ident+' expected terminal state',by[ident]['status']==status)
held=sorted([z for z in a['parentResults'] if z['id'].startswith('held-channel-')],key=lambda z:int(z['id'].split('-g')[1].split('.')[0]))
if held:
 check('held-channel information monotonicity',np.max(np.diff([z['recovery']['information'] for z in held]))<=1e-7)
 inputs=[json.loads(f.read_text()) for f in sorted((r.ROOT/'results/held-channel').glob('*.input.json'))]
 for v in inputs:v.pop('gammaDb')
 check('held-channel resources fixed',all(v==inputs[0] for v in inputs))
for fname in ['rank-regression-results.json','browser-mode-vm-results.json','drs-one-step-check.json']:
 v=json.loads((p/fname).read_text());check(fname,v['passed'])
x=by['fresh-nt4-k2-seed812733']['recovery'];y=by['unit-rescaling-mw-to-w']['recovery'];check('mW to W rescaling invariance',max(abs(np.array(x['sinr'])-y['sinr']))<1e-8 and abs(x['information']-y['information'])<1e-10 and abs(x['powerMw']*.001-y['powerMw'])<1e-10)
rec=[z['recovery'] for z in rows if z.get('recovery')];cert=[z['certificate'] for z in rows if z.get('certificate')]
summary={'verdict':'PASS: bounded offline JavaScript Eq33 and worker feasibility review' if all(z['passed'] for z in checks) else 'FAIL: inspect failed checks','allPassed':all(z['passed'] for z in checks),'checkCount':len(checks),'failedChecks':[z for z in checks if not z['passed']],'reviewTimeUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceSha256':{str(f.relative_to(r.ROOT)):hashlib.sha256(f.read_bytes()).hexdigest() for f in [r.ROOT/'js/core.js',r.ROOT/'js/hermitian.js',r.ROOT/'js/linalg.js',r.ROOT/'js/worker.js',r.ROOT/'js/worker-node-adapter.cjs']},'primaryPdfSha256':hashlib.sha256(__import__('pathlib').Path('/workspace/shared/paper-comparison-research/crb-beamforming-vor.pdf').read_bytes()).hexdigest(),'cases':{'independent':len(a['cases']),'parentSavedOutputs':len(a['parentResults']),'acceptedParentCases':sum(z['status']=='converged' for z in a['parentResults']),'independentFreshOracles':3},'maximumReplayErrors':{'powerMw':max(z['powerError'] for z in rec),'SINR':max(z['sinrError'] for z in rec),'normalizedInformation':max(z['informationError'] for z in rec),'rankResidual':max(z['rankResidualError'] for z in rec),'FisherCRBRelative':max(z['independentFisherCRBRelativeError'] for z in rec),'dualTStationarityResidual':max(z['tStationarityResidual'] for z in cert)},'checks':checks,'scopeLimits':['No actual browser launched; Node and Node VM timing cannot certify browser latency.','Not full-paper replication, no extended target or K1 replacement.','Finite floating-point certificate replay, not interval arithmetic.','No production, UI, external GitHub, or frozen reference writes.']};(p/'REVIEW.json').write_text(json.dumps(summary,indent=2,allow_nan=False));print(json.dumps({k:v for k,v in summary.items() if k!='checks'},indent=2));assert summary['allPassed']
