# Independent review of the actual JavaScript point-target optimizer

## Verdict

**PASS for a bounded offline Eq. (33) JavaScript/worker feasibility prototype.** The final reviewed implementation is `crb-point-drs-v0.4-feasibility`. All **194 automated assertions** pass. No unresolved model-algebra, cone-mapping, objective-sign, recovery, or dual-bound defect was found within the reviewed scope.

Exact `js/core.js` SHA-256: `208f4d91db12d5c24d8bff921a1f31806cea846cb3f1a3a6101f7520f2e335c1`.

This is **not** actual-browser latency or UI acceptance, production acceptance, interval-arithmetic certification, an extended-target implementation, or full-paper replication. There were no browser launches or writes to production, UI, GitHub, or the frozen Python reference. All reviewer-created files are under `independent-review/`.

## Evidence and independence

- Read the actual `core.js`, `worker.js`, utility/projection code, fixed published-paper text, and frozen source/model audit. The PDF hash is `3bb9519855b92a8cca870caf603efe0d05dc1d9369cadad0fb7de20750a61e6d`
- Wrote an independent NumPy reconstruction of centered physical steering, its radian derivative, A, A-dot, all Hermitian-coordinate affine maps, physical SINRs/CRB, eigenpair residuals, and the complete dual map. It does not import the Python reference or JS mathematical implementation
- Executed the actual final JS core on **32 independent cases**, including three newly generated random channels, cap/cancel, rank-deficient and infeasible examples, all listed input/option boundary rejections, extreme numeric-range regressions, and mW-to-W rescaling
- Solved the three new channels with a separately written native-complex CVXPY/CLARABEL Eq. (33) formulation: Nt4/K2/theta−37, Nt4/K2/theta60, and Nt6/K3/theta19. Retained solver warnings and full covariance outputs. JS normalized-information differences from these oracle objectives were at most approximately 3.88e−8
- Independently replayed **17 conditioned parent output files** (16 unique inputs; duplicate-channel CLARABEL/SCS bookkeeping produces two files), plus **five held-H threshold-sweep outputs**. The 13 accepted conditioned cases and all five held-H cases pass the replay
- For the conditioned cases, independently recomputed the saved Python recovered objectives from NPZ matrices and compared both implementations’ objective/bound intervals. The intervals are consistent. For the held-H sweep, Python only emits its report, so that comparison uses the reported repaired-bound interval rather than unavailable Python matrices
- Independently loaded the actual browser UMD branches and worker `importScripts` flow in a **Node VM**. Run, cancellation, replacement, malformed ID, and absence of superseded final results passed. This does not substitute for running an actual browser

## Model and optimizer audit

The JS steering function intentionally returns the conjugate row of the paper’s steering column. Its derivative is the conjugate radian derivative; this is consistent with channel rows H[k]=h_k^H and physical response H W. Centering makes a^H a-dot and b^H b-dot zero. Consequently, the implemented simplified D^H D and D^H A maps match the directly constructed physical matrices, including nonzero angles and both odd/even receive-array examples.

The normalization is reversible: V_k=W_k/P, sA=||A||_F², sD=||D||_F², B0=A^H A/sA, B2=D^H D/sD, and B1=D^H A/sqrt(sA sD). The normalized objective is effective information/(P sD); physical CRB restores P, L, radar noise, and |alpha|².

The Hermitian coordinate order is diagonal, sqrt(2) times upper real parts, then sqrt(2) times upper imaginary parts. Therefore the four Schur rows construct precisely [u2−t,u1;conj(u1),u0]. Cone projection uses this same isometry for the 2×2 Schur matrix and all covariance blocks. Physical SINR rows have the correct desired 1/Gamma coefficient, negative interference, and normalized noise.

The actual DRS proximal solve is for the **linear objective −t**. An independent first-state calculation reproduced the emitted w, z and x, with maximum x error 2.03e−15. It confirms the +1 epigraph RHS coefficient after solving rho A^T A, rather than a quadratic surrogate or wrong-sign objective. Anderson acceleration is an implementation choice; the final physical/dual gates remain independent of its success.

Principal-eigenpair recovery from the real Hermitian embedding yields a unit-norm complex eigenvector and the physical beam sqrt(lambda) v. Independent NumPy reconstruction verifies the exported beams against each covariance, including the rank-one residual. The source’s rank(H[a,a-dot])=2 premise is explicitly treated as a numerical gate, not assumed for all multiuser inputs. The final implementation rejects relative singular values at or below 1e−8; this is a conservative numerical threshold, not an exact symbolic rank test.

## Certificate audit

For a dual vector y in the negative PSD cones and nonpositive lower-bound multipliers, support over the product cone is the sum of multiplier×lower-bound. The objective certificate normalizes the Schur (0,0) multiplier to −1, giving **exact floating-point t stationarity**. With E=A^T y−e_t and m=min(0,min_k lambda_min(E_k)), PSD V_k and total trace≤1 give sum_k trace(E_k V_k)≥m. Hence t≤support−m. This matches the exported upper-information bound and its trace-residual correction.

For the infeasibility separator, the Schur multiplier is zeroed, eliminating unbounded t. The same trace bound gives a valid contradiction when −support+m>0. The three saved conditioned separators and the fresh duplicate-channel separator all pass independent cone, support, residual, and bound replay. Iteration limits and cancellation remain nonaccepted terminal states and are never reported as infeasibility.

The certificate eigenvalue corrections were conservative relative to independent NumPy eigenvalues in every replay. Padding and spectral-error subtraction remain floating-point safeguards, not formal interval proofs. Likewise, recovered feasibility and small negative gaps are interpreted at the declared numerical tolerances.

## Numerical replay results

Across accepted/recovered outputs, the largest discrepancies between exported values and independent physical recomputation were:

- Power: 3.41e−13 mW
- SINR: 9.10e−13 absolute
- Normalized information: 3.33e−16
- Rank-one residual: 5.61e−17
- CRB versus an independent three-parameter Fisher Schur complement: 2.56e−16 relative
- Certificate epigraph stationarity: exactly zero

All conditioned recovered objectives lie within the Python repaired-bound intervals. The largest JS/Python recovered-information difference, 2.25e−6 for Nt8/Gamma20, is below the corresponding Python certificate span. The source-size Nt16/K4 case also passes matrix, physical, rank and certificate replay. Its Node runtime is not a browser-latency measurement.

The held-H sweep at Gamma 0/5/10/15/20 dB keeps every other input identical, passes all physical and certificate checks, and has monotonically nonincreasing information. Its maximum JS/Python objective difference is approximately 2.91e−7 and remains within the reported Python bound interval. The unit-rescaling experiment preserves SINR, information, and the corresponding physical power scale.

## Defects found and verified fixed

1. **Finite-alpha overflow could be accepted as zero CRB.** Earlier code checked the alpha components but not the finite squared magnitude. The recorded pre-hardening input alpha=1e200 produced a passed gate and CRB=0. Final v0.4 rejects this input, bounds L, and additionally rejects nonfinite or nonpositive computed CRB. Separate alpha-product overflow, CRB overflow, and subnormal-noise underflow probes now all fail closed with `invalid_CRB`
2. **Subtractive Gram eigenvalues could falsely claim the theorem’s rank premise.** Exactly duplicated rows could previously report relative singular values just above 1e−8. Final v0.4 uses a reorthogonalized two-column residual and determinant/large-eigenvalue formula. **10,000 exactly rank-one probes have zero false full-rank reports**; worst reported relative small singular value is 5.61e−32

Pre-hardening evidence is retained in `pre-hardening/` and `rank-condition-degenerate-probe.json`. No reviewer patches were applied to the parent implementation; the parent made and reran the fixes.

## Reproduce and inspect

Run `bash independent-review/run-review.sh` from the prototype directory. It uses the existing single-thread-BLAS Python environment and installed Node 24.19, installs no packages, creates fresh independent oracle outputs, executes the current actual JS, replays the saved conditioned/sweep matrices, and checks the verdict.

Main artifacts:

- `REVIEW.json`: exact final source hashes, 194 assertions, case counts, replay maxima and scope limits
- `review.py`: independent physical model, CVXPY oracle and complete matrix/certificate replay
- `driver.js`, `plan.json`, `*.js.json`: actual JS independent execution inputs and complete outputs
- `review-results.json`: per-case NumPy replay and oracle comparisons
- `check_drs.py`, `drs-one-step-check.json`: first-step linear-objective verification
- `probe_rank.js`, `rank-regression-results.json`: 10,000 rank-degeneracy regressions
- `browser_mode_vm.js`, `browser-mode-vm-results.json`: Node VM browser-branch/worker protocol test

The original rho=1 iteration caps are retained by the parent in `results/default/`; this review does not erase them or relabel them as infeasible. The final rho rule is deterministic conditioning, with no change to the physical Eq. (33) model.
