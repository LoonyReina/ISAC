/* Independent read-only harness: executes actual parent core, writes only review outputs. */
'use strict';
const fs=require('fs'),path=require('path'),core=require('../js/core.js'),la=require('../js/linalg.js');
const dir=__dirname,plan=JSON.parse(fs.readFileSync(path.join(dir,'plan.json'),'utf8'));
const arr=x=>Array.from(x), outputs=[];
for(const item of plan.cases){
 let out;
 try{const solver=core.createSolver(item.input,item.options||{});if(item.cancel){solver.step(item.cancelAfter||1);out=solver.cancel();}else{while(solver.status==='running')solver.step(250);out=solver.result(true);}}
 catch(e){out={status:'input_rejection',error:String(e.message||e)};}
 fs.writeFileSync(path.join(dir,item.id+'.js.json'),JSON.stringify(out,null,2));outputs.push({id:item.id,status:out.status,iterations:out.iterations,ms:out.kernelWallMs,passed:out.physicalGate?.passed});console.log(JSON.stringify(outputs.at(-1)));
}
const models=[];for(const p of plan.models){const m=core.model(p.Nt,p.Nr,p.thetaDegrees),R=Float64Array.from(p.R.real.flatMap((row,i)=>row.flatMap((v,j)=>[v,p.R.imag[i][j]]))),x=la.coordinates(R,p.Nt),s=core.steeringRow(p.Nt,p.thetaDegrees);models.push({id:p.id,model:Object.fromEntries(Object.entries(m).map(([k,v])=>[k,typeof v==='number'?v:arr(v)])),coordinates:arr(x),metrics:core.pointMetrics(R,p.input,m),roundtrip:la.pack(la.matrix(x,p.Nt),p.Nt,p.Nt),steering:{a:arr(s.a),ad:arr(s.ad)}});}
fs.writeFileSync(path.join(dir,'models.js.json'),JSON.stringify(models,null,2));
fs.writeFileSync(path.join(dir,'index.js.json'),JSON.stringify(outputs,null,2));
