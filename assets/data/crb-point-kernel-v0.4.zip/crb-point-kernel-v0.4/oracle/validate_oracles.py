#!/usr/bin/env python3
"""Verify all serialized oracle values and hashes without solving again."""
from generate_oracles import *
index=json.loads((ROOT/'index.json').read_text())
checks=[]
def check(name,passed,value=None): checks.append({'name':name,'passed':bool(passed),'value':safe(value)})
def arr(x):
    return np.asarray(x['real'])+1j*np.asarray(x['imag']) if isinstance(x,dict) and set(x)=={'real','imag'} else np.asarray(x)
check('frozen reference matched generation snapshot',index['frozenReferenceUnchanged'])
check('frozen reference remains identical now',json.loads((ROOT/'reference-integrity.json').read_text())['after']==reference_snapshot())
check('12 routine inputs',sum(c['group']=='routine' for c in index['cases'])==12)
check('one separate source scaling input',sum(c['group']=='scaling' for c in index['cases'])==1)
check('routine seeds all unique',len({c['seed'] for c in index['cases'] if c['group']=='routine'})==12)
summaries=[]
for row in index['cases']:
    name=row['id']; inp=json.loads((ROOT/row['inputFile']).read_text()); data=json.loads((ROOT/row['resultFile']).read_text()); report=data['report']
    for kind in ['input','result','npz']:
        check(name+' '+kind+' hash',digest(ROOT/row[kind+'File'])==row[kind+'Sha256'])
    check(name+' exact API keys',set(inp)=={'Nt','Nr','K','L','powerMw','communicationNoiseMw','radarNoiseMw','thetaDegrees','alpha','H','gammaDb'})
    with np.load(ROOT/row['npzFile']) as saved:
        check(name+' JSON/NPZ array keys',set(saved.files)==set(data['arrays']))
        for key in saved.files:
            check(name+' '+key+' JSON/NPZ equality',np.array_equal(saved[key],arr(data['arrays'][key])))
    H=arr(inp['H']); check(name+' H shape',H.shape==(inp['K'],inp['Nt']))
    check(name+' H values equal solution',np.array_equal(H,arr(data['arrays']['H'])))
    if row['group'] in ('routine','scaling'):
        check(name+' numerical acceptance',report.get('accepted',False))
        direct=data['independentChecks']; r=direct['R_recovered']; d=direct['cert_dual']; b=direct['beams']
        check(name+' certificate gap bounded',-2e-5<=d['relativeGap']<=1e-4,d['relativeGap'])
        check(name+' positive certificate dual cone',d['coneMinEigenvalue']>=-1e-9,d['coneMinEigenvalue'])
        check(name+' positive stationarity cones',min(d['stationarityMinEigenvalues'])>=-1e-9,d['stationarityMinEigenvalues'])
        check(name+' certificate coefficient',d['coefficientError']<=1e-9,d['coefficientError'])
        check(name+' positive multipliers',d['minimumMultiplier']>=-1e-12,d['minimumMultiplier'])
        check(name+' beam power',b['powerMw']<=inp['powerMw']*(1+2e-5),b['powerMw'])
        check(name+' beam SINR',min(b['sinrToRequirement'])>=1-2e-5,b['sinrToRequirement'])
        check(name+' objective contraction agreement',abs(direct['R']['objectiveNormalized']-report['diagnostics']['recomputed_objective'])<1e-12)
        check(name+' finite difference FIM independent agreement',direct['independentFiniteDifferenceFIM']['relativeError']<1e-7,direct['independentFiniteDifferenceFIM']['relativeError'])
        summaries.append({'id':name,'status':report['status'],'accepted':report['accepted'],'normalizedObjective':r['objectiveNormalized'],
                          'rootCrbDegrees':report['radar']['root_crb_degrees'],'powerMw':b['powerMw'],'minimumSinrRatio':min(b['sinrToRequirement']),
                          'relativeCertificateGap':d['relativeGap'],'finiteDifferenceRelativeError':direct['independentFiniteDifferenceFIM']['relativeError'],
                          'rawRankOneMaximumResidual':max(report['recovery']['rank_one_relative_residuals']),
                          'warningCount':len(report['warnings'])})
    else:
        check(name+' never accepts stress case',not report.get('accepted',False))
validation={'checks':checks,'allPassed':all(x['passed'] for x in checks),'checkCount':len(checks),'acceptedCaseSummaries':summaries,
            'ranges':{'minimumSinrRatio':min(x['minimumSinrRatio'] for x in summaries),
                      'maximumRelativeCertificateGap':max(x['relativeCertificateGap'] for x in summaries),
                      'maximumFiniteDifferenceRelativeError':max(x['finiteDifferenceRelativeError'] for x in summaries),
                      'maximumRawRankOneResidual':max(x['rawRankOneMaximumResidual'] for x in summaries)},
            'warningsRetainedCount':sum(len(json.loads((ROOT/x['resultFile']).read_text())['report'].get('warnings',[])) for x in index['cases'])}
save_json(ROOT/'validation.json',validation)
print(json.dumps({k:v for k,v in validation.items() if k not in ('checks','acceptedCaseSummaries')},indent=2))
assert validation['allPassed'], [x for x in checks if not x['passed']]
