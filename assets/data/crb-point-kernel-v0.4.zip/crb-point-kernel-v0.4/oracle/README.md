# Fresh point-target Eq. (33) Python oracle

This directory is an independent, newly solved numerical reference for the JavaScript prototype. It does **not** interpolate or reuse stored experiment answers. It imports the frozen sibling `crb-beamforming-reference/reference.py`, without changing that tree or writing Python bytecode there. It does not execute a browser or modify production/UI/GitHub files.

## Contents

- `index.json`: machine-readable input/result paths, fresh random seeds, solver statuses, hashes, and warning/error summaries
- `routine/`: 12 inputs, with Nt = 4/6/8, Nr = Nt + 4, K = 2, L = 30; Γ = 0/10/20 dB at 0° and Γ = 10 dB at 23° for each Nt
- `scaling/`: a separate fresh Nt = 16, Nr = 20, K = 4, Γ = 15 dB, 0° case
- `stress/`: duplicate-channel, zero-channel, and near-collinear-channel cases; the duplicate has both its retained CLARABEL failure and a separate SCS retry
- `*.input.json`: the exact JavaScript-facing API, with scalar `gammaDb`
- `*.result.json`: raw solver report, finalized report, all warnings/errors, independent recomputations, and all numerical solution arrays
- `*.npz`: the identical solution arrays in NumPy format
- `validation.json` / `validation.log`: 474 checks of hashes, shapes, numerical metrics, constraints, certificates, and serialized-array agreement
- `reference-integrity.json`: SHA-256 snapshots of every file in the frozen reference, before and after generation

There are **16 unique inputs and 17 saved attempts**. Routine seeds are 290101–290112, scaling uses 290113, and stress inputs use 290114–290116. The SCS retry deliberately uses the identical duplicate-channel input and seed, not a replacement sample.

## Physical and array conventions

Every input uses 1000 mW transmit power, 1 mW communication noise, 1 mW radar noise, L = 30, and alpha = 1 + 0i. Gamma is `10 ** (gammaDb / 10)`, shared by all K users. No power or noise values are interpreted as dBm by the input API.

`H.real` and `H.imag` are K-by-Nt matrices. The row H[k] means h_k^H; communication responses are `H @ Wc`, without an additional conjugation of H. `Wc` is Nt-by-K in square-root-mW amplitude units, `Wks` contains the K physical-mW covariance matrices, and `R` is their sum. `R_recovered` is the physical-mW covariance of the finalized recovered beams. Internal normalized covariances are `Wks / powerMw`.

JSON complex arrays use `{ "real": <nested array>, "imag": <same-shaped nested array> }`. Real arrays use ordinary JSON arrays. A real scalar NumPy array such as `dual_power` is serialized as a number. Solver non-finite objectives, if present, are saved as explicit strings rather than invalid JSON numbers.

## Comparing JavaScript results

Use both the physical metrics and the normalized objective. The normalized objective is

`effectiveInformation / (powerMw * ||D||_F^2)`

where `A = b a^H` and `D = b_dot a^H + b a_dot^H`, with centered half-wavelength ULA positions. The objective in the raw report's `diagnostics.recomputed_objective` evaluates the solved SDR covariance `R`. The `independentChecks.R_recovered.objectiveNormalized` value evaluates the final recovered beams. Distinguish these rather than comparing arbitrary eigenvector phases or beam entries.

`independentChecks.cert_dual.upperObjectiveNormalized` is a repaired numerical dual upper bound. The saved `cert_dual_sinr`, `cert_dual_power`, and `cert_dual_lmi` arrays allow a fresh stationarity/PSD/objective check. Raw dual arrays are saved separately. These are floating-point weak-duality certificates, **not** interval-arithmetic proofs.

The independent checks also recompute transmit power, achieved SINRs, covariance contractions, and a real 3-by-3 Fisher-information matrix from finite-difference target observations and an exactly orthogonal finite block.

## Results and caveats

All 12 routine cases and the separate scaling case pass the frozen reference's finalized feasibility/certificate acceptance rule. All 13 retain their `optimal_inaccurate` solver warning; none has been relabeled as `optimal`.

Across those 13 cases:

- Maximum relative repaired-dual gap: 3.6853365749307435e-6
- Minimum achieved SINR / requirement: 0.9999801283927674
- Maximum finite-difference CRB relative error: 4.118076990522468e-10
- The frozen tree is unchanged, verified by full-file hashes

**Marginal raw rank flag:** Nt8/K2/Γ20/seed290111 has a maximum raw dominant-eigenpair covariance residual of 2.097338630284305e-5, slightly above the raw 2e-5 rank flag. Its raw report rejects it, but frozen `finalize_solution` subsequently accepts the recovered beams and repaired dual certificate. The original flags and arrays are retained. Do not claim every raw rank test passed, and do not use `accepted` as a claim of mathematical exactness.

Stress results:

- Duplicate channels, Γ10 dB: CLARABEL returned a retained SolverError with no accepted solution; a separate SCS attempt returned `infeasible`. Analytically, the two constraints imply x1 ≥ 10(x2+1) and x2 ≥ 10(x1+1), whose sum is impossible for nonnegative powers
- Zero second channel, Γ0 dB: rejected before solve with the exact validation exception
- Near-collinear channels, Γ10 dB: H[1] = H[0] + 1e-6 z with a fresh independent complex z; CLARABEL returned `infeasible`

No JavaScript runtime/iteration-cap behavior is asserted here; that belongs to the prototype tests.

## Reproducing

Use the existing interpreter:

`/workspace/shared/isac-paper-execution/atomic-receiver-reference/.venv/bin/python`

Set `PYTHONDONTWRITEBYTECODE=1`, `OPENBLAS_NUM_THREADS=1`, `OMP_NUM_THREADS=1`, `MKL_NUM_THREADS=1`, and `NUMEXPR_NUM_THREADS=1`. The generator also explicitly sets BLAS thread environment variables to 1 before importing NumPy/CVXPY.

Run `generate_oracles.py`, then `supplement_duplicate.py`, then `validate_oracles.py`. Generation writes only into this oracle directory. Archive an existing run before regeneration so its results remain available. `supplement_duplicate.py` refuses to overwrite an already retained supplementary attempt. `validate_oracles.py` only reads the solver data and writes the validation report; it never reruns optimization.
