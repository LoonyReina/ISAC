#!/usr/bin/env python3
"""Fresh Eq. (33) comparison cases, generated only from the frozen Python reference.
Writes ONLY alongside this script; never modifies or byte-compiles the reference.
"""
from __future__ import annotations
import os
for name in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','VECLIB_MAXIMUM_THREADS','BLIS_NUM_THREADS'):
    os.environ[name]='1'
import sys
sys.dont_write_bytecode=True
from pathlib import Path
ROOT=Path(__file__).resolve().parent
REFERENCE=Path(os.environ.get('CRB_REFERENCE_DIR', str(ROOT.parent/'python-reference')))
sys.path.insert(0,str(REFERENCE))
import reference as ref
import numpy as np
import cvxpy as cp
import json, hashlib, time, warnings, traceback, copy, platform
from datetime import datetime, timezone


def safe(x):
    if isinstance(x,dict): return {str(k):safe(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)): return [safe(v) for v in x]
    if isinstance(x,np.ndarray):
        return {'real':x.real.tolist(),'imag':x.imag.tolist()} if np.iscomplexobj(x) else safe(x.tolist())
    if isinstance(x,(np.floating,np.integer,np.bool_)): return safe(x.item())
    if isinstance(x,complex): return {'real':x.real,'imag':x.imag}
    if isinstance(x,float) and not np.isfinite(x): return str(x)
    return x


def save_json(path,x):
    path.write_text(json.dumps(safe(x),indent=2,allow_nan=False)+'\n')


def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()

def reference_snapshot():
    return {str(p.relative_to(REFERENCE)):digest(p) for p in sorted(REFERENCE.rglob('*')) if p.is_file()}


def direct_checks(s,c):
    """Recompute primal/dual data from exported arrays without metric helpers."""
    H=s['H']; gamma=s['gamma']; n=c.nt; k=len(H)
    t=np.deg2rad(c.theta_degrees)
    pt=np.arange(n)-(n-1)/2; pr=np.arange(c.nr)-(c.nr-1)/2
    at=np.exp(1j*np.pi*pt*np.sin(t)); ar=np.exp(1j*np.pi*pr*np.sin(t))
    ad=1j*np.pi*pt*np.cos(t)*at; bd=1j*np.pi*pr*np.cos(t)*ar
    A=ar[:,None]*at.conj()[None,:]
    D=bd[:,None]*at.conj()[None,:]+ar[:,None]*ad.conj()[None,:]
    sA=float(np.vdot(A,A).real); sD=float(np.vdot(D,D).real)
    B0=A.conj().T@A/sA; B2=D.conj().T@D/sD; B1=D.conj().T@A/np.sqrt(sA*sD)
    out={'sA':sA,'sD':sD,'objective_normalization':'effective information / (powerMw * sD)'}
    for key in ['R','R_recovered']:
        if key not in s: continue
        R=s[key]; r0=float(np.trace(A@R@A.conj().T).real)
        r1=complex(np.trace(A@R@D.conj().T)); r2=float(np.trace(D@R@D.conj().T).real)
        effective=r2-abs(r1)**2/r0 if r0>0 else None
        out[key]={'s0':r0,'s1':r1,'s2':r2,'effectiveInformation':effective,
                  'objectiveNormalized':effective/(c.power_mw*sD) if effective is not None else None,
                  'crbRad2':c.radar_noise_mw/(2*abs(c.alpha)**2*c.snapshots*effective) if effective is not None and effective>0 else None,
                  'powerMw':float(np.trace(R).real),
                  'minEigenvalue':float(np.linalg.eigvalsh((R+R.conj().T)/2).min())}
    if 'Wc' in s:
        W=s['Wc']; G=H@W; gains=abs(G)**2; desired=np.diag(gains); interference=gains.sum(axis=1)-desired
        sinr=desired/(interference+c.communication_noise_mw)
        out['beams']={'powerMw':float(np.vdot(W,W).real),'sinr':sinr,'sinrToRequirement':sinr/gamma,
                      'desiredMw':desired,'interferenceMw':interference,
                      'covarianceMismatch':float(np.linalg.norm(W@W.conj().T-s['R_recovered']))}
        # Independent finite-block observation and finite-difference real FIM.
        X=W@np.exp(2j*np.pi*np.arange(k)[:,None]*np.arange(c.snapshots)[None,:]/c.snapshots)
        dt=1e-6
        def a_theta(theta):
            aa=np.exp(1j*np.pi*pt*np.sin(theta)); bb=np.exp(1j*np.pi*pr*np.sin(theta))
            return bb[:,None]*aa.conj()[None,:]
        Dfd=(a_theta(t+dt)-a_theta(t-dt))/(2*dt)
        z=(A@X).ravel(order='F'); d=(c.alpha*Dfd@X).ravel(order='F')
        J=np.column_stack((d,z,1j*z)); FIM=2/c.radar_noise_mw*(J.conj().T@J).real
        try:
            fd=float(np.linalg.inv(FIM)[0,0]); exact=out['R_recovered']['crbRad2']
            out['independentFiniteDifferenceFIM']={'crbRad2':fd,'relativeError':abs(fd/exact-1),'stepRadians':dt}
        except Exception as exc: out['independentFiniteDifferenceFIM']={'error':repr(exc)}
    Q=np.array([np.outer(h.conj(),h)/np.vdot(h,h).real for h in H])
    eta=c.communication_noise_mw/(c.power_mw*np.sum(abs(H)**2,axis=1))
    if 'Wks' in s:
        V=s['Wks']/c.power_mw; R=V.sum(axis=0)
        out['covarianceSinrSlacks']=[float(np.trace(Q[j]@V[j]).real/gamma[j]-np.trace(Q[j]@(R-V[j])).real-eta[j]) for j in range(k)]
    for prefix in ['', 'cert_']:
        if prefix+'dual_lmi' not in s: continue
        Z=s[prefix+'dual_lmi']; mu=float(s[prefix+'dual_power']); lam=s[prefix+'dual_sinr']
        F=Z[0,0].real*B2+Z[1,1].real*B0+Z[1,0]*B1+Z[0,1]*B1.conj().T
        matrices=[mu*np.eye(n)-F+sum(lam[i]*Q[i] for i in range(k))-lam[j]*(1+1/gamma[j])*Q[j] for j in range(k)]
        bound=float(mu-lam@eta)
        out[prefix+'dual']={'upperObjectiveNormalized':bound,'stationarityMinEigenvalues':[float(np.linalg.eigvalsh((M+M.conj().T)/2).min()) for M in matrices],
                            'coneMinEigenvalue':float(np.linalg.eigvalsh((Z+Z.conj().T)/2).min()),'coefficientError':float(abs(Z[0,0]-1)),
                            'minimumMultiplier':float(min(mu,lam.min()))}
        if 'R_recovered' in out:
            obj=out['R_recovered']['objectiveNormalized']
            out[prefix+'dual']['relativeGap']=(bound-obj)/max(abs(obj),1e-15)
    return out


def make_input(nt,seed,gamma_db,theta=0,k=2,stress=None):
    H=ref.rayleigh(seed,k,nt)
    if stress=='duplicate': H[1]=H[0]
    if stress=='zero': H[1]=0
    if stress=='near-collinear':
        # Nearly identical nonzero, linearly independent rows; deliberately difficult and infeasible at 10 dB.
        H[1]=H[0]+1e-6*H[1]
    return dict(Nt=nt,Nr=nt+4,K=k,L=30,powerMw=1000.,communicationNoiseMw=1.,radarNoiseMw=1.,thetaDegrees=theta,
                alpha={'real':1.,'imag':0.},H={'real':H.real.tolist(),'imag':H.imag.tolist()},gammaDb=gamma_db),H


def generate(case):
    name=case['id']; api,H=make_input(case['nt'],case['seed'],case['gammaDb'],case.get('thetaDegrees',0),case.get('k',2),case.get('stress'))
    folder=ROOT/case['group']; folder.mkdir(exist_ok=True)
    input_file=folder/(name+'.input.json'); result_file=folder/(name+'.result.json'); npz_file=folder/(name+'.npz')
    save_json(input_file,api)
    c=ref.Config(nt=api['Nt'],nr=api['Nr'],snapshots=api['L'],power_mw=api['powerMw'],communication_noise_mw=api['communicationNoiseMw'],radar_noise_mw=api['radarNoiseMw'],theta_degrees=api['thetaDegrees'],alpha=complex(**{'real':api['alpha']['real'],'imag':api['alpha']['imag']}))
    gamma=np.full(api['K'],10**(api['gammaDb']/10))
    start=time.perf_counter(); report={'id':name,'group':case['group'],'seed':case['seed'],'inputFile':str(input_file.relative_to(ROOT)),
            'npzFile':str(npz_file.relative_to(ROOT)),'pythonReference':str(REFERENCE/'reference.py'),
            'inputConvention':'H[k] is the complex channel row h_k^H; communication responses are H @ Wc',
            'gammaLinear':gamma.tolist(),'solver':case.get('solver','CLARABEL'),'solverTolerance':case.get('tol',1e-9),'allAttemptsRetained':True}
    if case.get('stress'): report['stress']=case['stress']
    result={'H':H,'gamma':gamma}
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter('always')
        try:
            result=ref.solve_sdr(H,gamma,c,'point',solver=case.get('solver','CLARABEL'),tol=case.get('tol',1e-9))
            report['rawReport']=copy.deepcopy(result['report'])
            result=ref.finalize_solution(result,c)
            report['report']=result['report']
            if 'R' in result: report['independentChecks']=direct_checks(result,c)
        except Exception as exc:
            report['exception']={'type':type(exc).__name__,'message':str(exc),'traceback':traceback.format_exc()}
            report.setdefault('report',{'status':'rejected_before_solve' if isinstance(exc,ValueError) and 'Wks' not in result else 'exception','accepted':False})
        report['outerWarnings']=[{'category':w.category.__name__,'message':str(w.message),'filename':w.filename,'lineno':w.lineno} for w in caught]
    report['wallSeconds']=time.perf_counter()-start
    arrays={key:val for key,val in result.items() if isinstance(val,np.ndarray)}
    np.savez_compressed(npz_file,**arrays)
    report['arrays']=arrays
    report['inputSha256']=digest(input_file); report['npzSha256']=digest(npz_file)
    save_json(result_file,report)
    row={**case,'inputFile':str(input_file.relative_to(ROOT)),'resultFile':str(result_file.relative_to(ROOT)),'npzFile':str(npz_file.relative_to(ROOT)),
         'status':report['report']['status'],'accepted':report['report'].get('accepted',False),'wallSeconds':report['wallSeconds'],
         'inputSha256':digest(input_file),'resultSha256':digest(result_file),'npzSha256':digest(npz_file),
         'warnings':report['report'].get('warnings',[]),'outerWarnings':report['outerWarnings'],'error':report.get('exception') or report['report'].get('error')}
    cert=report['report'].get('certificate')
    if cert: row['relativeCertificateGap']=cert['relative_gap']
    print(json.dumps(safe({key:row[key] for key in ['id','status','accepted','wallSeconds','warnings','error'] })),flush=True)
    return row


def main():
    before=reference_snapshot()
    cases=[]; seed=290101
    for nt in [4,6,8]:
        for db in [0,10,20]:
            cases.append(dict(id=f'nt{nt}-k2-g{db}-theta0-seed{seed}',group='routine',nt=nt,k=2,gammaDb=db,thetaDegrees=0,seed=seed)); seed+=1
        cases.append(dict(id=f'nt{nt}-k2-g10-theta23-seed{seed}',group='routine',nt=nt,k=2,gammaDb=10,thetaDegrees=23,seed=seed));seed+=1
    cases.append(dict(id=f'nt16-k4-g15-theta0-seed{seed}',group='scaling',nt=16,k=4,gammaDb=15,thetaDegrees=0,seed=seed));seed+=1
    for stress,db in [('duplicate',10),('zero',0),('near-collinear',10)]:
        cases.append(dict(id=f'nt4-k2-{stress}-g{db}-seed{seed}',group='stress',nt=4,k=2,gammaDb=db,thetaDegrees=0,seed=seed,stress=stress));seed+=1
    index={'generatedAt':datetime.now(timezone.utc).isoformat(),'schemaVersion':1,'scope':'genuine fresh Python/CVXPY Eq33 point-target oracle; no stored-result interpolation',
           'referenceDirectory':str(REFERENCE),'referenceSha256':before['reference.py'],
           'physicalDefaults':{'powerMw':1000,'communicationNoiseMw':1,'radarNoiseMw':1,'L':30},
           'environment':{'pythonExecutable':sys.executable,'pythonVersion':platform.python_version(),'numpyVersion':np.__version__,'cvxpyVersion':cp.__version__,
                          'threadSettings':{x:os.environ[x] for x in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','VECLIB_MAXIMUM_THREADS','BLIS_NUM_THREADS')}},
           'jsonComplexArrayEncoding':'{real: nested arrays, imag: matching nested arrays}',
           'certificateCaveat':'Repaired floating-point weak-duality checks are numerical evidence, not interval-arithmetic proofs.',
           'cases':[]}
    for case in cases:
        index['cases'].append(generate(case)); save_json(ROOT/'index.json',index)
    after=reference_snapshot()
    index['frozenReferenceUnchanged']=before==after
    index['referenceFileCountChecked']=len(before)
    index['counts']={group:{'total':sum(x['group']==group for x in index['cases']),'accepted':sum(x['group']==group and x['accepted'] for x in index['cases'])} for group in ['routine','scaling','stress']}
    save_json(ROOT/'index.json',index)
    save_json(ROOT/'reference-integrity.json',{'unchanged':before==after,'before':before,'after':after})
    assert before==after, 'Frozen reference changed unexpectedly'
    print(json.dumps(index['counts']),flush=True)

if __name__=='__main__': main()
