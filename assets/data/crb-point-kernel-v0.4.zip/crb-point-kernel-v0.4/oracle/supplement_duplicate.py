#!/usr/bin/env python3
"""Retain CLARABEL failure and separately test the identical impossible input in SCS."""
from generate_oracles import *
index=json.loads((ROOT/'index.json').read_text())
case=dict(id='nt4-k2-duplicate-g10-seed290114-scs-check',group='stress',nt=4,k=2,gammaDb=10,thetaDegrees=0,seed=290114,stress='duplicate',solver='SCS',tol=1e-8,
          supplementaryAttemptOf='nt4-k2-duplicate-g10-seed290114')
if any(row['id']==case['id'] for row in index['cases']):
    raise RuntimeError('Supplement already generated; do not overwrite retained attempt')
before=reference_snapshot()
row=generate(case)
row['analyticInfeasibility']='With identical channel rows and gamma=10, SINR requires x1 >= 10*(x2+1) and x2 >= 10*(x1+1). Summing gives -9*(x1+x2) >= 20, impossible for nonnegative received powers.'
index['cases'].append(row)
index['counts']={group:{'total':sum(x['group']==group for x in index['cases']),'accepted':sum(x['group']==group and x['accepted'] for x in index['cases'])} for group in ['routine','scaling','stress']}
index['uniqueInputCount']=len({row['inputSha256'] for row in index['cases']})
index['attemptCount']=len(index['cases'])
index['supplementNotes']='One duplicate-channel input has a retained CLARABEL failure and a separate SCS attempt; there are 16 unique inputs and 17 saved attempts.'
after=reference_snapshot();assert before==after
index['supplementFrozenReferenceUnchanged']=True
save_json(ROOT/'index.json',index)
