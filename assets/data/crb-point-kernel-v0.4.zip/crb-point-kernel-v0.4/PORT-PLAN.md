# CRB multiuser browser-kernel feasibility plan

Primary source: Liu et al., *Cramér-Rao Bound Optimization for Joint Radar-Communication Beamforming*, IEEE TSP70 (2022),240–253, DOI10.1109/TSP.2021.3135692. [Fixed institution-hosted journal PDF](https://www.weizmann.ac.il/math/yonina/sites/math.yonina/files/Cramr-Rao_Bound_Optimization_for_Joint_Radar-Communication_Beamforming.pdf), SHA256 `3bb9519855b92a8cca870caf603efe0d05dc1d9369cadad0fb7de20750a61e6d`. No PDF is redistributed.

## Decision: point target first

The standalone JavaScript prototype solves the actual point-target multiuser SDP, journal Eq.(33). It does not run the old single-user theorem, evaluate stored beams, or interpolate offline curves. It has its own operator, linear objective, rank recovery and numerical certificate. Only reviewed Hermitian PSD/eigen primitives and elementary linear-algebra utilities are reused; their source hashes are in `LINALG-PROVENANCE.json`.

Reasons for choosing this branch first:

1. Its additional information cone is only 2×2. Existing tested projection supports complex PSD matrices up to17, so Nt16 remains within that primitive's reviewed dimension limit
2. All three source-sized point cases in the frozen Python reference passed its numerical gates, while three genuinely feasible extended cases failed recovery/certification
3. A fresh JavaScript Nt16/Nr20/K4/Gamma15 case now converges, with a separately retained initial80.69-second capped attempt. The final conditioned Node run is about5.67seconds; this is an original-size scaling result, not general browser-latency acceptance
4. All12 fresh reduced cases converge under the final deterministic conditioning rule, with measured Node durations approximately24–730ms. First teaching scope should be Nt4/6/8 and K2, explicit Run/Cancel, and unchanged source-unit resources. Do not advertise the entire supported-input range as benchmarked

## Exact point model

Physical input H has rows h_k^H. Covariances W_k=w_k w_k^H have mW units, R=sum W_k, and sum trace W_k<=P. Each user must satisfy tr(h_k h_k^H W_k)/[sum_{i≠k}tr(h_k h_k^H W_i)+sigmaC²]>=Gamma. There are K independent communication streams and no extra probing stream in this branch.

Centered half-wavelength unnormalized ULA a(theta), b(theta), with radians for the derivatives. A=b a^H, D=dA/dtheta. Let s0=tr(A^H A R), s1=tr(D^H A R), s2=tr(D^H D R). The unknown-complex-reflectivity angular CRB is sigmaR²/[2|alpha|² L(s2-|s1|²/s0)]. The code retains the nuisance-parameter subtraction. It does not substitute target illumination or a known-alpha Fisher term.

Eq.(33) maximizes t subject to the Hermitian cone [s2−t,s1;conj(s1),s0]>=0 and the communication/power/PSD constraints, after dropping the individual rank-one constraints. The internal V_k=W_k/P and diagonal congruence of the information cone are reversible conditioning operations. Returned normalizedInformation is (s2−|s1|²/s0)/(P||D||F²); it is **not** the old single-user lesson's g or a normalized radar-only improvement ratio.

Theorem2 requires rank(H[a,a_dot])=2. The code exposes its matrix, singular values, relative tolerance1e−8 and rank result. The small singular value is calculated using reorthogonalized two-column QR residuals to avoid subtractive Gram cancellation. Principal-eigenvector extraction is followed by real beam power/SINR/information checks. If the theorem rank condition fails, no accepted original-problem result is reported. The frozen Python K1 rank-two counterexample remains a separate warning against replacing the old single-user theorem with an unrestricted Eq.(33) relaxation.

## Numerical method and evidence

Real orthonormal Hermitian coordinates represent each V_k. A linear map stacks K PSD blocks, the2×2 information cone and K+1 affine inequalities. The objective is exactly −t. Douglas–Rachford splitting uses

z=projection_C(w), x=(rho A^T A)^−1[rho A^T(2z−w)−c], w←w+relaxation(Ax−z), c_t=−1.

Safeguarded Anderson acceleration is optional. The final default rho=clamp(Gamma_linear,1,100) is a declared conditioning heuristic, not a model change. Every option is exported. Earlier rho1 capped outcomes remain in `results/default/`; explicit rho10/100 experiments remain in `results/conditioning/`. No unsuccessful trial was replaced in those records.

The dual is projected into the proper cone-normal signs. Its t coefficient is normalized exactly; residual covariance stationarity is bounded using the shared trace budget and minimum eigenvalue. This yields a numerical upper bound on achievable normalized information. The design is accepted only after recovered-beam gates, not because the DRS iterate has a small residual. Infeasibility has a separate residual-adjusted live separator or necessary individual total-power bound; iteration limit is never relabeled infeasible.

These are floating-point, tolerance-qualified numerical checks. Small negative reported objective gaps and tiny constraint shortfalls can occur within explicit tolerances; do not describe them as exact interval-certified global optima.

## Stage gates

- Point model/actual JS: independent NumPy and separate CVXPY oracle replay, explicit raw-echo Fisher check, fresh complex channels, caps, rank exceptions and infeasibility separation
- Worker protocol: run IDs, cancellation, replacement, stale-result exclusion and invalid input tested using Node worker_threads and a browser-code VM harness. This is not a real browser test
- First lesson proposal: only after exact runtime hashes and independent review are frozen; no production/UI edit is authorized by this package
- Hosted-browser gate: actual supported browsers/devices, input-to-result measurements, worst-case progress/cancel responsiveness, stale display behavior, accessibility and exports/imports. Entirely open
- Source-size gate: substantially broader channel/SINR stability and latency evidence before including Nt16/K4 as a normal interactive control. Current single fresh case is a scaling experiment

## Extended branch: separate unopened port gate

Target: Eq.(46), equivalently Eq.(36), min tr(R^−1) with K data PSD blocks plus an unrestricted-rank auxiliary covariance, total power and Eq.(18) SINR including auxiliary interference. In normalized units, use [Nt sum V,I;I,T]>=0 and objective tr(T)/Nt. Recover communication beams using Eq.(48), then factor R−sum w_k w_k^H according to Eq.(49). This is not a point-target optimizer with a relabeled metric.

A direct epigraph port needs a2Nt-dimensional complex PSD cone. The reused projection's validated limit17 supports at most Nt8 for that cone; Nt16 would require expanding and independently validating the eigensolver to real dimension64. Do not merely raise an input cap. The trace-inverse domain also requires nonsingular full-rank R and stricter conditioning checks. The dual T-stationarity is a matrix equality, unlike the scalar t equality in the point branch, so the point certificate cannot be copied unchanged.

First extended gate should therefore be new reduced Nt4/K2 cases with full-rank auxiliary recovery, independent inverse/FIM checks, exact SINR including probing interference, and dedicated dual equality/positive-eigenvalue checks. Reusing Eq.(48) algebra from an existing covariance solver is appropriate only after fresh validation of this model's total-power constraint and inverse objective. An alternative eigenvalue-proximal inverse-trace algorithm would need its own derivation and reference checks.

Frozen reference source experiments preserve six rejected extended cases: three independently proved over-budget by numerical min-power duals, three feasible numerical failures with independent full-rank witnesses. All remain unresolved with respect to that strict optimizer gate; no browser success is inferred from the witnesses.

## Fixed-H comparisons and resource honesty

The routine oracle fixtures have different channel seeds and must not be joined into a tradeoff curve. `results/held-channel/` instead keeps the same H and every physical resource fixed while freshly solving Gamma0/5/10/15/20dB; allfive JS/Python comparisons pass and normalized information is monotone within tolerance. Gamma0dB means a threshold of1, not no communication requirement.

There is no browser implementation of the author's two prior-paper beampattern baselines. The initial lesson should compare same-H threshold choices, recovered constraints and dual bounds only. Keep alpha1 and use adaptive angle precision; any later educational radar-SNR rescaling must be visible and separately tested. Actual noisy ML in the frozen offline reference is a different experiment, not a consequence of executing this beam optimizer.
