"""Deterministic additive artifact packaging. Does not touch frozen solver files."""
import hashlib,json,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
files=sorted(p for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name not in ['ARTIFACT-MANIFEST.json'] and p.suffix not in ['.pyc'])
manifest={'artifact':'crb-beamforming-export-checker-v1','scope':'Independent numerical replay; no browser provenance or full-paper claim','files':[dict(path=str(p.relative_to(ROOT)),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in files]}
mp=ROOT/'ARTIFACT-MANIFEST.json';mp.write_text(json.dumps(manifest,indent=2)+'\n');files.append(mp)
archive=ROOT.parent/'crb-beamforming-export-checker-v1.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(files):
  info=zipfile.ZipInfo('crb-beamforming-export-checker-v1/'+str(p.relative_to(ROOT)),date_time=(2026,10,12,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,p.read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
print(json.dumps(dict(archive=str(archive),bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),manifestSha256=hashlib.sha256(mp.read_bytes()).hexdigest(),files=len(files)),indent=2))
