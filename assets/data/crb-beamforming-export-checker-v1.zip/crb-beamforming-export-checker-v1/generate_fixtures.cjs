/* Test-fixture generation only. The Python checker never executes this script. */
'use strict';
const fs=require('fs'),path=require('path');
const kernel=process.argv[2],adapter=process.argv[3];
if(!kernel||!adapter)throw Error('Usage: node generate_fixtures.cjs /path/to/frozen/core.js /path/to/lesson/model.js');
const Core=require(path.resolve(kernel)),Model=require(path.resolve(adapter));
const dir=path.join(__dirname,'fixtures');fs.mkdirSync(dir,{recursive:true});
const rows=[];
function solve(id,input,options={},mode='full',envelope=true){const solver=Core.createSolver(input,options);if(mode.startsWith('cancel')){solver.step(2);solver.cancel();}else while(solver.status==='running')solver.step(1000);const result=solver.result(mode!=='cancel-partial');let record=result;if(envelope)record=Model.buildRecord({input,result,runId:rows.length+1,uiTimingMs:null});fs.writeFileSync(path.join(dir,id+'.json'),JSON.stringify(record,null,2)+'\n');rows.push({id,status:result.status,physicalAccepted:result.status==='converged'&&result.physicalGate.passed,expectedAudit:mode!=='cancel-partial',envelope,provenance:'Fresh Node test generation; no browser claim'});return result;}
for(const [Nt,seed,gammaDb,thetaDegrees] of [[4,974101,3,23],[6,974102,13,0],[8,974103,19,23]])solve('fresh-nt'+Nt,Model.createInput({Nt,H:Model.seededH(Nt,seed),gammaDb,thetaDegrees}));
const base=Model.createInput({Nt:4,H:Model.seededH(4,974104),gammaDb:10,thetaDegrees:23});
solve('one-iteration-cap',base,{maxIterations:1});
solve('cancel-full',base,{},'cancel-full');solve('cancel-partial',base,{},'cancel-partial');
const zero=structuredClone(base);zero.H.real[0].fill(0);zero.H.imag[0].fill(0);solve('zero-channel-bound',zero);
const dup=structuredClone(base);dup.H.real[1]=dup.H.real[0].slice();dup.H.imag[1]=dup.H.imag[0].slice();solve('duplicate-infeasible',dup);
const rank=structuredClone(base);rank.gammaDb=-5;rank.thetaDegrees=0;rank.H={real:[Array(4).fill(1),Array(4).fill(1)],imag:[Array(4).fill(0),Array(4).fill(0)]};solve('rank-condition-rejected',rank,{},'full',false);
const badalpha=structuredClone(base);badalpha.alpha.real=1e151;solve('invalid-crb-rejected',badalpha,{},'full',false);
fs.writeFileSync(path.join(dir,'index.json'),JSON.stringify(rows,null,2)+'\n');console.log(JSON.stringify(rows,null,2));
