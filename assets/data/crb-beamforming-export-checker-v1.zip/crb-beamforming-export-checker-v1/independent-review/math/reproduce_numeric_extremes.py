"""Read-only adversarial numerical audit; never invokes a JS solver.
Run with OPENBLAS_NUM_THREADS=1 and the atomic-receiver-reference Python.
"""
from pathlib import Path
import copy
import decimal
import importlib.util
import json
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location("checker_under_review", ROOT / "check_export.py")
checker = importlib.util.module_from_spec(spec)
spec.loader.exec_module(checker)
original = checker.load_json(ROOT / "fixtures" / "fresh-nt4.json")
original = original.get("result", original)
decimal.getcontext().prec = 80

results = []
for alpha, noise in [(1.0, 1.0), (1e-150, 1e-310), (1.6e-162, 5e-324), (1e-160, 1e-320)]:
    candidate = copy.deepcopy(original)
    candidate["input"]["alpha"] = {"real": alpha, "imag": 0}
    candidate["input"]["radarNoiseMw"] = noise
    W = checker.decode(candidate["Wc"], (4, 2))
    recomputed, fisher = checker.radar(W @ W.conj().T, candidate["input"], checker.model(candidate["input"]))
    candidate["metrics"]["radar"] = checker.sanitize(recomputed)
    report = checker.audit_record(candidate)
    # Isolate the alpha/noise scaling error from negligible matrix rounding:
    # retain the checker's double-precision effective information, evaluate
    # the scalar CRB expression at 80-digit precision from exact binary64 inputs.
    D = decimal.Decimal.from_float
    reference = D(noise) / (2 * D(alpha)**2 * 30 * D(recomputed["effectiveInformationWithoutScale"]))
    results.append({
        "alphaReal": alpha,
        "radarNoiseMw": noise,
        "passed": report["passed"],
        "physicalAccepted": report["result"]["physicalAccepted"],
        "issues": report["result"]["issues"],
        "reportedCrbRad2": recomputed["crbRad2"],
        "decimal80ReferenceCrbRad2": str(reference),
        "relativeError": float(D(recomputed["crbRad2"]) / reference - 1),
        "fullFisherReplay": fisher,
    })
print(json.dumps(results, indent=2, allow_nan=False))
assert results[2]["physicalAccepted"] is True
assert abs(results[2]["relativeError"]) > 0.48
assert results[2]["fullFisherReplay"]["matrix"] is None
