"""Check the two independently discovered false-acceptance regressions.
All reads/writes remain in the export checker review subtree; no JS execution.
"""
from pathlib import Path
import argparse
import copy
import hashlib
import importlib.util
import json

ROOT = Path(__file__).resolve().parents[2]
parser = argparse.ArgumentParser()
parser.add_argument('--assert-fixed', action='store_true')
args = parser.parse_args()
spec = importlib.util.spec_from_file_location('checker_under_review', ROOT / 'check_export.py')
checker = importlib.util.module_from_spec(spec)
spec.loader.exec_module(checker)
results = []

def audit(name, candidate, expected_physical, expected_pass):
    out = checker.audit_record(candidate)
    results.append(dict(case=name, expectedPhysicalAccepted=expected_physical,
                        expectedPassed=expected_pass, passed=out['passed'],
                        physicalAccepted=out['result']['physicalAccepted'],
                        issues=out['result']['issues'],
                        expectationMet=(out['passed']==expected_pass and
                                        out['result']['physicalAccepted']==expected_physical)))

for fname in ['subnormal-alpha-crb.json', 'negative-exported-crb.json']:
    audit(fname, checker.load_json(ROOT / 'independent-review' / 'math' / fname), False, False)
# A positive but wrong tiny CRB must not pass merely by crossing zero.
q = checker.load_json(ROOT / 'independent-review' / 'math' / 'negative-exported-crb.json')
q['metrics']['radar']['crbRad2'] = 1e-301
q['metrics']['radar']['rootCrbDegrees'] = 1.9756922544984078e-150
# true CRB remains 1.189031416510766e-303: error is about 83-fold.
audit('positive-tiny-crb-inflated-84x', q, False, False)
# Independent root-CRB metric consistency matters as well.
q['metrics']['radar']['crbRad2'] = 1.189031416510766e-303
q['metrics']['radar']['rootCrbDegrees'] = 1e-9
audit('tiny-root-crb-inflated', q, False, False)
# The fix must retain correctly reported tiny positive CRBs with finite Fisher.
q = checker.load_json(ROOT / 'independent-review' / 'math' / 'negative-exported-crb.json')
W = checker.decode(q['Wc'], (q['input']['Nt'], q['input']['K']))
q['metrics']['radar'] = checker.sanitize(checker.radar(W @ W.conj().T, q['input'], checker.model(q['input']))[0])
audit('valid-tiny-normal-scale-crb', q, True, True)
for fname in ['fresh-nt4.json', 'fresh-nt6.json', 'fresh-nt8.json']:
    audit(fname, checker.load_json(ROOT / 'fixtures' / fname), True, True)
for fname in ['rank-condition-rejected.json', 'invalid-crb-rejected.json', 'duplicate-infeasible.json']:
    audit(fname, checker.load_json(ROOT / 'fixtures' / fname), False, True)
original = checker.load_json(ROOT / 'fixtures' / 'fresh-nt4.json')
original = original.get('result', original)
for kind in ['missing', 'null', 'dual-cone-sign', 'trace-correction-sign', 'bound-mismatch']:
    q = copy.deepcopy(original)
    if kind=='missing': del q['certificate']
    elif kind=='null': q['certificate']=None
    elif kind=='dual-cone-sign': q['certificate']['dual'][0]=100
    elif kind=='trace-correction-sign': q['certificate']['traceResidualCorrection'] *= -1
    elif kind=='bound-mismatch': q['certificate']['informationUpperBound'] -= .01
    audit('certificate-'+kind, q, False, False)
report = dict(checkerSha256=hashlib.sha256((ROOT/'check_export.py').read_bytes()).hexdigest(),
              allExpectationsMet=all(v['expectationMet'] for v in results), cases=results)
print(json.dumps(report, indent=2))
if args.assert_fixed: assert report['allExpectationsMet'], 'At least one math regression remains unresolved'
