#!/bin/sh
set -eu
cd "$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
export OPENBLAS_NUM_THREADS=1
PY=${PYTHON:-python3}
LEGACY=0
if [ "${1:-}" = '--include-legacy' ]; then LEGACY=1; fi
"$PY" adversarial_review.py --assert-fixed > adversarial.log
"$PY" parser_cli_review.py > parser-cli.log
"$PY" math/regression_numeric_acceptance.py --assert-fixed > math/regression-after-final-fix.json
if [ "$LEGACY" = 1 ]; then "$PY" prior_fixture_regression.py > prior-fixtures.log; fi
"$PY" - "$LEGACY" <<'PY'
import json,pathlib,hashlib,sys
p=pathlib.Path('.').resolve()
a=json.loads((p/'adversarial-results.json').read_text());b=json.loads((p/'parser-cli-results.json').read_text());d=json.loads((p/'math/regression-after-final-fix.json').read_text())
assert all(t['expectationMet'] for t in a['tests']);assert b['allPassed'];assert d['allExpectationsMet']
h=hashlib.sha256((p.parent/'check_export.py').read_bytes()).hexdigest()
assert all(z['checkerSha256']==h for z in [a,b,d]),'checker changed during review'
summary=dict(decision='ACCEPT within declared numerical-consistency scope',checkerSha256=h,adversarialProbes=len(a['tests']),substantiveAdversarialAssertions=sum(t['expected']!='observation' for t in a['tests']),descriptiveMetadataObservations=sum(t['expected']=='observation' for t in a['tests']),parserRejections=len(b['tests']),targetedMathAssertions=len(d['cases']),allAssertionsPassed=True,browserProvenanceEstablished=False,legacyArchiveIncluded=(sys.argv[1]=='1'))
if sys.argv[1]=='1':
 c=json.loads((p/'prior-accepted-math-fixture-results.json').read_text());assert c['allExpectationsMet'] and c['checkerSha256']==h
 summary['priorFrozenStateAssertions']=len(c['tests'])
(p/'SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
PY
