"""Independent read-only adversarial probes of NumPy checker; no JS or solver calls."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
import json, hashlib, importlib.util, copy, pathlib, warnings, sys, argparse
import numpy as np
HERE=pathlib.Path(__file__).resolve().parent; ROOT=HERE.parent
parser=argparse.ArgumentParser();parser.add_argument('--checker',type=pathlib.Path,default=ROOT/'check_export.py');parser.add_argument('--output',type=pathlib.Path,default=HERE/'adversarial-results.json');parser.add_argument('--assert-fixed',action='store_true');args=parser.parse_args();CHECKER=args.checker
s=importlib.util.spec_from_file_location('checker',CHECKER);c=importlib.util.module_from_spec(s);s.loader.exec_module(c)
ENVELOPE=HERE/'default-live-record.json'
def read(p):return json.loads(pathlib.Path(p).read_text())
envelope=read(ENVELOPE);base=envelope['result']; cap=read(ROOT/'fixtures/one-iteration-cap.json')['result']; analytic=read(ROOT/'fixtures/zero-channel-bound.json')['result']; sep=read(ROOT/'fixtures/duplicate-infeasible.json')['result']
rows=[]
def test(name,source,change,expected,save=False):
 v=copy.deepcopy(source);change(v)
 try:
  with warnings.catch_warnings(record=True) as ws:
   warnings.simplefilter('always');a=c.audit_record(v)
  result=dict(name=name,expected=expected,passed=a['passed'],physicalAccepted=a.get('result',{}).get('physicalAccepted',False),issues=a.get('envelopeIssues',[])+a.get('result',{}).get('issues',[]),warnings=[str(w.message) for w in ws])
  result['expectationMet']=(True if expected=='observation' else not result['passed'] if expected=='reject' else result['passed'] and result['physicalAccepted']==(expected=='physical'))
 except Exception as e:
  result=dict(name=name,expected=expected,crash=repr(e),expectationMet=False)
 if save:
  (HERE/(name+'.json')).write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
  result['fixture']=name+'.json'
 rows.append(result);return result

def setkey(key,value):return lambda r:r.__setitem__(key,value)
def rm(key):return lambda r:r.pop(key,None)
for path in sorted((ROOT/'fixtures').glob('*.json')):
 if path.name=='index.json':continue
 expectation='reject' if path.name=='cancel-partial.json' else 'physical' if path.name.startswith('fresh-') else 'evidence'
 test('baseline-'+path.stem,read(path),lambda r:None,expectation)
test('baseline-default-envelope',envelope,lambda r:None,'physical')
# Missing mandatory numerical data is always rejected.
for key in ['version','status','input','options','iterations','physicalGate','rankCondition','finalState','Wks','relaxedR','relaxedInformation','residuals','certificate','Wc','recovery','metrics']:
 test('missing-'+key,base,rm(key),'reject')
for key in ['x','w','z','rho']:
 test('missing-state-'+key,base,lambda r,key=key:r['finalState'].pop(key),'reject')
for key in ['matrix','singularValues','relativeSingularValue','relativeRankTolerance','fullColumnRank']:
 test('missing-rank-'+key,base,lambda r,key=key:r['rankCondition'].pop(key),'reject')
# Existing numerical gates and certificate checks must withstand tampering.
for key in ['x','w','z']:
 test('state-'+key+'-tamper',base,lambda r,key=key:r['finalState'][key].__setitem__(0,r['finalState'][key][0]+.01),'reject')
for key in ['powerMw','powerFraction']:
 test('metric-'+key+'-tamper',base,lambda r,key=key:r['metrics'].__setitem__(key,r['metrics'][key]*1.01),'reject')
for key in ['s0','s2','crbRad2','rootCrbDegrees','normalizedInformation']:
 test('radar-'+key+'-tamper',base,lambda r,key=key:r['metrics']['radar'].__setitem__(key,r['metrics']['radar'][key]*1.01),'reject')
for key in ['desiredMw','interferenceMw','sinr','sinrDb','ratioToThreshold']:
 test('user-'+key+'-tamper',base,lambda r,key=key:r['metrics']['users'][0].__setitem__(key,r['metrics']['users'][0][key]*1.01),'reject')
for key in ['support','traceResidualCorrection','minimizationLowerBound','informationUpperBound','tStationarityResidual','normalization','recoveredInformationGap','relativeRecoveredGap']:
 test('certificate-'+key+'-tamper',base,lambda r,key=key:r['certificate'].__setitem__(key,r['certificate'][key]+.01),'reject')
for key in ['kind','dual','stationarityMinimumEigenvalues','separationPassed','support','normalization','traceResidualCorrection','minimizationLowerBound','informationUpperBound','tStationarityResidual']:
 test('missing-certificate-'+key,base,lambda r,key=key:r['certificate'].pop(key),'reject')
test('certificate-null',base,setkey('certificate',None),'reject')
test('certificate-empty',base,setkey('certificate',{}),'reject')
test('certificate-false',base,setkey('certificate',False),'reject')
test('certificate-dual-positive',base,lambda r:r['certificate']['dual'].__setitem__(0,100),'reject')
test('certificate-nonconservative-eigenvalue',base,lambda r:r['certificate']['stationarityMinimumEigenvalues'].__setitem__(0,1),'reject')
test('Wc-zero',base,lambda r:r['Wc']['real'][0].__setitem__(0,0),'reject')
test('Wks-indefinite',base,lambda r:r['Wks'][0]['real'][0].__setitem__(0,-1000),'reject')
test('rank-forged',base,lambda r:r['rankCondition'].__setitem__('fullColumnRank',False),'reject')
test('status-forged-converged-from-cap',cap,setkey('status','converged'),'reject')
test('status-forged-infeasible-from-cap',cap,setkey('status','infeasible_certificate'),'reject')
test('cap-forged-passed-gate',cap,lambda r:r['physicalGate'].__setitem__('passed',True),'reject')
test('analytic-forged-bound',analytic,lambda r:r['failureReason'].__setitem__('bound',1e10),'reject')
test('analytic-missing-proof',analytic,rm('failureReason'),'reject')
# Strict status/evidence semantics: claimed malformed/missing terminal gate/trace data.
for status in ['numerical_rejection','numerical_failure','cancelled']:
 test('forged-status-'+status,cap,setkey('status',status),'reject',True)
for failures in [[],['invented'],[None],[False],['not_converged','invented']]:
 ident=str(len(rows)); test('malformed-cap-gate-'+ident,cap,lambda r,failures=failures:r['physicalGate'].__setitem__('failures',failures),'reject',True)
test('analytic-empty-gate',analytic,lambda r:r['physicalGate'].__setitem__('failures',[]),'reject',True)
test('analytic-extra-garbage-state',analytic,setkey('finalState',{'x':'forged','w':None}),'reject',True)
test('analytic-extra-accepted-recovery',analytic,setkey('Wc',base['Wc']),'reject',True)
test('missing-failureReason-numerical_failure',cap,lambda r:(r.__setitem__('status','numerical_failure'),r.pop('failureReason')),'reject',True)
test('converged-iterations-zero',base,setkey('iterations',0),'reject',True)
# Envelope schema must reject malformed declared values. Provenance still cannot be established.
for key in ['format','schemaVersion','inputDigest','scenarioDigest','input','options','tolerances','kernel','source','run','trace']:
 test('envelope-missing-'+key,envelope,rm(key),'reject')
test('envelope-bool-schemaVersion',envelope,setkey('schemaVersion',True),'reject',True)
test('envelope-trace-string',envelope,lambda r:(r['result'].__setitem__('trace','x'),r['trace'].__setitem__('samples',1)),'reject',True)
test('envelope-trace-fabricated',envelope,lambda r:(r['result'].__setitem__('trace',[{'iteration':-1,'primalInf':-1,'stationarityInf':-1,'normalizedInformation':'FAKE','elapsedMs':-1}]),r['trace'].__setitem__('samples',1)),'reject',True)
test('envelope-trace-samples-bool',envelope,lambda r:(r['result'].__setitem__('trace',r['result']['trace'][:1]),r['trace'].__setitem__('samples',True)),'reject',True)
# Types should produce structured failure, not crash or acceptance.
for source_name,src in [('result',base),('envelope',envelope)]:
 for key in src:
  for typ,v in [('null',None),('bool',True),('list',[]),('str','x'),('dict',{})]:
   expect='observation' if (source_name=='result' and key=='scope') or (source_name=='envelope' and key in ['createdAt','appBuild','generator','conventions','resources']) else 'physical' if source_name=='result' and key in ['failureReason','infeasibilityCertificate'] and typ=='null' else 'reject'
   test('type-'+source_name+'-'+key+'-'+typ,src,setkey(key,v),expect)
# Negative test taxonomy of deliberately ignored descriptive metadata is separated in report.
report=dict(checkerSha256=hashlib.sha256(CHECKER.read_bytes()).hexdigest(),envelopeSha256=hashlib.sha256(ENVELOPE.read_bytes()).hexdigest(),tests=rows)
args.output.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print('checker',report['checkerSha256']);print('tests',len(rows),'unexpected',sum(not x['expectationMet'] for x in rows))
for r in rows:
 if not r['expectationMet']:print(json.dumps(r))

if args.assert_fixed:assert all(x['expectationMet'] for x in rows),'Unresolved substantive adversarial regression'
