"""Exercise production CLI JSON parsing and failure behavior using saved local inputs only."""
import os,json,subprocess,pathlib,hashlib,sys
os.environ['OPENBLAS_NUM_THREADS']='1'
HERE=pathlib.Path(__file__).resolve().parent;CHECKER=HERE.parent/'check_export.py';PY=sys.executable
cases={'duplicate-key':'{"status":"converged","status":"cancelled"}', 'unsafe-prototype':'{"__proto__":{}}','nonfinite-token':'{"x":NaN}','overflow-number':'{"x":1e9999}','top-null':'null','top-list':'[]','top-string':'"status"','malformed-json':'{','deep-nesting':'['*2000+'0'+']'*2000}
rows=[]
for name,data in cases.items():
 p=HERE/(name+'.json');p.write_text(data)
 r=subprocess.run([PY,str(CHECKER),str(p)],text=True,capture_output=True,env={**os.environ,'OPENBLAS_NUM_THREADS':'1'})
 try:o=json.loads(r.stdout);valid=not o['passed'] and r.returncode==1
 except Exception:o=None;valid=False
 rows.append(dict(name=name,returncode=r.returncode,structuredRejection=valid,stdout=r.stdout,stderr=r.stderr))
report=dict(checkerSha256=hashlib.sha256(CHECKER.read_bytes()).hexdigest(),allPassed=all(r['structuredRejection'] for r in rows),tests=rows)
(HERE/'parser-cli-results.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
