"""Replay independently saved frozen-kernel states; no solver invocation."""
import os,importlib.util,pathlib,json,hashlib,argparse
os.environ['OPENBLAS_NUM_THREADS']='1'
ROOT=pathlib.Path(__file__).resolve().parent.parent
s=importlib.util.spec_from_file_location('checker',ROOT/'check_export.py');c=importlib.util.module_from_spec(s);s.loader.exec_module(c)
parser=argparse.ArgumentParser(description='Optional regression requiring the external sibling frozen-kernel review archive');parser.add_argument('--legacy-root',type=pathlib.Path,default=ROOT.parent/'crb-beamforming-browser-prototype/independent-review');args=parser.parse_args();D=args.legacy_root
expected={
 'fresh-nt4-k2-seed812733':(True,True), 'fresh-nt4-k2-seed812734':(True,True),
 'fresh-nt6-k3-seed812735':(True,True), 'one-iteration-cap':(True,False),
 'cancel-after-step':(False,False), 'duplicate-infeasible':(True,False),
 'necessary-bound-infeasible':(True,False), 'zero-channel-infeasible':(True,False),
 'rank-one-channel-feasible':(True,False), 'unit-rescaling-mw-to-w':(True,True),
 'alpha-product-overflow-probe':(True,False), 'radar-noise-overflow-probe':(True,False),
 'radar-noise-underflow-probe':(True,False)}
rows=[]
for name,want in expected.items():
 v=json.loads((D/(name+'.js.json')).read_text());r=c.audit_record(v)
 row=dict(name=name,status=v.get('status'),finalState=('finalState' in v),passed=r['passed'],physicalAccepted=r['result']['physicalAccepted'],issues=r['result']['issues'],expectationMet=(r['passed'],r['result']['physicalAccepted'])==want);rows.append(row)
report=dict(checkerSha256=hashlib.sha256((ROOT/'check_export.py').read_bytes()).hexdigest(),allExpectationsMet=all(r['expectationMet'] for r in rows),tests=rows)
(ROOT/'independent-review/prior-accepted-math-fixture-results.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2));assert report['allExpectationsMet']
