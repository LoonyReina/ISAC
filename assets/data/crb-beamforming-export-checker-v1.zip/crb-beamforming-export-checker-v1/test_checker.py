"""Portable fixture and adversarial controls. Does not execute any optimizer."""
import copy,json,os,tempfile,subprocess,sys
from pathlib import Path
import check_export as c
HERE=Path(__file__).resolve().parent

def run():
    tests=[]
    def check(name,record,expected=True,accepted=None):
        out=c.audit_record(record);ok=out['passed']==expected
        if accepted is not None:ok=ok and out['result']['physicalAccepted']==accepted
        tests.append(dict(name=name,passed=ok,expectedAudit=expected,actualAudit=out['passed'],physicalAccepted=out['result']['physicalAccepted'],issues=out['envelopeIssues']+out['result']['issues']))
        return out
    for row in json.loads((HERE/'fixtures/index.json').read_text()):
        check(row['id'],json.loads((HERE/'fixtures'/ (row['id']+'.json')).read_text()),row['expectedAudit'],row['physicalAccepted'])
    envelope=json.loads((HERE/'fixtures/fresh-nt4.json').read_text());base=envelope['result']
    def mutation(name,fn,root=base):
        v=copy.deepcopy(root);fn(v);check(name,v,False)
    mutation('tamper-H',lambda r:r['input']['H']['real'][0].__setitem__(0,r['input']['H']['real'][0][0]+.2))
    mutation('tamper-power',lambda r:r['input'].__setitem__('powerMw',900))
    mutation('tamper-angle',lambda r:r['input'].__setitem__('thetaDegrees',12))
    mutation('tamper-alpha',lambda r:r['input']['alpha'].__setitem__('real',.5))
    mutation('tamper-Gamma',lambda r:r['input'].__setitem__('gammaDb',4))
    mutation('tamper-beam',lambda r:r['Wc']['real'][0].__setitem__(0,r['Wc']['real'][0][0]+.1))
    mutation('tamper-Wk',lambda r:r['Wks'][0]['real'][0].__setitem__(0,r['Wks'][0]['real'][0][0]+.1))
    mutation('tamper-relaxed-sum',lambda r:r['relaxedR']['imag'][0].__setitem__(1,1))
    mutation('tamper-primal-x',lambda r:r['finalState']['x'].__setitem__(0,r['finalState']['x'][0]+.01))
    mutation('tamper-projection-z',lambda r:r['finalState']['z'].__setitem__(0,r['finalState']['z'][0]+.01))
    mutation('tamper-dual-w',lambda r:r['finalState']['w'].__setitem__(0,r['finalState']['w'][0]+.01))
    mutation('tamper-rho',lambda r:r['finalState'].__setitem__('rho',1))
    mutation('tamper-primal-residual',lambda r:r['residuals'].__setitem__('primalInf',.01))
    mutation('tamper-stationarity',lambda r:r['residuals'].__setitem__('stationarityInf',.01))
    mutation('tamper-t',lambda r:r.__setitem__('relaxedInformation',.2))
    mutation('tamper-cert-dual',lambda r:r['certificate']['dual'].__setitem__(0,5))
    mutation('tamper-cert-bound',lambda r:r['certificate'].__setitem__('informationUpperBound',0))
    mutation('tamper-cert-support',lambda r:r['certificate'].__setitem__('support',0))
    mutation('tamper-cert-correction',lambda r:r['certificate'].__setitem__('traceResidualCorrection',1))
    mutation('tamper-cert-eigen',lambda r:r['certificate']['stationarityMinimumEigenvalues'].__setitem__(0,1))
    mutation('tamper-cert-gap',lambda r:r['certificate'].__setitem__('recoveredInformationGap',1))
    mutation('tamper-rank-ratio',lambda r:r['rankCondition'].__setitem__('relativeSingularValue',0))
    mutation('tamper-rank-residual',lambda r:r['recovery'][0].__setitem__('relativeRankOneResidual',.1))
    mutation('tamper-user2',lambda r:r['metrics']['users'][1].__setitem__('sinr',999))
    mutation('tamper-CRB',lambda r:r['metrics']['radar'].__setitem__('crbRad2',1e-8))
    mutation('tamper-normalized-info',lambda r:r['metrics']['radar'].__setitem__('normalizedInformation',.1))
    mutation('missing-state',lambda r:r.pop('finalState'))
    mutation('missing-certificate',lambda r:r.pop('certificate'))
    mutation('missing-user',lambda r:r['metrics']['users'].pop())
    mutation('missing-Wk',lambda r:r['Wks'].pop())
    mutation('bool-Nt',lambda r:r['input'].__setitem__('Nt',True))
    mutation('string-beam',lambda r:r['Wc']['real'][0].__setitem__(0,'1'))
    mutation('unknown-version',lambda r:r.__setitem__('version','new-version'))
    mutation('unknown-status',lambda r:r.__setitem__('status','great'))
    mutation('unsupported-Gamma',lambda r:r['input'].__setitem__('gammaDb',31))
    mutation('tamper-envelope-input',lambda r:r['input']['H']['real'][0].__setitem__(0,1),envelope)
    mutation('tamper-envelope-digest',lambda r:r.__setitem__('inputDigest','0'*64),envelope)
    mutation('tamper-envelope-scenario',lambda r:r.__setitem__('scenarioDigest','0'*64),envelope)
    mutation('tamper-envelope-options',lambda r:r['options'].__setitem__('rho',1),envelope)
    mutation('tamper-kernel-declaration',lambda r:r['kernel']['runtimeFiles'].__setitem__('crb-multiuser/core.js','0'*64),envelope)
    mutation('tamper-envelope-tolerance',lambda r:r['tolerances'].__setitem__('sinrRelative',1),envelope)
    mutation('tamper-trace-count',lambda r:r['trace'].__setitem__('samples',99),envelope)
    cap=json.loads((HERE/'fixtures/one-iteration-cap.json').read_text())['result']
    mutation('cap-promoted-to-converged',lambda r:r.__setitem__('status','converged'),cap)
    mutation('cap-fake-pass',lambda r:r['physicalGate'].__setitem__('passed',True),cap)
    mutation('cap-fake-infeasibility',lambda r:r.__setitem__('status','infeasible_certificate'),cap)
    sep=json.loads((HERE/'fixtures/duplicate-infeasible.json').read_text())['result']
    mutation('separator-zero-dual',lambda r:r['infeasibilityCertificate'].__setitem__('dual',[0]*len(r['infeasibilityCertificate']['dual'])),sep)
    bound=json.loads((HERE/'fixtures/zero-channel-bound.json').read_text())['result']
    mutation('false-individual-bound',lambda r:r['failureReason'].__setitem__('bound',99999),bound)
    mutation('trace-string',lambda r:r.__setitem__('trace','x'))
    mutation('trace-impossible-iteration',lambda r:r['trace'][-1].__setitem__('iteration',99999))
    mutation('trace-false-last-residual',lambda r:r['trace'][-1].__setitem__('primalInf',.01))
    mutation('trace-boolean-iteration',lambda r:r['trace'][0].__setitem__('iteration',True))
    mutation('trace-negative-time',lambda r:r['trace'][0].__setitem__('elapsedMs',-1))
    mutation('converged-zero-iterations',lambda r:r.__setitem__('iterations',0))
    mutation('boolean-schema-version',lambda r:r.__setitem__('schemaVersion',True),envelope)
    mutation('cap-relabeled-no-failure-reason',lambda r:r.__setitem__('status','numerical_failure'),cap)
    mutation('cap-relabeled-no-recovery-reason',lambda r:r.__setitem__('status','numerical_rejection'),cap)
    mutation('cap-empty-gate',lambda r:r['physicalGate'].__setitem__('failures',[]),cap)
    mutation('analytic-garbage-state',lambda r:r.__setitem__('finalState',{'garbage':True}),bound)
    tiny=copy.deepcopy(base);tiny['input']['alpha']={'real':1.6e-162,'imag':0};tiny['input']['radarNoiseMw']=5e-324
    W=c.decode(tiny['Wc'],(tiny['input']['Nt'],tiny['input']['K']))
    tiny['metrics']['radar']=c.sanitize(c.radar(W@W.conj().T,tiny['input'],c.model(tiny['input']))[0])
    check('subnormal-Fisher-fails-closed',tiny,False,False)
    small=copy.deepcopy(base);small['input']['radarNoiseMw']=1e-295
    small['metrics']['radar']=c.sanitize(c.radar(W@W.conj().T,small['input'],c.model(small['input']))[0])
    check('valid-tiny-normal-CRB',small,True,True)
    small['metrics']['radar']['crbRad2']=-1e-301;small['metrics']['radar']['rootCrbDegrees']=0
    check('forged-negative-tiny-CRB',small,False,False)
    mutation('cap-relabeled-cancelled',lambda r:r.__setitem__('status','cancelled'),cap)
    # Principal eigenvectors have an arbitrary complex phase, not a unique byte representation.
    phase=copy.deepcopy(base)
    for i in range(phase['input']['Nt']):
        for j in range(phase['input']['K']):
            a,b=phase['Wc']['real'][i][j],phase['Wc']['imag'][i][j]
            phase['Wc']['real'][i][j]=-b;phase['Wc']['imag'][i][j]=a
    check('valid-global-phase-change',phase,True,True)
    # No wrapper assertion is accepted as evidence of actual browser execution.
    provenance=copy.deepcopy(envelope);provenance['browser']='claimed Chrome';o=check('no-browser-inference',provenance,True,True)
    tests.append(dict(name='browser-provenance-remains-unestablished',passed=o['browserProvenanceEstablished'] is False))
    with tempfile.TemporaryDirectory() as tmp:
        p=Path(tmp)/'record.json'
        for name,text in [('duplicate-json-key','{"status":1,"status":2}'),('nonfinite-json','{"x":NaN}'),('unsafe-json-key','{"__proto__":{}}')]:
            p.write_text(text)
            try:c.load_json(p);ok=False
            except ValueError:ok=True
            tests.append(dict(name=name,passed=ok))
    report=dict(passed=all(q['passed'] for q in tests),checks=len(tests),fixtures='Fresh Node records; no browser claim',tests=tests)
    print(json.dumps(report,indent=2));return report
if __name__=='__main__':
    out=run()
    if '--output' in sys.argv:Path(sys.argv[sys.argv.index('--output')+1]).write_text(json.dumps(out,indent=2)+'\n')
    raise SystemExit(0 if out['passed'] else 1)
