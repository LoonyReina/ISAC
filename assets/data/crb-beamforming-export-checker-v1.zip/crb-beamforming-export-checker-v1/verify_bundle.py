"""Verify additive bundle integrity; optional full portable regression with --test."""
import hashlib,json,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parent;manifest=json.loads((root/'ARTIFACT-MANIFEST.json').read_text());errors=[]
for row in manifest['files']:
 p=root/row['path']
 if not p.is_file() or p.stat().st_size!=row['bytes'] or hashlib.sha256(p.read_bytes()).hexdigest()!=row['sha256']:errors.append(row['path'])
print(json.dumps({'passed':not errors,'checkedFiles':len(manifest['files']),'errors':errors},indent=2))
if errors:raise SystemExit(1)
if '--test' in sys.argv:raise SystemExit(subprocess.call([sys.executable,str(root/'test_checker.py')],cwd=root))
