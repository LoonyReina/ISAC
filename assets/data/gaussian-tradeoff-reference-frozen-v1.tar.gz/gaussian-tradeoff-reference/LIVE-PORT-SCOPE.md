# Bounded live-port contract proposal

This is implementation scope for a future JavaScript Worker, not a claim that the port, UI or latency is already validated. Keep the separately reviewed teaching package independent; do not overwrite it with this reference’s figure experiments.

## First useful live surface

1. **Complex matrix Bayesian model.** Start with the reviewed teaching instance M=4, Nc=3, Ns=2, T=8, PT=1, sensing noise variance 0.7, communication noise variance 1, prior variance 1.3 and the supplied complex DFT-basis channel with gains [3.5,0.8,0.08,0]. Load its exact H and covariance values from the teaching evidence, not a hand-redrawn real diagonal substitute. Label it a teaching instance, not Fig. 10 or Fig. 11.
2. **Matrix covariance shaping.** Expose κ in {0,0.1,1,10,100,communication-only}, with PT, prior/noise and H displayed explicitly. κ modifies the source (48) optimizer, not a post hoc hand-drawn interpolation. Show actual complex Q, its eigenvalues, power feasibility, objective gap and source48 α mapping. The null direction stays in sensing, even when communication allocates it no energy.
3. **Waveform law.** Compare iid complex Gaussian blocks with random Stiefel blocks of the same Q and expected energy. Show one actual X and R=XXᴴ/T, then a bounded seeded average. A fixed deterministic waveform has zero data rate; fixed covariance alone is not zero-rate signaling.
4. **Estimator.** Show Y, posterior H estimate and conditional posterior trace. Truth belongs only in a clearly separate scoring view. The estimator input contract is Y, X, noise and prior. Preserve the h-column versus H-row covariance transpose distinction.
5. **Source presets.** Add the exact Fig. 4 M=Ns in {2,4,6}, T=4M, prior-precision grid as a separate finite-integral comparison. Add a single frozen Fig. 10 H realization at M=Nc=Ns=4, T=16 with an explicit 24 dB total/per-antenna toggle; label it a single-channel case, not the fading expectation. Show the offline two-seed fading result as evidence, not as a live solve.

Keep dimension/prior/channel changes bounded to reviewed presets initially. Arbitrary M/Nc/Ns/T, editable complex H, continuously variable power/noise/prior, and arbitrary covariance entry editing can follow only with new golden tests and budget/conditioning checks. Never silently resize a channel, discard an eigenmode, normalize a Gaussian block, or substitute a different prior to make a computation work. Full-rank deterministic covariance requires T≥M; an initial UI may explicitly restrict T accordingly.

## Metric and computation labels

| Quantity | Allowed first-port computation and label |
|---|---|
| Gaussian MI/T | Direct complex log determinant, bits per complex use; exact mathematical expression for the specified Gaussian input |
| Conditional Bayesian matrix error | Direct proper-prior posterior trace from the actual X; exact model expression up to numerical error |
| Deterministic-covariance sensing point | Source (95)/(97), with rank/block-length conditions; exact model expression |
| Covariance outer pair | Jensen sensing quantity plus Gaussian-entropy rate bound; not an achieved pair for a single law in general |
| Gaussian waveform mean error | Seeded finite Monte Carlo with B, seed, mean and standard error; retain random block energy |
| Isotropic Wishart mean error | Finite-size one-dimensional spectral quadrature, with refinement/error diagnostics; not MP substituted as truth |
| Source (100) MP curve | Explicit approximation compared with finite-size quadrature |
| General-covariance source (101) | Optional diagnostic only; disclose positive-eigenvalue conditions and valid-subset counts |
| Rank-one Stiefel MI | Separate finite-SNR numerical integral with quadrature/tail diagnostics; never substitute it for full-MIMO Stiefel MI |
| Full-MIMO Stiefel rate | Optional source (56)/(111) leading approximations, separately labeled; no finite-SNR certification or achieved-hull claim |
| Estimator MSE | Finite truth-only Monte Carlo score, with uncertainty; not the CRB itself |

For the rank-deficient teaching H, all-Gaussian signaling is a valid achievable input-law pair. It is not the paper’s stronger null-space-completed construction (51)/Remark 1. Do not label it as that construction.

## Worker and release gates

- The numerical Worker must recompute from serialized inputs; UI plots and JSON downloads must share its result, not duplicate formulas
- Export complex matrices as real/imaginary arrays, all model units and seeds, covariance/input-law identity, sample count, mean/SE, optimizer feasibility/gap, convergence/failure state, exact/asymptotic/MC classification and source/core hashes
- Preserve pending/error/cancel/reset states and reject invalid dimensions, Hermitian/PSD failures, improper-prior nonidentifiability and unsupported ranks without stale-success plots
- Cross-language tests must compare against this frozen core and the separately frozen teaching evidence, including nondiagonal complex matrices, inactive modes, low/high prior, endpoint weights and matrix transpose conventions
- Bound live Monte Carlo cost separately from offline fading runs; any B cap is an explicit UI resource limit, not a paper parameter. Measure actual end-to-end latency after implementation
- No full-paper, exact p(X)-optimized region, finite-length coding or general finite-SNR MIMO Stiefel MI claim

## Fixed reference identities

- Paper PDF v8: `8bfc316c0faf57c42a8cf2395a1bce594a9f987750f37287680fdb9e190dc342`
- Operational numerical core: `b06e329b927cda7adb1e2d38b320a1f2ca1bee287ebe8dec50d6de86fe176bb2`
- Region JSON: `1a039bb22f109b22b173f54b9f0a14c7a0ed22ad046a8130fb9d252a04eae0a4`
- Region raw NPZ: `a3658902f508652ecbdcd94874618cbb409beae344bfa72da8899c8f909f69cf`
