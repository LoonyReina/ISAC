# Gaussian-channel ISAC Bayesian matrix reference

Independent, source-audited numerical work for [arXiv:2204.06938v8](https://arxiv.org/abs/2204.06938v8). This directory is separate from the teaching website and changes no UI or repository files.

## Deliverable boundaries

- Full complex matrix response model and proper Gaussian prior; known transmitted blocks; finite-block Bayesian error
- Actual covariance-shaping convex program from source Eq. (48), with a global optimality-gap certificate for every solved channel/weight pair
- Exact Gaussian-input mutual information, Gaussian waveform-averaged error, and deterministic-covariance outer pairs
- Selected Fig. 4 finite-size experiment; bounded Fig. 10 parameter/normalization audit, with both printed-power interpretations retained
- Stiefel waveform construction and explicitly asymptotic MIMO rates; an independent finite-SNR rank-one sphere-integral check
- Source conflicts documented, rather than silently changed to fit a plot

Not an exact solution over all waveform distributions, complete paper reproduction, general finite-SNR MIMO Stiefel mutual-information computation, or a website/browser release.

## Files

- `SOURCE-AUDIT.md`: fixed source identity, equation crosswalk, original figure choices, preserved omissions/conflicts and claim limits
- `MATHEMATICS.md`: independent model derivation, optimization certificate and finite-size integration
- `core.py`: numerical core; no truth input to the estimator or optimizer
- `test_core.py`: model, endpoints, direct real-Fisher/posterior, independent SLSQP, rank/invalid-input, unitary covariance and sphere-rate tests
- `run_reference.py`: seeded experiments and raw NPZ/JSON generation
- `high_precision_checks.py`: independent 60-digit integral oracles
- `verify_records.py`: raw-record and supporting-hyperplane checks, independent of the covariance solver
- `plot_evidence.py`: newly generated plots from local numerical records; no reproduced paper images
- `evidence/`: settings, raw numerical samples, summaries, checks and plots
- `LIVE-PORT-SCOPE.md`: bounded future JavaScript Worker scope and metric labels; not a port validation
- `HANDOFF.md`: final measured outcomes and remaining gaps (written after the final runs)
- `MANIFEST.json`: final source-free file hashes (written at freeze)

## Reproduction

Python 3.12.14, NumPy 2.3.5, SciPy 1.17.0 and mpmath 1.3.0 were available in the task environment. Plotting additionally uses Matplotlib 3.10.8. No author code or external package source is bundled.

Run from this directory, setting all four variables before Python starts:

```sh
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1
python -m unittest -v test_core.py
python run_reference.py --trials 16384
python high_precision_checks.py
python run_reference.py --region --channels 256 --blocks 256
python verify_records.py
python plot_evidence.py
```

The region run is larger and must be scheduled separately from another agent's heavy release checks. Each experiment stores its seed, count, numerical settings, dependency versions and core SHA-256. Normal-approximation Monte Carlo intervals and quadrature error estimates are not rigorous universal guarantees. Raw arrays permit checks without relying on rounded plot values.

## Units and fairness

Rate: bits per complex channel use. T: complex samples per coherent block. Matrix CRB: summed squared complex coefficient error; normalized CRB divides by M·Ns. Power: expected trace of XXᴴ/T, with per-antenna and total conventions explicitly distinguished. All waveform comparisons preserve the same expected block energy, prior, noises and block length. Gaussian blocks keep their random energy; no normalization changes their input law.
