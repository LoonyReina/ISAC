"""Fail-closed verification of saved experiment summaries against raw records.

Does not rerun the optimizer or trust its reported objective gap.
"""
import hashlib,json,math
from pathlib import Path
import numpy as np
import core as c
HERE=Path(__file__).parent

def check_close(a,b,rtol=2e-11,atol=2e-13):
    if not np.allclose(a,b,rtol=rtol,atol=atol):raise AssertionError((a,b))

def main():
    checks=0
    sha=hashlib.sha256((HERE/'core.py').read_bytes()).hexdigest()
    for name in ('figure4','estimator_check','sphere_integration','source_conflicts','region'):
        data=json.loads((HERE/'evidence'/f'{name}.json').read_text())
        if data['core_sha256']!=sha:raise AssertionError(f'{name}: stale core hash')
        checks+=1
    data=json.loads((HERE/'evidence/figure4.json').read_text());raw=np.load(HERE/'evidence/figure4_raw.npz')
    for r in data['rows']:
        eig=raw[f"eigenvalues_M{r['M']}"];z=r['prior_precision']/r['T']
        val=r['Ns']/r['T']*np.sum(1/(eig+z),axis=1)
        check_close(val.mean(),r['monte_carlo']['mean']);check_close(val.std(ddof=1)/np.sqrt(len(val)),r['monte_carlo']['standard_error']);checks+=2
    data=json.loads((HERE/'evidence/region.json').read_text());raw=np.load(HERE/'evidence/region_raw.npz');maxgap=0.
    for run in data['runs']:
        convention=run['power_convention'];rep=(run['seed']-91021)//10000;key=f'{convention}_rep{rep}'
        h=raw[key+'_channel_real']+1j*raw[key+'_channel_imag'];model=c.Model(**run['model'])
        for ki,p in enumerate(run['points']):
            arr=raw[f'{key}_weight{ki}_metrics'];qs=raw[f'{key}_weight{ki}_allocations']
            check_close(qs.sum(axis=1),model.budget);assert (qs>=0).all()
            for j,(hh,q) in enumerate(zip(h,qs)):
                g,v=np.linalg.eigh(hh.conj().T@hh/model.communication_noise);g=np.maximum(g,0)
                w=q/model.power_per_antenna;aa=g*model.power_per_antenna;delta=model.z/model.power_per_antenna
                kk=math.inf if p['weight']=='communication-only' else p['weight']
                if np.isinf(kk):f=-np.log1p(aa*w).sum();grad=-aa/(1+aa*w)
                else:f=np.sum(1/(w+delta))-kk*np.log1p(aa*w).sum();grad=-1/(w+delta)**2-kk*aa/(1+aa*w)
                gap=max(0.,float(grad@w-model.m*grad.min()))/max(1,abs(f));maxgap=max(maxgap,gap)
                assert gap<1e-9
                # Independent direct determinant and direct inverse of reconstructed matrix.
                Q=(v*q)@v.conj().T
                direct_rate=np.linalg.slogdet(np.eye(len(hh))+hh@Q@hh.conj().T/model.communication_noise)[1]/np.log(2)
                direct_crb=np.trace(np.linalg.inv(Q+model.z*np.eye(model.m))).real*model.sensing_noise/(model.t*model.m)
                check_close(arr[j,0],direct_rate);check_close(arr[j,1],direct_crb);checks+=3
            check_close(arr[:,0].mean(),p['rate_gaussian']['mean']);check_close(arr[:,2].mean(),p['crb_gaussian_normalized']['mean']);checks+=2
    out={'status':'pass','checks':checks,'core_sha256':sha,'maximum_independently_recomputed_relative_optimizer_gap':maxgap,
         'scope':'Saved summaries/raw arrays, all covariance allocations, direct matrix outer rate/error, supporting-hyperplane certificates; not a full random-waveform replay'}
    (HERE/'evidence/record_verification.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))

if __name__=='__main__':main()
