"""Generate reproducible bounded numerical evidence; single-thread BLAS required."""
from __future__ import annotations
import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):
    if os.environ.get(key)!='1': raise RuntimeError(f'Set {key}=1 before running')
import argparse,dataclasses,hashlib,json,math,platform,time
from pathlib import Path
import numpy as np
import scipy
from scipy.optimize import minimize_scalar
import core as c

HERE=Path(__file__).resolve().parent

def serial(x):
    if isinstance(x,np.ndarray):return x.tolist()
    if isinstance(x,np.generic):return x.item()
    raise TypeError(type(x).__name__)

def write(name,obj):
    p=HERE/'evidence'/name;p.parent.mkdir(exist_ok=True)
    p.write_text(json.dumps(obj,indent=2,default=serial,allow_nan=False)+'\n')

def base():
    return {'schema':'gaussian-tradeoff-reference-v1','source':'https://arxiv.org/html/2204.06938v8',
        'source_pdf_sha256':'8bfc316c0faf57c42a8cf2395a1bce594a9f987750f37287680fdb9e190dc342',
        'numpy':np.__version__,'scipy':scipy.__version__,'python':platform.python_version(),
        'core_sha256':hashlib.sha256((HERE/'core.py').read_bytes()).hexdigest(),
        'random_generator':'numpy.random.Generator(PCG64)','blas_threads':1,
        'rate_unit':'bits per complex channel use','error_unit':'complex channel coefficient squared error',
        'monte_carlo_interval':'mean +/- 1.96 standard errors is an asymptotic diagnostic, not a deterministic certificate'}


def figure4(count):
    out=base();out.update(experiment='Fig. 4 finite-dimensional isotropic Wishart check',trials=count,
        grid_origin='Independent log-spaced prior-precision grid, source endpoints/legend retained',rows=[])
    raw={}
    for m in (2,4,6):
        t=4*m;seed=42000+m
        x=c.cn(np.random.default_rng(seed),(count,m,t));r=x@x.conj().transpose(0,2,1)/t
        eig=np.linalg.eigvalsh(r);raw[f'eigenvalues_M{m}']=eig
        for precision in np.logspace(-2,2,13):
            model=c.Model(m,m,t,1,prior_variance=1/precision)
            vals=model.sensing_scale*np.sum(1/(eig+model.z),axis=1)
            finite=c.isotropic_gaussian_crb(m,t,1,ns=m,prior_variance=1/precision)
            mp=model.sensing_scale*m*c.mp_resolvent(m/t,model.z)
            stats=c.mean_se(vals)
            out['rows'].append({'M':m,'Ns':m,'T':t,'seed':seed,'prior_precision':precision,
                'finite_exact_integral':finite,'monte_carlo':stats,'paper_eq100':mp,
                'relative_mp_error':(mp/finite['value']-1),
                'mc_standardized_difference':(stats['mean']-finite['value'])/stats['standard_error'],
                'deterministic_covariance_lower_bound':c.minimum_crb(model),
                'unregularized_upper_limit':m*m/(t-m)})
    out['summary']={'points':len(out['rows']),
        'max_abs_relative_mp_error':max(abs(r['relative_mp_error']) for r in out['rows']),
        'max_abs_mc_zscore':max(abs(r['mc_standardized_difference']) for r in out['rows'])}
    np.savez_compressed(HERE/'evidence'/'figure4_raw.npz',**raw)
    write('figure4.json',out);return out['summary']


def estimator_check(count=8192):
    model=c.Model(2,2,4,1.5,sensing_noise=.7,prior_variance=1.3)
    cov=np.array([[1,.35j],[-.35j,2.]])
    rows=[];raw={}
    for mode in ('gaussian','semiunitary'):
        wave_seed=17291 if mode=='gaussian' else 17292
        generator=c.gaussian_waveforms if mode=='gaussian' else c.semiunitary_waveforms
        x=generator(cov,model.t,count,wave_seed)
        rng=np.random.default_rng(18291)
        truth=np.sqrt(model.prior_variance)*c.cn(rng,(count,model.ns,model.m))
        noise=np.sqrt(model.sensing_noise)*c.cn(rng,(count,model.ns,model.t))
        y=truth@x+noise
        estimates=np.asarray([c.posterior_mean(yy,xx,model.sensing_noise,model.prior_variance) for yy,xx in zip(y,x)])
        errors=np.sum(abs(estimates-truth)**2,axis=(1,2));bounds=c.crb_from_waveforms(x,model)
        delta=errors-bounds
        stats=c.mean_se(delta)
        raw[mode+'_squared_errors']=errors;raw[mode+'_conditional_crb']=bounds
        rows.append({'signaling':mode,'waveform_seed':wave_seed,'truth_noise_seed':18291,
            'mse':c.mean_se(errors),'conditional_crb_average':c.mean_se(bounds),
            'paired_mse_minus_bound':stats,'paired_standardized_difference':stats['mean']/stats['standard_error'],
            'expected_total_block_energy':model.t*np.trace(cov).real,
            'empirical_block_energy':c.mean_se(np.sum(abs(x)**2,axis=(1,2)))})
    out=base();out.update(experiment='Truth-only evaluation of posterior estimator',model=dataclasses.asdict(model),
        estimator_inputs=['Y','X','sensing_noise','prior_variance'],scope='Independent linear-Gaussian verification, not a paper estimator figure',rows=rows)
    write('estimator_check.json',out);np.savez_compressed(HERE/'evidence'/'estimator_raw.npz',**raw)
    return [r['paired_standardized_difference'] for r in rows]


def sphere_check():
    out=base();out.update(experiment='Finite-SNR exact rank-one Stiefel signaling sanity cases',
        scope='Low-dimensional independent integration, not full-rank MIMO Stiefel mutual information',rows=[])
    for t in (1,2,4,16):
        for snr in (.01,.1,1.,10.,100.,1000.):
            model=c.Model(2,1,t,1)
            cov=np.diag([1.,0.]);h=np.array([[np.sqrt(snr),0.]])
            value=c.rank_one_sphere_rate(snr,t)
            out['rows'].append({'T':t,'SNR':snr,'finite_SNR_integral':value,
                'Gaussian_capacity':np.log2(1+snr),
                'eq56_high_SNR_leading_value':c.semiunitary_asymptotic_rate(h,cov,model),
                'eq111_identity_leading_value':c.semiunitary_asymptotic_rate(h,cov,model,True),
                'matrix_sensing_crb':c.conditional_crb(cov,model)})
    write('sphere_integration.json',out)


def source_discrepancies():
    # Exact second moments, derived by Gaussian fourth-moment factorization.
    q=np.array([1.,4.]);m=2;t=8
    actual=float(np.sum(q*q)+np.sum(q)**2/t)
    component=float((1+m/t)*np.sum(q*q))
    g=np.array([.1,5.]);delta=.1;k=10
    minus=minimize_scalar(lambda w:1/(w+delta)+1/(2-w+delta)-k*(np.log1p(g[0]*w)+np.log1p(g[1]*(2-w))),bounds=(0,2),method='bounded',options={'xatol':1e-14})
    plus=minimize_scalar(lambda w:1/(w+delta)+1/(2-w+delta)+k*(np.log1p(g[0]*w)+np.log1p(g[1]*(2-w))),bounds=(0,2),method='bounded',options={'xatol':1e-14})
    full_plus=[]
    for gi in g:
        candidates=[0.,2.]+[float(r.real) for r in np.roots([k*gi,2*k*gi*delta-gi,k*gi*delta**2-1]) if abs(r.imag)<1e-12 and 0<r.real<2]
        full_plus.append(min(candidates,key=lambda w:1/(w+delta)+k*np.log1p(gi*w)))
    full_plus=np.asarray(full_plus)
    if full_plus.sum()>2:raise AssertionError('chosen separable plus minimizers must fit the inequality budget')
    out=base();out.update(experiment='Printed expression audit with independent finite counterexamples',
        prior={'complex_variance':1.,'real_coordinate_variance':.5,'printed_pre93_prior_information':1.,'derived_prior_information':2.,'eq94_prior_information':2.},
        eq101={'M':m,'T':t,'population_eigenvalues':q,'exact_expected_trace_R_squared':actual,
            'componentwise_mp_expected_trace_R_squared':component,'difference':component-actual,
            'fixed_beta_half_1_half_4_asymptotic_normalized_second_moment_true':8.5+.25*2.5**2,
            'fixed_beta_componentwise_normalized_second_moment':1.25*8.5,
            'conclusion':'Componentwise scaled MP is not the general unequal-covariance spectral law; this moment check alone does not disprove every z~1/T inverse-resolvent asymptotic path'},
        eq109={'gain_eigenvalues':g,'delta':delta,'kappa':k,
            'literal_plus_optimization_status':'bounded scalar optimizer diagnostic on fixed-power subset; no global certificate claimed for nonconvex plus objective',
            'literal109_full_constraint_note':'Source (109) allows trace <= budget; its plus-rate objective also permits the zero-transmission solution, unlike the desired communication endpoint',
            'source48_minus_rate_allocation':[minus.x,2-minus.x],
            'plus_rate_full_budget_slice_allocation':[plus.x,2-plus.x],
            'literal109_inequality_global_allocation':full_plus,
            'literal109_inequality_total_power':float(full_plus.sum()),
            'literal109_inequality_objective':float(np.sum(1/(full_plus+delta)+k*np.log1p(g*full_plus))),
            'literal109_inequality_proof':'Each independent coordinate global minimum is enumerated from endpoints and all derivative roots; their total power is feasible, hence the separable global lower bound is attained',
            'literal109_inequality_rate_bits':float(np.log2(1+g*full_plus).sum()),
            'source48_rate_bits':float(np.log2(1+g*np.array([minus.x,2-minus.x])).sum()),
            'plus_rate_full_budget_slice_rate_bits':float(np.log2(1+g*np.array([plus.x,2-plus.x])).sum())})
    write('source_conflicts.json',out)


def region(channels,blocks,replicates=2):
    kappas=[0.,.01,.1,1.,10.,100.,1000.,10000.,math.inf]
    out=base();out.update(experiment='Bounded Fig. 10 configuration audit',
        channels_per_replicate=channels,waveform_blocks_per_channel=blocks,replicates=replicates,
        weights=['communication-only' if np.isinf(x) else x for x in kappas],
        scope='Source equations at disclosed finite Monte Carlo settings; figure-power convention unresolved; general Stiefel rates asymptotic only',
        raw_metric_columns=['rate_bits','outer_crb_normalized','gaussian_crb_normalized_mean','within_channel_mean_variance','eq101_approx_or_NaN','eq56_asymptotic_rate','eq111_asymptotic_rate','relative_optimizer_gap','objective','absolute_optimizer_gap','normalized_budget_residual'],
        source_settings={'M':4,'Nc':4,'Ns':4,'T':16,'Hc_entry_variance':.25,'Hs_entry_variance':1.,'transmit_snr_db':24.},runs=[])
    raw={}
    for convention,pt in [('table_as_per_antenna',10**2.4),('table_as_total',10**2.4/4)]:
        model=c.Model(4,4,16,pt)
        for rep in range(replicates):
            seed=91021+rep*10000
            rng=np.random.default_rng(seed)
            h=c.cn(rng,(channels,4,4))/2
            # Shared draws across covariance weights are intentional common random numbers.
            z=c.cn(rng,(channels,blocks,4,16))
            key=f'{convention}_rep{rep}'
            raw[key+'_channel_real']=h.real;raw[key+'_channel_imag']=h.imag
            per=[]
            for ki,k in enumerate(kappas):
                rates=[];epsout=[];epsgauss=[];epsvar=[];approx=[];uasym=[];uidentity=[];gaps=[];objectives=[];absolute_gaps=[];feasibility=[];alloc=[]
                for ci,hc in enumerate(h):
                    sol=c.covariance_shape(hc,model,k);q=sol['eigenvalues'];v=sol['eigenvectors'];Q=sol['covariance']
                    x=np.einsum('ij,bjt->bit',v*np.sqrt(q),z[ci])
                    sense=c.crb_from_waveforms(x,model)/(model.m*model.ns)
                    rates.append(c.gaussian_rate(hc,Q,model.communication_noise));epsout.append(c.conditional_crb(Q,model)/(model.m*model.ns))
                    epsgauss.append(sense.mean());epsvar.append(sense.var(ddof=1)/blocks)
                    approx.append(c.printed_mp101(q,model)/(model.m*model.ns) if np.min(q)>1e-10 else np.nan)
                    uasym.append(c.semiunitary_asymptotic_rate(hc,Q,model));uidentity.append(c.semiunitary_asymptotic_rate(hc,Q,model,True))
                    gaps.append(sol['global_gap_bound']/max(1,abs(sol['objective'])));objectives.append(sol['objective']);absolute_gaps.append(sol['global_gap_bound']);feasibility.append(sol['feasibility_residual']);alloc.append(q)
                rates=np.asarray(rates);epsout=np.asarray(epsout);epsgauss=np.asarray(epsgauss)
                app=np.asarray(approx)
                raw[f'{key}_weight{ki}_allocations']=np.asarray(alloc)
                raw[f'{key}_weight{ki}_metrics']=np.column_stack([rates,epsout,epsgauss,epsvar,app,uasym,uidentity,gaps,objectives,absolute_gaps,feasibility])
                point={'weight':'communication-only' if np.isinf(k) else k,
                    'rate_gaussian':c.mean_se(rates),'crb_outer_normalized':c.mean_se(epsout),
                    'crb_gaussian_normalized':c.mean_se(epsgauss),
                    'within_waveform_mean_variance_contribution':float(np.mean(epsvar)/channels),
                    'eq101_approx_mean_valid_subset':float(np.mean(app[np.isfinite(app)])) if np.isfinite(app).any() else None,
                    'eq101_valid_channels':int(np.isfinite(app).sum()),
                    'semiunitary_eq56_asymptotic_rate':c.mean_se(uasym),
                    'semiunitary_eq111_asymptotic_rate':c.mean_se(uidentity),
                    'max_relative_global_optimization_gap':max(gaps),'max_absolute_global_optimization_gap':max(absolute_gaps),'max_normalized_budget_residual':max(feasibility)}
                per.append(point)
            conservative_points=[(c.minimum_crb(model)/(model.m*model.ns),0.)]+[(p['crb_gaussian_normalized']['mean'],p['rate_gaussian']['mean']) for p in per]
            out['runs'].append({'power_convention':convention,'model':dataclasses.asdict(model),'seed':seed,'points':per,
                'semiunitary_minimum_crb_normalized':c.minimum_crb(model)/(model.m*model.ns),
                'estimated_achievable_timesharing_hull':c.achievable_hull(conservative_points),
                'hull_warning':'Gaussian coordinates have Monte Carlo uncertainty; anchor has exact zero-rate deterministic signaling; high-SNR approximations are excluded'})
    np.savez_compressed(HERE/'evidence'/'region_raw.npz',**raw)
    write('region.json',out)
    return {'runs':len(out['runs']),'channels_per_run':channels,'points_per_run':len(kappas),
        'maximum_relative_global_gap':max(p['max_relative_global_optimization_gap'] for r in out['runs'] for p in r['points'])}


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--region',action='store_true');parser.add_argument('--channels',type=int,default=256);parser.add_argument('--blocks',type=int,default=256)
    parser.add_argument('--trials',type=int,default=16384);args=parser.parse_args()
    (HERE/'evidence').mkdir(exist_ok=True)
    start=time.monotonic()
    if args.region:summary=region(args.channels,args.blocks)
    else:
        summary={'figure4':figure4(args.trials),'estimator_zscores':estimator_check()};sphere_check();source_discrepancies()
    summary['wall_seconds']=time.monotonic()-start
    print(json.dumps(summary,indent=2))

if __name__=='__main__':main()
