# Numerical-reference handoff

## Accepted claim boundary

This package is an independent implementation and numerical validation of a bounded matrix-response Bayesian specialization of arXiv:2204.06938v8. It is substantially beyond the prior real-scalar LS prerequisite. It does not solve the arbitrary input-distribution functional problem or reproduce the full paper.

The primary named experiment is the Fig. 4 finite-Wishart/MP comparison. The Fig. 10 work is a bounded source-parameter/region audit under both unresolved power interpretations, not an unqualified figure reproduction. The direct real-likelihood model and source Eq. (48)/(95) are the operational mathematical authority; conflicting printed formulas are preserved in SOURCE-AUDIT.md.

## What ran

- 15 test methods passed, including complex real-Fisher/posterior agreement, independent SLSQP covariance optimization, full PSD competitors, rank/structural-null guards, finite-SNR sphere MI, fairness and invalid inputs
- Fig. 4: 39 configurations, M=Ns in {2,4,6}, T=4M, covariance I, prior precision 0.01–100; 16,384 Gaussian blocks per M, with shared blocks across prior settings
- Fig. 4 maximum finite-integral versus printed isotropic MP relative difference: 0.002345380009984 (0.234538%)
- Fig. 4 maximum Monte Carlo standardized difference from the finite integral: 1.7726945103
- Implementation-side 60-digit Laguerre/Bessel integral checks: maximum binary64 difference 1.19e−15
- Separate reviewer’s 90-digit finite-polynomial/E1 oracle covered all 39 Fig. 4 points: maximum difference 1.33e−15, as recorded in the independent review
- Truth-only posterior-MSE evaluation: 8,192 blocks per law. Paired MSE-minus-conditional-bound z scores: 0.03185 (Gaussian) and 1.36274 (Stiefel). These are finite sampling diagnostics, not proofs from observed equality
- Fig. 10 audit: two power conventions × two independent seed replicates × 256 channels × nine covariance weights; 256 Gaussian waveform draws per channel/weight. Total 9,216 covariance solves and 2,359,296 waveform/covariance evaluations. The same base draws are intentionally reused across weights and power conventions: 512 unique fading channels and 131,072 independent base waveform draws, not 2.36 million independent trials
- Maximum relative convex supporting-hyperplane objective gap: 8.52757208097e−14; maximum absolute objective gap: 1.06556399260e−8; maximum normalized power-budget residual: 1.77635683940e−15
- All 27,803 saved-record checks passed, including raw summary replay, every covariance allocation, direct complex-matrix determinant/inverse results and recomputed gap certificates
- The declared larger sweep took 38.11 seconds on this executor, single-threaded. This is one offline runtime observation, not a browser latency benchmark

## Power-interpretation results

The source’s lowercase Pt in Table II is not silently equated with its earlier per-antenna PT.

| Interpretation of 24 dB | PT per antenna | Minimum normalized CRB | Gaussian communication endpoint, seed 91021 | Same endpoint, seed 101021 |
|---|---:|---:|---:|---:|
| Total transmitted power | 62.79716079 | 0.0009942783530 | 19.74530 ± 0.10522 SE bits/use | 20.00967 ± 0.11357 SE bits/use |
| Per-antenna power | 251.18864315 | 0.0002487550871 | 27.01683 ± 0.13463 SE bits/use | 27.30549 ± 0.14234 SE bits/use |

The total-power convention is visually compatible with Fig. 10’s scale. That is an inference, not author confirmation. Both complete records remain available.

## Important gaps retained

1. **Deep-fade sensing loss is present.** Water filling switches off a covariance mode in 51/256 and 47/256 channels under the total-power interpretation, and 13/256 and 18/256 under the per-antenna interpretation. Those sensing directions are prior-limited and remain in the error average. At the exact Gaussian communication endpoint, normalized error is approximately 0.05122/0.04733 or 0.01304/0.01800, respectively. It was not clipped to the source figure’s axis range.
2. **The Eq. (101) diagnostic excludes invalid channels explicitly.** Its positive-eigenvalue assumption fails at those rank-deficient endpoints. The record reports the valid-subset count and never relabels that subset average as the full Gaussian sensing result.
3. **High-SNR rates are not finite-SNR guarantees.** The leading forms from (56) and (111) are stored separately and both appear in the new plot. Small singular modes in fading channels can make their difference material even at the nominal 24 dB setting. No time-sharing claim is certified from either truncated asymptotic curve.
4. **Achievable time sharing is conservative.** The saved estimated hull combines finite-Monte-Carlo Gaussian-input pairs with the exact zero-rate deterministic sensing point. It does not substitute an asymptotic rate for the true sensing-optimal finite-SNR rate.
5. **Original figure numerics remain unavailable.** No author seed, channel sample list, quadrature/solver settings, weight grid, numerical data or exact normalization clarification was supplied by the paper. There is no coordinate-by-coordinate digitized figure match claim.
6. **Estimator scope is narrow.** Exact Bayes-MMSE equality holds here because sensing is linear with a proper Gaussian prior. The paper’s nonlinear angle/amplitude nuisance model, arbitrary priors, arbitrary input laws, hardware and finite-length communication codes remain outside this package.
7. **Rank and numerical conditioning are explicit.** T<M with an improper sensing prior is structurally unidentifiable. Near-zero unregularized directions fail closed rather than being silently removed or reported as trustworthy finite inverses. Full-rank deterministic covariance needs T≥M.
8. **Source-expression conflicts remain visible.** Optimization sign, prior factor, coordinate transform/block ordering, sample-covariance scaling, rate-log normalization and the general-covariance approximation’s limited verification are all documented. These were not tuned away to fit a figure.

## Independent verification and freeze

The numerical core is frozen at SHA-256:

`b06e329b927cda7adb1e2d38b320a1f2ca1bee287ebe8dec50d6de86fe176bb2`

Main region JSON:

`1a039bb22f109b22b173f54b9f0a14c7a0ed22ad046a8130fb9d252a04eae0a4`

Main region raw NPZ:

`a3658902f508652ecbdcd94874618cbb409beae344bfa72da8899c8f909f69cf`

The independent reviewer works in the separate sibling `gaussian-tradeoff-independent-review` directory, without editing this package. Final independent verification passed on this exact core: all 10 regenerated numerical JSON/NPZ artifacts are byte-identical; all 9,216 solutions and all 2,359,296 waveform evaluations were independently audited; maximum waveform-mean disagreement was 1.12e−14 and independently computed normalized gap was 8.37e−14. All 15 tests, separate mathematical oracles and 27,803 raw-record checks passed. The separate hash-specific review report should accompany this package at integration. The package manifest hashes every deliverable and retained pilot/log file; it excludes temporary downloaded papers and interpreter caches. No UI, repository, remote, browser or publication action was taken.

## Suggested next integration gate

Keep the matrix derivation, metric ordering, source conflicts and original scalar prerequisite separately labeled. An interactive implementation must independently validate matrix arithmetic, input-law controls, export replay, failure states, and measured end-to-end latency against this frozen numerical reference. The current reference gives no automatic permission to claim those UI/release stages passed.
