"""Independent analytic-integral oracles (mpmath, 60 decimal digits).

No call to core inside the oracle definitions. Comparisons use core only after
independent values have been constructed.
"""
import json
from pathlib import Path
import mpmath as mp
mp.mp.dps=60

def finite_wishart_trace(m,t,q,noise,prior,ns):
    a=t-m;z=mp.mpf(noise)/(mp.mpf(prior)*t)
    def density(x):
        return x**a*mp.exp(-x)*sum(mp.factorial(k)/mp.factorial(k+a)*mp.laguerre(k,a,x)**2 for k in range(m))
    result=mp.quad(lambda x:density(x)/(mp.mpf(q)*x/t+z),[0,1,4,12,40,mp.inf])
    return mp.mpf(noise)*ns/t*result

def sphere_mutual_information(t,snr):
    a=mp.sqrt(t*mp.mpf(snr));area=2*mp.pi**t/mp.gamma(t)
    def fy(r):
        if r==0:return mp.exp(-a*a)/mp.pi**t
        return mp.exp(-r*r-a*a)/mp.pi**t*mp.gamma(t)*(a*r)**(1-t)*mp.besseli(t-1,2*a*r)
    def fun(r):
        if r==0:return 0
        py=fy(r);return area*r**(2*t-1)*py*(-mp.log(py)-t*mp.log(mp.pi*mp.e))
    return mp.quad(fun,[0,a,a+2,a+6,a+14,mp.inf])/(t*mp.log(2))

if __name__=='__main__':
    import core
    rows=[]
    for args in [(1,4,'1','1','1',1),(2,8,'1','1','10',2),(2,8,'2.5','.7','.4',3)]:
        v=finite_wishart_trace(*args)
        m,t,q,noise,prior,ns=args
        reference=core.isotropic_gaussian_crb(m,t,float(q),ns,float(noise),float(prior))['value']
        rows.append({'kind':'finite_Wishart','parameters':list(args),'mpmath_60_digits':str(v),'binary64':reference,'absolute_error':float(abs(v-reference))})
    v=sphere_mutual_information(2,'3')
    reference=core.rank_one_sphere_rate(3,2)['rate']
    rows.append({'kind':'rank_one_sphere_MI','T':2,'SNR':3,'mpmath_60_digits':str(v),'binary64':reference,'absolute_error':float(abs(v-reference))})
    out={'schema':'independent-high-precision-integrals-v1','precision_decimal_digits':60,'rows':rows,'max_absolute_error':max(x['absolute_error'] for x in rows)}
    path=Path(__file__).parent/'evidence'/'high_precision.json';path.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))
