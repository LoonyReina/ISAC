"""Draw new plots from this package's numerical records; no paper images."""
import os
os.environ['MPLCONFIGDIR']='/tmp/gaussian-tradeoff-mpl'
os.environ['XDG_CACHE_HOME']='/tmp/gaussian-tradeoff-cache'
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
HERE=Path(__file__).resolve().parent
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False})

p=json.loads((HERE/'evidence/figure4.json').read_text())
fig,ax=plt.subplots(figsize=(7.4,4.7))
for m,col in [(2,'#076b85'),(4,'#bd6013'),(6,'#7865ab')]:
    rr=[r for r in p['rows'] if r['M']==m];x=np.array([r['prior_precision'] for r in rr])
    y=np.array([r['finite_exact_integral']['value'] for r in rr]);mp=np.array([r['paper_eq100'] for r in rr])
    mc=np.array([r['monte_carlo']['mean'] for r in rr]);se=np.array([r['monte_carlo']['standard_error'] for r in rr])
    ax.loglog(x,y,color=col,label=f'M=Ns={m}: finite integral')
    ax.loglog(x,mp,'x',color=col,ms=5,label=f'M={m}: paper Eq. (100)')
    ax.errorbar(x,mc,yerr=1.96*se,fmt='.',color=col,alpha=.6,capsize=2)
ax.set(xlabel='Prior precision 1 / prior variance',ylabel='Total Bayesian matrix CRB',title='Finite-Wishart check of the source Fig. 4 configuration')
ax.legend(fontsize=8,ncol=2);ax.grid(alpha=.2,which='both')
fig.text(.5,.005,'New computation: T=4M, covariance I, noise variance 1; dots ±1.96 MC standard errors',ha='center',fontsize=8)
fig.tight_layout(rect=(0,.035,1,1));fig.savefig(HERE/'evidence/figure4_reference.png',dpi=160);plt.close(fig)

path=HERE/'evidence/region.json'
if path.exists():
    p=json.loads(path.read_text());fig,axes=plt.subplots(1,2,figsize=(11.5,4.6))
    for ax,conv in zip(axes,['table_as_total','table_as_per_antenna']):
        runs=[r for r in p['runs'] if r['power_convention']==conv]
        for ri,r in enumerate(runs):
            a=np.array([v['crb_outer_normalized']['mean'] for v in r['points']]);b=np.array([v['crb_gaussian_normalized']['mean'] for v in r['points']]);rate=np.array([v['rate_gaussian']['mean'] for v in r['points']]);ur=np.array([v['semiunitary_eq56_asymptotic_rate']['mean'] for v in r['points']]);ui=np.array([v['semiunitary_eq111_asymptotic_rate']['mean'] for v in r['points']])
            ax.semilogx(a,rate,'o-',ms=3,color='#096b87',alpha=1 if ri==0 else .35,label='Covariance outer pair' if ri==0 else None)
            ax.semilogx(b,rate,'s-',ms=3,color='#d0791f',alpha=1 if ri==0 else .35,label='Gaussian inner estimate' if ri==0 else None)
            ax.semilogx(a,ur,':',color='#8a5fb4',alpha=1 if ri==0 else .35,label='Semi-unitary Eq. (56) leading term' if ri==0 else None)
            ax.semilogx(a,ui,'--',color='#ae5272',alpha=1 if ri==0 else .35,label='Semi-unitary Eq. (111) leading term' if ri==0 else None)
        ax.set(title='24 dB interpreted as '+('total power' if conv=='table_as_total' else 'per-antenna power'),xlabel='Normalized matrix CRB',ylabel='Bits per complex channel use');ax.grid(alpha=.2)
    axes[0].legend(fontsize=8,loc='lower right')
    fig.suptitle('Bounded Fig. 10 configuration audit: both power conventions retained',fontsize=12)
    fig.text(.5,.008,'Light lines are independent seed replicates. Asymptotic Stiefel rates are not finite-SNR certificates.',ha='center',fontsize=8)
    fig.tight_layout(rect=(0,.04,1,.95));fig.savefig(HERE/'evidence/region_reference.png',dpi=160);plt.close(fig)
print('Plots written from recorded numerical data')
