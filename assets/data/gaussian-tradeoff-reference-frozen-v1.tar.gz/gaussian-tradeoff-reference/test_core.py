import math
import unittest
import numpy as np
from scipy.optimize import minimize
import core as c

class CoreTests(unittest.TestCase):
    def test_real_fisher_matches_complex_posterior(self):
        rng=np.random.default_rng(91)
        for m,t,ns in [(1,1,1),(2,4,3),(3,2,2)]:
            x=c.cn(rng,(m,t));model=c.Model(m,ns,t,1,0.7,1,2.3)
            direct=ns*np.trace(np.linalg.inv(c.real_bfim(x,0.7,2.3)))
            self.assertAlmostEqual(direct,c.conditional_crb(c.sample_covariance(x),model),places=11)

    def test_zero_data_prior(self):
        m=c.Model(3,2,4,2,1,1,7)
        self.assertAlmostEqual(c.conditional_crb(np.zeros((3,3)),m),42)
        self.assertAlmostEqual(np.trace(np.linalg.inv(c.real_bfim(np.zeros((3,4)),1,7))),21)

    def test_stiefel_covariance_and_nonconstant_gaussian_energy(self):
        q=np.array([[1,0.2j],[-0.2j,2]])
        u=c.semiunitary_waveforms(q,5,20,8)
        self.assertLess(np.max(np.abs(u@u.conj().transpose(0,2,1)/5-q)),1e-13)
        g=c.gaussian_waveforms(q,5,40,8)
        self.assertGreater(np.std(np.sum(abs(g)**2,axis=(1,2))),1)
        with self.assertRaises(ValueError):c.semiunitary_waveforms(np.eye(3),2,1,1)

    def test_rank_and_prior(self):
        model=c.Model(3,2,4,1,prior_variance=math.inf)
        self.assertTrue(math.isinf(c.conditional_crb(np.diag([1,0,2]),model)))
        self.assertTrue(math.isinf(c.isotropic_gaussian_crb(3,3,1,prior_variance=math.inf)['value']))
        self.assertAlmostEqual(c.isotropic_gaussian_crb(2,8,1,3,prior_variance=math.inf)['value'],1.)
        with self.assertRaises(ValueError):c.minimum_crb(c.Model(3,1,2,1))

    def test_finite_wishart_and_mp(self):
        for m in [1,2,4]:
            ans=c.isotropic_gaussian_crb(m,4*m,1,ns=m,prior_variance=100)
            low=c.Model(m,m,4*m,1,prior_variance=100)
            self.assertGreater(ans['value'],c.minimum_crb(low))
            self.assertLess(ans['value'],m*m/(4*m-m))
        self.assertAlmostEqual(c.mp_resolvent(.25,0),4/3)
        self.assertAlmostEqual(c.mp_resolvent(.25,1e-12),4/3,places=10)
        self.assertAlmostEqual(c.mp_resolvent(.25,1e8)*1e8,1.,places=7)
        self.assertAlmostEqual(c.mp_resolvent(2,1e-8)*1e-8,.5,places=7)

    def test_shape_global_certificate_and_slsqp(self):
        rng=np.random.default_rng(178)
        for m in [2,3,4]:
            model=c.Model(m,2,2*m,3,1,2,.4)
            h=c.cn(rng,(m,m))
            for k in [0,.03,.4,5,100,math.inf]:
                got=c.covariance_shape(h,model,k)
                self.assertLess(got['global_gap_bound'],2e-8*max(1,abs(got['objective'])))
                a=got['channel_gains']*model.power_per_antenna
                delta=model.z/model.power_per_antenna
                fun=lambda w:c.objective_gradient(w,a,delta,k)[0]
                jac=lambda w:c.objective_gradient(w,a,delta,k)[1]
                res=minimize(fun,np.ones(m),jac=jac,bounds=[(0,m)]*m,
                    constraints=[{'type':'eq','fun':lambda w:w.sum()-m,'jac':lambda w:np.ones(m)}],
                    method='SLSQP',options={'ftol':1e-11,'maxiter':1000})
                self.assertTrue(res.success,res.message)
                self.assertAlmostEqual(res.fun,got['objective'],delta=1e-7*max(1,abs(res.fun)))

    def test_eigenbasis_rotation_invariance(self):
        rng=np.random.default_rng(281);h=c.cn(rng,(3,3));v,_=np.linalg.qr(c.cn(rng,(3,3)))
        model=c.Model(3,2,6,2)
        a=c.covariance_shape(h,model,.8);b=c.covariance_shape(h@v,model,.8)
        self.assertLess(np.linalg.norm(a['covariance']-v@b['covariance']@v.conj().T),1e-10)

    def test_matrix_bound_support_hyperplane(self):
        rng=np.random.default_rng(312);model=c.Model(2,2,4,2)
        h=c.cn(rng,(2,2));k=.7;s=c.covariance_shape(h,model,k)
        q=s['covariance']/model.power_per_antenna;A=h.conj().T@h*model.power_per_antenna
        d=model.z/model.power_per_antenna
        # Arbitrary complex PSD competitors, not diagonal allocations.
        for _ in range(80):
            z=c.cn(rng,(2,2));w=z@z.conj().T;w*=2/np.trace(w).real
            obj=np.trace(np.linalg.inv(w+d*np.eye(2))).real-k*np.linalg.slogdet(np.eye(2)+h@w@h.conj().T*model.power_per_antenna)[1]
            self.assertGreaterEqual(obj,s['objective']-1e-10)

    def test_lowdimensional_sphere_rate(self):
        for t in [1,2,4]:
            for snr in [.01,1,10,100]:
                r=c.rank_one_sphere_rate(snr,t)
                self.assertGreater(r['rate'],0)
                self.assertLess(r['rate'],np.log2(1+snr)+1e-9)
                self.assertLess(r['quadrature_error'],1e-7)
                self.assertLess(r['omitted_tail_probability'],1e-35)

    def test_posterior_has_no_truth_argument(self):
        x=np.array([[1+1j,2],[.2,1j]])
        h=np.array([[.4+1j,-.8]])
        y=h@x
        expected=y@x.conj().T@np.linalg.inv(x@x.conj().T+2*np.eye(2))
        np.testing.assert_allclose(c.posterior_mean(y,x,2,1),expected)

    def test_fail_closed_inputs(self):
        for a in [np.array([[1,2],[0,1]]),np.diag([1,-1]),np.array([[np.nan]])]:
            with self.assertRaises(ValueError):c.hermitian_psd(a)
        with self.assertRaises(ValueError):c.Model(2,1,2,-1)
        with self.assertRaises(ValueError):c.covariance_shape(np.eye(2),c.Model(2,1,2,1),-1)
        with self.assertRaises(ValueError):c.printed_mp101([1,0],c.Model(2,1,2,1))
        with self.assertRaises(ValueError):c.rank_one_sphere_rate(-1,2)
        with self.assertRaises(ValueError):c.crb_from_waveforms(np.zeros((2,1,3)),c.Model(2,1,3,1))

    def test_no_silent_positive_eigenmode_drop(self):
        with self.assertRaises(ValueError):c.semiunitary_waveforms(np.diag([1.,1e-13]),1,1,1)
        x=np.diag([1.,1e-7]).astype(complex)
        model=c.Model(2,1,2,1,prior_variance=math.inf)
        direct=c.conditional_crb(c.sample_covariance(x),model)
        batch=c.crb_from_waveforms(x[None,:,:],model)[0]
        self.assertAlmostEqual(batch/direct,1.,places=14)
        self.assertTrue(np.isfinite(batch))

    def test_structural_nullspace_and_rank_ambiguity(self):
        rng=np.random.default_rng(83)
        for m,t in [(2,1),(3,2)]:
            x=c.cn(rng,(4,m,t))
            values=c.crb_from_waveforms(x,c.Model(m,1,t,1,prior_variance=math.inf))
            self.assertTrue(np.isinf(values).all())
        x=np.array([[1+1j,2],[1+1j,2]],complex)
        model=c.Model(2,1,2,1,prior_variance=math.inf)
        try:
            values=c.crb_from_waveforms(x[None,:,:],model)
            self.assertTrue(np.isinf(values).all())
        except ValueError as exc:
            self.assertIn('rank-ambiguous',str(exc))
        with self.assertRaisesRegex(ValueError,'full-row-rank'):
            c.posterior_mean(np.ones((1,1)),np.ones((2,1)),prior_variance=math.inf)
        with self.assertRaisesRegex(ValueError,'rank-ambiguous'):
            c.conditional_crb(np.diag([1.,1e-30]),model)

    def test_integral_float_dimensions_normalized(self):
        model=c.Model(2.0,1.0,2.0,1)
        self.assertIsInstance(model.m,int)
        c.covariance_shape(np.eye(2),model,0)
        self.assertEqual(c.gaussian_waveforms(np.eye(2),4.0,2.0,1).shape,(2,2,4))
        self.assertEqual(c.semiunitary_waveforms(np.eye(2),4.0,2.0,1).shape,(2,2,4))

    def test_time_sharing_hull(self):
        self.assertEqual(c.achievable_hull([(1,0),(2,1),(3,3),(4,2),(5,4)]),[(1,0),(3,3),(5,4)])

if __name__=='__main__':unittest.main(verbosity=2)
