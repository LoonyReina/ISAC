# OFDM ICI Worker lifecycle

`ici-worker.js` is a real Worker entry point with separate browser and Node loading paths:

- **Classic browser Worker:** `new Worker('./worker/ici-worker.js')`. The worker imports `../js/linalg.js`, `../js/sha256.js`, `../js/evaluate.js`, and `../js/ici-kernel.js` with `importScripts`. Serve the directory with ordinary same-origin HTTP(S); this entry is not an ES-module Worker.
- **Node:** `new (require('node:worker_threads').Worker)(absoluteWorkerPath)`. The worker requires `../js/ici-kernel.js`; that module requires its numerical dependencies.

No DOM, UI, server, fetch, production deployment, or cached numerical output is involved.

## Input protocol

Send exactly one of the following structured-cloneable objects:

```js
worker.postMessage({ type: 'run', runId: 'unique-run-1', input: rawKernelRequest });
worker.postMessage({ type: 'cancel', runId: 'unique-run-1' });
worker.postMessage({ type: 'reset' });
```

Every run ID is a fresh 1–128-character ASCII identifier, starting with a letter or digit and otherwise containing letters, digits, `_`, `.`, `:`, or `-`. Reusing an accepted ID is rejected, including after reset; replacing the Worker starts a new session. A session accepts at most 10,000 runs so the ID ledger is bounded. Unknown message types and envelope fields are rejected. Inputs must be ordinary objects containing an acyclic tree of supported structured data, with a 4 MiB approximate preflight byte budget, 200,000 nodes, and depth at most 32. Shared object references are also rejected. Typed-array bytes count toward the budget. The numerical kernel performs all detailed schema, dimensional, finite-value, and computational-resource validation.

The worker receives a message only after the browser/Node transport has cloned it. Its preflight avoids numerical allocations for oversized inputs; it cannot avoid that initial transport clone. Limits are not a process-wide memory or security sandbox.

## Output protocol

- `ready`: `{type:'ready', ok, protocol:'ofdm-ici-worker-v1', limits, error}` after imports succeed or fail
- `accepted`: `{type:'accepted', runId}` for a validated envelope
- `progress`: `{type:'progress', runId, progress}` with the fresh kernel progress event, including `phase` and `input_revision`
- `complete`: `{type:'complete', runId, result}` with a freshly computed kernel result and typed arrays preserved
- `cancelled`: `{type:'cancelled', runId, reason:'requested'|'reset'}`
- `superseded`: `{type:'superseded', runId, reason:'newer-run'}`
- `error`: `{type:'error', runId, error:{code,message}}` for an accepted run that fails numerically; a core wall-time cap preserves `error.status:'time_cap'` with `error.code:'TIME_CAP'`
- A rejected request returns the same `error` shape with `rejected:true`; its `runId` is null when invalid. This is a rejection of the request, not a second terminal outcome for an existing run. A rejected request does not cancel valid active work.
- `reset`: `{type:'reset', pendingStop}` acknowledges reset. An executing run's `cancelled` terminal follows once it has actually unwound.
- `cancel-ignored`: `{type:'cancel-ignored', runId, reason:'not-current'}` for a cancellation that cannot affect the current run

An accepted run has exactly one terminal outcome: `complete`, `cancelled`, `superseded`, or `error`. Only `complete` contains results. Progress and all terminals carry the matching run ID. An import failure sends an unsuccessful `ready`, leaves the listener alive, and rejects later run requests explicitly with `KERNEL_LOAD_FAILED`.

## Cancellation and supersession

The core's async checkpoint yields via `setTimeout(..., 0)`, rather than a microtask-only `Promise.resolve()`. This permits Worker message events to process while numerical work is ongoing. Cancellation throws out of the core at a checkpoint and unwinds it; it does not finish the computation and label its final result cancelled. One numerical run executes at a time. A new accepted run stops the previous selected run, replaces any queued run, and starts only after the executing run unwinds. Burst submissions therefore do not create overlapping numerical computations.

Progress and completion publication both check the currently selected generation. There is also a final event-loop checkpoint after the core returns. A cancelled or superseded run cannot publish subsequent progress or a complete result. A reset suppresses further output from its selected run, cancels it, and allows a fresh run. First cancellation cause wins: a requested cancellation is not relabelled by a later replacement.

Cancellation latency is bounded by the core's checkpoint placement and event-loop scheduling, not a guaranteed millisecond SLA. Synchronous work between checkpoints cannot be interrupted. `Worker.terminate()` is available for immediate session disposal. This protocol does not transfer a partial result on cancellation or claim browser performance from Node tests.

## Optional client wrapper

`ici-client.js` exports the `ICIWorkerClient` class under CommonJS or `globalThis.ICIWorkerClient`. Supply an already-created browser or Node Worker:

```js
const client = new ICIWorkerClient(worker, {
  onEvent(event) { /* Only the current submitted run reaches this observer. */ }
});
const job = client.run(rawKernelRequest, {
  onProgress(progress) { /* Render fresh progress. */ }
});
const terminal = await job.result;
if (terminal.type === 'complete') render(terminal.result);
// job.cancel();                 // Request cancellation of that run.
// client.reset();               // Request reset, retaining run-ID uniqueness.
// await client.dispose();       // Terminate the Worker and settle pending jobs.
```

`run()` returns `{runId, result:Promise, cancel()}`. IDs are generated unless supplied in options. The client bounds its own ID ledger to 10,000 submitted runs, including rejected attempts. The promise resolves with complete/cancelled/superseded envelopes, and rejects with `ICIWorkerError` on rejected requests, numerical failures, import failures, transport failures, or unexpected Worker exit. Its `code`, `runId`, and any core `status` are inspectable. `dispose()` terminates the Worker and settles remaining jobs as cancelled with reason `client-disposed`; it also removes listeners. Handle each promise rejection normally.

Use one client as the exclusive owner of its Worker. The client's current view follows the latest **submitted** run, even if that request is subsequently rejected. It does not display an older completion as the result of a newer input. All per-run promises still settle; the optional current-view observer suppresses stale events. A defensive old completion is settled as superseded rather than forwarded. If a completion was already queued when the client requests cancellation or reset, it is discarded and settled as cancelled with `queuedResultSuppressed:true`; this is explicitly a client delivery race and does not claim the already-finished computation was interrupted. Observer exceptions do not break lifecycle bookkeeping. This client is a transport helper, not a UI state implementation.

## Verification

With Node 18 or newer, from the prototype root:

```sh
node test-worker.cjs --require-core
```

The test file clearly separates:

1. Protocol-fixture tests for precise interruption instrumentation, bounded queueing, malformed/oversized requests, reset, repeated IDs, import failure, and client stale filtering
2. Actual Node `worker_threads` execution of the protocol fixture and production numerical core
3. The actual browser `importScripts` branch loaded in Node's VM, using both the protocol fixture and production core

The VM tests are **not real browser execution evidence**. The fixture tests are **not numerical parity evidence**. Production-core tests assert fresh completion, provenance identity, actual CFO-stage cancellation, supersession, numerical error propagation, and clean worker termination. Numerical parity and actual browser runtime/performance evidence belong to their separate verification tracks.
