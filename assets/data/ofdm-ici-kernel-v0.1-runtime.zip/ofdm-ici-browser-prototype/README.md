# Bounded fresh-computation MIMO-OFDM ICI kernel

Actual Float64 JavaScript MUSIC → APES/GLRT-OMP → original-observation joint refits → CA-CFAR → literal source CFO unwrapping, with a real cancellable Worker. **No UI, repository integration, deployment or browser-performance claim.**

Fixed source: [Keskin, Wymeersch and Koivunen, arXiv:2103.15694v1](https://arxiv.org/pdf/2103.15694v1). Python source-derived core pinned at `fee9e4a55707fe251f73bf343d0ac0142607d6c827cfd4e8bd0c974bba439cdb`.

## Scope

- N=64, M=16, N_R=N_T=8, L=12, CP/T=.25; fixed physical B=50 MHz, carrier=60 GHz
- Default angle grid −80…80° in .5° steps, CFO grid −3.5…3.5 with 113 points
- **Finite-grid only.** Continuous refinements are rejected rather than silently ignored
- Pmax defaults to3 and accepts1–4 independently of simulated target count; MDL selects MUSIC order from observed Y by default. Optional declared order0–7 is explicitly labelled
- Full complex128-style arithmetic. Certified Hermitian cyclic Jacobi, complex Householder QR and one-sided complex Jacobi SVD. No Gram-eigenvalue SVD shortcut, ridge loading, pseudoinverse or truth-centred search
- Known-X operational FFT uses identical actual X/Y and observed MUSIC angles. The separately labelled ICI-free result is synthetic; imported counterfactual pairing is caller-declared
- Truth enters simulation and evaluation only. `receive`, OMP, search and stopping receive no truth

This is a port of a bounded source-derived algorithm, **not reproduction of the paper's published figures or calibrated false-alarm performance**. The existing independent Python review does not automatically accept this new port; any separate port review has its own scope.

## Run

No production dependencies. Node 22+ was used here.

```js
const K = require('./js/ici-kernel.js');
const result = await K.run({
  schema_version: 'ofdm-ici-input-v1', input_revision: 'example-1', mode: 'simulate',
  config: {},
  simulation: {seed:123, noise_seed:456, noise_variance:1,
    targets:[{delay_samples:3, epsilon:1.1, angle_deg:-30, alpha_real:1, alpha_imag:0}]}
});
// Portable JSON, preserving every output; nonfinite failure cells become null:
const json = JSON.stringify(K.toJSON(result));
```

Use `worker/ici-worker.js` for isolation and real event-loop cancellation. The browser branch loads four local scripts via importScripts; Node uses worker_threads. See [Worker protocol](worker/README.md). Browser-branch loading is verified in a VM, not an actual browser.

`K.exportRaw(result, 'new-revision')` produces explicit raw X/Y with SHA-256 checksums. Serialize with `K.toJSON`, parse with `K.parseRawJSON`, then execute `K.run` to perform a new solve. Historical output objects are rejected as fresh inputs. Saved oracle outputs are test evidence; the runtime never loads them.

## Tests and evidence

Run `./run_all.sh`. Regenerating or checking Python fixtures requires the pinned `ofdm-ici-reference` package extracted alongside this directory, Python3.12, NumPy2.3.5 and SciPy1.17.0. JavaScript fixture comparisons, Worker tests and runtime need no Python.

- `reports/oracle-comparison.json`: 16 fresh varied inputs plus separately held finite-grid mechanism; complete source intermediate comparison. All-ones downstream minimizer parity is deliberately excluded because the CFO objective is numerically flat
- `reports/native-python-comparison.json`: independent Python re-execution of native JavaScript QPSK and nonconstant-amplitude QAM samples, including non-real reflection gains
- `reports/kernel-tests.json`: import, checksums, deterministic generation, held-Y recomputation, truth isolation, rank, alias, time-cap and bounds tests
- `tests/linalg_oracle_report.json`: 265 independently generated NumPy/SciPy algebra cases; `tests/linalg_contract.cjs`:55 API/UMD/error checks
- `reports/worker-tests.log`:15 Worker/client tests, including actual Node numerical completion/cancellation/supersession and browser loading in VM
- `oracle/fixture-qa.json`:697 stored arrays,34 dense observation checks,58 dense RD maps,24 joint invariant checks
- `oracle/evaluation-qa.json`:58 Python matching comparisons and500 exhaustive Hungarian-matching checks
- `reports/held-grid-js-output.json`: actual fresh JavaScript full-stage held-input result
- `reports/resource-benchmark.json`: explicit Node environment and all measured workload records

## Retained adverse outcomes

The held finite-grid mechanism gives **4 hits, 3 false detections and 1 miss**, with a cap on one angle branch. This differs from the original continuously refined Python example's4/1/1 and must never be relabelled as that result.

Fresh cases retain same-CFO cross-angle duplicates (2 hits,2 false); q14 inside CP but outside L with a miss; out-of-search CFO with a miss; an alias-edge example with2 false and a cap; a Pmax1 example with a miss and cap; and all-one symbols with a flat unidentifiable CFO profile. Endpoints±80° are included and flagged. Noise-only and zero-Y default MDL0 runs do not calibrate Pfa.

The literal source alias rule can choose the wrong zone near an edge. Fractional delay is not snapped into the finite-tap model. Near-rank-deficient covariance can make MDL log scores sensitive to roundoff eigenvalues; the result flags this and does not replace the source formula with an undocumented floor.

The prior reduced96-trial Python study had96 reference hits and198 false detections. That historical result remains unfavorable and is not replaced by these new cases. No source curves, original-size complete OMP, calibrated Pfa, communications BER, field data or universal ICI advantage is established.

## Resource envelope

Maximum exposed workload:7 angle branches ×4 OMP iterations ×113 CFO points =3164 candidate records. Full exports cap at3,000,000 numeric scalars; dimensions and grids are validated before allocation. Worker preflight is4 MiB and200,000 structural nodes, with an explicit note that transport cloning happens before worker preflight. Input components must be finite and bounded; shared raw storage is rejected. Wall-clock cap is120 seconds maximum, configurable downward. Cancel/time-cap does not return a misleading completed estimate.

Measured Node cloud executor: held case three trials ~2.58–2.78 seconds, maximum forced7-angle/4-OMP QAM-noise workload ~10.59 seconds. That maximum workload emitted all3164 records and1.81 million numeric scalars (~14.5 MB Float64 payload); all7 branches retained their caps. Maximum observed checkpoint gap ~215 ms. These are observations, not browser deadlines or peak-memory guarantees. RSS snapshots include the whole Node process. Three repetitions do not establish meaningful p95 latency.

## Attribution and packaging

The complex Hermitian eigensolver is adapted from the reviewed nearfield MUSIC numerical helper, not its UI. Its source SHA and exact changes are in `tests/LINALG.md` and `LINALG-PROVENANCE.json`. QR/SVD and this source-derived receiver are independently authored here. No private source PDF/text/screenshots are included.

`SOURCE-FREEZE.json` pins runtime files and upstream references. `ARTIFACT-MANIFEST.json` pins the deliverable. No main/work branch or remote was changed.
