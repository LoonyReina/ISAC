import fs from 'node:fs';
import * as c from '/workspace/shared/recovery/public-baseline/labs/pilot-pattern/runtime/core.mjs';
import * as p from '/workspace/shared/recovery/public-baseline/labs/pilot-pattern/runtime/processing.mjs';
const gain=[1,0,.75*Math.cos(.4),.75*Math.sin(.4),.55*Math.cos(-.7),.55*Math.sin(-.7),.4*Math.cos(1.1),.4*Math.sin(1.1)];
const scenes={four:{delays_samples:[3,20,36,72],dopplers_hz:[0,-400,400,800],gains:gain},close:{delays_samples:[20,21,36,72],dopplers_hz:[0,75,400,800],gains:gain},beyond:{delays_samples:[3,20,36,93],dopplers_hz:[0,-400,400,800],gains:gain},continuous:{delays_samples:[3,20,36,72],dopplers_hz:[0,-400,400,800],gains:gain}};
let out={scenes,patterns:{},seed:20261018,noise_seed:70000000};
for(const pattern of ['A','D']){const g=c.grid({N:96,Ncp:12,S:6,J:1,delta_f:15000,offsets:Array.from({length:24},(_,i)=>pattern==='A'?0:i%6)}),tx=await c.transmit(g,20261018);let q={grid:c.gridSpec(g),x:tx.x,pilots:tx.pilots,frequencies:tx.frequencies,ledger:tx.ledger,clean:{},oracles:{},aliases:p.aliases(g)};
for(const [name,s]of Object.entries(scenes)){q.clean[name]=(await c.observe(g,tx,s,name==='continuous'?'continuous-doppler':'source-low-doppler',0,0)).clean;}
const y=await c.observe(g,tx,scenes.four,'source-low-doppler',.7,70000000);q.oracle_y=y.y;
for(const ell of pattern==='A'?[5]:[5,0]){const input={grid:c.gridSpec(g),y:y.y,pilots:tx.pilots},r=await c.recover(input,ell),ax=p.axes(g),Z=await p.directGrid(r.H,g,ax.delay_samples,ax.doppler_hz);q.oracles[ell]={H:r.H,Z,candidates:p.peakCandidates(p.powers(Z,1).raw_power,ax.delay_samples,ax.doppler_hz)};}
out.patterns[pattern]=q;}
fs.writeFileSync(new URL('fixtures.json',import.meta.url),JSON.stringify(out,(_,v)=>ArrayBuffer.isView(v)?Array.from(v):v));
