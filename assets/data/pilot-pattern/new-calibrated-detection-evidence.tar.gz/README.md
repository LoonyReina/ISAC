# Recomputed pilot detection package

This source-free package contains a NEW replay after workspace reset. Read REPORT.md and RECOVERY-REPLAY.md. It does not claim original archive identity or restoration of original raw trial bytes.

Existing outcome checks:

    OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 python recovery_audit.py --results . --baseline ../public-baseline
    OPENBLAS_NUM_THREADS=1 python summarize.py
    python package_results.py

The baseline option is needed for the three historical source hash checks; supply a relocated unchanged baseline if this package is extracted elsewhere. Raw receiver/map replay itself uses retained fixtures and does not need the baseline. fixtures.mjs retains original absolute imports for frozen identity; fixtures-recovery-runner.mjs points to the recovered unchanged baseline.

Full new rerun, preferably in a copied directory to preserve this run:

    OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 python study.py pilot
    OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 python study.py main
    OPENBLAS_NUM_THREADS=1 python summarize.py

No freeze.py is included in this run: do not rewrite historical FREEZE. Current dependency versions are in PILOT.json and HISTORICAL-COMPARISON.json. Noise PCG64 seeds, fixed raw waveform/clean arrays and all scalar records permit reconstruction without storing every dense map. Exact old generated output rows were lost; current rows are newly computed.

lesson-data.json contains full offline summary and paired comparisons plus threshold binding inputs for later live integration. Source-fixed regression and browser acceptance for that integration remain separate gates.

New independent checks: run independent-review.py, then independent-js-review.mjs with one CPU/BLAS thread. The first creates a19MB regenerable independent-replay-input.json interchange file omitted from the distributed archive; its expected hash is retained in INDEPENDENT-REVIEW.json. Reviewer source copies are in reviewer-runtime/.
