"""RECREATED audit, not byte-identical old reviewer harness; no main experiment execution.
Default checks frozen identities only. --results DIR audits a separately regenerated run.
Numerical row replay uses the author implementation; not an independent third algorithm.
"""
import argparse,collections,gzip,hashlib,json,math,pathlib,sys
R=pathlib.Path(__file__).resolve().parent
SHA='4fd44bb22ac031b00e2e0c8853eb10740b99e3c77d8a8ffe5245fc4cb9ae1087'
SOURCES={'labs/pilot-pattern/runtime/core.mjs':'53591126e91fe7f1c838bc7cd58e57a1a50035de9b5a811206d3ce3c47c1c87f','labs/pilot-pattern/runtime/processing.mjs':'48427712f64f00de71e5c3e44af9557ee577343159b50b47179a22c4e10fc7e7','assets/data/pilot-pattern/CONTRACT.md':'5f4d8b73aecf1856adfd973f356b5d4243e911ad881961c6a015c2cc715ba66c'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
p=argparse.ArgumentParser();p.add_argument('--results',type=pathlib.Path);p.add_argument('--baseline',type=pathlib.Path,default=R.parent/'public-baseline');a=p.parse_args()
assert sha(R/'FREEZE.json')==SHA
freeze=json.loads((R/'FREEZE.json').read_text())
for name,h in freeze['hashes'].items():assert sha(R/name)==h,(name,sha(R/name),h)
for name,h in SOURCES.items():assert sha(a.baseline/name)==h
report=dict(status='frozen_source_identity_recovered',freeze_sha256=SHA,frozen_files=freeze['hashes'],source_hashes=SOURCES,main_run_performed=False,results_audited=False,audit_identity='recreated after reset; not byte-identical historical reviewer harness')
if a.results:
 import numpy as np
 from scipy.stats import beta
 D=a.results.resolve();rows=[json.loads(s)for s in gzip.open(D/'records.jsonl.gz','rt')];th=json.loads((D/'THRESHOLDS.json').read_text());summary=json.loads((D/'SUMMARY.json').read_text())
 assert len(rows)==18816
 expected={'cal':2048,'hold':2048,'four':1024,'close':1024,'beyond':64,'continuous':64};bases={'cal':20000000,'hold':30000000,'four':40000000,'close':50000000,'beyond':60000000,'continuous':61000000}
 counts=collections.Counter();keys=set();cal=collections.defaultdict(list);seeds=collections.defaultdict(set);hold=collections.Counter()
 for x in rows:
  split=x['split'];cfg=x['config'];i=x['index'];assert split in expected and cfg in ['A5','D5','D0'];assert 0<=i<expected[split]
  key=(split,cfg,i);assert key not in keys;keys.add(key);counts[(split,cfg)]+=1
  assert x['seed']==bases[split]+i;seeds[split].add(x['seed']);assert x['status']=='ok' and math.isfinite(x['score']) and x['score']>=0 and math.isfinite(x['variance']) and x['variance']>0
  if split=='cal':cal[cfg].append(x['score']);assert 'methods'not in x;continue
  assert set(x['methods'])=={'heuristic','0.01','0.05'}
  for name,m in x['methods'].items():
   threshold=.05*x['score']if name=='heuristic'else th['values'][cfg][name];cs=m['candidates'];assert m['detected']==(x['score']>threshold)==bool(cs);assert len(cs)<=8
   assert all(math.isfinite(v)and v>threshold and 0<=f<121 and 0<=d<192 and int(f)==f and int(d)==d for v,f,d in cs)
   assert m['targets']==(0 if split=='hold'else 4);assert m['matched']+m['misses']==m['targets'];assert m['matched']+m['spurious']==len(cs);assert len(m['assignments'])==m['matched']
   assert len({v[0]for v in m['assignments']})==m['matched']==len({v[1]for v in m['assignments']})
   assert all(0<=ci<len(cs)and 0<=ti<m['targets']and 0<=de<=2 and 0<=fe<=150 for ci,ti,de,fe in m['assignments'])
   if split=='hold':hold[(cfg,name)]+=m['detected']
 for split,n in expected.items():
  for cfg in ['A5','D5','D0']:assert counts[(split,cfg)]==n
 for s,ss in seeds.items():
  for t,tt in seeds.items():
   if s!=t:assert not ss&tt
 for alpha in [.01,.05]:
  name=str(alpha);k=math.ceil(2049*(1-alpha));assert th['ranks'][name]==k;params=[2049-k,k];assert th['calibration_pfa_beta'][name]['parameters']==params
  assert np.allclose(th['calibration_pfa_beta'][name]['interval95'],beta.ppf([.025,.975],*params),rtol=1e-12,atol=1e-14)
  for cfg,scores in cal.items():assert sorted(scores)[k-1]==th['values'][cfg][name]
 for row in summary['summary']:
  if row['split']!='hold':continue
  k=hold[(row['config'],row['method'])];n=2048;ci=[float(beta.ppf(.025,k,n-k+1))if k else 0.,float(beta.ppf(.975,k+1,n-k))if k<n else 1.]
  assert row['scene_detections']==k and row['frames']==n;assert np.allclose(row['scene_binomial_ci95'],ci,rtol=1e-12,atol=1e-14)
 # Deterministic replay deliberately uses author functions, separate from prior JS-vs-NumPy gate.
 sys.path.insert(0,str(R));import study as author
 replay=[]
 for x in rows:
  if (x['split'],x['index'])not in [('hold',777),('four',600),('close',13),('continuous',12),('beyond',37)]:continue
  seed,var,ys=author.frame(x['split'],x['index'],x['scene'],x['snr_db']);power=author.power(ys[x['config'][0]],x['config'][0],int(x['config'][1]),var);assert abs(float(power.max())-x['score'])<1e-10
  for name,m in x['methods'].items():
   threshold=.05*x['score']if name=='heuristic'else th['values'][x['config']][name];cs=author.candidates(power,threshold);assert np.allclose(cs,m['candidates'],rtol=1e-12,atol=1e-10);ev=author.match(cs,x['scene']);assert all(ev[k]==m[k]for k in ev)
  replay.append({'split':x['split'],'index':x['index'],'config':x['config'],'score':x['score']})
 assert len(replay)==15
 report.update(status='regenerated_results_audit_pass',results_audited=True,result_directory=str(D),rows_audited=len(rows),replay=replay,limitations=['Author-function replay is not independent numerical implementation','No claim to restored historical raw trial file','No arbitrary-clutter CFAR or guaranteed conditional Pfa'])
(D if a.results else R).joinpath('RECOVERY-AUDIT.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
