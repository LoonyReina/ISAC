"""Independent NumPy raw-IQ receiver; project-owned calibrated detection extension."""
import os
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
import numpy as np, scipy, json,gzip,pathlib,time,sys,hashlib,resource
from scipy.ndimage import maximum_filter
from scipy.stats import beta
ROOT=pathlib.Path(__file__).resolve().parent
FIX=json.loads((ROOT/'fixtures.json').read_text()); DS=np.arange(192)/2; FS=np.arange(121)*25-1500
N=96;CP=12;S=6;M=24;K=16;B=108;T=B/(N*15000);COUNT=2700
CONFIG=[('A',5),('D',5),('D',0)]
def z(a):a=np.asarray(a);return a[::2]+1j*a[1::2]
def serial(o):
 if isinstance(o,np.ndarray):return o.tolist()
 if isinstance(o,np.generic):return o.item()
 raise TypeError(type(o))
def write(name,obj): (ROOT/name).write_text(json.dumps(obj,default=serial,indent=2))
P={}
for pat,q in FIX['patterns'].items():
 F=np.array(q['grid']['offsets']); tones=6*np.arange(K)[None,:]+F[:,None]; pilots=z(q['pilots']).reshape(M,K)
 P[pat]=dict(F=F,tones=tones,pilots=pilots,clean={s:z(y) for s,y in q['clean'].items()},E=np.exp(2j*np.pi*tones[:,:,None]*DS/N),V=np.exp(-2j*np.pi*FS[:,None]*np.arange(M)*T))
def recover(y,pat,ell):
 q=P[pat];L=N-ell*K;r=np.arange(L);idx=(1+np.arange(M)[:,None])*B+CP+ell*K+r
 return np.fft.fft(y[idx]*np.exp(-2j*np.pi*q['F'][:,None]*(ell*K+r)/N),axis=1)[:,(S-ell)*np.arange(K)]/(L*q['pilots'])
def mapraw(H,pat):q=P[pat];return q['V']@np.einsum('im,imd->id',H,q['E'])
def power(y,pat,ell,var):
 H=recover(y,pat,ell);Z=mapraw(H,pat);v=var*np.sum(1/((N-ell*K)*abs(P[pat]['pilots'])**2));return abs(Z)**2/v

def candidates(p,threshold):
 mx=float(p.max());eps=1e-12*mx
 if mx<=0:return []
 idx=np.argwhere((p>=maximum_filter(p,size=3,mode='constant',cval=-np.inf)-eps)&(p>threshold))
 order=sorted([(float(p[f,d]),int(f),int(d)) for f,d in idx],key=lambda x:(-x[0],x[1],x[2]));group=[];i=0
 while i<len(order):
  j=i+1
  while j<len(order) and order[i][0]-order[j][0]<=eps:j+=1
  group.extend(sorted(order[i:j],key=lambda x:(x[1],x[2])));i=j
 chosen=[]
 for v,f,d in group:
  if any(abs(d-dd)<=4 and abs(f-ff)<=6 for _,ff,dd in chosen):continue
  chosen.append([v,f,d])
  if len(chosen)==8:break
 return chosen

def match(c,scene):
 s=FIX['scenes'][scene] if scene!='H0' else dict(delays_samples=[],dopplers_hz=[]);pairs=[]
 for ci,(_,f,d) in enumerate(c):
  for ti,(td,tf) in enumerate(zip(s['delays_samples'],s['dopplers_hz'])):
   de=abs(DS[d]-td);fe=abs(FS[f]-tf)
   if de<=2 and fe<=150:pairs.append(((de/2)**2+(fe/150)**2,ci,ti,float(de),float(fe)))
 usedc=set();usedt=set();a=[]
 for _,ci,ti,de,fe in sorted(pairs):
  if ci not in usedc and ti not in usedt:usedc.add(ci);usedt.add(ti);a.append([ci,ti,de,fe])
 return dict(targets=len(s['delays_samples']),matched=len(a),misses=len(s['delays_samples'])-len(a),spurious=len(c)-len(a),assignments=a)
def noise(seed):
 rng=np.random.Generator(np.random.PCG64(seed));return (rng.standard_normal(COUNT)+1j*rng.standard_normal(COUNT))/np.sqrt(2)
def frame(split,index,scene='H0',snr=None):
 offsets={'pilot':10000000,'cal':20000000,'hold':30000000,'four':40000000,'close':50000000,'beyond':60000000,'continuous':61000000}
 seed=offsets[split]+index;w=noise(seed)
 var=1. if scene=='H0' else float(np.mean(abs(P['D']['clean'][scene][B:])**2)/10**(snr/10))
 ys={p:(np.zeros(COUNT) if scene=='H0' else P[p]['clean'][scene])+np.sqrt(var)*w for p in P}
 return seed,var,ys

def pilot():
 errors={}
 for pat,ell in CONFIG:
  q=FIX['patterns'][pat];y=z(q['oracle_y']);h=recover(y,pat,ell);zz=mapraw(h,pat);ref=q['oracles'][str(ell)];eh=np.max(abs(h.ravel()-z(ref['H'])));ez=np.max(abs(zz.ravel()-z(ref['Z'])));assert eh<1e-10 and ez<1e-9
  for f,d in [(0,0),(50,77),(120,191)]:assert abs(zz[f,d]-np.sum(h*np.exp(2j*np.pi*P[pat]['tones']*DS[d]/N-2j*np.pi*FS[f]*np.arange(M)[:,None]*T)))<1e-9
  cc=candidates(abs(zz)**2,.05*np.max(abs(zz)**2));expected=ref['candidates'];assert [(DS[d],FS[f])for _,f,d in cc]==[(c['delay_samples'],c['doppler_hz'])for c in expected]
  before=power(y,pat,ell,.7);original=FIX['scenes']['four'];FIX['scenes']['four']={'malicious_truth':'unusable'};after=power(y,pat,ell,.7);FIX['scenes']['four']=original;assert np.array_equal(before,after)
  # Independent physical synthesis from known frequency cells plus CP.
  freq=z(q['frequencies']).reshape(25,96);x=np.fft.ifft(freq,axis=1)*96;x=np.concatenate([x[:,-12:],x],axis=1).ravel();assert np.max(abs(x-z(q['x'])))<1e-11;assert abs(np.sum(abs(x)**2)-COUNT)<1e-8
  errors[f'{pat}{ell}']={'H_max_absolute':float(eh),'map_max_absolute':float(ez),'direct_sum_cells':3,'candidate_parity':True,'no_truth_mutation':True,'physical_cp_energy':float(np.sum(abs(x)**2))}
 t=time.perf_counter()
 for i in range(16):
  _,v,ys=frame('pilot',i,'four',0)
  for pat,ell in CONFIG:
   pp=power(ys[pat],pat,ell,v);candidates(pp,5);match(candidates(pp,.05*pp.max()),'four')
 elapsed=time.perf_counter()-t
 write('PILOT.json',dict(frames=16,three_configs=True,seconds=elapsed,estimated_main_seconds=elapsed/16*(4096+2048+128),peak_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,checks=errors,numpy=np.__version__,scipy=scipy.__version__,rng='NumPy PCG64 proper complex CN(0,1); disjoint integer seeds',status='pass'))
 print((ROOT/'PILOT.json').read_text())

def main():
 assert (ROOT/'FREEZE.json').exists();records=[];cal={f'{p}{e}':[] for p,e in CONFIG};thresholds={};start=time.perf_counter()
 with gzip.open(ROOT/'records.jsonl.gz','wt') as f:
  for split,count in [('cal',2048),('hold',2048),('four',1024),('close',1024),('beyond',64),('continuous',64)]:
   for i in range(count):
    scene='H0' if split in ['cal','hold'] else split;snr=None if scene=='H0' else ([-5,0,5,10][i//256] if split in ['four','close'] else 5)
    seed,var,ys=frame(split,i,scene,snr)
    for pat,ell in CONFIG:
     key=f'{pat}{ell}';p=power(ys[pat],pat,ell,var);score=float(p.max());row=dict(split=split,index=i,seed=seed,scene=scene,snr_db=snr,config=key,variance=var,score=score,status='ok')
     if split=='cal':cal[key].append(score)
     else:
      methods={'heuristic':.05*score,**thresholds[key]};row['methods']={}
      for name,th in methods.items():
       cs=candidates(p,th);row['methods'][name]=dict(detected=score>th,candidates=cs,**match(cs,scene))
     f.write(json.dumps(row,default=serial,separators=(',',':'))+'\n')
    if i%256==0:print(split,i,round(time.perf_counter()-start,1),flush=True)
   if split=='cal':
    for key,scores in cal.items():
     thresholds[key]={}
     for alpha in [.01,.05]:
      k=int(np.ceil((2048+1)*(1-alpha)));thresholds[key][str(alpha)]=sorted(scores)[k-1]
    write('THRESHOLDS.json',dict(values=thresholds,n=2048,convention='ascending kth score; strict score > threshold',ranks={str(a):int(np.ceil(2049*(1-a)))for a in [.01,.05]},calibration_pfa_beta={str(a):dict(parameters=[2049-int(np.ceil(2049*(1-a))),int(np.ceil(2049*(1-a)))],interval95=beta.ppf([.025,.975],2049-int(np.ceil(2049*(1-a))),int(np.ceil(2049*(1-a)))))for a in [.01,.05]}))
 write('RUN.json',dict(seconds=time.perf_counter()-start,rows=3*(4096+2048+128),statuses={'ok':3*(4096+2048+128)},peak_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss))
if __name__=='__main__':pilot() if sys.argv[1]=='pilot' else main()
