# Recomputed pilot detection evidence

New frozen-protocol replay after reset; not restoration of the original archive. Author numerical gates and NEW independent review pass; see INDEPENDENT-REVIEW.json/.md.

All18,816 configuration-frame rows retained:12,288 H0 calibration/holdout,6144 mainH1 and384 diagnostic rows. All statuses ok. New runtime38.259s, peakRSS92,128KiB. Python3.12.14, NumPy2.3.5, SciPy1.17.0; one BLAS/OpenMP thread. Original frozen source+fixture identities exactly recovered.

All six regenerated thresholds exactly equal the historical printed values. All156 retained scalar count comparisons also match (six H0 counts and30H1 rows×five fields). Full new records, summary, raw replay fixture, seeds and exact threshold metadata are retained. No claim that the compressed archive has the original hash.

Holdout alpha.01: A5=20/2048, D5=29/2048, D0=18/2048. Alpha.05:104,99,105/2048 respectively. All exact95%binomial intervals contain nominal. D5's measured1.416% exceeds nominal1%; retain that observation. Calibration Beta intervals remain distinct, and no conditional upper-bound guarantee is claimed.

All mainH1 frames trigger scene detection, but target recovery is not saturated. Four-path5dB/alpha.05: A5 matches512/1024 with1536spurious; D5 matches1024/1024 with1024spurious; D0 matches768/1024 with1280spurious. Close-pair-5dB reverses D5/D0 matches:639 vs821, with194 vs1159spurious. Calibration cannot remove aliases, sidelobes or infer model order.

See RECOVERY-REPLAY.md for scientific limitations, HISTORICAL-COMPARISON.json for every retained comparison, SUMMARY.json for all denominators/intervals/paired differences, RECOVERY-AUDIT.json for newly executed audit scope, and lesson-data.json/LIVE-EXTENSION-CONTRACT.md for downstream integration. No UI or publication action performed here.

New independent review additionally checked all99summary groups,192paired comparisons and18raw replay rows across every split without importing study.py. Independent direct finite-sum DFT, CP synthesis and integer-delay propagation cover both Doppler conventions; maximum score error1.73e-11. Unchanged JS whole-map replay error8.56e-12,72truth-boundary checks and teaching absolute-candidate parity pass. This extends the original limited propagation validation; it remains sampled numerical replay rather than a second full main run.
