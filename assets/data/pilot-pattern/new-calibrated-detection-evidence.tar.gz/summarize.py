import os
os.environ['OPENBLAS_NUM_THREADS']='1'
import json,gzip,pathlib,collections,numpy as np
from scipy.stats import beta
R=pathlib.Path(__file__).resolve().parent
rows=[json.loads(l)for l in gzip.open(R/'records.jsonl.gz','rt')]
assert len(rows)==18816
seen=set();groups=collections.defaultdict(list);cal=collections.defaultdict(list)
for r in rows:
 key=(r['split'],r['index'],r['config']);assert key not in seen;seen.add(key);assert r['status']=='ok'
 if r['split']=='cal':cal[r['config']].append(r['score'])
 else:groups[(r['split'],r['snr_db'],r['config'])].append(r)
th=json.loads((R/'THRESHOLDS.json').read_text());summ=[]
def interval(k,n):return [float(beta.ppf(.025,k,n-k+1)) if k else 0.,float(beta.ppf(.975,k+1,n-k)) if k<n else 1.]
for config,s in cal.items():
 for a in ['0.01','0.05']:assert sorted(s)[th['ranks'][a]-1]==th['values'][config][a]
for (split,snr,c),rr in groups.items():
 for method in ['0.01','0.05','heuristic']:
  m=[r['methods'][method]for r in rr];k=sum(x['detected']for x in m);targets=sum(x['targets']for x in m);matches=sum(x['matched']for x in m);spurious=sum(x['spurious']for x in m);assign=[a for x in m for a in x['assignments']]
  summ.append(dict(split=split,snr_db=snr,config=c,method=method,frames=len(rr),scene_detections=k,scene_detection_rate=k/len(rr),scene_binomial_ci95=interval(k,len(rr)),targets=targets,matched=matches,misses=targets-matches,spurious=spurious,candidates=matches+spurious,all_targets_frames=sum(x['matched']==x['targets']for x in m),conditional_delay_mae=float(np.mean([a[2]for a in assign]))if assign else None,conditional_doppler_mae=float(np.mean([a[3]for a in assign]))if assign else None))
paired=[]
for split in ['four','close']:
 for snr in [-5,0,5,10]:
  for a,b in [('D5','A5'),('D5','D0')]:
   aa=sorted(groups[(split,snr,a)],key=lambda r:r['index']);bb=sorted(groups[(split,snr,b)],key=lambda r:r['index']);assert [r['seed']for r in aa]==[r['seed']for r in bb]
   for method in ['0.01','0.05','heuristic']:
    for metric in ['detected','matched','misses','spurious']:
     d=np.array([float(x['methods'][method][metric])-float(y['methods'][method][metric])for x,y in zip(aa,bb)]);mean=float(d.mean());err=float(1.96*d.std(ddof=1)/np.sqrt(len(d)));paired.append(dict(scene=split,snr_db=snr,a=a,b=b,method=method,metric=metric,n=len(d),mean_difference=mean,approximate_ci95=[mean-err,mean+err]))
seedsets={s:{r['seed']for r in rows if r['split']==s}for s in {r['split']for r in rows}}
for s,ss in seedsets.items():
 for t,tt in seedsets.items():
  if s!=t:assert not ss&tt
(R/'SUMMARY.json').write_text(json.dumps(dict(all_rows=len(rows),statuses={'ok':len(rows)},threshold_reconstruction=True,split_disjointness=True,summary=summ,paired_differences=paired),indent=2))
print(json.dumps([x for x in summ if x['split']=='hold'],indent=2))
