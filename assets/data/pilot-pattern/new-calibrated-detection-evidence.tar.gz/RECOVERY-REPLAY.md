# New frozen-protocol replay after cloud reset

This directory is a NEW recomputation on 2026-10-18 after the original workspace was lost. It is not restoration of the original trial-record file or its archive. The recovered original study.py, fixtures.mjs, fixtures.json and FREEZE.json have verified exact frozen identities; public-baseline core/processing/CONTRACT hashes match the original source.

Historical FREEZE SHA2564fd44bb22ac031b00e2e0c8853eb10740b99e3c77d8a8ffe5245fc4cb9ae1087 is retained unchanged. The original archive SHA25696b790022308dddb819a6a9a141a9608482f55287293ea4d431e06e4bd1cb026 is historical provenance only. Do not apply it to a newly packaged artifact.

The frozen protocol is unchanged: N96/CP12/S6/M24/J1, three configurations A5/D5/D0, fixed waveform seed20261018, independent H0cal2048+hold2048 per configuration, two scenes×four SNRs×256 H1frames and two64frame mismatch diagnostics. One process with BLAS/OpenMP threads1. All18,816 configuration-frame rows must remain. Timing, versions, all threshold/maxima/candidate/assignment outcomes and separate audit results are newly measured here.

Source: https://arxiv.org/pdf/2401.09643v3. This is a project-owned independent-H0 calibrated detection extension of the accepted interpreted raw-IQ receiver, not original Fig10/Fig23 reproduction or arbitrary-clutter CFAR. Source PDF is not included. INHERITED-CONTRACT.md preserves source interpretation discrepancies and exact signal conventions.

Known variance is used; score=max coherent raw map power/[sigma_t² sum1/(L|pilot|²)]. H1 SNR uses D's clean full sensing-block received power excluding preceding block, with identical noise variance for A/D. D0/D5 use identical y; A/D use different waveforms with common standardized noise. Physical CP-inclusive whole-frame transmit normalization is retained.

Thresholds use ascending rank ceil((n+1)(1-alpha)), strict >, alpha.01/.05. Calibration Beta uncertainty and holdout exact binomial intervals are distinct; neither guarantees conditional Pfa below nominal. Absolute-threshold candidate extraction never uses the test peak as threshold. Fixed numerical tie handling, suppression and cap8 remain. The old heuristic comparison has strict>5% maximum versus historical JS's >= exact-boundary rule; fixture parity is tested, universal boundary equivalence is not claimed.

All main H1 outcomes, including misses and spurious candidates, are retained. Scene detection is not target recovery or model-order estimation. Exact aliases remain. ell0's guard12 is exceeded in main scenes; it is a deliberate mismatched H1 comparison. Beyond-guard and continuous-Doppler panels are diagnostic, not restored model guarantees. Conditional matched errors must not hide missed-target denominators; H0 all_targets_frames is vacuous.

The recovered original independent NumPy-vs-unchanged-JS comparison covers receiver/map and CP synthesis, not an independently reimplemented clean propagation generator. Recreated review harnesses must identify themselves; author-function replay is not a third independent implementation. New independent acceptance is recorded separately from historical acceptance.
