"""New independent reviewer implementation. Does not import study.py or recovery_audit.py."""
import os
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
import json,gzip,pathlib,hashlib,collections,math,subprocess
import numpy as np
from scipy.stats import beta
R=pathlib.Path(__file__).resolve().parent; F=json.loads((R/'fixtures.json').read_text()); T=json.loads((R/'THRESHOLDS.json').read_text()); S=json.loads((R/'SUMMARY.json').read_text()); freeze=json.loads((R/'FREEZE.json').read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(R/'FREEZE.json')=='4fd44bb22ac031b00e2e0c8853eb10740b99e3c77d8a8ffe5245fc4cb9ae1087'
for name,h in freeze['hashes'].items():assert sha(R/name)==h==sha(R.parent/'pilot-detection-reference'/name)
def z(v):return np.array(v[::2])+1j*np.array(v[1::2])
def flat(v):return np.column_stack([v.real.ravel(),v.imag.ravel()]).ravel().tolist()
def close(a,b):assert np.allclose(a,b,rtol=2e-11,atol=2e-9),(np.max(abs(np.array(a)-np.array(b))))
D=np.arange(192)/2; V=np.arange(121)*25-1500; dt=1/1440000; block=108; tm=block*dt
# Independent CP synthesis and integer-delay propagation, including both Doppler conventions.
clean={};errors={}
for pat,q in F['patterns'].items():
 freq=z(q['frequencies']).reshape(25,96); wave=(np.exp(2j*np.pi*np.outer(np.arange(96),np.arange(96))/96)@freq.T).T
 x=np.concatenate((wave[:,-12:],wave),axis=1).ravel();close(x,z(q['x']));close(np.vdot(x,x).real,2700)
 clean[pat]={};n=np.arange(2700)
 for scene,s in F['scenes'].items():
  y=np.zeros(2700,complex)
  for delay,fd,gain in zip(s['delays_samples'],s['dopplers_hz'],z(s['gains'])):
   shifted=np.zeros(2700,complex);shifted[delay:]=x[:2700-delay]
   times=(n-108)*dt if scene=='continuous' else (n//108-1)*tm
   y+=gain*shifted*np.exp(2j*np.pi*fd*times)
  close(y,z(q['clean'][scene]));clean[pat][scene]=y
 offsets=q['grid']['offsets']; witnesses=[[a,b]for a in range(1,6)for b in range(6)if all((i*b-(o-offsets[0])*a)%6==0 for i,o in enumerate(offsets))]
 assert witnesses==q['aliases']['witnesses']
 for a,b in witnesses:
  phase=np.exp(2j*np.pi*(np.array(offsets)[:,None]+6*np.arange(16))*a/6-2j*np.pi*np.arange(24)[:,None]*b/6);close(phase,np.ones((24,16)))
# Direct finite sum receiver: no FFT, no study functions.
def receiver(y,pat,ell):
 q=F['patterns'][pat];pil=z(q['pilots']).reshape(24,16);o=np.array(q['grid']['offsets']);L=96-16*ell;r=np.arange(L);h=np.empty((24,16),complex)
 for i in range(24):
  for m in range(16):h[i,m]=np.sum(y[(i+1)*108+12+16*ell+r]*np.exp(-2j*np.pi*(o[i]*(16*ell+r)/96+m*r/16)))/(L*pil[i,m])
 delay=np.empty((24,192),complex)
 for i in range(24):delay[i]=h[i]@np.exp(2j*np.pi*np.outer(6*np.arange(16)+o[i],D)/96)
 zz=np.exp(-2j*np.pi*np.outer(V,np.arange(24))*tm)@delay
 return h,zz
# Independent neighborhood loop and deterministic selection.
def candidates(p,t):
 eps=float(p.max())*1e-12;pool=[]
 for f,d in np.argwhere(p>t):
  if p[f,d]>=p[max(0,f-1):min(121,f+2),max(0,d-1):min(192,d+2)].max()-eps:pool.append((float(p[f,d]),int(f),int(d)))
 pool.sort(key=lambda x:(-x[0],x[1],x[2]));ordered=[]
 while pool:
  j=1
  while j<len(pool)and pool[0][0]-pool[j][0]<=eps:j+=1
  ordered+=sorted(pool[:j],key=lambda x:(x[1],x[2]));pool=pool[j:]
 out=[]
 for c in ordered:
  if all(abs(c[1]-a[1])>6 or abs(c[2]-a[2])>4 for a in out):out.append(list(c))
  if len(out)==8:break
 return out
def assignment(cs,scene):
 truth=F['scenes'].get(scene,{'delays_samples':[],'dopplers_hz':[]});pairs=[]
 for ci,(_,f,d) in enumerate(cs):
  for ti,(td,tf) in enumerate(zip(truth['delays_samples'],truth['dopplers_hz'])):
   de=abs(D[d]-td);fe=abs(V[f]-tf)
   if de<=2 and fe<=150:pairs.append(((de/2)**2+(fe/150)**2,ci,ti,float(de),float(fe)))
 out=[]
 for _,ci,ti,de,fe in sorted(pairs):
  if all(ci!=x[0]and ti!=x[1]for x in out):out.append([ci,ti,de,fe])
 return out,len(truth['delays_samples'])
rows=[json.loads(l)for l in gzip.open(R/'records.jsonl.gz','rt')];assert len(rows)==18816;seen=set();groups=collections.defaultdict(list);cal=collections.defaultdict(list)
for row in rows:
 sp=row['split'];i=row['index'];cfg=row['config'];key=(sp,i,cfg);assert key not in seen;seen.add(key);assert cfg in ['A5','D5','D0'];spec=freeze['splits'][sp];assert 0<=i<spec['n'];assert row['seed']==spec['seed_base']+i;assert row['status']=='ok';scene='H0'if sp in ['hold','cal']else sp;snr=None if scene=='H0'else ([-5,0,5,10][i//256]if sp in ['four','close']else 5);assert row['scene']==scene and row['snr_db']==snr
 var=1 if scene=='H0'else float(np.mean(abs(clean['D'][scene][108:])**2)/10**(snr/10));close(var,row['variance']);assert math.isfinite(row['score'])and row['score']>=0
 if sp=='cal':assert 'methods'not in row;cal[cfg].append(row['score']);continue
 groups[(sp,snr,cfg)].append(row);assert set(row['methods'])=={'0.01','0.05','heuristic'}
 for name,m in row['methods'].items():
  t=.05*row['score']if name=='heuristic'else T['values'][cfg][name];cs=m['candidates'];assert m['detected']==(row['score']>t)==bool(cs);assert len(cs)<=8
  for j,(v,f,d)in enumerate(cs):
   assert math.isfinite(v)and t<v<=row['score']+1e-8 and isinstance(f,int)and isinstance(d,int)and 0<=f<121 and 0<=d<192
   assert all(abs(f-a[1])>6 or abs(d-a[2])>4 for a in cs[:j])
  aa,nt=assignment(cs,scene);assert aa==m['assignments'];assert m['targets']==nt and m['matched']==len(aa)and m['misses']==nt-len(aa)and m['spurious']==len(cs)-len(aa)
assert len(seen)==sum(v['n']for k,v in freeze['splits'].items()if k!='pilot')*3
for alpha in [.01,.05]:
 a=str(alpha);k=math.ceil(2049*(1-alpha));assert T['ranks'][a]==k;assert T['calibration_pfa_beta'][a]['parameters']==[2049-k,k];close(T['calibration_pfa_beta'][a]['interval95'],beta.ppf([.025,.975],2049-k,k))
 for c,v in cal.items():assert len(v)==2048 and sorted(v)[k-1]==T['values'][c][a]
for s in S['summary']:
 rr=groups[(s['split'],s['snr_db'],s['config'])];mm=[r['methods'][s['method']]for r in rr];n=len(mm);k=sum(m['detected']for m in mm);assert s['frames']==n and s['scene_detections']==k;assert s['scene_detection_rate']==k/n
 close(s['scene_binomial_ci95'],[beta.ppf(.025,k,n-k+1)if k else 0,beta.ppf(.975,k+1,n-k)if k<n else 1])
 for field in ['targets','matched','misses','spurious']:assert s[field]==sum(m[field]for m in mm)
 assert s['candidates']==sum(len(m['candidates'])for m in mm);assert s['all_targets_frames']==sum(m['matched']==m['targets']for m in mm)
 aa=[a for m in mm for a in m['assignments']]
 for key,j in [('conditional_delay_mae',2),('conditional_doppler_mae',3)]:
  if aa:close(s[key],sum(a[j]for a in aa)/len(aa))
  else:assert s[key]is None
assert len(S['summary'])==len(groups)*3
for p in S['paired_differences']:
 a=groups[(p['scene'],p['snr_db'],p['a'])];b=groups[(p['scene'],p['snr_db'],p['b'])];assert [r['seed']for r in a]==[r['seed']for r in b];delta=np.array([r['methods'][p['method']][p['metric']]-t['methods'][p['method']][p['metric']]for r,t in zip(a,b)],float);assert p['n']==len(delta);close(p['mean_difference'],delta.mean());err=1.96*delta.std(ddof=1)/len(delta)**.5;close(p['approximate_ci95'],[delta.mean()-err,delta.mean()+err])
# New selected raw replay includes each split and all configurations; no main rerun.
selected=[r for r in rows if (r['split'],r['index'])in [('cal',100),('hold',777),('four',600),('close',13),('beyond',37),('continuous',12)]];js=[];maxerr=0
for r in selected:
 pat=r['config'][0];ell=int(r['config'][1]);rng=np.random.Generator(np.random.PCG64(r['seed']));w=(rng.standard_normal(2700)+1j*rng.standard_normal(2700))/2**.5;y=(0 if r['scene']=='H0'else clean[pat][r['scene']])+np.sqrt(r['variance'])*w;h,zz=receiver(y,pat,ell);den=r['variance']*sum(1/((96-ell*16)*abs(z(F['patterns'][pat]['pilots']))**2));p=abs(zz)**2/den;close(p.max(),r['score']);maxerr=max(maxerr,abs(float(p.max())-r['score']))
 for name,m in r.get('methods',{}).items():
  t=.05*r['score']if name=='heuristic'else T['values'][r['config']][name];cc=candidates(p,t);assert [(c[1],c[2])for c in cc]==[(c[1],c[2])for c in m['candidates']];close(cc,m['candidates'])
 js.append(dict(config=r['config'],grid=F['patterns'][pat]['grid'],pilots=F['patterns'][pat]['pilots'],y=flat(y),H=flat(h),Z=flat(zz),variance=r['variance'],score=r['score'],methods=r.get('methods',{})))
(R/'independent-replay-input.json').write_text(json.dumps(js))
lesson=json.loads((R/'lesson-data.json').read_text());assert lesson['thresholds']==T and lesson['summary']==S['summary']and lesson['paired_differences']==S['paired_differences'];assert lesson['binding']['axes']=={'delay_samples':D.tolist(),'doppler_hz':V.tolist()};assert lesson['binding']['pilots']=={p:q['pilots']for p,q in F['patterns'].items()}
assert T==json.loads((R/'HISTORICAL-THRESHOLDS.json').read_text());hist=json.loads((R/'HISTORICAL-COMPARISON.json').read_text());assert len(hist['known_count_checks'])==156 and all(c['old']==c['new']for c in hist['known_count_checks'])
report=dict(status='independent_algebra_and_all_row_audit_pass',rows=len(rows),summary_groups=len(S['summary']),paired_comparisons=len(S['paired_differences']),small_replay_rows=len(selected),maximum_score_absolute_error=maxerr,independent_clean_propagation=True,independent_direct_DFT_receiver=True,independent_CP_synthesis=True,all_row_greedy_matching=True,all_summary_and_intervals=True,thresholds_historical_exact=True,known_historical_counts=156,main_rerun=False)
(R/'INDEPENDENT-REVIEW.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
