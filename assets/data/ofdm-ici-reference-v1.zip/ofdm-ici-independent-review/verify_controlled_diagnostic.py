"""Independent input-pair, output-replay, association, aggregate verification."""
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import runpy,sys,json,hashlib,time
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parent;REF=ROOT.parent/'ofdm-ici-reference';sys.dont_write_bytecode=True
ns=runpy.run_path(str(ROOT/'metrics_and_false_positives.py'))
r=ns['r'];oracle=ns['oracle'];path=REF/'results/controlled-cfo-comparison.json';data=json.loads(path.read_text());cfg=r.Config(**data['config']);checks=[]
started=time.perf_counter()
for row in data['trials']:
    x=r.qpsk(cfg,row['symbol_seed']);same=row['cases']['same_cfo'];diff=row['cases']['distinct_cfo'];ts=same['truth_evaluation_only'];td=diff['truth_evaluation_only']
    only=ts[0]==td[0] and all(ts[1][k]==td[1][k] for k in ts[1] if k!='epsilon') and abs(td[1]['epsilon']-ts[1]['epsilon']-2/cfg.rho)<1e-12
    ys,z=r.simulate(cfg,x,ts,1,row['noise_seed']);yd,z2=r.simulate(cfg,x,td,1,0,noise=z);mus=r.music(ys,cfg)
    checks.append({'name':'pair_inputs','fractional':row['fractional_delay_offset'],'seed':row['noise_seed'],'passed':bool(only and np.array_equal(z,z2) and np.max(abs(np.array(mus['angles'])-row['shared_observed_music_angles']))<1e-10 and row['same_slow_phase_max_abs_error']<1e-12)})
    for label,y in [('same_cfo',ys),('distinct_cfo',yd)]:
        case=row['cases'][label];out=r.receive(y,x,cfg,shared_music=mus);fft=r.fft_baseline(y,x,mus['angles'],cfg)
        old=case['receiver']['detections'];new=out['detections'];same_det=len(old)==len(new) and all(abs(a[k]-b[k])<1e-9 for a,b in zip(old,new) for k in ('delay_samples','epsilon','angle_deg','power'))
        baseline_same=len(fft['detections'])==len(case['fft_known_x']['detections']) and all(abs(a[k]-b[k])<1e-8 for a,b in zip(fft['detections'],case['fft_known_x']['detections']) for k in ('delay_samples','epsilon','angle_deg','power'))
        checkrow={'config':data['config'],'truth_evaluation_only':case['truth_evaluation_only'],'metrics':{'apes':case['apes'],'fft_known_x':case['fft_known_x']}}
        metric=oracle(checkrow,'apes') and oracle(checkrow,'fft_known_x')
        checks.append({'name':'end_to_end_replay_and_association','fractional':row['fractional_delay_offset'],'seed':row['noise_seed'],'condition':label,'passed':bool(same_det and baseline_same and metric and out['music']['angles']==row['shared_observed_music_angles'])})
for group in data['summary']:
    rows=[row for row in data['trials'] if row['fractional_delay_offset']==group['fractional_delay_offset']]
    for condition in ('same_cfo','distinct_cfo'):
        for method in ('apes','fft_known_x'):
            mets=[row['cases'][condition][method] for row in rows]
            want={'matched_targets':sum(z['matched_count'] for z in mets),'targets':sum(z['target_count'] for z in mets),'false_detections':sum(z['false_detections'] for z in mets),'reference_detections':sum('1' in z['matches'] for z in mets)}
            checks.append({'name':'group_summary','fractional':group['fractional_delay_offset'],'condition':condition,'method':method,'passed':want==group[condition][method]})
report={'artifact_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'runner_sha256':hashlib.sha256((REF/'controlled_cfo_comparison.py').read_bytes()).hexdigest(),'core_sha256':hashlib.sha256((REF/'ici_reference.py').read_bytes()).hexdigest(),'checks':checks,'passed':all(z['passed'] for z in checks),'runtime_s':time.perf_counter()-started,'summary':data['summary'],'interpretation':'Conditional on the reused observed-data MUSIC candidates. Different CFO improves weak-target recovery in the exact-grid case but also increases false detections from8 to16. The off-grid case keeps all16 hits and reduces false detections16 to0. This is a32-execution controlled receiver diagnostic; neither monotone improvement nor source curves are established.'}
(ROOT/'controlled-diagnostic-results.json').write_text(json.dumps(report,indent=2)+'\n');print('CONTROLLED',len(checks),'checks passed=',report['passed'],'runtime=',report['runtime_s'])
