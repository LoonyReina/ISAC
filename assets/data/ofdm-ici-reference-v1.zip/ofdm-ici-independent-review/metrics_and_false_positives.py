"""Independent metric association and predeclared explanatory diagnostics.
Not threshold tuning; conditional oracles are labelled and not headline trials.
"""
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import sys,json,hashlib,itertools
from pathlib import Path
from dataclasses import replace
import numpy as np
ROOT=Path(__file__).resolve().parent;REF=ROOT.parent/'ofdm-ici-reference'
sys.dont_write_bytecode=True;sys.path.insert(0,str(REF))
import ici_reference as r
from ici_reference import _constrained

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def circular(x,p):return (x+p/2)%p-p/2

def oracle(row,method):
    c=r.Config(**row['config']);ts=row['truth_evaluation_only'];ds=row['metrics'][method]['detections'];amb=method!='apes';p=c.slow_epsilon_period
    options=[];edge={}
    for i,t in enumerate(ts):
        choices=[None]
        for j,d in enumerate(ds):
            dq=abs(d['delay_samples']-t['delay_samples']);de=abs(circular(d['epsilon']-t['epsilon'],p)) if amb else abs(d['epsilon']-t['epsilon']);da=abs(d['angle_deg']-t['angle_deg'])
            if dq<=1 and de<=1.5*p/c.m and da<=2:
                choices.append(j);edge[i,j]=dq+de/(p/c.m)+da/2
        options.append(choices)
    feasible=[]
    for assign in itertools.product(*options):
        used=[j for j in assign if j is not None]
        if len(used)==len(set(used)):
            feasible.append((len(used),sum(edge[i,j] for i,j in enumerate(assign) if j is not None),assign))
    best=min(feasible,key=lambda f:(-f[0],f[1]))
    old=row['metrics'][method];reported={int(k):v['detection_index'] for k,v in old['matches'].items()}
    score=sum(edge.get((i,j),1e20) for i,j in reported.items())
    correct=len(reported)==best[0] and abs(score-best[1])<1e-9 and len(set(reported.values()))==len(reported) and old['false_detections']==len(ds)-best[0] and old['missed_target_indices']==[i for i in range(len(ts)) if i not in reported]
    # Verify every stored physical error, including aliased FFT velocity penalties.
    errors=[]
    for i,j in reported.items():
        t=ts[i];d=ds[j];z=old['matches'][str(i)]
        want={'range_error_m':(d['delay_samples']-t['delay_samples'])*c.range_step,'epsilon_error':d['epsilon']-t['epsilon'],'velocity_error_mps':(d['epsilon']-t['epsilon'])*c.velocity_per_epsilon,'angle_error_deg':d['angle_deg']-t['angle_deg']}
        errors.extend(abs(z[k]-v) for k,v in want.items())
    return correct and max(errors,default=0)<1e-10

files=['mechanism.json','bounded-tableII.json','original-dimension-capped-capture.json','noise-only-holdout.json']
data={f:json.loads((REF/'results'/f).read_text()) for f in files}
rep={'input_hashes':{f:sha(REF/'results'/f) for f in files},'core_sha256':sha(REF/'ici_reference.py'),'association':{},'aggregate':{},'false_positive_geometry':{},'diagnostics':{}}
methods=['apes','fft_known_x','fft_ici_free_counterfactual']
for label,rows in [('mechanism',[data['mechanism.json']]),('bounded',data['bounded-tableII.json']['trials']),('source_dimension',[data['original-dimension-capped-capture.json']])]:
    results=[oracle(row,m) for row in rows for m in methods]
    rep['association'][label]={'rows':len(rows),'method_metric_records':len(results),'passed':all(results)}
    geom={}
    for m in methods:
        cats={'cross_angle_duplicate_at_other_true_delay':0,'near_own_delay_wrong_doppler':0,'other_range_near_doppler':0,'other_range_wrong_doppler':0};ratios=[]
        for row in rows:
            c=r.Config(**row['config']);ts=row['truth_evaluation_only'];ds=row['metrics'][m]['detections'];used={v['detection_index'] for v in row['metrics'][m]['matches'].values()};p=c.slow_epsilon_period
            for j,d in enumerate(ds):
                if j in used:continue
                own=min(ts,key=lambda t:abs(t['angle_deg']-d['angle_deg']));dq=abs(d['delay_samples']-own['delay_samples'])
                diff=d['epsilon']-own['epsilon'];de=abs(circular(diff,p)) if m!='apes' else abs(diff);near_ep=de<=1.5*p/c.m
                # Categorization evidence, not a causal proof.
                cross=any(abs(t['angle_deg']-d['angle_deg'])>2 and abs(t['delay_samples']-d['delay_samples'])<=1 and (abs(circular(d['epsilon']-t['epsilon'],p)) if m!='apes' else abs(d['epsilon']-t['epsilon']))<=1.5*p/c.m for t in ts)
                if cross:cat='cross_angle_duplicate_at_other_true_delay'
                elif dq<=1:cat='near_own_delay_wrong_doppler'
                elif near_ep:cat='other_range_near_doppler'
                else:cat='other_range_wrong_doppler'
                cats[cat]+=1;ratios.append(d['power']/d['threshold'])
        geom[m]={'counts':cats,'total_false':sum(cats.values()),'power_over_threshold_median':float(np.median(ratios)) if ratios else None}
    rep['false_positive_geometry'][label]=geom

b=data['bounded-tableII.json'];group_ok=[]
for rows,summary in [(b['trials'],b['summary'])]+[([row for row in b['trials'] if row['source_nominal_velocity_mps']==g['source_nominal_velocity_mps'] and row['reference_snr_db']==g['reference_snr_db']],g) for g in b['groups']]:
    for m in methods:
        metrics=[z['metrics'][m] for z in rows];ref=[z['matches'].get('1') for z in metrics];hits=[z for z in ref if z is not None];false=sum(z['false_detections'] for z in metrics);allhits=sum(z['matched_count'] for z in metrics)
        expected={'trials':len(rows),'reference_detections':len(hits),'reference_detection_probability':len(hits)/len(rows),'false_detections':false,'all_target_detections':allhits,'source_FDR_V_over_V_plus_reference_S':false/(false+len(hits)) if false+len(hits) else None,'conventional_FDR_V_over_all_detections':false/(false+allhits) if false+allhits else None,'conditional_range_rmse_m':float(np.sqrt(sum(z['range_error_m']**2 for z in hits)/len(hits))) if hits else None,'conditional_velocity_rmse_mps':float(np.sqrt(sum(z['velocity_error_mps']**2 for z in hits)/len(hits))) if hits else None,'reference_misses':len(rows)-len(hits)}
        ok=all((summary[m][k] is None and v is None) or (v is not None and abs(summary[m][k]-v)<1e-9) for k,v in expected.items())
        group_ok.append(ok)
        if len(rows)==96:rep['aggregate'][m]=expected
rep['aggregate']['all_39_method_summaries_pass']=all(group_ok)
# All failed/accepted traces and raw receiver detections preserved.
trace_ok=[]
for row in b['trials']+[data['mechanism.json'],data['original-dimension-capped-capture.json']]:
    out=row['receiver'];trace_ok.append(out['detections']==row['metrics']['apes']['detections'])
    for branch in out['angles']:
        trace_ok.append(len(branch['epsilons'])==sum(t['accepted'] for t in branch['traces']))
        if branch['stop_reason']=='threshold':trace_ok.append(not branch['traces'][-1]['accepted'])
rep['raw_result_retention_pass']=all(trace_ok)

# Conditional same-CFO mechanism. Exact angles/CFO supplied only to operator oracle.
# Identical X/noise in both cases; channel and support are exactly on-grid.
c=r.Config(n=64,m=16,nr=8,nt=8,l=12,max_omp=3,cfo_points=17)
x=r.qpsk(c,390833);angle=-25.;aa=r.steering(angle,c.nr);pilot=r.PilotProjector(x,c)
conditional=[]
for other_ep in (.77,-.63):
    ts=[dict(delay_samples=3,epsilon=other_ep,angle_deg=-35.,alpha=10**(25/20)),dict(delay_samples=9,epsilon=.77,angle_deg=-25.,alpha=1.)]
    y,z=r.simulate(c,x,ts,1.,82812);phase=np.exp(-2j*np.pi*.77*np.arange(c.n)/c.n)
    q=r.covariance(pilot.residual(y*phase[None,:,None]));info,v=_constrained(q,aa,c.rank_rtol)
    response=abs(r.steering(-35.,c.nr)@v)
    qnoise=r.covariance(pilot.residual(z*phase[None,:,None]));rel_noise=float(np.linalg.norm(q-qnoise)/np.linalg.norm(qnoise))
    conditional.append({'same_cfo':other_ep==.77,'desired_response':abs(aa@v),'interferer_response':response,'interferer_response_db':20*np.log10(response),'Q_difference_from_projected_noise_relative':rel_noise})
rep['diagnostics']['shared_CFO_conditional_operator']=conditional

# CFAR range-ridge test, small strictly positive variation solely to break plateau.
# This is a detector-geometry falsification, not a new simulated target trial.
cc=replace(c,l=12,m=64,cfar_guard=(1,1),cfar_train=(4,4));power=np.ones((cc.n,cc.m));power[:cc.l,cc.m//2]=1e6*(1+0.01*np.cos(2*np.pi*np.arange(cc.l)/3))
cuts,threshold,counts=r.ca_cfar(power,cc)
q=6;d=cc.m//2
rep['diagnostics']['CFAR_coherent_range_ridge']={'cuts':cuts,'interior_threshold_to_CUT':float(threshold[q,d]/power[q,d]),'training_count':int(counts[q,d]),'interpretation':'2D CA-CFAR averages a Doppler-concentrated ridge over many empty Doppler cells; nominal iid multiplier can be crossed by ridge local maxima. This mechanism is not an implementation arithmetic bug.'}

# H0 uncertainty: no events does not certify 1e-4.
h=data['noise-only-holdout.json'];n=h['trials'];sm=h['summary']
rep['H0']={'trials':n,'reported_summary':sm,'one_sided_95pct_frame_probability_upper_if_zero':1-.05**(1/n),'not_per_cell_pfa':True,'full_MDl_gate_zero_trials':sum(row['music_order']==0 for row in h['full_pipeline'])}
rep['all_metric_checks_pass']=all(z['passed'] for z in rep['association'].values()) and rep['aggregate']['all_39_method_summaries_pass'] and rep['raw_result_retention_pass']
(ROOT/'metrics-results.json').write_text(json.dumps(r.jsonable(rep),indent=2,allow_nan=False)+'\n')
print(json.dumps(r.jsonable(rep),indent=2,allow_nan=False))
