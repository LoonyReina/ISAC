"""Verify saved frozen-input trace arrays using separate dense/SVD definitions."""
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import sys,json,hashlib,runpy
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parent;REF=ROOT.parent/'ofdm-ici-reference'
sys.dont_write_bytecode=True
ns=runpy.run_path(str(ROOT/'independent_numerics.py'))
r=ns['r'];cfg=ns['cfg'];y=ns['yh'];x=ns['xh'];result=ns['rerun'];atoms=ns['atoms'];oracle=ns['constrained_svd_oracle'];dft=ns['dft']
p=REF/'results'/'mechanism-full-stages.npz';arrays=np.load(p);manifest=json.loads((p.with_suffix('.json')).read_text());checks=[];seen=set()
def ck(key,want,rtol=2e-8,atol=2e-8):
    actual=arrays[key];err=float(np.max(abs(actual-want))) if actual.size else 0.;scale=max(float(np.max(abs(want))),1.)
    checks.append({'key':key,'passed':bool(np.allclose(actual,want,rtol=rtol,atol=atol)),'max_abs_error':err,'relative_to_max_or_one':err/scale});seen.add(key)
def cov(z):
    q=z.reshape(-1,z.shape[-1]);return q.conj().T@q
F=dft(cfg.n);FM=dft(cfg.m);FNL=F[:,:cfg.l]
ck('input_x',x,0,0);ck('input_y',y,0,0);ck('input_noise',ns['zh'],0,0);ck('music_scm',cov(y))
for ai,branch in enumerate(result['angles']):
    a=ns['steer'](branch['angle_deg'],cfg.nr);prefix=f'angle_{ai}';ck(prefix+'_steering',a)
    residual=y;eps=[]
    for trace in branch['traces']:
        it=trace['iteration'];q=f'{prefix}_iteration_{it}';ck(q+'_input_residual',residual);ck(q+'_R',cov(residual))
        search=trace.get('search')
        if search and search['ok']:
            ep=search['epsilon'];phi=atoms(x,cfg.l,[ep]);v,hh,_,cost=oracle(residual,phi,a)
            null=[]
            for ym,ph in zip(residual,phi):
                u,s,vh=np.linalg.svd(ph,full_matrices=False);null.append(ym-u@(u.conj().T@ym))
            ck(q+'_selected_cfo_Q',cov(np.array(null)))
            ck(q+'_selected_cfo_v',v)
            ck(q+'_cfo_grid_epsilon',np.array([z['epsilon'] for z in search['evaluations'] if z['kind']=='grid']),0,0)
            ck(q+'_cfo_grid_profile_cost',np.array([z['cost'] for z in search['evaluations'] if z['kind']=='grid']))
        if trace['accepted']:
            eps.append(search['epsilon']);phi=atoms(x,cfg.l,eps);v,hh,residual,cost=oracle(y,phi,a)
            ck(q+'_joint_channels',hh.reshape(cfg.m,len(eps),cfg.l).transpose(1,0,2))
            ck(q+'_output_residual',residual)
            null=[]
            for ym,ph in zip(y,phi):
                u,s,vh=np.linalg.svd(ph,full_matrices=False);null.append(ym-u@(u.conj().T@ym))
            ck(q+'_joint_Q',cov(np.array(null)));ck(q+'_joint_v',v)
    if branch['channels'] is not None:
        for ci,h in enumerate(branch['channels']):
            q=f'{prefix}_component_{ci}';fs=FNL@h.T;power=np.fft.fftshift(abs(F.conj().T@fs@FM)**2,axes=1)
            ck(q+'_channel_FS',fs);ck(q+'_rd_power',power)
            # Threshold/count arithmetic already independently checked by separate oracle.
            _,threshold,count=r.ca_cfar(power,cfg)
            ck(q+'_cfar_threshold',threshold);ck(q+'_cfar_training_count',count,0,0)
# Counterfactual independently generated from explicit frequency-phase model.
free=np.zeros_like(y)
for t in ns['held']['truth_evaluation_only']:
    b=np.exp(-2j*np.pi*np.arange(cfg.n)*t['delay_samples']/cfg.n)
    slow=np.exp(2j*np.pi*t['epsilon']*cfg.rho*np.arange(cfg.m))
    tx=ns['steer'](t['angle_deg'],cfg.nt)@ns['steer'](cfg.tx_angle_deg,cfg.nt).conj()
    waves=(F.conj().T@(x*b[:,None]*slow[None,:])).T
    free+=t['alpha']*tx*waves[:,:,None]*ns['steer'](t['angle_deg'],cfg.nr)
free+=ns['zh'];ck('input_y_ici_free_counterfactual',free)
for label,data in [('fft_known_x',y),('fft_ici_free_counterfactual',free)]:
    for ai,angle in enumerate(result['music']['angles']):
        a=ns['steer'](angle,cfg.nr);fs=F@np.array([ym@a.conj() for ym in data]).T/x
        power=np.fft.fftshift(abs(F.conj().T@fs@FM)**2,axes=1);q=f'{label}_angle_{ai}'
        ck(q+'_rd_power',power)
        _,threshold,count=r.ca_cfar(power,cfg);ck(q+'_cfar_threshold',threshold);ck(q+'_cfar_training_count',count,0,0)
meta_ok=manifest['archive_sha256']==hashlib.sha256(p.read_bytes()).hexdigest() and manifest['core_sha256']==hashlib.sha256((REF/'ici_reference.py').read_bytes()).hexdigest()
for e in manifest['entries']:meta_ok=meta_ok and list(arrays[e['key']].shape)==e['shape'] and str(arrays[e['key']].dtype)==e['dtype']
out={'archive_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'manifest_sha256':hashlib.sha256(p.with_suffix('.json').read_bytes()).hexdigest(),'core_sha256':hashlib.sha256((REF/'ici_reference.py').read_bytes()).hexdigest(),'manifest_matches_bytes_and_core':bool(meta_ok),'arrays_in_archive':len(arrays.files),'arrays_checked':len(seen),'unchecked_arrays':sorted(set(arrays.files)-seen),'checks':checks,'passed':bool(meta_ok and set(seen)==set(arrays.files) and all(z['passed'] for z in checks))}
(ROOT/'saved-stage-results.json').write_text(json.dumps(out,indent=2)+'\n')
print('SAVED STAGES',len(seen),'passed=',out['passed'])
for z in checks:
    if not z['passed']:print(z)
