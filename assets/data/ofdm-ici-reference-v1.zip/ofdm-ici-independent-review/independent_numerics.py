"""Independent verification; never writes the owner source/results directory.
Runs with OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1.
Uses explicit oscillator/DFT, SVD nullspace-constrained LS, and 80-digit KKT.
"""
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
os.environ.setdefault('OMP_NUM_THREADS','1')
os.environ.setdefault('MKL_NUM_THREADS','1')
import hashlib,json,sys,time,platform
from pathlib import Path
from dataclasses import replace
import numpy as np
import scipy
import mpmath as mp
ROOT=Path(__file__).resolve().parent
REF=ROOT.parent/'ofdm-ici-reference'
sys.dont_write_bytecode=True
sys.path.insert(0,str(REF))
import ici_reference as r
import run_experiments as exp
report={'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'versions':{'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__,'mpmath':mp.__version__},'checks':[],'defects':[],'limits':[]}

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def record(name,passed,**data):
    item={'name':name,'passed':bool(passed),**r.jsonable(data)}
    report['checks'].append(item)
    print(name,'PASS' if passed else 'FAIL',flush=True)
    return item

def dft(n):
    return np.exp(-2j*np.pi*np.outer(np.arange(n),np.arange(n))/n)/np.sqrt(n)
def steer(t,n):return np.exp(1j*np.pi*np.arange(n)*np.sin(np.deg2rad(t)))
def pilot(x,L):
    n,m=x.shape;F=dft(n)
    return np.array([F.conj().T@np.diag(x[:,j])@F[:,:L] for j in range(m)])
def atoms(x,L,eps):
    p=pilot(x,L);n=x.shape[0]
    return np.concatenate([p*np.exp(2j*np.pi*ep*np.arange(n)/n)[None,:,None] for ep in eps],axis=2)

def constrained_svd_oracle(y,phi,a):
    """Residualize with SVD, then optimize free coordinates of a.T v = 1.
    No covariance, normal-equation solve, inverse, or owner helper.
    """
    _,_,vh=np.linalg.svd(a[None,:],full_matrices=True)
    null=vh.conj().T[:,1:]
    particular=a.conj()/np.vdot(a,a).real
    residualized=[]
    for ym,pm in zip(y,phi):
        u,s,vh=np.linalg.svd(pm,full_matrices=False)
        residualized.append(ym-u@(u.conj().T@ym))
    residualized=np.concatenate(residualized,axis=0)
    beta=np.linalg.lstsq(residualized@null,-residualized@particular,rcond=None)[0]
    v=particular+null@beta
    hs=np.array([np.linalg.lstsq(pm,ym@v,rcond=None)[0] for pm,ym in zip(phi,y)])
    models=np.array([pm@h for pm,h in zip(phi,hs)])
    residual=y-models[:,:,None]*a[None,None,:]
    cost=np.linalg.norm(residualized@v)**2
    return v,hs,residual,float(cost)

def scalar_observation(c,x,targets,ici=True):
    y=np.zeros((c.m,c.n,c.nr),complex)
    for t in targets:
        tx=sum(np.exp(1j*np.pi*i*(np.sin(np.deg2rad(t['angle_deg']))-np.sin(np.deg2rad(c.tx_angle_deg)))) for i in range(c.nt))
        for j in range(c.m):
            for ell in range(c.n):
                wave=sum(x[k,j]*np.exp(2j*np.pi*k*(ell-t['delay_samples'])/c.n) for k in range(c.n))/np.sqrt(c.n)
                phase=np.exp(2j*np.pi*t['epsilon']*(c.rho*j+(ell/c.n if ici else 0)))
                y[j,ell]+=t['alpha']*tx*phase*wave*steer(t['angle_deg'],c.nr)
    return y

for file in ('source-private.pdf','ici_reference.py','test_reference.py','run_experiments.py','review/SOURCE-AUDIT.md','results/mechanism-input.npz','results/mechanism.json'):
    report.setdefault('input_hashes',{})[file]=sha(REF/file)

# Small, independent sample model, both Doppler signs, off-grid delay, array gain.
c=r.Config(n=16,m=5,nr=3,nt=2,l=3,max_omp=3,cfo_points=13,cfo_min=-1.5,cfo_max=1.5,refine=False,cfar_guard=(0,0),cfar_train=(2,2))
rng=np.random.default_rng(871933)
x=np.exp(1j*(np.pi/4+np.pi/2*rng.integers(0,4,(c.n,c.m))))
targets=[dict(delay_samples=1.31,epsilon=-.79,angle_deg=-22.7,alpha=.7-.8j),dict(delay_samples=2,epsilon=.23,angle_deg=14.2,alpha=-.3+.2j)]
for ici in (True,False):
    actual,z=r.simulate(c,x,targets,.3,872341,ici=ici)
    oracle=scalar_observation(c,x,targets,ici)+z
    err=float(np.max(abs(actual-oracle)))
    record('direct_scalar_observation_'+str(ici),err<2e-13,max_abs_error=err)

# 80 decimal digit direct KKT to avoid shared double-precision covariance oracle.
mp.mp.dps=80
small=replace(c,n=8,m=2,nr=2,nt=2,l=2,max_omp=2,cfo_points=5,cfo_min=-1,cfo_max=1)
xs=x[:8,:2]
a=steer(-21.3,2)
y=(rng.normal(size=(2,8,2))+1j*rng.normal(size=(2,8,2)))/np.sqrt(2)
phi=atoms(xs,2,[-.37])
rows,cols=16,6
A=mp.zeros(rows,cols)
for j in range(2):
    for n in range(8):
        for q in range(2):A[j*8+n,q]=mp.mpc(complex(y[j,n,q]))
        for q in range(2):A[j*8+n,2+2*j+q]=-mp.mpc(complex(phi[j,n,q]))
con=mp.matrix([mp.mpc(complex(z)) for z in a]+[0]*4)
G=A.H*A;K=mp.zeros(cols+1,cols+1)
for i in range(cols):
    for j in range(cols):K[i,j]=G[i,j]
    K[i,cols]=mp.conj(con[i]);K[cols,i]=con[i]
b=mp.zeros(cols+1,1);b[cols]=1
sol=mp.lu_solve(K,b)
w=sol[:cols,0]; mp_cost=float(mp.re(((A*w).H*(A*w))[0]))
info,h,res=r.joint_refit(y,a,[-.37],r.PilotProjector(xs,small),small)
mp_h=np.array([complex(sol[k]) for k in range(2,6)]).reshape(2,2)
record('80_digit_direct_KKT',info['ok'] and abs(info['cost']-mp_cost)<2e-12 and np.max(abs(h[0]-mp_h))<2e-12,cost_absolute_error=abs(info['cost']-mp_cost),channel_max_abs_error=float(np.max(abs(h[0]-mp_h))))

# General nonconstant modulus pilots and a near duplicate, preserving failures.
errs=[]
for scale in (np.ones_like(x.real), .3+1.2*rng.random(x.shape)):
    xx=x*scale; yy=rng.normal(size=(c.m,c.n,c.nr))+1j*rng.normal(size=(c.m,c.n,c.nr));aa=steer(-18.1,c.nr)
    for es in ([.13],[-.45,.67]):
        ph=atoms(xx,c.l,es)
        v,hh,rr,cc=constrained_svd_oracle(yy,ph,aa)
        inf,oh,orr=r.joint_refit(yy,aa,es,r.PilotProjector(xx,c),c)
        dh=float(np.max(abs(oh.transpose(1,0,2).reshape(c.m,-1)-hh)))
        dr=float(np.max(abs(orr-rr)))
        dc=abs(inf['cost']-cc)
        errs.append(max(dh,dr,dc))
record('free_coordinate_SVD_single_and_joint_QPSK_QAM',max(errs)<3e-11,max_abs_error=max(errs))

# Rerun exact held observations, rather than manufacturing a second scene.
held=json.loads((REF/'results/mechanism.json').read_text())
cfg=r.Config(**held['config'])
npz=np.load(REF/'results/mechanism-input.npz')
xh,yh,zh=npz['x'],npz['y'],npz['noise']
# Independent all-target replay, explicit matrix expression from Eq. 10.
F=dft(cfg.n);expected=np.zeros_like(yh)
for t in held['truth_evaluation_only']:
    b=np.exp(-2j*np.pi*np.arange(cfg.n)*t['delay_samples']/cfg.n)
    for j in range(cfg.m):
        wave=np.exp(2j*np.pi*t['epsilon']*np.arange(cfg.n)/cfg.n)*(F.conj().T@(xh[:,j]*b))*np.exp(2j*np.pi*t['epsilon']*cfg.rho*j)
        tx=steer(t['angle_deg'],cfg.nt)@steer(cfg.tx_angle_deg,cfg.nt).conj()
        expected[j]+=t['alpha']*tx*wave[:,None]*steer(t['angle_deg'],cfg.nr)[None,:]
held_obserr=float(np.max(abs(expected+zh-yh)))
record('held_observation_dense_replay',held_obserr<2e-10,max_abs_error=held_obserr)

started=time.perf_counter();rerun=r.receive(yh,xh,cfg);runtime=time.perf_counter()-started
rrmetrics=exp.evaluation(rerun['detections'],held['truth_evaluation_only'],cfg)
oldmetrics=held['metrics']['apes']
detection_err=max((abs(d[k]-e[k]) for d,e in zip(rerun['detections'],oldmetrics['detections']) for k in ('delay_samples','epsilon','angle_deg','power','gain_real','gain_imag')),default=0.)
record('held_pipeline_replay',rrmetrics['matched_count']==oldmetrics['matched_count'] and rrmetrics['false_detections']==oldmetrics['false_detections'] and detection_err<1e-8 and len(rerun['detections'])==len(oldmetrics['detections']),max_detection_difference=detection_err,runtime_s=runtime,matched=rrmetrics['matched_count'],false_detections=rrmetrics['false_detections'],misses=rrmetrics['missed_target_indices'],stops=[a['stop_reason'] for a in rerun['angles']])

# Every accepted joint fit uses original Y, independent alternative oracle.
fitrows=[];profile_rows=[]
for branch in rerun['angles']:
    a=steer(branch['angle_deg'],cfg.nr);eps=[];prev_res=yh.copy();last_cost=float('inf')
    for trace in branch['traces']:
        if not trace['accepted']:continue
        selected=trace['search']['epsilon'];eps.append(selected)
        phi=atoms(xh,cfg.l,eps)
        v,hh,rr,cc=constrained_svd_oracle(yh,phi,a)
        inf,oh,orr=r.joint_refit(yh,a,eps,r.PilotProjector(xh,cfg),cfg)
        rel_cost=abs(inf['cost']-cc)/cc
        channel_error=float(np.max(abs(oh.transpose(1,0,2).reshape(cfg.m,-1)-hh)))
        normal=float(np.linalg.norm(np.array([ph.conj().T@(res@v) for ph,res in zip(phi,orr)])))
        fitrows.append({'angle':branch['angle_deg'],'count':len(eps),'relative_cost_error':rel_cost,'channel_max_abs_error':channel_error,'residual_max_abs_error':float(np.max(abs(orr-rr))),'normal_equation_norm':normal,'nested_cost_nonincreasing':cc<=last_cost*(1+1e-10)})
        # Profile the chosen CFO on pre-iteration residual with the separate oracle.
        sv,sh,sr,sc=constrained_svd_oracle(prev_res,atoms(xh,cfg.l,[selected]),a)
        cpre=float(trace['capon']['cost']);prod=float(trace['search']['cost'])
        profile_rows.append({'cost_relative_error':abs(sc-prod)/max(sc,1e-300),'normalized_statistic_error':abs((1-sc/cpre)-trace['normalized_statistic']),'glrt_statistic_error':abs((cpre-sc)-trace['glrt_log_statistic'])})
        prev_res=orr;last_cost=cc
record('held_every_joint_fit_independent_SVD',all(z['relative_cost_error']<1e-9 and z['channel_max_abs_error']<1e-7 and z['residual_max_abs_error']<1e-7 and z['normal_equation_norm']<1e-6 and z['nested_cost_nonincreasing'] for z in fitrows),fits=fitrows)
record('held_selected_CFO_and_GLRT_independent_SVD',all(z['cost_relative_error']<1e-9 and z['normalized_statistic_error']<1e-9 and z['glrt_statistic_error']<1e-5 for z in profile_rows),fits=profile_rows)

# Evaluate every coarse first-iteration grid candidate on a fresh held noise seed.
yfresh,_=r.simulate(c,x,[dict(delay_samples=1,epsilon=-.36,angle_deg=-23,alpha=1.2+.4j)],.7,313731)
a=steer(-23,c.nr);search=r.cfo_search(yfresh,a,r.PilotProjector(x,c),c)
grid_errors=[];grid_costs=[]
for v in search['evaluations']:
    _,_,_,cost=constrained_svd_oracle(yfresh,atoms(x,c.l,[v['epsilon']]),a)
    grid_errors.append(abs(cost-v['cost']));grid_costs.append(cost)
record('all_coarse_CFO_grid_direct_free_coordinate_LS',max(grid_errors)<1e-10 and search['epsilon']==search['evaluations'][int(np.argmin(grid_costs))]['epsilon'],max_cost_error=max(grid_errors))

# Gain/FFT scaling and known symbols for every signed Doppler bin, odd/even M.
rd_errors=[]
for m in (5,6):
    cc=replace(c,m=m,cfar_guard=(0,0),cfar_train=(2,4));g=.37-.82j
    for k in np.arange(-(m//2),m-m//2):
        q=2;ch=g*np.outer(np.exp(-2j*np.pi*np.arange(cc.n)*q/cc.n),np.exp(2j*np.pi*np.arange(m)*k/m))
        z=r.recover(ch,cc,-23)
        ds=z['detections'];good=len(ds)==1
        if good:
            d=ds[0];err=max(abs(d['epsilon_ambiguous']-k/(m*cc.rho)),abs(complex(d['gain_real'],d['gain_imag'])-g),abs(d['power']-cc.n*m*abs(g)**2))
        else:err=1e9
        rd_errors.append(err)
record('signed_odd_even_range_Doppler_and_complex_gain',max(rd_errors)<1e-10,max_abs_error=max(rd_errors))

# CFAR oracle with unique cells and explicit Euclidean circular distance.
cf_errors=[]
for m in (5,6):
    cc=replace(c,m=m,cfar_guard=(1,1),cfar_train=(20,20));power=rng.exponential(size=(cc.n,m));power[cc.l:]=0
    cuts,threshold,count=r.ca_cfar(power,cc)
    for q in range(cc.l):
        for d in range(m):
            cells=[(qi,di) for qi in range(cc.l) for di in range(m) if not(abs(qi-q)<=1 and min(abs(di-d),m-abs(di-d))<=1)]
            want=np.mean([power[qi,di] for qi,di in cells])*len(cells)*(cc.pfa**(-1/len(cells))-1)
            cf_errors.append(abs(want-threshold[q,d]))
            assert count[q,d]==len(cells)
record('CA_CFAR_unique_circular_training_oracle',max(cf_errors)<1e-12,max_threshold_error=max(cf_errors))

# CA-CFAR nominal iid law validation, separate from adaptive receiver calibration.
# 40000 independent trial windows at Pfa .01 yields useful confidence width.
ntrain=20;pfa=.01;draws=40000;rrng=np.random.default_rng(520291)
training=rrng.exponential(size=(draws,ntrain));cut=rrng.exponential(size=draws)
mult=ntrain*(pfa**(-1/ntrain)-1)
fps=int(np.count_nonzero(cut>mult*np.mean(training,axis=1)));rate=fps/draws
zscore=(rate-pfa)/np.sqrt(pfa*(1-pfa)/draws)
record('iid_exponential_CFAR_multiplier_statistical_check',abs(zscore)<4,draws=draws,false_alarms=fps,nominal_pfa=pfa,observed_rate=rate,z_score=zscore)

# Literal zone rule and acknowledged failures for both signs.
period=c.slow_epsilon_period;zone_errors=[]
for zone in range(-4,5):
    for amb in (-.49*period,0.,.49*period):
        truth=amb+zone*period;zone_errors.append(abs(r.unwrap_source(amb,truth,c)-truth))
badplus=r.unwrap_source(.49*period,.51*period,c);badminus=r.unwrap_source(-.49*period,-.51*period,c)
record('literal_unwrap_signed_zones_and_visible_boundary_failures',max(zone_errors)<1e-12 and abs(badplus-.49*period)>period*.99 and abs(badminus+.49*period)>period*.99,max_normal_error=max(zone_errors),positive_crossing_result=badplus,negative_crossing_result=badminus,period=period)

# Fair baselines: same x, same noise, same estimated angles, baseline demodulation.
bs=r.fft_baseline(yh,xh,rerun['music']['angles'],cfg)
yfree,_=r.simulate(cfg,xh,held['truth_evaluation_only'],1,0,ici=False,noise=zh)
fs=r.fft_baseline(yfree,xh,rerun['music']['angles'],cfg)
rows={}
for name,out in [('fft_known_x',bs),('fft_ici_free_counterfactual',fs)]:
    ev=exp.evaluation(out['detections'],held['truth_evaluation_only'],cfg,True)
    prev=held['metrics'][name]
    rows[name]={'matches':ev['matched_count'],'false':ev['false_detections'],'misses':ev['missed_target_indices'],'same_counts':(ev['matched_count'],ev['false_detections'],ev['missed_target_indices'])==(prev['matched_count'],prev['false_detections'],prev['missed_target_indices'])}
record('held_paired_fair_baseline_replay',all(q['same_counts'] for q in rows.values()),results=rows)

# Failure preservation and observable non-identifiability, rather than assertions of recovery.
cc=replace(c,refine=False,cfo_points=13)
ones=np.ones_like(x);yy=rng.normal(size=(cc.m,cc.n,cc.nr))+1j*rng.normal(size=(cc.m,cc.n,cc.nr));aa=steer(-30,cc.nr)
flat=r.cfo_search(yy,aa,r.PilotProjector(ones,cc),cc)
spread=np.ptp([z['cost'] for z in flat['evaluations']]);base=np.mean([z['cost'] for z in flat['evaluations']])
record('all_one_symbols_nonidentifiable_CFO_is_flat',spread/base<1e-12,relative_cost_spread=spread/base,returned_cfo=flat['epsilon'],warning='Current API returns arbitrary minimizer without identifiability flag; do not use all-one pilot mode as evidence of CFO estimation')
info,h,res=r.joint_refit(yy,aa,[.2,.2],r.PilotProjector(x,cc),cc)
record('duplicate_CFO_failure_preserved',not info['ok'] and info['reason']=='rank_deficient_joint_pilot',result=info)
noiseonly=np.zeros_like(yy)
info,h,res=r.joint_refit(noiseonly,aa,[.2],r.PilotProjector(x,cc),cc)
record('singular_zero_observation_failure_preserved',not info['ok'] and info['reason']=='rank_deficient_covariance',result=info)
# Insufficient residual DoF although PL<N.
rc=replace(c,n=8,m=1,nr=8,nt=1,l=2,max_omp=3)
rx=np.exp(1j*np.pi/2*rng.integers(0,4,(8,1)));ry=rng.normal(size=(1,8,8))+1j*rng.normal(size=(1,8,8))
info,h,res=r.joint_refit(ry,steer(-22,8),[0.,.8],r.PilotProjector(rx,rc),rc)
record('insufficient_residual_DOF_failure_preserved',not info['ok'],result=info,residual_dimension=4,nr=8)

# Integer retained support exactness, offgrid model boundary, and CP endpoint.
F=dft(cfg.n);fnl=F[:,:cfg.l];projection_errors=[]
for q in (0.,cfg.l-1.,4.37,cfg.n*cfg.cp_ratio):
    b=np.exp(-2j*np.pi*np.arange(cfg.n)*q/cfg.n)
    e=float(np.linalg.norm(b-fnl@(fnl.conj().T@b))/np.linalg.norm(b));projection_errors.append({'delay':q,'relative_error':e})
record('finite_channel_model_boundary',projection_errors[0]['relative_error']<1e-12 and projection_errors[1]['relative_error']<1e-12 and projection_errors[2]['relative_error']>.05 and projection_errors[3]['relative_error']>.99,cases=projection_errors)

# Adversarial accepted configuration: target exactly at either angular endpoint.
endpoint=[]
ac=replace(c,n=32,m=8,nr=4,nt=1,l=6,max_omp=3,music_order=1,refine=True,angle_min=-40.,angle_max=40.,angle_step=.5)
ax=r.qpsk(ac,915)
for th in (-40.,40.):
    ay,_=r.simulate(ac,ax,[dict(delay_samples=2,epsilon=.2,angle_deg=th,alpha=50)],1e-8,442)
    out=r.music(ay,ac)
    endpoint.append({'truth_angle':th,'returned_angles':out['angles'],'global_grid_peak':out['angle_grid'][int(np.argmax(out['spectrum']))],'unresolved_peak_count':out['unresolved_peak_count'],'correct':any(abs(t-th)<.1 for t in out['angles'])})
record('MUSIC_search_endpoint_peak_support',all(z['correct'] for z in endpoint),cases=endpoint)
if not all(z['correct'] for z in endpoint):
    report['defects'].append({'id':'NUM-01','severity':'medium','file':'ici_reference.py','function':'music','description':'Both declared angle search endpoints are excluded from peakidx. A strong target at a valid endpoint is replaced by an interior sidelobe rather than returned or marked unresolved.','evidence':endpoint,'suggestion':'Handle endpoint local maxima against their sole neighbor; do not refine past bounds. Add positive and negative endpoint regression tests, or explicitly shrink/document an open valid domain and report edge candidates as unresolved.'})
# Adversarial valid M=1: local-max neighbors wrap back to the CUT itself.
mc=replace(c,m=1,cfar_guard=(0,0),cfar_train=(2,2))
pp=np.ones((mc.n,mc.m));pp[1,0]=1e6
cuts,thr,counts=r.ca_cfar(pp,mc)
record('CFAR_single_symbol_range_peak',len(cuts)==1,cuts=cuts,cut_power=float(pp[1,0]),threshold=float(thr[1,0]))
if len(cuts)!=1:report['defects'].append({'id':'NUM-02','severity':'low','file':'ici_reference.py','function':'ca_cfar','description':'M=1 is accepted by Config, but wrapped local-max neighbors include the CUT, rejecting every range peak.','suggestion':'Deduplicate local neighbors after wrapping and exclude the actual CUT, or reject unsupported M=1 in Config.'})

report['limits']=['Reduced algorithm validation, not the original 100-trial figure reproduction','Nominal iid CFAR multiplier does not calibrate adaptive receiver Pfa','No full fast-time principal-interval CFO sweep or continuous global optimizer certificate','Literal Eq.36 retains alias-boundary failures; no robust nearest-alias correction was substituted','Fractional and CP-endpoint delays need explicit finite-L model-mismatch disclosure','Truth used for simulation and evaluation only in inspected receiver/runner; shared_music is an optional caller input and its origin is caller responsibility','All-one pilot non-identifiability is visible in objective but not warned by runtime API']
report['passed']=sum(z['passed'] for z in report['checks']);report['failed']=len(report['checks'])-report['passed'];report['completed_utc']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())
(ROOT/'numerical-results.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print('RESULT',report['passed'],'passed,',report['failed'],'failed',flush=True)
