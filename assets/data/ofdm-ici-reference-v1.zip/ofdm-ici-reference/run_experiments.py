"""Reproducible evidence. Seeds/budgets are fixed before seeing results.
Truth enters simulation and evaluation only; never receiver initialization,
search intervals, threshold selection, model order, or iteration stopping.
"""
import argparse, hashlib, json, pathlib, time, platform
from dataclasses import replace, asdict
import numpy as np
from scipy.optimize import linear_sum_assignment
from ici_reference import *

ROOT=pathlib.Path(__file__).resolve().parent

def write(name,data):
    (ROOT/'results').mkdir(exist_ok=True)
    (ROOT/'results'/name).write_text(json.dumps(jsonable(data),indent=2,allow_nan=False)+'\n')

def evaluation(detections,targets,cfg,ambiguous=False):
    period=cfg.slow_epsilon_period
    cost=np.full((len(targets),len(detections)),1e9)
    for k,t in enumerate(targets):
        truth_ep=(t['epsilon']+period/2)%period-period/2 if ambiguous else t['epsilon']
        for j,d in enumerate(detections):
            dq=abs(d['delay_samples']-t['delay_samples'])
            de=abs(d['epsilon']-truth_ep)
            if ambiguous:de=min(de,abs(de-period))
            da=abs(d['angle_deg']-t['angle_deg'])
            if dq<=1 and de<=1.5*period/cfg.m and da<=2:
                cost[k,j]=dq+de/(period/cfg.m)+da/2
    matches={}
    if cost.size:
        rows,cols=linear_sum_assignment(cost)
        for k,j in zip(rows,cols):
            if cost[k,j]<1e8:
                t=targets[k]; d=detections[j]
                matches[int(k)]={'detection_index':int(j),'range_error_m':(d['delay_samples']-t['delay_samples'])*cfg.range_step,'velocity_error_mps':(d['epsilon']-t['epsilon'])*cfg.velocity_per_epsilon,'epsilon_error':d['epsilon']-t['epsilon'],'angle_error_deg':d['angle_deg']-t['angle_deg']}
    return {'matches':matches,'matched_count':len(matches),'target_count':len(targets),'false_detections':len(detections)-len(matches),'missed_target_indices':[k for k in range(len(targets)) if k not in matches],'association_domain':'ambiguous-for-FFT-source-footnote8' if ambiguous else 'unambiguous-for-APES-source-footnote8','association_tolerances':{'delay_samples':1,'doppler_bins':1.5,'angle_deg':2},'detections':detections}

def compact(receiver):
    # Keep all searches, failures, grid points, optimizer status, and detections.
    out={k:v for k,v in receiver.items() if k!='angles'}; out['angles']=[]
    for a in receiver['angles']:
        out['angles'].append({k:v for k,v in a.items() if k not in ('channels','residual','recoveries')})
    return out

def trial(cfg,targets,xseed,zseed,retain_trace=True):
    x=qpsk(cfg,xseed); y,z=simulate(cfg,x,targets,1,zseed)
    r=receive(y,x,cfg)
    t=time.perf_counter(); baseline=fft_baseline(y,x,r['music']['angles'],cfg); fft_seconds=time.perf_counter()-t
    # ICI-free counterfactual shares X, noise, hardware and *same angle estimates*.
    yf,_=simulate(cfg,x,targets,1,zseed,ici=False,noise=z)
    free=fft_baseline(yf,x,r['music']['angles'],cfg)
    result={'config':asdict(cfg),'seeds':{'symbols':xseed,'noise':zseed},'truth_evaluation_only':targets,'music_order':r['music']['order'],'angles':r['music']['angles'],'metrics':{'apes':evaluation(r['detections'],targets,cfg),'fft_known_x':evaluation(baseline['detections'],targets,cfg,True),'fft_ici_free_counterfactual':evaluation(free['detections'],targets,cfg,True)},'timing':{**r['timing'],'fft_baseline_s':fft_seconds},'stops':[a['stop_reason'] for a in r['angles']],'cap_reached':any(a['cap_reached'] for a in r['angles']),'cfo_evaluations':sum(len(t.get('search',{}).get('evaluations',[])) for a in r['angles'] for t in a['traces']),'rank_failure_count':sum(not e['ok'] for a in r['angles'] for t in a['traces'] for e in t.get('search',{}).get('evaluations',[]))}
    if retain_trace:result['receiver']=compact(r)
    return result,r,x,y,z

def summarize(rows,reference_index=1):
    summary={}
    for method in ('apes','fft_known_x','fft_ici_free_counterfactual'):
        metrics=[r['metrics'][method] for r in rows]
        matched=[m['matches'].get(reference_index,m['matches'].get(str(reference_index))) for m in metrics]
        hits=[m for m in matched if m is not None]; false=sum(m['false_detections'] for m in metrics); totaltrue=sum(m['matched_count'] for m in metrics)
        summary[method]={'trials':len(rows),'reference_detections':len(hits),'reference_detection_probability':len(hits)/len(rows),'false_detections':false,'all_target_detections':totaltrue,'source_FDR_V_over_V_plus_reference_S':false/(false+len(hits)) if false+len(hits)>0 else None,'conventional_FDR_V_over_all_detections':false/(false+totaltrue) if false+totaltrue>0 else None,'conditional_range_rmse_m':float(np.sqrt(np.mean([h['range_error_m']**2 for h in hits]))) if hits else None,'conditional_velocity_rmse_mps':float(np.sqrt(np.mean([h['velocity_error_mps']**2 for h in hits]))) if hits else None,'reference_misses':len(rows)-len(hits)}
    times=[r['timing']['total_s'] for r in rows]
    summary['cost']={'trials':len(rows),'p50_s':float(np.median(times)),'p95_s':float(np.percentile(times,95)),'worst_s':max(times),'total_s':sum(times),'cap_reached_trials':sum(r['cap_reached'] for r in rows),'rank_failure_count':sum(r['rank_failure_count'] for r in rows),'cfo_evaluations':sum(r['cfo_evaluations'] for r in rows),'all_stop_reasons':[r['stops'] for r in rows]}
    return summary

def mechanism():
    cfg=replace(Config(),max_omp=4)
    targets=[dict(delay_samples=4,epsilon=ep,angle_deg=-35,alpha=10**(s/20)) for ep,s in [(-1.47,20),(.13,15),(1.73,10)]]+[dict(delay_samples=q,epsilon=1.6384,angle_deg=-25,alpha=10**(s/20)) for q,s in [(8,10),(10,-10)]]
    result,r,x,y,z=trial(cfg,targets,20261012,1729)
    result['experiment']='Scaled mechanism corresponding to source Fig.3–6 structure; NOT source original target coordinates or dimensions'
    result['interpretation']='Same-angle same-aliased-Doppler targets; strong/weak shared-CFO pair; all false detections, weak-target miss and cap retained'
    literal=fft_baseline(y,x,r['music']['angles'],cfg,False)
    result['literal_printed_eq63_falsification']=evaluation(literal['detections'],targets,cfg,True)
    write('mechanism.json',result)
    np.savez_compressed(ROOT/'results'/'mechanism-input.npz',x=x,y=y,noise=z)
    print('mechanism',result['timing'],result['stops'],flush=True)

def bounded(trials):
    cfg=Config(n=128,m=16,l=32,max_omp=2,cfo_points=113)
    rows=[]; groups=[]
    for v in (20,70,120):
        for snr in (-20,-10,0,10):
            targets=[dict(delay_samples=40/3,epsilon=.016384*v,angle_deg=-35,alpha=10**(25/20)),dict(delay_samples=80/3,epsilon=.016384*v,angle_deg=-25,alpha=10**(snr/20))]
            local=[]
            for k in range(trials):
                # Fixed data matrix; independent paired noise, source §V-B design.
                row,*_=trial(cfg,targets,86420,100000+int(v)*1000+(snr+20)*100+k)
                row.update(source_nominal_velocity_mps=v,actual_velocity_mps=v*16,reference_snr_db=snr,replicate=k)
                rows.append(row);local.append(row)
            groups.append({'source_nominal_velocity_mps':v,'actual_velocity_mps':v*16,'reference_snr_db':snr,**summarize(local)})
            write('bounded-tableII.json',{'status':'running','planned_trials_per_cell':trials,'completed_trials':len(rows),'config':asdict(cfg),'groups':groups,'trials':rows})
            print('bounded',v,snr,'PD',[(m,groups[-1][m]['reference_detection_probability'])for m in ('apes','fft_known_x','fft_ici_free_counterfactual')],flush=True)
    write('bounded-tableII.json',{'status':'complete','experiment':'Table II / Figs.7–10 bounded-dimensional sweep, not original curves','scaling':'N=128 vs2048; M=16 vs64; B=50MHz and CP ratio=.25 retained; velocities x16 retain epsilon and slow-time phase per symbol; coherent dwell 1/64 original. L=32 is declared full CP tap budget.','original_unknown_choices':'Source does not specify L, grids, CFO bounds, CFAR windows, MUSIC model-order selection, or association tolerances','planned_trials_per_cell':trials,'completed_trials':len(rows),'config':asdict(cfg),'groups':groups,'trials':rows,'summary':summarize(rows)})

def original_capture():
    cfg=Config(n=2048,m=64,l=512,max_omp=1,cfo_points=65)
    targets=[dict(delay_samples=40/3,epsilon=.016384*70,angle_deg=-35,alpha=10**(25/20)),dict(delay_samples=80/3,epsilon=.016384*70,angle_deg=-25,alpha=1.)]
    row,*_=trial(cfg,targets,86420,707070)
    row['experiment']='Table I/II original observation dimensions, one SNR=0dB v=70m/s noise capture; fixed Pmax=1 computational cap, NOT full original Monte Carlo or convergence'
    row['source_choices']={'L':512,'L_status':'declared CP-limit choice; actual source implementation L unspecified','cfo_grid':65,'cfo_bounds_epsilon':[-3.5,3.5],'Pmax':1,'Pmax_status':'hardware-independent resource cap, not supplied target count','monte_carlo':1,'source_original_monte_carlo':100}
    write('original-dimension-capped-capture.json',row); print('original_capture',row['timing'],row['stops'],flush=True)

def holdout(trials):
    cfg=replace(Config(),max_omp=3)
    rows=[]; conditional=[];x=qpsk(cfg,75315)
    for k in range(trials):
        y,z=simulate(cfg,x,[],1,990000+k); r=receive(y,x,cfg)
        rows.append({'seed':990000+k,'music_order':r['music']['order'],'detection_count':len(r['detections']),'receiver':compact(r)})
        # Fixed-angle H0 sensitivity makes selection-bias and heuristic behavior observable.
        out=omp(y,-30,x,cfg);conditional.append({'seed':990000+k,'receiver':{k:v for k,v in out.items() if k not in ('channels','residual')},'accepted_cfos':len(out['epsilons'])})
    write('noise-only-holdout.json',{'status':'complete','trials':trials,'policy':'Predeclared Pfa and Eq65 threshold not fitted to these noise realizations','full_pipeline':rows,'fixed_angle_sensitivity':conditional,'summary':{'full_pipeline_any_detection_trials':sum(r['detection_count']>0 for r in rows),'MDL_nonzero_trials':sum(r['music_order']>0 for r in rows),'fixed_angle_any_CFO_trials':sum(r['accepted_cfos']>0 for r in conditional),'fixed_angle_total_CFOs':sum(r['accepted_cfos'] for r in conditional)}})
    print('holdout',trials,flush=True)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('suite',choices=['mechanism','bounded','original','holdout']);ap.add_argument('--trials',type=int,default=8);args=ap.parse_args()
    if args.trials<1:raise ValueError('At least one trial')
    {'mechanism':mechanism,'bounded':lambda:bounded(args.trials),'original':original_capture,'holdout':lambda:holdout(args.trials)}[args.suite]()
if __name__=='__main__':main()
