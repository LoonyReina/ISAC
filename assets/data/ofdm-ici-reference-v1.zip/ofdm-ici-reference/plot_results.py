"""Static views of actual stored numerical outcomes, not live solver output."""
import os,pathlib,json
ROOT=pathlib.Path(__file__).resolve().parent
os.environ.setdefault('MPLCONFIGDIR',str(ROOT/'.mpl-cache'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'figure.dpi':140})
(ROOT/'figures').mkdir(exist_ok=True)
data=json.loads((ROOT/'results/bounded-tableII.json').read_text())
fig,axes=plt.subplots(2,3,figsize=(12,6.7),sharex=True,sharey='row',constrained_layout=True)
styles=[('apes','APES/GLRT-OMP','#145A83','o'),('fft_known_x','FFT, same known X','#C75D29','s'),('fft_ici_free_counterfactual','FFT, synthetic ICI-free','#72834A','^')]
for ci,v in enumerate((20,70,120)):
    rows=[g for g in data['groups'] if g['source_nominal_velocity_mps']==v];snr=[g['reference_snr_db'] for g in rows]
    for key,label,color,marker in styles:
        axes[0,ci].plot(snr,[g[key]['reference_detection_probability'] for g in rows],label=label,color=color,marker=marker)
        axes[1,ci].plot(snr,[g[key]['source_FDR_V_over_V_plus_reference_S'] for g in rows],color=color,marker=marker)
    axes[0,ci].set_title(f'Actual velocity {v*16} m/s\n(source nominal {v} × 16)')
    axes[1,ci].set_xlabel('Reference target source SNR (dB)')
    for ax in axes[:,ci]:ax.set_ylim(-.04,1.06);ax.grid(alpha=.2)
axes[0,0].set_ylabel('Reference detection fraction')
axes[1,0].set_ylabel('FDR formula V / (V + reference S)')
fig.legend(*axes[0,0].get_legend_handles_labels(),loc='outside lower center',ncol=3,frameon=False)
fig.suptitle('Bounded Table II adaptation: N=128, M=16, 8 noise trials/cell\nHigh detection is accompanied by substantial false detections; not published-curve replication',fontsize=13)
fig.savefig(ROOT/'figures/bounded-detection-and-fdr.png');plt.close(fig)

mech=json.loads((ROOT/'results/mechanism.json').read_text());angle=mech['receiver']['angles'][0]
fig,ax=plt.subplots(figsize=(10,4.3),constrained_layout=True)
for ti,t in enumerate(angle['traces']):
    evals=[e for e in t['search']['evaluations'] if e['kind']=='grid'];ep=[e['epsilon'] for e in evals];z=[1-e['cost']/t['capon']['cost'] for e in evals]
    line,=ax.plot(ep,z,label=f'Iteration {ti+1}' + (' (spurious CFO / cap)' if ti==3 else ''))
    ax.plot([t['search']['epsilon']],[t['normalized_statistic']],'o',ms=4,color=line.get_color())
ax.axhline(.3,color='black',ls='--',lw=1,label='Source illustrative heuristic threshold 0.3')
ax.set(xlabel='CFO epsilon = f_D T (cycles / useful symbol)',ylabel='Normalized Eq. (65) statistic',title='Real small-scene OMP trace: three true components plus a retained spurious fourth')
ax.grid(alpha=.2);ax.legend(loc='upper right',fontsize=8)
fig.savefig(ROOT/'figures/mechanism-omp-trace.png');plt.close(fig)
print('Saved two static plots from actual retained evidence')
