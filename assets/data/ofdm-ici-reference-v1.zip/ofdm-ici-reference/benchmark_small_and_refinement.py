"""Held fresh-input cases: grid-only vs genuine local continuous refinement.
No target truth is used by either receiver. These are future browser candidates,
not a browser implementation or latency measurement.
"""
import json,time,pathlib,resource,numpy as np
from dataclasses import replace,asdict
from ici_reference import *
from run_experiments import ROOT,compact,evaluation

CASES=[
 ('distinct_angles',[(3.,-.67,-37.,10),(8.,1.41,-21.,0)]),
 ('fractional_delays',[(4.42,.48,-33.7,12),(8.35,1.86,-18.2,-4)]),
 ('outside_configured_CFO_search',[(5.2,3.6,-28.6,10)]),
 ('same_angle_alias_pair',[(4.,-1.44,-35.,12),(4.,.16,-35.,5)]),
 ('all_one_data_nonidentifiable',[(4.,1.1,-28.,10)]),
 ('declared_angular_endpoint',[(4.,.4,-40.,10)])]

def main():
    rows=[]
    for ci,(label,scene) in enumerate(CASES):
        cfg=Config();cfg=replace(cfg,angle_min=-40,angle_max=40) if label=='declared_angular_endpoint' else cfg
        targets=[dict(delay_samples=q,epsilon=e,angle_deg=a,alpha=10**(snr/20)) for q,e,a,snr in scene]
        x=qpsk(cfg,55100+ci) if label!='all_one_data_nonidentifiable' else np.ones((cfg.n,cfg.m),complex)
        y,z=simulate(cfg,x,targets,1,77100+ci);pair={}
        for refine in (False,True):
            c=replace(cfg,refine=refine);runs=[];r=None
            for repeat in range(3):
                r=receive(y,x,c);runs.append(r['timing']['total_s'])
            pair['continuous_local' if refine else 'grid_only']={'receiver':compact(r),'evaluation':evaluation(r['detections'],targets,c),'timing_repeats_s':runs,'all_local_refinement_successes':[s['success'] for a in r['angles'] for t in a['traces'] for s in t.get('search',{}).get('refinements',[])]}
        rows.append({'label':label,'config':asdict(cfg),'symbol_seed':None if label=='all_one_data_nonidentifiable' else 55100+ci,'noise_seed':77100+ci,'truth_evaluation_only':targets,'paired_results':pair})
    alltimes=[t for r in rows for t in r['paired_results']['continuous_local']['timing_repeats_s']]
    output={'kind':'fresh-input-bounded-Python-candidate-not-browser','all_cases_predeclared_in_script':True,'cases':rows,'compute':{'samples':len(alltimes),'p50_s':float(np.median(alltimes)),'p95_s':float(np.percentile(alltimes,95)),'worst_s':max(alltimes),'peak_process_rss_kib_linux':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss},'claims':'A future browser port must actually recompute the same operators and match independent fixtures. These Python timings do not demonstrate browser performance; boundary/unidentifiable/capped and failed outcomes remain visible.'}
    (ROOT/'results/fresh-input-and-refinement.json').write_text(json.dumps(jsonable(output),indent=2,allow_nan=False)+'\n');print(json.dumps(output['compute']))
    for r in rows:print(r['label'],[(k,v['evaluation']['matched_count'],v['evaluation']['false_detections'],[a['stop_reason'] for a in v['receiver']['angles']]) for k,v in r['paired_results'].items()])
if __name__=='__main__':main()
