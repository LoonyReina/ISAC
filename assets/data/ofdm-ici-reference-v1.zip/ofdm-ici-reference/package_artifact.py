"""Build immutable source-free artifact, preserving independent-review paths."""
import pathlib,json,hashlib,zipfile,datetime
ROOT=pathlib.Path(__file__).resolve().parent
REVIEW=ROOT.parent/'ofdm-ici-independent-review'
excluded={'source-private.pdf','source-private.txt','DELIVERY-MANIFEST.json','FREEZE.json','ARCHIVE.json','ARCHIVE-VERIFICATION.json','package-verification.log'}
files=[]
for p in ROOT.rglob('*'):
    if not p.is_file():continue
    rel=p.relative_to(ROOT)
    if any(part.startswith('.') or part in ('__pycache__','package-check') for part in rel.parts):continue
    if p.name in excluded or p.suffix=='.zip':continue
    if p.suffix not in ('.py','.md','.json','.npz','.png','.log','.txt','.sh') and p.name!='NOTICE':continue
    if 'source-private' in p.name or p.suffix=='.pdf':raise AssertionError('Private source input in archive list')
    files.append((p,'ofdm-ici-reference/'+rel.as_posix()))
for p in REVIEW.iterdir():
    if p.is_file() and p.suffix in ('.py','.md','.json','.log'):files.append((p,'ofdm-ici-independent-review/'+p.name))
files.sort(key=lambda x:x[1])
manifest={'format_version':1,'artifact':'ofdm-ici-reference-v1','source_pdf_distributed':False,'core_sha256':hashlib.sha256((ROOT/'ici_reference.py').read_bytes()).hexdigest(),'independent_review_sha256':hashlib.sha256((REVIEW/'INDEPENDENT-NUMERICAL-REVIEW.md').read_bytes()).hexdigest(),'independent_review_exclusions':['results/fresh-input-and-refinement.json is owner-only exploratory'],'files':[{'path':arc,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p,arc in files]}
manifest_path=ROOT/'DELIVERY-MANIFEST.json';manifest_path.write_text(json.dumps(manifest,indent=2)+'\n')
freeze={'artifact':'ofdm-ici-reference-v1','core_sha256':manifest['core_sha256'],'manifest_sha256':hashlib.sha256(manifest_path.read_bytes()).hexdigest(),'independent_review_sha256':manifest['independent_review_sha256'],'file_count':len(files),'scope':'Independent bounded operational reconstruction; published low-FDR curves not reproduced; no browser implementation. Fresh six-case benchmark is owner-only exploratory.'}
freeze_path=ROOT/'FREEZE.json';freeze_path.write_text(json.dumps(freeze,indent=2)+'\n')
files +=[(manifest_path,'ofdm-ici-reference/DELIVERY-MANIFEST.json'),(freeze_path,'ofdm-ici-reference/FREEZE.json')]
archive=ROOT/'ofdm-ici-reference-v1.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p,arc in files:
        info=zipfile.ZipInfo(arc,date_time=(2026,10,12,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=(0o755 if p.suffix=='.sh' else 0o644)<<16
        z.writestr(info,p.read_bytes())
meta={'filename':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'manifest_sha256':freeze['manifest_sha256'],'members':len(files),'source_pdf_distributed':False}
(ROOT/'ARCHIVE.json').write_text(json.dumps(meta,indent=2)+'\n');print(json.dumps(meta))
