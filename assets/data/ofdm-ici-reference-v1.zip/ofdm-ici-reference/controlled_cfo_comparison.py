"""Paired causal diagnostic: only one target's fast-time CFO changes.
Not a retuning exercise and not substituted for any original unfavorable trial.
"""
import pathlib,json,time,numpy as np
from dataclasses import replace,asdict
from ici_reference import *
from run_experiments import evaluation,compact,ROOT

def main():
    cfg=replace(Config(),max_omp=3);x=qpsk(cfg,84321);rows=[]
    for fractional in (0.,.3):
        for k in range(8):
            common=[dict(delay_samples=4+fractional,epsilon=.13,angle_deg=-35,alpha=10.),dict(delay_samples=8+fractional,epsilon=.13,angle_deg=-25,alpha=1.)]
            distinct=[dict(t) for t in common];distinct[1]['epsilon']+=2*cfg.slow_epsilon_period
            samey,noise=simulate(cfg,x,common,1,830000+k);diffy,_=simulate(cfg,x,distinct,1,0,noise=noise)
            # Candidate angles are estimated once from observed same-CFO data.
            # Exactly the same observed-data candidates feed both conditions.
            shared=music(samey,cfg)
            cases={}
            for label,y,targets in [('same_cfo',samey,common),('distinct_cfo',diffy,distinct)]:
                r=receive(y,x,cfg,shared_music=shared)
                f=fft_baseline(y,x,shared['angles'],cfg)
                cases[label]={'truth_evaluation_only':targets,'receiver':compact(r),'apes':evaluation(r['detections'],targets,cfg),'fft_known_x':evaluation(f['detections'],targets,cfg,True)}
            slowdiff=np.max(abs(np.exp(2j*np.pi*np.arange(cfg.m)*cfg.rho*common[1]['epsilon'])-np.exp(2j*np.pi*np.arange(cfg.m)*cfg.rho*distinct[1]['epsilon'])))
            rows.append({'fractional_delay_offset':fractional,'noise_seed':830000+k,'symbol_seed':84321,'shared_observed_music_angles':shared['angles'],'same_slow_phase_max_abs_error':float(slowdiff),'changed_parameter':'second target epsilon +1.6; only fast-time D differs since slow phase aliases by two periods','cases':cases})
    summaries=[]
    for fraction in (0.,.3):
        subset=[r for r in rows if r['fractional_delay_offset']==fraction];summary={'fractional_delay_offset':fraction,'paired_trials':len(subset)}
        for condition in ('same_cfo','distinct_cfo'):
            summary[condition]={}
            for method in ('apes','fft_known_x'):
                mets=[r['cases'][condition][method] for r in subset]
                summary[condition][method]={'matched_targets':sum(m['matched_count'] for m in mets),'targets':sum(m['target_count'] for m in mets),'false_detections':sum(m['false_detections'] for m in mets),'reference_detections':sum(1 in m['matches'] for m in mets)}
            summary[condition]['caps']=sum(any(a['cap_reached'] for a in r['cases'][condition]['receiver']['angles']) for r in subset)
        summaries.append(summary)
    output={'kind':'paired-controlled-CFO-mechanism-diagnostic','config':asdict(cfg),'scope':'Same X, noise, gains, true angles, delay, thresholds, association and reused observed-data MUSIC candidates. Only target2 fast-time phase changes; baseline/truth matching unchanged. No original trials replaced.','trials':rows,'summary':summaries}
    (ROOT/'results/controlled-cfo-comparison.json').write_text(json.dumps(jsonable(output),indent=2,allow_nan=False)+'\n');print(json.dumps(summaries,indent=2))
if __name__=='__main__':main()
