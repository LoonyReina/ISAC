import json,pathlib,numpy as np
from scipy.stats import beta
ROOT=pathlib.Path(__file__).resolve().parent

def exact_interval(k,n):
    return [0. if k==0 else float(beta.ppf(.025,k,n-k+1)),1. if k==n else float(beta.ppf(.975,k+1,n-k))]

def main():
    sweep=json.loads((ROOT/'results/bounded-tableII.json').read_text()); out={'method':'Exact Clopper-Pearson 95% binomial interval per fixed operating cell; no pooling across heterogeneous cells','cells':[]}
    for g in sweep['groups']:
        row={'source_nominal_velocity_mps':g['source_nominal_velocity_mps'],'actual_velocity_mps':g['actual_velocity_mps'],'reference_snr_db':g['reference_snr_db']}
        for method in ('apes','fft_known_x','fft_ici_free_counterfactual'):
            n=g[method]['trials'];k=g[method]['reference_detections'];row[method]={'k':k,'n':n,'interval_95':exact_interval(k,n)}
        out['cells'].append(row)
    h=json.loads((ROOT/'results/noise-only-holdout.json').read_text());n=h['trials'];out['H0']={'trials':n,'summary':h['summary'],'one_sided_95_upper_probability_if_zero':float(1-.05**(1/n)),'scope':'Probability of any event per tested frame/fixed-angle CFO scan; NOT per-cell Pfa. 64 zero-event trials cannot certify 1e-4.'}
    (ROOT/'results/uncertainty.json').write_text(json.dumps(out,indent=2)+'\n')
if __name__=='__main__':main()
