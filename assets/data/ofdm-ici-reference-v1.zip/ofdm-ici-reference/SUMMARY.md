# Results and limits

## Status

The actual source receiver core is implemented and independently checked: MUSIC, constrained APES CFO/channel recovery, GLRT/OMP joint channel refitting, CFAR delay/Doppler recovery, and the literal CFO alias-zone rule. This is an independently validated **bounded operational reconstruction**, not a reproduction of the paper's low-FDR result curves.

Source: arXiv:2103.15694v1 (29 March 2021). PDF SHA256: `ec454aa4e6e270f780ee28772b37ebc8f213203f9bf121bbf82a53cdc97dd5b5`.

Final core SHA256: `fee9e4a55707fe251f73bf343d0ac0142607d6c827cfd4e8bd0c974bba439cdb`.

## Retained outcomes

### Reduced Table II sweep

96 trials: 3 normalized-CFO conditions × 4 reference-target SNR levels × 8 independent noise realizations. Fixed known QPSK is shared by all methods; the same received data and observed MUSIC candidates feed APES and the known-X FFT. All ranks, grid points, local optimizer outcomes, detections and rejected iterations remain in `results/bounded-tableII.json`.

| Receiver | Reference detections | False detections | Source FDR formula | Conventional FDR |
|---|---:|---:|---:|---:|
| APES/GLRT-OMP | 96/96 | 198 | 0.6735 | 0.5077 |
| FFT with the same known X | 8/96 | 64 | 0.8889 | 0.4706 |
| FFT on synthetic ICI-free data | 85/96 | 151 | 0.6398 | 0.4548 |

Source FDR formula is V/(V+reference detections); conventional FDR uses all matched targets in the denominator. Association is a declared one-to-one 3D rule, not a reconstructed author implementation. **High detection alone is not success:** APES has many false detections, and its conventional FDR is not better than these baselines. Detection and FDR must be read together.

APES conditional range RMSE is 1 m, reflecting the retained integer-delay FFT grid for fractional true ranges, not continuous range refinement. Conditional physical velocity RMSE is 15.61 m/s in this velocity-scaled system. Misses are separate; they never become zero error. There were no capped trials or rank-failed CFO candidates in this particular 96-trial sweep.

This is N=128, M=16, L=32 rather than source N=2048, M=64. B=50 MHz, source SNRs, ranges and angles are retained; physical velocities are multiplied by16 to preserve normalized CFO. Dwell and NM decrease by64, physical velocity-bin width increases by64, CP range falls from1536m to96m, and range resolution stays3m. These are materially different sensing budgets, not dynamically equivalent or directly comparable original PD/RMSE curves.

### Five-target mechanism

The N64/M16/L12 structural example exercises unknown-angle MUSIC, three same-angle alias-overlapping CFOs, and a strong/weak shared-CFO pair. It retains a spurious fourth CFO with an iteration-cap stop and a missed weak target. The real iteration trace and 95-array stage archive make these failures inspectable. Its coordinates are not the original Figure3 coordinates.

### Original observation dimensions

N2048/M64/L512, 8TX×8RX, source Table II v=70m/s and reference SNR0dB: both targets were associated, but APES produced33 false detections. Both angle paths are cap-limited at predeclared Pmax1. This is one operating-point capture, not full OMP convergence, the source100-run Monte Carlo, or published-curve agreement.

Final measured receiver time: 14.458s. Full isolated job including both FFT comparisons and serialization: 18.323s, peak RSS 261.37MiB. The generic full-size P2 design matrix alone would be2GiB; that multi-CFO run was not attempted.

### H0 and uncertainty

64 independent noise-only frames produced0 nonzero-MDL/detection frames, and64 fixed-angle CFO scans produced0 accepted CFOs under the predeclared heuristic. Zero events in64 trials has a one-sided95% upper probability bound of4.57% per tested frame/scan. This cannot establish calibrated per-cell Pfa=1e-4. Each8/8 detection cell has a two-sided95% exact binomial lower bound of about0.631. See `results/uncertainty.json`.

## Controlled explanation, with mixed outcomes

The independent conditional operator test confirms that same-CFO exact-grid components are jointly removed by the null projection, so the covariance cannot infer spatial rejection from those components. This supports one cross-angle leakage mechanism, but does not alone determine full receiver performance.

A separate16-pair end-to-end control holds X/noise/gains/true angles/delays, observed-data MUSIC candidates, thresholds and association fixed. One target changes CFO by two complete slow-time alias periods, preserving slow-time phase:

- Integer delays: same-CFO gives8/16 matched targets plus8 false detections; distinct-CFO gives16/16 matched targets plus16 false detections
- Fractional delays: both conditions match16/16; false detections change16→0

Thus distinct CFO is not a universal false-positive fix. Unstructured-channel identifiability, finite-L mismatch, subsequent OMP, and CFAR all matter. These controls supplement rather than replace the original96 unfavorable trials.

Independent classification of the reduced APES198 false detections:192 cross-angle duplicates at the other target's range,5 other range ghosts near the correct Doppler, and1 wrong-Doppler output near its own range. Full-size range-ridge/local-noise CFAR ghosts are also retained. No thresholds were retuned after observing these failures.

## Computation and possible live scope

Single-thread cloud Python, NumPy2.3.5 / SciPy1.17.0 / Python3.12.14:

- Reduced96-trial receiver p50=0.353s, p95=0.406s, worst=0.434s
- Owner-only exploratory benchmark, outside independent-review scope: six fresh small scenes, three repeats each, continuous-local mode: p50=0.196s, p95=0.247s, worst=0.266s
- These owner-only fresh controls include distinct-angle, fractional delay, out-of-search CFO, same-angle alias pair, all-one nonidentifiable X, and angular search endpoint. Grid-only and continuous-local results are stored separately; failures and caps persist

These are Python timings, not browser timings. The fresh six-case file was not independently audited and is not included in the numerical reviewer’s acceptance claim. See `LIVE-SCOPE-HANDOFF.md` for a proposed bounded port and mandatory stage outputs. No UI, JS kernel, browser run, cloud task or publication was created here.

## Important source/implementation boundaries

1. Printed FFT Eq63 omits removing known X. The scientific comparator performs known-symbol division; literal-source output is a falsification control only
2. Finite L cannot exactly represent arbitrary fractional delays. The generator does not snap truth to the receiver grid
3. Source heuristic0.3 is applied to normalized Eq65, not to Eq49; nominal CFAR Pfa is not empirically calibrated by64 H0 trials
4. MDL order selection, search domains/grids/refinement, L, Pmax, complex phases, CFAR windows and matching tolerances are operational choices the source does not fully specify
5. APES and FFT differ in spatial filtering and channel modeling as well as ICI handling, so their difference is not a pure causal measure of ICI compensation
6. Gain/power normalization differs because the source FFT receive beam is unnormalized; raw gains are not directly comparable
7. Full-cube residual energy is not guaranteed monotone; joint profiled APES cost and normal equations are the validated invariants
8. True continuous refinement applies only to angle and CFO, locally around grid candidates. Delay/Doppler recovery remains a finite FFT grid

## Validation and files

16 owner tests plus8 source-auditor implementation oracles pass. The separate numerical reviewer independently checked high-precision KKT/profile costs, SVD joint refits, signed observation operators, CFAR training, all held stage arrays, and exhaustive associations; its detailed report is included separately. It found two genuine boundary bugs, both fixed and regression-tested before every experiment was rerun. Main96-trial detection/FDR/RMSE outcomes were unchanged after those edge fixes.

`check_results.py` verifies all stored trial counts, seeds, associations, metrics, adverse outcomes, and the95-array manifest. All code/results are frozen by `DELIVERY-MANIFEST.json`; the source PDF, extracted article text and original paper imagery are excluded from the portable archive.
