# Executable model and scope contract

Fixed source: arXiv:2103.15694v1, 29 March 2021, 14 pages, SHA256 `ec454aa4e6e270f780ee28772b37ebc8f213203f9bf121bbf82a53cdc97dd5b5`. The independent equation-located audit is `review/SOURCE-AUDIT.md`.

## Canonical model

The canonical generator is source post-CP sampled Eq. (5)/(10), not an OTFS model, a generic range–Doppler FFT, or a continuously time-scaled wideband channel. `Y[m,l,r]` is one M-symbol/N-fast-sample/N_R-antenna data cube. The known data matrix `X[n,m]` is arbitrary nonzero communication data; experiments use random unit-energy QPSK. All symbols are locally known because the sensing processor shares the transmitter. This reference does not decode bits or assume perfect unknown radar CSI.

Unknowns are target count, angle, delay, Doppler/CFO, and complex gain. Targets are supplied only to `simulate` and evaluation. `receive(y,x,cfg,noise_variance)` has no truth argument. Configured search domains, maximum iterations, channel support, grids, and thresholds are fixed before trials and independent of target realizations. A supplied MUSIC order is allowed only as a labelled source-style assumption; all reported default experiments use observed-data MDL instead. MDL is an operational extension because source model-order selection is unspecified, and its independent-snapshot approximation is not exact under all modeled signals.

## Units, signs and budgets

- Delay `q=B*tau`; range `R=c*q/(2B)`
- CFO `epsilon=f_c*T*nu=f_D*T`, with source `nu=2v/c`; `v=c*epsilon/(2*f_c*T)`
- Positive phase steering `a[r]=exp(j*pi*r*sin(theta))`; unnormalized transmit beam `f_T=conj(a_T(-30 degrees))`
- Unitary negative-exponent DFT; delay phase is negative; received slow-time and fast-time Doppler phases positive
- Complex noise `CN(0,sigma^2)` per antenna/sample, with each real component variance `sigma^2/2`; source target SNR `|alpha|^2/sigma^2` excludes array and coherent processing gain
- Known-X conventional FFT and APES receive exactly the same Y, X, noise variance, angle candidates and delay-search support. The source-intended ordinary steering beam differs from adaptive APES as part of the algorithm comparison, not a secret CSI difference
- Counterfactual ICI-free observations retain X, source gains, the same additive noise, the same MUSIC angle candidates, and positive slow-time Doppler; only D(epsilon) is replaced by I. They are synthetic and cannot resolve aliases. No blanket upper-bound or universal ICI-benefit claim follows

## Implemented algorithms

1. MUSIC Eqs. (15),(19), using conjugated steering in the covariance convention. Coarse angular grid and optional genuine continuous bounded refinement of selected grid peaks. Model-order and peak-picking outcomes are saved
2. APES single-CFO null covariance Eqs. (22),(27),(29),(30). Unit-modulus X admits an exact four-FFT projection; arbitrary nonzero QAM uses explicit QR. Q is Hermitian symmetrized and solved without ridge, pseudoinverse, or hidden diagonal loading
3. Algorithm 2 GLRT/OMP, Eqs. (44)–(57). Save both unnormalized Eq. (49) statistic and normalized Eq. (65) statistic. Experiments use source illustrative heuristic 0.3 on Eq. (65), not a calibrated Pfa. Search is a full fixed CFO grid plus optional continuous bounded local refinements around up to three grid minima. These refinements are local, not a global optimality certificate. All evaluations, local optimizer success/failures, search boundaries and grid-best values are retained
4. Jointly refit all accepted CFO-channel blocks against original Y, rebuild original Y minus the complete fitted model, and retain all previous CFOs unchanged as specified by source. No joint continuous CFO reoptimization is silently added. Channel/rank failures and resource caps stop explicitly; partial estimates remain visible
5. Algorithm 3 Eqs. (58)–(61): unpadded finite delay/slow-Doppler FFT, CA-CFAR, local maxima, gain Eq. (33), and literal Eq. (36) alias-zone correction. Delay/Doppler outputs are grid estimates; only angle/CFO have continuous refinement. This is not continuous range/velocity recovery

## Explicit operational choices and limitations

- Source Eq. (63) omits removing X. The scientific FFT comparator divides transformed observations by the identical known X. The literal printed path is a falsification control, never the headline comparator
- Finite L-tap Eq. (23) is exact for retained integer-delay taps but only approximate for fractional delays. The generator retains physical fractional phase exactly; receiver mismatch remains in Table II evidence. No truth snapping or model alteration is used
- CFO domain is epsilon in [-3.5,3.5], smaller than source theoretical [-N/2,N/2]. This is a predeclared surveillance/search budget. A boundary-selected answer is flagged, not treated as a global search result
- General search grid has 113 points, including both bounds; original-dimension resource-bounded capture uses 65. Angle scan [-80,80] degrees in 0.5-degree steps. Principal array ambiguities outside that field are not investigated
- CFAR nominal Pfa=1e-4; guard=(1,1), training half-window=(4,4). Range training uses only available valid [0,L) support, Doppler wraps, duplicate wrapped cells are removed, and a 3x3 local maximum is required. This avoids treating structural zeros outside the recovered channel support as noise samples. The same policy applies to all methods. This does not calibrate actual post-adaptive-beam false alarms
- Finite support restricts detections to q=0,...,L-1. Range edge truncation changes training count; each threshold/count is saved in selected matrix evidence
- Positive-definite covariance checks use minimum eigenvalue > 1e-11*maximum. LP>=N fails because there is no nullspace. Joint pilot singular values are checked; no all-failure search is converted into a successful estimate
- Source Eq. (36) uses the CFO estimate's alias zone. Near-zone-edge failures are kept. A nearest-alias robustness repair is not used
- Source does not fully specify L, Pmax, search grids/domains, source subspace-order selection, CFAR windows or association tolerances. Exact published figure replication is therefore not established
- Evaluation uses one-to-one Hungarian association: delay error <=1 sample, Doppler error <=1.5 slow bins, angle error <=2 degrees. FFT matching uses ambiguous Doppler as source footnote 8; APES requires the physical unwrapped coordinate. Both conditional physical velocity RMSE and misses remain visible
- Source-style FDR `V/(V+reference detections)` and conventional `V/(V+all matched detections)` are both saved. Neither is cell Pfa

## Physical assumptions retained

Co-located far-field point targets, single stream, half-wave ULAs, perfectly decoupled TX/RX (no self-interference), CP covers each delay, no ISI, constant per-frame parameters, narrowband Doppler phase without wideband time scaling or range migration. Formal huge fast-time velocity bounds do not override these assumptions. The maximum-CFO/slow-alias ratio is N*(1+CP/T), not exactly N when CP is retained.

## Evidence boundaries

- Small five-target mechanism follows the structural configuration of source Figs. 3–6 but changes coordinates/dimensions; it is not a reproduction of the source plot
- Bounded Table II sweep preserves ranges/SNRs/angles and normalized CFO, while reducing N and M and scaling physical velocity. It measures actual Algorithms 1–3 under those budgets, not source curves
- Source-dimension capture uses Table I dimensions and a Table II operating point, but fixed Pmax=1 and one noise capture. Cap-limited results are not convergence or the source 100-run experiment
- No live UI, browser timing, GPU implementation, full-size 100-run curves, communications BER, field data, or deployment is claimed

Additional scaling consequences: in the bounded Table II sweep, NM is reduced by 64, corresponding to 18.06 dB less coherent sample-count gain at fixed per-sample target SNR. Physical velocity-bin width increases by 64 (epsilon-bin width by 4); CP-limited range falls from 1536 m to 96 m, with the 80 m target now near the support boundary. Range resolution remains 3 m. This is not a dynamically equivalent copy of the original system. Complex reflection phases are fixed to zero in all selected simulation targets; the source specifies magnitudes/SNRs but does not specify these phases.

Comparison interpretation: APES versus the conventional source FFT differs in adaptive spatial filtering and finite-channel modeling as well as ICI handling. Shared data/angles/budgets make the receiver comparison fair under the declared scope, but do not isolate a causal effect attributable only to ICI compensation. A successful APES detection is not a universal claim that ICI is beneficial.

Gain normalization: `gain_real/gain_imag` are gains of the channel being mapped. APES uses a distortionless normalized receive beam and reports effective alpha including TX beam gain. The source FFT uses an unnormalized RX sum, so its target gain also includes the receive-beam response (N_R at the matched angle). Raw gains/powers across these methods are therefore not directly comparable; detection comparisons use identical scale-invariant CFAR rules. No gain-estimation superiority is claimed.

Boundary repairs discovered independently: the final receiver includes both configured MUSIC angular endpoints and flags them as search-boundary results without extrapolation. Wrapped local-CFAR neighborhoods use unique coordinates and remove the test cell after wrapping, including M=1. Both edge failures and regressions are documented in the independent review; all selected experiments were rerun against the fixed core.
