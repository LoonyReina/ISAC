import unittest
from dataclasses import replace
import numpy as np
from ici_reference import *
from ici_reference import _constrained

class ReferenceTests(unittest.TestCase):
    def setUp(self):
        self.c=Config(n=32,m=8,nr=4,nt=3,l=6,max_omp=3,cfo_points=33,refine=False)
        self.x=qpsk(self.c,77)
    def test_eq5_direct_scalar(self):
        c=self.c;t={'delay_samples':2.37,'epsilon':1.21,'angle_deg':-21.7,'alpha':.7-.2j}
        y,_=simulate(c,self.x,[t],0,8)
        oracle=np.zeros_like(y)
        for m in range(c.m):
            for ell in range(c.n):
                s=sum(self.x[n,m]*np.exp(2j*np.pi*n*ell/c.n-2j*np.pi*n*t['delay_samples']/c.n) for n in range(c.n))/np.sqrt(c.n)
                tx=sum(np.exp(1j*np.pi*i*(np.sin(np.deg2rad(t['angle_deg']))-np.sin(np.deg2rad(c.tx_angle_deg)))) for i in range(c.nt))
                for r in range(c.nr):
                    oracle[m,ell,r]=t['alpha']*tx*np.exp(1j*np.pi*r*np.sin(np.deg2rad(t['angle_deg'])))*np.exp(2j*np.pi*t['epsilon']*(ell/c.n+c.rho*m))*s
        np.testing.assert_allclose(y,oracle,atol=2e-13)
    def test_pilot_fft_equals_dense_and_qam(self):
        rng=np.random.default_rng(14); v=rng.normal(size=(self.c.m,self.c.n,self.c.nr))+1j*rng.normal(size=(self.c.m,self.c.n,self.c.nr))
        for x in (self.x,self.x*(.5+rng.random(self.x.shape))):
            p=PilotProjector(x,self.c); a=p.matrices(); h=p.analyze(v)
            expected=np.array([np.linalg.lstsq(am,vm,rcond=None)[0] for am,vm in zip(a,v)])
            np.testing.assert_allclose(h,expected,atol=1e-13)
            np.testing.assert_allclose(p.synthesize(h),np.einsum('mnl,mlr->mnr',a,h),atol=1e-13)
    def test_capon_kkt(self):
        rng=np.random.default_rng(66); z=rng.normal(size=(20,4))+1j*rng.normal(size=(20,4)); q=z.conj().T@z; a=steering(-22,4)
        info,v=_constrained(q,a,1e-11)
        kkt=np.block([[q,a.conj()[:,None]],[a[None,:],np.zeros((1,1))]])
        sol=np.linalg.solve(kkt,np.r_[np.zeros(4),1])[:4]
        np.testing.assert_allclose(v,sol,atol=1e-13)
        self.assertAlmostEqual(info['cost'],float(np.real(sol.conj()@q@sol)),places=12)
        self.assertLess(abs(a@v-1),1e-14)
    def test_single_cfo_dense_profile(self):
        c=self.c; y,_=simulate(c,self.x,[{'delay_samples':3,'epsilon':.42,'angle_deg':-24,'alpha':2+1j}],.1,23)
        p=PilotProjector(self.x,c); a=steering(-24,c.nr); search=cfo_search(y,a,p,c)
        grid=np.linspace(c.cfo_min,c.cfo_max,c.cfo_points); explicit=[]
        for ep in grid:
            q=np.zeros((c.nr,c.nr),complex)
            for ym,pm in zip(y,p.matrices()):
                phi=np.diag(np.exp(2j*np.pi*ep*np.arange(c.n)/c.n))@pm
                proj=np.eye(c.n)-phi@np.linalg.inv(phi.conj().T@phi)@phi.conj().T
                q+=ym.conj().T@proj@ym
            explicit.append(1/np.real(a@np.linalg.solve(q,a.conj())))
        np.testing.assert_allclose([r['cost'] for r in search['evaluations']],explicit,rtol=1e-10,atol=1e-10)
    def test_music_negative_angle(self):
        c=replace(self.c,music_order=1,refine=True)
        y,_=simulate(c,self.x,[{'delay_samples':3,'epsilon':.6,'angle_deg':-24,'alpha':4}],.01,23)
        out=music(y,c); self.assertLess(abs(out['angles'][0]+24),.04)
    def test_joint_refit_normal_equations(self):
        c=self.c; targets=[{'delay_samples':2,'epsilon':-.7,'angle_deg':-24,'alpha':3},{'delay_samples':4,'epsilon':1.3,'angle_deg':-24,'alpha':1}]
        y,_=simulate(c,self.x,targets,.1,23); p=PilotProjector(self.x,c); a=steering(-24,c.nr)
        one,h1,r1=joint_refit(y,a,[-.7],p,c); two,h2,r2=joint_refit(y,a,[-.7,1.3],p,c)
        self.assertTrue(one['ok']); self.assertTrue(two['ok']); self.assertLessEqual(two['cost'],one['cost']*(1+1e-10))
        phis=np.concatenate([p.matrices()*np.exp(2j*np.pi*ep*np.arange(c.n)/c.n)[None,:,None] for ep in [-.7,1.3]],axis=2)
        q=sum(ym.conj().T@(np.eye(c.n)-ph@np.linalg.pinv(ph))@ym for ym,ph in zip(y,phis))
        _,v=_constrained(q,a,c.rank_rtol)
        normal=np.array([ph.conj().T@(rm@v) for ph,rm in zip(phis,r2)])
        self.assertLess(np.linalg.norm(normal),1e-10)
        models=np.einsum('mnl,ml->mn',phis,h2.transpose(1,0,2).reshape(c.m,-1))
        np.testing.assert_allclose(r2,y-models[:,:,None]*a,atol=1e-12)
    def test_rd_known_symbol_baseline(self):
        c=self.c; ep=1/(c.rho*c.m); t={'delay_samples':3,'epsilon':ep,'angle_deg':-24,'alpha':1}
        y,_=simulate(c,self.x,[t],0,1,ici=False)
        correct=fft_baseline(y,self.x,[-24],c); literal=fft_baseline(y,self.x,[-24],c,False)
        power=correct['maps'][0]['power']; bad=literal['maps'][0]['power']
        peak=np.unravel_index(np.argmax(power),power.shape)
        self.assertEqual(peak,(3,c.m//2+1)); self.assertAlmostEqual(power[peak]/power.sum(),1,places=12)
        self.assertLess(bad[peak]/bad.sum(),.1)
    def test_noise_convention_and_ici_free_pair(self):
        c=self.c; y,z=simulate(c,self.x,[],2,35); np.testing.assert_array_equal(y,z)
        rng=np.random.default_rng(2); big=np.sqrt(2/2)*(rng.standard_normal(100000)+1j*rng.standard_normal(100000)); self.assertLess(abs(np.mean(abs(big)**2)-2),.015)
        t={'delay_samples':3,'epsilon':0.,'angle_deg':-24,'alpha':1}
        ya,_=simulate(c,self.x,[t],2,1); yb,_=simulate(c,self.x,[t],2,9,ici=False,noise=z)
        clean,_=simulate(c,self.x,[t],0,1); np.testing.assert_allclose(yb,clean+z,atol=1e-14)
    def test_cfar_training_has_no_structural_zeros(self):
        c=self.c;p=np.ones((c.n,c.m)); p[c.l:]=0; cuts,threshold,count=ca_cfar(p,c)
        self.assertFalse(cuts)
        np.testing.assert_allclose(threshold,count*np.expm1(-np.log(c.pfa)/count))
    def test_source_unwrap_boundary_failure_is_visible(self):
        c=self.c; period=c.slow_epsilon_period
        # A coarse CFO estimate crosses +period/2; Eq36 chooses wrong alias.
        self.assertAlmostEqual(unwrap_source(.39,.41,c),1.19)
        self.assertGreater(abs(unwrap_source(.39,.41,c)-.39),.7)
    def test_fractional_delay_not_exact_finite_channel(self):
        p=PilotProjector(self.x,self.c); b=np.exp(-2j*np.pi*np.arange(self.c.n)*2.37/self.c.n)
        projection=p.fnl@(p.fnl.conj().T@b)
        self.assertGreater(np.linalg.norm(b-projection)/np.linalg.norm(b),.1)
    def test_rank_and_cap_failures(self):
        a=steering(-30,4); info,v=_constrained(np.zeros((4,4)),a,1e-11); self.assertFalse(info['ok'])
        c=replace(self.c,l=8,max_omp=4); x=qpsk(c,1); p=PilotProjector(x,c)
        fit,h,res=joint_refit(np.ones((c.m,c.n,c.nr),complex),a,[0,1,2,3],p,c)
        self.assertEqual(fit['reason'],'no_nullspace_at_LP_ge_N')
    def test_input_bounds(self):
        with self.assertRaises(ValueError):Config(l=17)
        with self.assertRaises(ValueError):Config(max_omp=6)
        with self.assertRaises(ValueError):Config(cfo_min=-100)
    def test_music_both_declared_endpoints(self):
        c=replace(self.c,angle_min=-40,angle_max=40,music_order=1,refine=True)
        for angle in (-40.,40.):
            y,_=simulate(c,self.x,[{'delay_samples':3,'epsilon':.6,'angle_deg':angle,'alpha':20}],.0001,42)
            out=music(y,c)
            self.assertAlmostEqual(out['angles'][0],angle,places=10)
            self.assertTrue(out['peaks'][0]['at_search_boundary'])
            self.assertEqual(out['unresolved_peak_count'],0)
    def test_cfar_one_symbol_does_not_compare_cut_to_itself(self):
        c=replace(self.c,m=1);power=np.ones((c.n,1));power[3,0]=1e6
        cuts,threshold,counts=ca_cfar(power,c)
        self.assertEqual(len(cuts),1);self.assertEqual(cuts[0]['delay_samples'],3.)
        self.assertLess(threshold[3,0],power[3,0])
    def test_noise_only_mdl(self):
        y,_=simulate(self.c,self.x,[],1,981); out=music(y,self.c); self.assertEqual(out['order'],0)

if __name__=='__main__': unittest.main(verbosity=2)
