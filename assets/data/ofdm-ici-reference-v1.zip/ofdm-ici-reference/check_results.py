"""Checks complete evidence, including unfavorable outcomes; no success filtering."""
import json,pathlib,hashlib,numpy as np
from ici_reference import Config,qpsk,simulate
from run_experiments import evaluation,summarize
ROOT=pathlib.Path(__file__).resolve().parent

def read(name):return json.loads((ROOT/'results'/name).read_text(),parse_constant=lambda v:(_ for _ in ()).throw(ValueError(v)))
def close(a,b):
    if isinstance(a,dict):
        assert set(a)==set(b),(set(a),set(b))
        for k in a:close(a[k],b[k])
    elif isinstance(a,list):
        assert len(a)==len(b)
        for aa,bb in zip(a,b):close(aa,bb)
    elif isinstance(a,(float,int)) and not isinstance(a,bool):assert np.isclose(a,b,rtol=1e-10,atol=1e-12),(a,b)
    else:assert a==b,(a,b)

def validate_row(r):
    c=Config(**r['config']);targets=r['truth_evaluation_only']
    for method,m in r['metrics'].items():
        expected=evaluation(m['detections'],targets,c,method!='apes')
        expected=json.loads(json.dumps(expected));close(m,expected)
    assert len(r['receiver']['music']['angles'])==len(r['receiver']['angles'])
    count=0; rank=0
    for a in r['receiver']['angles']:
        accepted=sum(t['accepted'] for t in a['traces']);assert accepted==len(a['epsilons'])
        assert a['cap_reached']==(a['stop_reason']=='iteration_cap')
        for t in a['traces']:
            ev=t.get('search',{}).get('evaluations',[]);count+=len(ev);rank+=sum(not e['ok'] for e in ev)
            if 'normalized_statistic' in t:
                close(t['normalized_statistic'],1-t['search']['cost']/t['capon']['cost'])
                close(t['glrt_log_statistic'],t['capon']['cost']-t['search']['cost'])
    assert count==r['cfo_evaluations'];assert rank==r['rank_failure_count']

s=read('bounded-tableII.json');assert s['status']=='complete';assert len(s['trials'])==96;assert len(s['groups'])==12;assert len({r['seeds']['noise'] for r in s['trials']})==96
for r in s['trials']:validate_row(r)
close(s['summary'],json.loads(json.dumps(summarize(s['trials']))))
for g in s['groups']:
    rows=[r for r in s['trials'] if r['source_nominal_velocity_mps']==g['source_nominal_velocity_mps'] and r['reference_snr_db']==g['reference_snr_db']];assert len(rows)==8
    got=summarize(rows)
    for k,v in got.items():close(g[k],json.loads(json.dumps(v)))
mechanism=read('mechanism.json');validate_row(mechanism);cfg=Config(**mechanism['config']);fixture=np.load(ROOT/'results/mechanism-input.npz');x=qpsk(cfg,mechanism['seeds']['symbols']);y,z=simulate(cfg,x,mechanism['truth_evaluation_only'],1,mechanism['seeds']['noise']);np.testing.assert_array_equal(x,fixture['x']);np.testing.assert_array_equal(y,fixture['y']);np.testing.assert_array_equal(z,fixture['noise'])
assert mechanism['cap_reached'];assert mechanism['metrics']['apes']['false_detections']>0;assert mechanism['metrics']['apes']['missed_target_indices']
original=read('original-dimension-capped-capture.json');validate_row(original);assert original['config']['n']==2048 and original['config']['m']==64 and original['config']['l']==512 and original['config']['max_omp']==1;assert original['cap_reached']
holdout=read('noise-only-holdout.json');assert len(holdout['full_pipeline'])==len(holdout['fixed_angle_sensitivity'])==holdout['trials']==64
stages=read('mechanism-full-stages.json');archive=ROOT/'results/mechanism-full-stages.npz';assert stages['archive_sha256']==hashlib.sha256(archive.read_bytes()).hexdigest();assert stages['core_sha256']==hashlib.sha256((ROOT/'ici_reference.py').read_bytes()).hexdigest();stored=np.load(archive);assert len(stored.files)==len(stages['entries'])==95
for e in stages['entries']:
    a=stored[e['key']];assert list(a.shape)==e['shape'];assert str(a.dtype)==e['dtype'];assert a.nbytes==e['uncompressed_bytes']
for i in stages['stage_invariants']:
    assert i['constraint_error']<1e-9 and i['joint_normal_max_abs']<1e-7 and i['residual_reconstruction_max_abs']<1e-9
    close(i['reported_joint_cost'],i['recomputed_profile_cost'])
print('PASS: all 96 bounded trials, original-dimension capture, complete held mechanism, 64 H0 trials, 95-array stage manifest, every metric and preserved adverse outcome')
controlled=read('controlled-cfo-comparison.json');assert len(controlled['trials'])==16
for row in controlled['trials']:
    assert row['same_slow_phase_max_abs_error']<1e-12
    same=row['cases']['same_cfo'];different=row['cases']['distinct_cfo'];t0=same['truth_evaluation_only'];t1=different['truth_evaluation_only']
    assert t0[0]==t1[0]
    for key in ('delay_samples','angle_deg','alpha'):assert t0[1][key]==t1[1][key]
    close(t1[1]['epsilon']-t0[1]['epsilon'],1.6)
    for case in (same,different):
        assert case['receiver']['music']['angles']==row['shared_observed_music_angles']
        cfg=Config(**case['receiver']['config'])
        for method in ('apes','fft_known_x'):
            expected=evaluation(case[method]['detections'],case['truth_evaluation_only'],cfg,method!='apes');close(case[method],json.loads(json.dumps(expected)))
fresh=read('fresh-input-and-refinement.json');assert len(fresh['cases'])==6
for case in fresh['cases']:
    for label,result in case['paired_results'].items():
        assert len(result['timing_repeats_s'])==3
        expected=evaluation(result['evaluation']['detections'],case['truth_evaluation_only'],Config(**result['receiver']['config']));close(result['evaluation'],json.loads(json.dumps(expected)))
print('PASS: all16 matched controlled pairs and6 grid/refinement fresh-input cases retain their complete outcomes')
