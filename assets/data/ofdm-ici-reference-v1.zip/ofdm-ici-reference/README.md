# MIMO-OFDM ICI-aware receiver: independent bounded reference

Actual source MUSIC, APES, GLRT/OMP and CFAR/CFO-unwrapping algorithms for **MIMO-OFDM Joint Radar-Communications: Is ICI Friend or Foe?**, fixed [arXiv:2103.15694v1](https://arxiv.org/pdf/2103.15694v1).

**What is established:** a tested numerical implementation with transparent source reconstruction choices, held complex observations, complete adverse outcomes, and independent algebra/implementation checks.

**What is not established:** reproduction of the paper's published low-FDR curves, full-size converged multi-CFO Monte Carlo results, browser execution, or general ICI benefit. In the retained 96-trial reduced sweep, APES detects all reference targets but also produces 198 false detections. Please read detection and FDR together.

## Start here

- `SUMMARY.md`: outcomes, costs, and limitations
- `MODEL-CONTRACT.md`: exact conventions, truth/knowledge boundary, operational choices
- `review/SOURCE-AUDIT.md`: independent equation-located source audit and source ambiguities
- `ici_reference.py`: actual receiver, not a generic prerequisite FFT
- `results/mechanism.json`: real five-target receiver trace, including false fourth CFO and cap
- `results/mechanism-full-stages.json` / `.npz`: 95-array full-stage replay evidence, separate from compact summaries
- `results/bounded-tableII.json`: all 96 trials, all detections, searches, failures/caps, and metrics
- `results/original-dimension-capped-capture.json`: original observation dimensions, one explicitly capped capture
- `results/controlled-cfo-comparison.json`: 16 matched same-/distinct-CFO pairs; mixed outcomes retained
- `results/noise-only-holdout.json`: 64 unretuned H0 frames and fixed-angle sensitivity checks
- `results/fresh-input-and-refinement.json`: owner-only exploratory fresh-input Python candidates outside independent-review acceptance, finite-grid versus genuine local angle/CFO refinement; no browser claim

## Reproduce

Use Python 3.12 with the pinned `requirements.txt`. No paper PDF is needed to run the reference or saved-evidence checks.

```sh
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python -m unittest -v test_reference
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python -m unittest discover -s review -p 'test_*.py' -v
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python check_results.py
```

`./run_all.sh` regenerates the selected experiments and plots. It includes the source-dimension Pmax=1 capture and can take around a minute or two on the measured cloud CPU; do not interpret that as a browser guarantee. Timing fields vary across machines/runs. Numerical data and all seeds/configuration are retained.

The source-dimension generic multi-CFO explicit design would require about 2 GiB **for Phi alone** at P=2. This version does not run that case and does not promise a general full-size memory budget. Use the published bounded configurations unless deliberately extending and measuring the numerical resource envelope.

## Evidence interpretation

Every X symbol is known; CSI/target locations/counts are not given to the receiver. Reported default MUSIC rank is estimated from Y by a disclosed MDL extension. Both scientific receivers use identical Y/X and angle candidates; the conventional FFT removes known X. The literal printed Eq.63 path is retained only as a source-omission control. ICI-free observations are a synthetic counterfactual sharing the same noise, not measured hardware.

All source dimensions, reduced dimensions, numeric choices and incomplete/cap-limited states are distinguished. Conditional RMSE does not replace missed detections. The source-style FDR **formula** is used with explicitly stated one-to-one 3D matching because source association details are unspecified; the alternative conventional FDR is also included.

Source PDF/text/screenshots are private research inputs and are excluded from the portable archive. The release contains original code, numerical artifacts, analysis, and citation/hash metadata only.

The separate independent review is preserved unchanged in the archive's sibling `ofdm-ici-independent-review/` folder, so its relative paths still work. Its original top-level numerical-review command also hashes the privately retrieved PDF; to repeat that particular review command, independently retrieve the fixed PDF to `source-private.pdf` and verify SOURCE-MANIFEST.json first. The main reference, owner/source-auditor tests, saved-evidence checker and all simulation generators need no PDF. The review does not claim independent acceptance of the added six-case exploratory fresh-input benchmark.
