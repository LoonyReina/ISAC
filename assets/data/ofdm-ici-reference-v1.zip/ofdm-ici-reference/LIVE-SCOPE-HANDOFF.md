# Bounded live-port handoff (no live code or UI implemented here)

## Status and exact base

Independent Python reference core `ici_reference.py`: SHA256 `fee9e4a55707fe251f73bf343d0ac0142607d6c827cfd4e8bd0c974bba439cdb`.

Use the separate independent numerical review for its precise accepted scope. The six-case `fresh-input-and-refinement.json` benchmark is **owner-only exploratory evidence outside that independent review**. It proposes future held inputs and gives Python timing, not accepted browser fixtures or independent live acceptance. No broader claim should inherit the review's pass.

The 96 reduced Table II trials, original-dimension capped capture, 95-array held mechanism, and 16 controlled CFO pairs have independent evidence, with all false detections/caps retained. Published low-FDR curves are not reproduced.

## Recommended first port envelope

- N=64 fast samples/subcarriers, M=16 symbols, N_R=N_T=8, L=12, CP/T=0.25
- Known independent unit-energy QPSK X; single transmit stream; source unnormalized steering beam at −30 degrees
- Angle search [−80,+80] degrees in0.5-degree steps; include and flag endpoints
- CFO epsilon search [−3.5,+3.5],113 points; source theoretical CFO range is wider and must not be implied
- Fixed independent OMP budget default3, selectable1–4; never set from simulator target count
- Source illustrative normalized GLRT threshold0.3, CA-CFAR nominal Pfa1e−4, existing valid-support/unique-wrap/local-max policy
- Optional genuine local scalar refinements around up to3 CFO grid minima and selected interior angle peaks. Keep finite-grid-only mode separate. If the port only supports grids, label that limitation and validate against grid-only reference results rather than refined values
- MDL from observed Y estimates MUSIC rank; scene target count must not initialize rank, support, search domain, or stopping
- Scene controls may change target angle, delay, physical velocity/epsilon, gain/SNR, relative phase and random seed. Search budgets and inference assumptions are separately visible. Delays inside CP but outside first L taps and CFO outside the configured search are model/search-failure cases, not silently clamped truths
- First release should keep dimensions fixed. Expanding dimensions or Pmax needs new numeric, conditioning, memory, and latency measurements

This envelope is a proposed faithful computational scope. Python fresh-case timings around0.2s do not establish browser latency. Original N2048/M64/L512 one-capture evidence is offline/cap-limited and must not be relabelled as a live run.

## Required actual intermediate outputs

A fresh run must recompute the operator and every enabled algorithm stage from its accepted input revision. It must not interpolate saved curves or reconstruct maps from final detection coordinates.

1. Input contract: full accepted config, X/Y/noise seed or explicit complex samples, units, knowledge policy, nominal noise variance, effective observation count; truth held separately for evaluation
2. MUSIC: empirical complex SCM, eigenvalues, MDL score/order, angular grid/power, selected grid/continuous angles, endpoint/peak-shortfall status
3. Each angle/OMP iteration: input residual cube or a verifiable selected slice plus an accessible full export; R; every CFO grid coordinate/profile cost; local refinement seeds, results/success/evaluation count; selected Q/beamformer; absolute Eq49 and normalized Eq65 statistic; threshold/decision
4. Each accepted joint refit: complete selected CFO list; all jointly refitted time-domain channels H; joint Q/beamformer; original-Y model reconstruction; output residual; rank/condition checks; distortionless and joint-normal residuals; stop reason and explicit cap flag. Do not require full-cube residual-energy monotonicity
5. Each final CFO component: actual complex frequency channel F_L H, full RD power grid, CFAR threshold/training-count grids, selected peaks and gains, ambiguous slow-Doppler estimate, CFO alias-zone index and unwrapped estimate
6. Fair comparisons: known-X FFT maps from identical Y and angle candidates; optional synthetic ICI-free maps from identical noise/X with only D removed. Clearly label that counterfactual. Never give ordinary FFT unknown/wrong data symbols
7. Evaluation: one-to-one associations, misses, false detections, source-formula and conventional FDR where defined, conditional RMSE, caps/failures/search-boundary outcomes. Changing only display selections cannot change any numeric result

Complex arrays should preserve complex128/Float64 semantics during initial validation; explicit real/imag arrays and shapes are acceptable. Every stage output needs accepted-input revision provenance. Run/cancel/reset/stale-result behavior and cached replay versus fresh solve must be tested separately by the integrator.

## Existing full-stage artifact

`results/mechanism-full-stages.npz` contains95 actual arrays (~2MB compressed), with explicit keys/shapes/dtypes/hash and invariants in `results/mechanism-full-stages.json`. It is fixed-input replay evidence and should be lazy-loaded when requested, not placed in normal startup assets. `export_stages.py` creates it by actual receiver rerun and exact accepted-support joint refits from the same original observation. Compact summaries remain separate.

To validate a new live kernel, compare its outputs at every stage to independently recomputed Python values and held source oracles, not merely final peak coordinates. Fixed replay agreement is necessary but insufficient: require additional independent unseen seed/parameter inputs and all boundary/negative cases before acceptance.

## Must-visible limits

- The five-target held mechanism contains a spurious fourth CFO, a cap, and a weak-target miss
- The reduced96-trial sweep has198 APES false detections; it is not a low-FDR success story
- Same-CFO/cross-angle, fractional-delay mismatch, all-one symbols, source alias-zone edge, angular endpoint, M=1 wrap, noise-only input, insufficient residual rank, out-of-search CFO, rejected target and exhausted iteration budget must remain distinct outcomes
- Source convention and source reconstruction choices are explicit in MODEL-CONTRACT.md; no source-supplied K or truth-tight bounds may be silently introduced
- No full-size converged OMP, full-paper reproduction, communications BER, calibrated Pfa, or browser latency is established
