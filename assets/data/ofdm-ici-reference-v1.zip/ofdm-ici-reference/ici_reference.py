"""Independent bounded receiver reference for arXiv:2103.15694v1.

Array layout: Y[m,l,r], X[n,m]. CFO epsilon=f_c*T*nu, delay in samples
q=B*tau. No target object reaches the receiver. Source equation locators
are in docstrings; implementation disclosures are in SOURCE-AUDIT.md.
"""
from dataclasses import dataclass, asdict
import time
import numpy as np
from scipy.optimize import minimize_scalar
from scipy.ndimage import maximum_filter

VERSION = '0.1.0'

@dataclass(frozen=True)
class Config:
    n: int = 64
    m: int = 16
    nr: int = 8
    nt: int = 8
    l: int = 12
    cp_ratio: float = .25
    bandwidth: float = 50e6
    carrier: float = 60e9
    light_speed: float = 3e8
    tx_angle_deg: float = -30.
    angle_min: float = -80.
    angle_max: float = 80.
    angle_step: float = .5
    cfo_min: float = -3.5
    cfo_max: float = 3.5
    cfo_points: int = 113
    refine: bool = True
    refinement_starts: int = 3
    music_order: int | None = None
    max_omp: int = 3
    normalized_threshold: float = .3
    pfa: float = 1e-4
    cfar_guard: tuple = (1,1)
    cfar_train: tuple = (4,4)
    rank_rtol: float = 1e-11

    def __post_init__(self):
        if not (2 <= self.n and 1 <= self.m and 2 <= self.nr and 1 <= self.nt):
            raise ValueError('Invalid observation dimensions')
        if not (1 <= self.l < self.n and self.l <= self.n*self.cp_ratio):
            raise ValueError('Finite L must be positive, below N, and within CP')
        if not (0 < self.pfa < 1 and 0 < self.normalized_threshold < 1):
            raise ValueError('Invalid detection thresholds')
        if not (self.cfo_min < self.cfo_max and self.cfo_min >= -self.n/2 and self.cfo_max <= self.n/2 and self.cfo_points >= 3):
            raise ValueError('CFO domain outside Eq.34 principal interval')
        if not (0 < self.max_omp <= self.n//self.l):
            raise ValueError('OMP cap violates necessary source LP<=N condition')
        if self.music_order is not None and not 0 <= self.music_order < self.nr:
            raise ValueError('Invalid declared MUSIC order')
        if not (-90 < self.angle_min < self.angle_max < 90 and self.angle_step>0):
            raise ValueError('Invalid angle search domain')

    @property
    def rho(self): return 1+self.cp_ratio
    @property
    def t(self): return self.n/self.bandwidth
    @property
    def range_step(self): return self.light_speed/(2*self.bandwidth)
    @property
    def velocity_per_epsilon(self): return self.light_speed/(2*self.carrier*self.t)
    @property
    def slow_epsilon_period(self): return 1/self.rho


def steering(degrees, count):
    """Eqs.(3),(4): unnormalized half-wavelength ULA, positive phase."""
    return np.exp(1j*np.pi*np.arange(count)*np.sin(np.deg2rad(degrees)))


def qpsk(cfg, seed):
    r=np.random.default_rng(seed)
    return np.exp(1j*(np.pi/4+np.pi/2*r.integers(0,4,(cfg.n,cfg.m))))


def simulate(cfg, x, targets, noise_variance, seed, ici=True, noise=None):
    """Eq.(10); target fields delay_samples, epsilon, angle_deg, alpha.
    sigma^2=E|Z|^2 per complex antenna/time sample, not post-beamforming SNR.
    f_T=a_T*(-30deg), without normalization as in source Section V.
    """
    x=np.asarray(x,complex)
    if x.shape != (cfg.n,cfg.m): raise ValueError('X shape mismatch')
    y=np.zeros((cfg.m,cfg.n,cfg.nr),complex)
    n=np.arange(cfg.n); m=np.arange(cfg.m)
    for target in targets:
        q=float(target['delay_samples']); ep=float(target['epsilon'])
        if not 0 <= q <= cfg.n*cfg.cp_ratio:
            raise ValueError('Delay exceeds CP model')
        a=steering(target['angle_deg'],cfg.nr)
        tx=steering(target['angle_deg'],cfg.nt) @ steering(cfg.tx_angle_deg,cfg.nt).conj()
        b=np.exp(-2j*np.pi*n*q/cfg.n)
        slow=np.exp(2j*np.pi*ep*cfg.rho*m)
        fast=np.exp(2j*np.pi*ep*n/cfg.n) if ici else np.ones(cfg.n)
        wave=np.fft.ifft(x*b[:,None]*slow[None,:],axis=0,norm='ortho')*fast[:,None]
        y += (target['alpha']*tx)*wave.T[:,:,None]*a[None,None,:]
    if noise is None:
        rng=np.random.default_rng(seed)
        noise=np.sqrt(noise_variance/2)*(rng.standard_normal(y.shape)+1j*rng.standard_normal(y.shape))
    noise=np.asarray(noise,complex)
    if noise.shape != y.shape: raise ValueError('Noise shape mismatch')
    return y+noise,noise


def covariance(y):
    return np.einsum('mni,mnj->ij',y.conj(),y,optimize=True)


def _hermitian(a): return (a+a.conj().T)/2


def _constrained(q,a,rtol):
    """min v^H Q v, a^T v=1. Eq.(28) uses v=w*. Strict inverse scope.
    Rank failures are returned rather than silently diagonal-loading or pinv.
    """
    q=_hermitian(q)
    eig=np.linalg.eigvalsh(q)
    scale=max(float(eig[-1]),np.finfo(float).tiny)
    if eig[0] <= rtol*scale:
        return {'ok':False,'reason':'rank_deficient_covariance','min_eigenvalue':float(eig[0]),'max_eigenvalue':float(eig[-1]),'cost':None,'condition':None},None
    z=np.linalg.solve(q,a.conj())
    denom=float(np.real(a@z))
    if not np.isfinite(denom) or denom<=0:
        return {'ok':False,'reason':'invalid_constraint_denominator','cost':None},None
    v=z/denom
    return {'ok':True,'cost':1/denom,'condition':float(eig[-1]/eig[0]),'min_eigenvalue':float(eig[0]),'max_eigenvalue':float(eig[-1])},v


def music(y,cfg):
    """Eqs.(15),(19). Data-driven MDL is an explicit operational extension.
    A supplied music_order is a declared source-style assumed subspace order,
    never obtained from target truth. Same angles feed both receiver families.
    """
    r=covariance(y); ev,u=np.linalg.eigh(_hermitian(r)); vals=np.maximum(ev[::-1],np.finfo(float).tiny)
    snapshots=cfg.n*cfg.m; mdl=[]
    for k in range(cfg.nr):
        tail=vals[k:]; geo=np.mean(np.log(tail)); ari=np.log(np.mean(tail))
        mdl.append(float(-snapshots*(cfg.nr-k)*(geo-ari)+.5*k*(2*cfg.nr-k)*np.log(snapshots)))
    order=int(np.argmin(mdl)) if cfg.music_order is None else cfg.music_order
    un=u[:,:cfg.nr-order]
    def val(th):
        a=steering(th,cfg.nr)
        return 1/max(float(np.linalg.norm(un.conj().T@a.conj())**2),1e-300)
    grid=np.arange(cfg.angle_min,cfg.angle_max+cfg.angle_step*.1,cfg.angle_step)
    spectrum=np.array([val(t) for t in grid])
    peakidx=[i for i in range(len(grid)) if (i==0 or spectrum[i]>=spectrum[i-1]) and (i==len(grid)-1 or spectrum[i]>spectrum[i+1])]
    ranked=sorted(peakidx,key=lambda i:spectrum[i],reverse=True)[:order]
    records=[]; angles=[]
    for i in ranked:
        th=float(grid[i]); record={'grid_angle':th,'grid_power':float(spectrum[i]),'refined':False,'at_search_boundary':i in (0,len(grid)-1)}
        if cfg.refine and 0<i<len(grid)-1:
            opt=minimize_scalar(lambda a:-val(a),bounds=(grid[i-1],grid[i+1]),method='bounded',options={'xatol':1e-8})
            record.update(success=bool(opt.success),nfev=int(opt.nfev),refined_angle=float(opt.x),message=str(opt.message))
            if opt.success and -opt.fun>=spectrum[i]: th=float(opt.x); record['refined']=True
        angles.append(th); records.append(record)
    return {'angles':angles,'order':order,'order_policy':'MDL-extension' if cfg.music_order is None else 'declared-source-style-order','eigenvalues':ev.tolist(),'mdl':mdl,'angle_grid':grid.tolist(),'spectrum':spectrum.tolist(),'peaks':records,'unresolved_peak_count':max(0,order-len(angles))}


class PilotProjector:
    """Eq.(22). QPSK uses exact FFT factorization; general X uses QR.
    Optimization preserves the source subspace. No ridge or truth support.
    """
    def __init__(self,x,cfg):
        self.x=np.asarray(x,complex); self.cfg=cfg
        self.constant_modulus=bool(np.allclose(np.abs(self.x),1,rtol=1e-12,atol=1e-12))
        n=np.arange(cfg.n)
        self.fnl=np.exp(-2j*np.pi*n[:,None]*np.arange(cfg.l)[None,:]/cfg.n)/np.sqrt(cfg.n)
        self.explicit=None; self.qr=None
        if not self.constant_modulus:
            self.explicit=self.matrices()
            self.qr=[]
            for p in self.explicit:
                q,r=np.linalg.qr(p,mode='reduced')
                if np.linalg.matrix_rank(r,tol=cfg.rank_rtol*np.linalg.norm(r,2))<cfg.l:
                    raise ValueError('Rank-deficient known pilot design')
                self.qr.append((q,r))

    def matrices(self):
        if self.explicit is None:
            return np.fft.ifft(self.x.T[:,:,None]*self.fnl[None,:,:],axis=1,norm='ortho')
        return self.explicit

    def analyze(self,v):
        if self.constant_modulus:
            return np.fft.ifft(np.fft.fft(v,axis=1,norm='ortho')*self.x.T.conj()[:,:,None],axis=1,norm='ortho')[:,:self.cfg.l,:]
        return np.array([np.linalg.solve(r,q.conj().T@vm) for (q,r),vm in zip(self.qr,v)])

    def synthesize(self,h):
        if self.constant_modulus:
            pad=np.zeros((self.cfg.m,self.cfg.n,h.shape[2]),complex); pad[:,:self.cfg.l]=h
            return np.fft.ifft(np.fft.fft(pad,axis=1,norm='ortho')*self.x.T[:,:,None],axis=1,norm='ortho')
        return np.einsum('mnl,mlr->mnr',self.explicit,h,optimize=True)

    def residual(self,v): return v-self.synthesize(self.analyze(v))


def cfo_search(y,a,pilot,cfg):
    """Eqs.(27),(29),(46),(47). Bounded grid or genuine continuous local
    refinement around top grid peaks. Every failure and optimizer outcome kept.
    """
    fast=np.arange(cfg.n)/cfg.n; records=[]
    def evaluate(ep,kind):
        comp=y*np.exp(-2j*np.pi*ep*fast)[None,:,None]
        resid=pilot.residual(comp)
        info,_=_constrained(covariance(resid),a,cfg.rank_rtol)
        record={'epsilon':float(ep),'kind':kind,**info}; records.append(record)
        return float(info['cost']) if info['ok'] else float('inf')
    grid=np.linspace(cfg.cfo_min,cfg.cfo_max,cfg.cfo_points)
    costs=np.array([evaluate(ep,'grid') for ep in grid])
    valid=np.flatnonzero(np.isfinite(costs)); refinements=[]
    if not len(valid): return {'ok':False,'reason':'all_cfo_covariances_rank_failed','evaluations':records,'refinements':[]}
    best=int(valid[np.argmin(costs[valid])]); chosen=float(grid[best]); minimum=float(costs[best]); grid_best=chosen
    if cfg.refine:
        local=[i for i in range(1,len(grid)-1) if np.isfinite(costs[i]) and costs[i]<=costs[i-1] and costs[i]<=costs[i+1]]
        for i in sorted(local,key=lambda j:costs[j])[:cfg.refinement_starts]:
            opt=minimize_scalar(lambda ep:evaluate(ep,'continuous'),bounds=(grid[i-1],grid[i+1]),method='bounded',options={'xatol':1e-7,'maxiter':80})
            refinements.append({'seed_grid_epsilon':float(grid[i]),'epsilon':float(opt.x),'cost':float(opt.fun) if np.isfinite(opt.fun) else None,'success':bool(opt.success),'nfev':int(opt.nfev),'message':str(opt.message)})
            if opt.success and opt.fun<minimum: chosen=float(opt.x); minimum=float(opt.fun)
    return {'ok':True,'epsilon':chosen,'cost':minimum,'grid_best_epsilon':grid_best,'grid_best_cost':float(costs[best]),'at_search_boundary':chosen in (cfg.cfo_min,cfg.cfo_max),'evaluations':records,'refinements':refinements}


def joint_refit(y,a,eps,pilot,cfg):
    """Eqs.(50)–(57): recompute channels against ORIGINAL Y after every
    accepted CFO; subtract all atoms jointly. Single atom uses exact FFT path.
    """
    p=len(eps); fast=np.arange(cfg.n)/cfg.n
    if p*cfg.l>=cfg.n:
        return {'ok':False,'reason':'no_nullspace_at_LP_ge_N','p':p,'lp':p*cfg.l},None,None
    if p==1:
        phase=np.exp(2j*np.pi*eps[0]*fast)
        comp=y*phase.conj()[None,:,None]
        raw=pilot.analyze(comp); null=pilot.residual(comp)
        info,v=_constrained(covariance(null),a,cfg.rank_rtol)
        if not info['ok']: return info,None,None
        h=np.einsum('mlr,r->ml',raw,v)[None,:,:]
        model=pilot.synthesize(h[0,:,:,None])[:,:,0]*phase[None,:]
        residue=y-model[:,:,None]*a[None,None,:]
        return {**info,'p':p,'lp':cfg.l,'pilot_condition_max':1. if pilot.constant_modulus else None,'beamformer_constraint_error':float(abs(a@v-1))},h,residue
    xmat=pilot.matrices()
    phis=np.concatenate([xmat*np.exp(2j*np.pi*ep*fast)[None,:,None] for ep in eps],axis=2)
    qs=[]; rs=[]; projected=[]; nulls=[]; conds=[]
    for phi,ym in zip(phis,y):
        q,r=np.linalg.qr(phi,mode='reduced'); sv=np.linalg.svd(r,compute_uv=False)
        if sv[-1]<=cfg.rank_rtol*sv[0]:
            return {'ok':False,'reason':'rank_deficient_joint_pilot','p':p,'min_singular':float(sv[-1]),'max_singular':float(sv[0])},None,None
        qs.append(q); rs.append(r); projected.append(q.conj().T@ym); nulls.append(ym-q@(q.conj().T@ym)); conds.append(float(sv[0]/sv[-1]))
    info,v=_constrained(covariance(np.array(nulls)),a,cfg.rank_rtol)
    if not info['ok']: return info,None,None
    channels=np.array([np.linalg.solve(r,pr@v) for r,pr in zip(rs,projected)])
    models=np.einsum('mnl,ml->mn',phis,channels,optimize=True)
    residue=y-models[:,:,None]*a[None,None,:]
    h=channels.reshape(cfg.m,p,cfg.l).transpose(1,0,2)
    return {**info,'p':p,'lp':p*cfg.l,'pilot_condition_max':max(conds),'beamformer_constraint_error':float(abs(a@v-1))},h,residue


def omp(y,angle,x,cfg,noise_variance=1.):
    """Algorithm 2. Source Fig.5/Eq.65 normalized heuristic threshold .3;
    retain Eq.49 absolute statistic too. Pmax is a fixed resource cap.
    """
    pilot=PilotProjector(x,cfg); a=steering(angle,cfg.nr); residual=y.copy(); eps=[]; traces=[]; h=None
    stop='iteration_cap'
    for iteration in range(cfg.max_omp):
        pre,v0=_constrained(covariance(residual),a,cfg.rank_rtol)
        trace={'iteration':iteration,'residual_energy':float(np.linalg.norm(residual)**2),'capon':pre}
        if not pre['ok']: trace['accepted']=False; traces.append(trace); stop=pre['reason']; break
        search=cfo_search(residual,a,pilot,cfg); trace['search']=search
        if not search['ok']: trace['accepted']=False; traces.append(trace); stop=search['reason']; break
        normalized=1-search['cost']/pre['cost']; glrt=(pre['cost']-search['cost'])/noise_variance
        trace.update(normalized_statistic=float(normalized),glrt_log_statistic=float(glrt),accepted=False)
        if normalized<=cfg.normalized_threshold: traces.append(trace); stop='threshold'; break
        candidate=search['epsilon']
        # Duplicate support would make Phi rank deficient; report, do not hide it.
        fit,h_new,res_new=joint_refit(y,a,eps+[candidate],pilot,cfg); trace['joint_refit']=fit
        if not fit['ok']: traces.append(trace); stop=fit['reason']; break
        eps.append(candidate); h=h_new; residual=res_new; trace['accepted']=True
        trace['updated_residual_energy']=float(np.linalg.norm(residual)**2)
        trace['joint_fit_cost']=fit['cost']; traces.append(trace)
    return {'angle_deg':float(angle),'epsilons':eps,'stop_reason':stop,'cap_reached':stop=='iteration_cap','traces':traces,'channels':h,'residual':residual}


def rd_map(channel):
    """Eqs.(32),(61): b^H H_FS c, with positive slow-time Doppler.
    Output unshifted q row, fftshifted slow-frequency column; absolute power.
    """
    n,m=channel.shape
    z=np.fft.fftshift(np.fft.fft(np.fft.ifft(channel,axis=0)*n,axis=1),axes=1)
    return abs(z)**2/(n*m)


def ca_cfar(power,cfg):
    """Algorithm 3: explicit operational CA-CFAR choices absent from source.
    Search known delay support [0,L); same mask/window/Pfa for all methods.
    Range edge uses available cells, Doppler wraps; guard excluded. CFAR
    nominal iid exponential multiplier does NOT certify achieved Pfa here.
    """
    l=cfg.l; m=cfg.m; gq,gd=cfg.cfar_guard; tq,td=cfg.cfar_train
    valid=power[:l,:]; cuts=[]; threshold=np.full(valid.shape,np.nan); training=np.zeros(valid.shape,int)
    for q in range(l):
        for d in range(m):
            cells=set()
            for qi in range(max(0,q-tq),min(l,q+tq+1)):
                for dd in range(-td,td+1):
                    di=(d+dd)%m
                    delta=min((di-d)%m,(d-di)%m)
                    if abs(qi-q)<=gq and delta<=gd: continue
                    cells.add((qi,di))
            count=len(cells); training[q,d]=count
            if not count: continue
            mean=np.mean([valid[qi,di] for qi,di in cells]); multiplier=count*np.expm1(-np.log(cfg.pfa)/count)
            threshold[q,d]=mean*multiplier
            if valid[q,d] <= threshold[q,d]: continue
            neighbor_cells={(qi,(d+dd)%m) for qi in range(max(0,q-1),min(l,q+2)) for dd in (-1,0,1)}
            neighbor_cells.discard((q,d))
            neighbors=[valid[qi,di] for qi,di in neighbor_cells]
            if neighbors and valid[q,d] <= max(neighbors): continue
            cuts.append({'delay_samples':float(q),'slow_bin':int(d),'power':float(valid[q,d]),'threshold':float(threshold[q,d]),'training_cells':count})
    return cuts,threshold,training


def unwrap_source(epsilon_ambiguous,epsilon_cfo,cfg):
    """Literal Eq.(36), in epsilon units. The potential boundary sensitivity
    is documented/tested, not quietly replaced by nearest-alias rounding.
    """
    period=cfg.slow_epsilon_period
    return epsilon_ambiguous+period*np.floor((epsilon_cfo+period/2)/period)


def recover(channel,cfg,angle,cfo=None):
    p=rd_map(channel); cuts,threshold,training=ca_cfar(p,cfg); detections=[]
    slow=np.fft.fftshift(np.fft.fftfreq(cfg.m))/cfg.rho
    for cut in cuts:
        q=int(cut['delay_samples']); d=cut['slow_bin']; amb=float(slow[d]); ep=amb if cfo is None else float(unwrap_source(amb,cfo,cfg))
        b=np.exp(-2j*np.pi*np.arange(cfg.n)*q/cfg.n)
        c=np.exp(-2j*np.pi*amb*cfg.rho*np.arange(cfg.m))
        gain=b.conj()@channel@c/(cfg.n*cfg.m)
        detections.append({**cut,'angle_deg':float(angle),'epsilon_ambiguous':amb,'epsilon':ep,'cfo_epsilon':cfo,'range_m':q*cfg.range_step,'velocity_mps':ep*cfg.velocity_per_epsilon,'gain_real':float(gain.real),'gain_imag':float(gain.imag)})
    return {'detections':detections,'power':p,'threshold':threshold,'training_cells':training}


def fft_baseline(y,x,angles,cfg,divide_known_symbols=True):
    """Source Eqs.(62),(63), plus explicitly disclosed known-X division.
    Literal printed route retained with divide_known_symbols=False; it is not
    the scientific comparator because known arbitrary QPSK would mask peaks.
    Unnormalized beamforming matches source; CA-CFAR is scale invariant.
    """
    detections=[]; maps=[]
    for angle in angles:
        projected=np.einsum('mnr,r->nm',y,steering(angle,cfg.nr).conj(),optimize=True)
        fs=np.fft.fft(projected,axis=0,norm='ortho')
        if divide_known_symbols:
            if np.any(abs(x)<1e-12): raise ValueError('Cannot divide nulled known symbols')
            fs=fs/x
        rec=recover(fs,cfg,angle); detections+=rec['detections']; maps.append(rec)
    return {'detections':detections,'maps':maps,'known_symbol_demodulation':divide_known_symbols}


def receive(y,x,cfg,noise_variance=1.,shared_music=None):
    """Actual Algorithms 1–3 bounded receiver. Truth is not an argument."""
    start=time.perf_counter(); mus=music(y,cfg) if shared_music is None else shared_music
    stages={'music_s':time.perf_counter()-start}; outputs=[]; detections=[]; t=time.perf_counter()
    for angle in mus['angles']:
        out=omp(y,angle,x,cfg,noise_variance); outputs.append(out)
        out['recoveries']=[]
        if out['channels'] is not None:
            fnl=PilotProjector(x,cfg).fnl
            for ep,h in zip(out['epsilons'],out['channels']):
                fs=fnl@h.T; rec=recover(fs,cfg,angle,ep)
                detections+=rec['detections']; out['recoveries'].append(rec)
    stages['apes_omp_and_recovery_s']=time.perf_counter()-t; stages['total_s']=time.perf_counter()-start
    return {'config':asdict(cfg),'music':mus,'angles':outputs,'detections':detections,'timing':stages}


def jsonable(value):
    """All numeric failures become explicit nulls; no dropped trials."""
    if isinstance(value,np.ndarray):
        if np.iscomplexobj(value): return {'shape':list(value.shape),'real':value.real.tolist(),'imag':value.imag.tolist()}
        return jsonable(value.tolist())
    if isinstance(value,dict): return {k:jsonable(v) for k,v in value.items()}
    if isinstance(value,(list,tuple)): return [jsonable(v) for v in value]
    if isinstance(value,(np.integer,)):return int(value)
    if isinstance(value,(np.floating,float)):return float(value) if np.isfinite(value) else None
    if isinstance(value,(np.bool_,)):return bool(value)
    return value
