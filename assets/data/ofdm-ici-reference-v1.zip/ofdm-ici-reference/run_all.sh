#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
python -m unittest -v test_reference
python -m unittest discover -s review -p 'test_*.py' -v
python review/audit_probes.py
python run_experiments.py mechanism
python run_experiments.py bounded --trials 8
python run_experiments.py holdout --trials 64
python benchmark_source.py
python export_stages.py
python controlled_cfo_comparison.py
python benchmark_small_and_refinement.py
python summarize_uncertainty.py
python check_results.py
python plot_results.py
