"""Small independent implementation tests: direct oscillators and full KKT oracle."""
from dataclasses import replace
from pathlib import Path
import sys
import unittest
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import ici_reference as receiver


def cn(rng,shape):
    return (rng.normal(size=shape)+1j*rng.normal(size=shape))/np.sqrt(2)


def dft(n):
    # Explicit independent definition: not receiver's FFT/fnl helper.
    return np.array([[np.exp(-2j*np.pi*j*k/n)/np.sqrt(n) for k in range(n)] for j in range(n)])


def full_kkt(y,phis,a):
    """Direct simultaneous constrained LS over spatial beam and all channels.

    No null-projector profiling or receiver helper is used. This oracle solves
    [Y -blockdiag(Phi)]^H[Y -blockdiag(Phi)] with one linear constraint.
    """
    m,n,nr=y.shape
    pl=phis[0].shape[1]
    design=np.zeros((m*n,nr+m*pl),complex)
    for j in range(m):
        design[j*n:(j+1)*n,:nr]=y[j]
        design[j*n:(j+1)*n,nr+j*pl:nr+(j+1)*pl]=-phis[j]
    constraint=np.r_[a,np.zeros(m*pl)]
    gram=design.conj().T@design
    kkt=np.block([[gram,constraint.conj()[:,None]],[constraint[None,:],np.zeros((1,1))]])
    answer=np.linalg.solve(kkt,np.r_[np.zeros(gram.shape[0]),1])[:-1]
    v=answer[:nr]
    h=answer[nr:].reshape(m,pl)
    cost=np.linalg.norm(design@answer)**2
    residual=np.array([ym-(ph@hm)[:,None]*a[None,:] for ym,ph,hm in zip(y,phis,h)])
    return v,h,float(cost),residual


class IndependentReceiverAudit(unittest.TestCase):
    def setUp(self):
        self.cfg=receiver.Config(n=24,m=5,nr=3,nt=2,l=4,max_omp=3,cfo_points=9,refine=False,
            cfo_min=-1.5,cfo_max=1.5,cfar_train=(2,2),cfar_guard=(0,0))
        self.rng=np.random.default_rng(426035)
        self.x=np.exp(.5j*np.pi*self.rng.integers(0,4,(self.cfg.n,self.cfg.m)))
        self.a=np.exp(1j*np.pi*np.arange(self.cfg.nr)*np.sin(-.39))
        self.f=dft(self.cfg.n)

    def pilot(self,x):
        return [self.f.conj().T@np.diag(x[:,m])@self.f[:,:self.cfg.l] for m in range(self.cfg.m)]

    def atoms(self,x,eps):
        pp=self.pilot(x)
        return [np.column_stack([np.exp(2j*np.pi*ep*np.arange(self.cfg.n)/self.cfg.n)[:,None]*p for ep in eps]) for p in pp]

    def test_qpsk_and_qam_joint_full_kkt_oracle(self):
        for amplitudes in (np.ones(self.x.shape), .5+self.rng.random(self.x.shape)):
            with self.subTest(constant_modulus=bool(np.all(amplitudes==1))):
                x=self.x*amplitudes
                eps=[-.47,.84]
                phis=self.atoms(x,eps)
                htrue=cn(self.rng,(self.cfg.m,2*self.cfg.l))
                y=np.array([(p@h)[:,None]*self.a for p,h in zip(phis,htrue)])+.2*cn(self.rng,(self.cfg.m,self.cfg.n,self.cfg.nr))
                v,h,cost,residual=full_kkt(y,phis,self.a)
                info,actual_h,actual_residual=receiver.joint_refit(y,self.a,eps,receiver.PilotProjector(x,self.cfg),self.cfg)
                self.assertTrue(info['ok'])
                np.testing.assert_allclose(actual_h.transpose(1,0,2).reshape(self.cfg.m,-1),h,atol=2e-11,rtol=2e-11)
                np.testing.assert_allclose(actual_residual,residual,atol=2e-11,rtol=2e-11)
                self.assertAlmostEqual(info['cost'],cost,places=10)
                self.assertLess(abs(self.a@v-1),1e-12)

    def test_single_cfo_profile_matches_full_kkt_grid(self):
        y=cn(self.rng,(self.cfg.m,self.cfg.n,self.cfg.nr))
        search=receiver.cfo_search(y,self.a,receiver.PilotProjector(self.x,self.cfg),self.cfg)
        costs=[]
        for evaluation in search['evaluations']:
            _,_,cost,_=full_kkt(y,self.atoms(self.x,[evaluation['epsilon']]),self.a)
            costs.append(cost)
            self.assertAlmostEqual(evaluation['cost'],cost,places=10)
        self.assertEqual(search['epsilon'],search['evaluations'][int(np.argmin(costs))]['epsilon'])

    def test_fft_pilot_analysis_and_synthesis_direct_definitions(self):
        p=receiver.PilotProjector(self.x,self.cfg)
        sample=cn(self.rng,(self.cfg.m,self.cfg.n,self.cfg.nr))
        coeff=cn(self.rng,(self.cfg.m,self.cfg.l,self.cfg.nr))
        dense=self.pilot(self.x)
        np.testing.assert_allclose(p.matrices(),dense,atol=5e-15)
        np.testing.assert_allclose(p.analyze(sample),np.array([d.conj().T@y for d,y in zip(dense,sample)]),atol=2e-14)
        np.testing.assert_allclose(p.synthesize(coeff),np.array([d@h for d,h in zip(dense,coeff)]),atol=2e-14)

    def test_sample_model_mixed_sign_targets_and_common_noise(self):
        targets=[dict(delay_samples=1.7,epsilon=-.8,angle_deg=-25.,alpha=.6-.2j),dict(delay_samples=3.,epsilon=.34,angle_deg=17.,alpha=-.3+.5j)]
        for ici in (True,False):
            y,noise=receiver.simulate(self.cfg,self.x,targets,.5,718,ici=ici)
            expected=np.zeros_like(y)
            for t in targets:
                for m in range(self.cfg.m):
                    for ell in range(self.cfg.n):
                        tx=sum(np.exp(1j*np.pi*k*(np.sin(np.deg2rad(t['angle_deg']))-np.sin(np.deg2rad(self.cfg.tx_angle_deg)))) for k in range(self.cfg.nt))
                        slow=np.exp(2j*np.pi*t['epsilon']*self.cfg.rho*m)
                        fast=np.exp(2j*np.pi*t['epsilon']*ell/self.cfg.n) if ici else 1
                        wave=sum(self.x[k,m]*np.exp(2j*np.pi*k*(ell-t['delay_samples'])/self.cfg.n) for k in range(self.cfg.n))/np.sqrt(self.cfg.n)
                        expected[m,ell]=t['alpha']*tx*slow*fast*wave*np.exp(1j*np.pi*np.arange(self.cfg.nr)*np.sin(np.deg2rad(t['angle_deg'])))+expected[m,ell]
            np.testing.assert_allclose(y,expected+noise,atol=5e-14)

    def test_signed_rd_map_and_complex_gain(self):
        cfg=replace(self.cfg,cfar_train=(3,2),cfar_guard=(0,0))
        for k in (-2,-1,0,1,2):
            q=2; gain=.7+.9j
            b=np.exp(-2j*np.pi*np.arange(cfg.n)*q/cfg.n)
            slow=np.exp(2j*np.pi*np.arange(cfg.m)*k/cfg.m)
            channel=gain*np.outer(b,slow)
            result=receiver.recover(channel,cfg,-22.)
            self.assertEqual(len(result['detections']),1)
            d=result['detections'][0]
            self.assertEqual(d['delay_samples'],q)
            self.assertAlmostEqual(d['epsilon_ambiguous'],k/(cfg.m*cfg.rho),places=12)
            self.assertAlmostEqual(abs(complex(d['gain_real'],d['gain_imag'])-gain),0,places=12)
            self.assertAlmostEqual(d['power'],cfg.n*cfg.m*abs(gain)**2,places=10)

    def test_source_unwrap_positive_and_negative_zone_boundaries(self):
        period=self.cfg.slow_epsilon_period
        for zone in range(-3,4):
            for slow in (-.49*period,.12*period,.49*period):
                truth=slow+zone*period
                self.assertAlmostEqual(receiver.unwrap_source(slow,truth,self.cfg),truth,places=12)
        self.assertAlmostEqual(receiver.unwrap_source(.49*period,.51*period,self.cfg),1.49*period,places=12)
        self.assertAlmostEqual(receiver.unwrap_source(-.49*period,-.51*period,self.cfg),-1.49*period,places=12)

    def test_generalized_pilot_full_rank_rejects_insufficient_support(self):
        x=np.zeros_like(self.x); x[:self.cfg.l-1,:]=1
        with self.assertRaisesRegex(ValueError,'Rank-deficient'):
            receiver.PilotProjector(x,self.cfg)

    def test_cfar_unique_wrapped_training_and_support(self):
        cfg=replace(self.cfg,cfar_train=(20,20),cfar_guard=(0,0))
        power=np.ones((cfg.n,cfg.m)); power[cfg.l:]=0
        cuts,threshold,count=receiver.ca_cfar(power,cfg)
        self.assertFalse(cuts)
        np.testing.assert_array_equal(count,np.full((cfg.l,cfg.m),cfg.l*cfg.m-1))
        np.testing.assert_allclose(threshold,count*np.expm1(-np.log(cfg.pfa)/count))


if __name__=='__main__':
    unittest.main(verbosity=2)
