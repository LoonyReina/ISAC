#!/usr/bin/env python3
"""Independent, bounded algebra probes; does not import the receiver implementation."""
from pathlib import Path
import json
import numpy as np

RNG = np.random.default_rng(210315694)

def cnormal(shape):
    return (RNG.standard_normal(shape) + 1j * RNG.standard_normal(shape)) / np.sqrt(2)

def qpsk(shape):
    return np.exp(0.5j * np.pi * RNG.integers(0, 4, shape))

def unitary_dft(n):
    return np.exp(-2j * np.pi * np.outer(np.arange(n), np.arange(n)) / n) / np.sqrt(n)

def projection(a):
    u, s, _ = np.linalg.svd(a, full_matrices=False)
    rank = int(np.count_nonzero(s > s.max() * 1e-12)) if len(s) else 0
    return u[:, :rank] @ u[:, :rank].conj().T

def phase(n, cfo_cycles):
    return np.exp(2j * np.pi * cfo_cycles * np.arange(n) / n)

def joint_fit(y, atoms, steering):
    # y[m,n,r], atoms[m,n,pL], z=w* avoids alternating transposes.
    nr = y.shape[-1]
    qq = np.zeros((nr, nr), complex)
    for ym, am in zip(y, atoms):
        e = ym - projection(am) @ ym
        qq += e.conj().T @ e
    z = np.linalg.solve(qq, steering.conj())
    z /= steering.T @ z
    hs = np.array([np.linalg.lstsq(am, ym @ z, rcond=None)[0] for ym, am in zip(y, atoms)])
    residual = y - np.einsum('mnl,ml,r->mnr', atoms, hs, steering)
    objective = float(sum(np.linalg.norm(rm @ z) ** 2 for rm in residual))
    orth = float(max(np.linalg.norm(am.conj().T @ rm @ z) for am, rm in zip(atoms, residual)))
    return hs, z, residual, objective, orth


def main():
    out = {}
    n, m, l, nr = 32, 16, 6, 4
    f = unitary_dft(n)
    fl = f[:, :l]
    x = qpsk((n, m))
    delay_bin, doppler_bin = 3, 4
    b = np.exp(-2j * np.pi * np.arange(n) * delay_bin / n)
    c = np.exp(-2j * np.pi * np.arange(m) * doppler_bin / m)
    g = np.outer(b, c.conj())
    ici = phase(n, 1.125)
    y = ici[:, None] * (f.conj().T @ (x * g))
    # Equation 5 direct oscillator sum, independent from the matrix construction.
    y_direct = np.empty_like(y)
    for sample in range(n):
        y_direct[sample] = (
            np.sum(x * b[:, None] * np.exp(2j*np.pi*np.arange(n)*sample/n)[:,None], axis=0)
            / np.sqrt(n) * ici[sample] * c.conj()
        )
    out['equation5_vs10_relative_error'] = float(np.linalg.norm(y-y_direct)/np.linalg.norm(y))
    assert out['equation5_vs10_relative_error'] < 1e-12
    assert np.isclose(np.linalg.norm(y),np.linalg.norm(x*g))
    out['unitary_dft_and_ici_energy_preserved'] = True

    maps = {}
    for name, matrix in [('literal_eq63', x*g), ('known_x_reconstruction', (x*g)/x)]:
        rd = np.fft.fft(np.fft.ifft(matrix,axis=0,norm='ortho'),axis=1,norm='ortho')
        power = np.abs(rd)**2
        maps[name] = {'peak_bin':list(map(int,np.unravel_index(power.argmax(),power.shape))),
                      'true_bin_power_fraction':float(power[delay_bin,doppler_bin]/power.sum())}
    out['baseline_ambiguity'] = maps
    assert maps['known_x_reconstruction']['peak_bin'] == [delay_bin,doppler_bin]
    assert maps['known_x_reconstruction']['true_bin_power_fraction'] > 1-1e-12
    assert maps['literal_eq63']['true_bin_power_fraction'] < 0.1

    fraction = 3.37
    b_off = np.exp(-2j*np.pi*np.arange(n)*fraction/n)
    out['finite_tap_span'] = {
        'on_grid_relative_projection_error':float(np.linalg.norm(b-fl@(fl.conj().T@b))/np.linalg.norm(b)),
        'off_grid_relative_projection_error':float(np.linalg.norm(b_off-fl@(fl.conj().T@b_off))/np.linalg.norm(b_off)),
        'delay_bins_inside_cp':True,
    }
    assert out['finite_tap_span']['on_grid_relative_projection_error'] < 1e-12
    assert out['finite_tap_span']['off_grid_relative_projection_error'] > 0.05

    # Correct covariance for known, fixed beam and unit-modulus symbols.
    a = np.exp(1j*np.pi*np.arange(nr)*np.sin(np.deg2rad(-25)))
    z = a.conj()/nr
    spatial_variance_factor = float(np.vdot(z,z).real)
    freq_covariance = spatial_variance_factor * fl @ fl.conj().T
    offdiag = freq_covariance - np.diag(np.diag(freq_covariance))
    delay_covariance = f.conj().T @ freq_covariance @ f
    out['noise_model'] = {
        'post_beam_variance_over_original_sigma2':spatial_variance_factor,
        'frequency_noise_covariance_rank':int(np.linalg.matrix_rank(freq_covariance,tol=1e-10)),
        'frequency_noise_offdiagonal_relative_norm':float(np.linalg.norm(offdiag)/np.linalg.norm(freq_covariance)),
        'outside_tap_delay_noise_covariance_norm':float(np.linalg.norm(delay_covariance[l:,l:])),
    }
    assert out['noise_model']['frequency_noise_covariance_rank'] == l
    assert out['noise_model']['outside_tap_delay_noise_covariance_norm'] < 1e-12

    # Supplement Eq.76 expected diagonal follows trace/N, not the printed addition.
    dn = phase(n, 0.45)
    sigma_x2 = 2.3
    lhs = sigma_x2*np.eye(n)*(f @ np.diag(dn) @ f.conj().T)
    correct = sigma_x2*np.sum(dn)/n*np.eye(n)
    printed = (sigma_x2+np.sum(dn))*np.eye(n)
    out['supplement_eq76'] = {
        'correct_relative_error':float(np.linalg.norm(lhs-correct)/np.linalg.norm(lhs)),
        'printed_relative_error':float(np.linalg.norm(lhs-printed)/np.linalg.norm(lhs)),
    }
    assert out['supplement_eq76']['correct_relative_error'] < 1e-12

    # All-one pilot degeneracy is structural, not a numerical accident.
    xbar_ones = f.conj().T @ fl
    spans = [projection(phase(n,e)[:,None]*xbar_ones) for e in (-3.5,0,2.25)]
    out['all_one_symbols_cfo_span_max_difference'] = float(max(np.linalg.norm(q-spans[0]) for q in spans))
    assert out['all_one_symbols_cfo_span_max_difference'] < 1e-11

    # P=N/L can erase all remaining dimensions even when every CFO is distinct.
    leq, peq = 8, 4
    xb = f.conj().T @ np.diag(x[:,0]) @ f[:,:leq]
    phi = np.concatenate([phase(n,e)[:,None]*xb for e in (-3.4,-1.2,1.3,4.1)],axis=1)
    out['equality_rank_bound'] = {
        'N':n,'L':leq,'P':peq,'rank_phi':int(np.linalg.matrix_rank(phi)),
        'null_projector_norm':float(np.linalg.norm(np.eye(n)-projection(phi))),
    }
    assert out['equality_rank_bound']['rank_phi'] == n
    assert out['equality_rank_bound']['null_projector_norm'] < 1e-11

    # Beamformed joint LS normal equations and profile cost nesting.
    xbars = np.array([f.conj().T@np.diag(x[:,j])@fl for j in range(m)])
    blocks = [phase(n,e)[None,:,None]*xbars for e in (-0.3,1.1)]
    atoms2 = np.concatenate(blocks,axis=2)
    htrue = cnormal((m,2*l))
    ycube = np.einsum('mnl,ml,r->mnr',atoms2,htrue,a) + 0.3*cnormal((m,n,nr))
    h1,z1,r1,j1,o1 = joint_fit(ycube,blocks[0],a)
    h2,z2,r2,j2,o2 = joint_fit(ycube,atoms2,a)
    # A deliberately incorrect matching-pursuit update: fit newest block to old residual.
    hwrong,zw,rwrong,jwrong,owrong = joint_fit(r1,blocks[1],a)
    wrong_joint_orth = max(np.linalg.norm(am.conj().T@rm@zw) for am,rm in zip(atoms2,rwrong))
    out['joint_refit_and_residual'] = {
        'first_profile_cost':j1,'second_profile_cost':j2,
        'joint_normal_equation_max_error':o2,
        'sequential_only_normal_equation_error':float(wrong_joint_orth),
        'constraint_error':float(abs(a.T@z2-1)),
        'residual_rebuilt_from_original_error':float(np.linalg.norm(r2-(ycube-np.einsum('mnl,ml,r->mnr',atoms2,h2,a)))),
    }
    assert j2 <= j1+1e-10
    assert o2 < 1e-10
    assert wrong_joint_orth > 1e-3

    # MUSIC on the chosen Y column convention requires the conjugated steering.
    r = np.einsum('mni,mnj->ij',ycube.conj(),ycube)
    evals,evecs = np.linalg.eigh(r)
    un = evecs[:,:nr-1]
    angles = np.linspace(-60,60,2401)
    manifold = np.exp(1j*np.pi*np.outer(np.arange(nr),np.sin(np.deg2rad(angles))))
    right = np.sum(abs(un.conj().T@manifold.conj())**2,axis=0)
    wrong = np.sum(abs(un.conj().T@manifold)**2,axis=0)
    out['music_conjugation'] = {'correct_peak_degrees':float(angles[right.argmin()]),
                                'wrong_peak_degrees':float(angles[wrong.argmin()])}
    assert abs(out['music_conjugation']['correct_peak_degrees']+25)<0.5
    assert abs(out['music_conjugation']['wrong_peak_degrees']-25)<0.5

    # Equation 36 uses the CFO's alias zone, not the nearest alias to the slow-time estimate.
    period = 1.0
    vslow = 0.49
    vcfo = 0.51
    literal = vslow+period*np.floor((vcfo+period/2)/period)
    nearest = vslow+period*np.round((vcfo-vslow)/period)
    out['ambiguity_boundary_counterexample'] = {'slow_estimate':vslow,'cfo_estimate':vcfo,
        'true_value':0.49,'source_floor_result':float(literal),'nearest_alias_result':float(nearest)}
    assert abs(literal-0.49) > 0.9 and abs(nearest-0.49)<1e-12

    # Finite-block source covariance is not generally equal to its diagonal-target approximation.
    a2=np.exp(1j*np.pi*np.arange(nr)*np.sin(np.deg2rad(15)))
    yd=np.einsum('nm,r->mnr',y,a)+np.einsum('nm,r->mnr',y,a2)
    actual=np.einsum('mni,mnj->ij',yd.conj(),yd)
    expected=np.linalg.norm(y)**2*(np.outer(a.conj(),a)+np.outer(a2.conj(),a2))
    out['coherent_targets_covariance_approximation_relative_error']=float(np.linalg.norm(actual-expected)/np.linalg.norm(actual))
    assert out['coherent_targets_covariance_approximation_relative_error'] > 0.1

    out['source']={'url':'https://arxiv.org/pdf/2103.15694v1',
        'sha256':'ec454aa4e6e270f780ee28772b37ebc8f213203f9bf121bbf82a53cdc97dd5b5',
        'scope':'Independent algebra probes; not receiver validation or figure reproduction.'}
    out['status']='PASS: all independent audit probe assertions'
    output=Path(__file__).with_name('audit_probe_results.json')
    output.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))

if __name__=='__main__':
    main()
