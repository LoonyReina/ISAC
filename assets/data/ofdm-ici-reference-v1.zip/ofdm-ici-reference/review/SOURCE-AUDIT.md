# Independent source audit: bounded MIMO-OFDM ICI receiver

Source: [Keskin, Wymeersch and Koivunen, arXiv:2103.15694v1](https://arxiv.org/pdf/2103.15694v1), 29 March 2021. The inspected PDF has SHA-256 `ec454aa4e6e270f780ee28772b37ebc8f213203f9bf121bbf82a53cdc97dd5b5`. Equations and algorithm numbers below refer to that fixed version. Page 8 and supplementary page 14 were also inspected visually to distinguish source text from extraction artifacts.

This is a mathematical/source audit, not validation of the parent receiver implementation. `audit_probes.py` is independent of that implementation; its reproducible output is `audit_probe_results.json`. No source PDF, extracted paper text, or paper screenshots should be included in a portable reference release.

## Priority findings

1. **Source omission, Eqs. 62–63:** the published FFT benchmark never removes the known data matrix X. With random QPSK, the literal expression does not provide the usual coherent radar channel map. A functioning conventional baseline should divide frequency observations elementwise by X, clearly identifying this as an operational reconstruction. Keep a literal-source mode only to expose the omission. Our noiseless one-target test assigns 0.00356 of total map power to the correct bin literally, versus 1.0 after data removal.
2. **Exact OMP update, Eqs. 50–57:** after adding a CFO block, refit every selected block using the original data cube and the joint null covariance. Rebuild the residual from original data minus the entire refitted model. Latest-block-only subtraction is matching pursuit, not the specified joint refit.
3. **Noise assumptions, Eqs. 38–41 and 58–61:** the projected noise variance depends on the beamformer; channel recovery also colors the noise. A fixed white variance is an approximation, especially with a beamformer chosen from the same observations. Do not claim calibrated false-alarm probability from the nominal formulas alone.
4. **Finite channel approximation, Eq. 23:** a truncated DFT tap basis represents an integer-delay target exactly only when its tap is retained. General fractional delays remain outside that span, even when safely within the CP. Our example has 0.244 relative projection error. Primary correctness tests should be on-grid; off-grid tests should quantify the mismatch.
5. **Rank caveat after Eq. 56:** `P L <= N` is necessary, not sufficient, for distinct block identifiability. Equality can make the atom matrix square/full-rank and annihilate Q. An implementation needs actual rank checks, a residual-dimension budget, and a declared singularity strategy.
6. **Supplement Eq. 76 contains a verified algebra error:** with unitary F, the displayed diagonal scalar must be `sigma_x^2 * sum(d_n) / N`, not the printed addition. This does not invalidate the zero-cross-term conclusion when its orthogonality assumptions actually hold, but the printed coefficient must not become a covariance oracle.

## Executable conventions and normalization

The simplest consistent implementation uses `Y[m,n,r]`, where a per-symbol matrix has N sample rows and N_R antenna columns. Define unnormalized array steering with positive phase, and use a unitary negative-exponent DFT. Use `nu=2*v/c` only for the paper's dimensionless velocity parameter. If computation uses CFO in Hz `f_D=f_c*nu` or cycles per useful OFDM symbol `epsilon=f_D*T`, name that variable separately and convert explicitly.

Equation crosswalk:

- Eqs. 3–4: `a[r] = exp(+j*pi*r*sin(theta))`; norms are `sqrt(N_R)` and `sqrt(N_T)`, not one
- Eqs. 6–10: delay steering has negative exponent; slow-time steering c also has negative exponent, but the channel uses `b c^H`, hence positive received slow-time Doppler; D has positive exponent
- Eq. 10: `D @ F^H @ (X * channel)` is the post-CP fast-time model. Setting D to identity changes only the intra-symbol Doppler component for the ICI-free oracle; retain the same slow-time Doppler, X, target gains, and preferably the same noise realization
- Eq. 15: R is an unnormalized sum, so its noise expectation is `N*M*sigma^2*I`. Dividing by NM leaves MUSIC eigenvectors unchanged but changes downstream Capon/APES and unnormalized GLRT scales
- Eqs. 18–19: signal eigenvectors follow conjugated steering because the covariance is `Y^H Y`. MUSIC evaluates projection of `a.conj()` onto the noise subspace. Using a instead mirrors the angular response in a ULA
- Eqs. 22–23: `Xbar_m = F^H diag(x_m) F_L`. For unit-modulus QPSK, `Xbar_m^H Xbar_m=I_L`. An integer-bin target of effective gain alpha has tap amplitude `sqrt(N)*alpha`, not alpha, under unitary F
- Eqs. 31–33: `G=F_L H`; the coherent score is `b^H G c`; effective complex gain is score divided by NM. FFT implementation must be inverse FFT along frequency/range and forward FFT along slow time, with its scaling documented

A convenient numerically safe notation is `z=w.conj()` and `s=a.conj()`. Then the distortionless constraint is `a.T @ z=1`. For an invertible Q, `z=solve(Q,s)/(a.T@solve(Q,s))`; the profiled cost is `1/(a.T@solve(Q,s))`. This directly reproduces Eqs. 28–30 without fragile mixed transpose conventions. Use solves/QR/SVD, not explicit matrix inverses. Hermitian symmetrization is a roundoff safeguard; diagonal loading, pseudoinverses, and rank truncation are explicit implementation extensions and must be disclosed.

## Source assumptions and what the bounded reference must promise

- All of X is known to the monostatic radar processor (§II-D and footnote 4). Recovering unknown communication payload bits, bit-error rates, imperfect decoded X, pilot interpolation, or synchronization from scratch is outside Algorithms 1–3
- Co-located, perfectly decoupled transmit/receive arrays; no self-interference model; far-field point targets; common transmit/receive azimuth; half-wavelength ULAs; single transmitted stream, not orthogonal virtual-MIMO waveforms
- CP at least the largest round-trip delay; no inter-symbol interference; `tau=2R/c`; target parameters are fixed over one block; `|nu| << 1/N`; negligible time scaling/range migration under the stated narrowband/finite-block approximation. A useful implementation-side diagnostic is the omitted wideband phase scale `2*pi*B*|nu|*M*T_sym`
- Full-band, nonzero known X makes elementwise division possible. QPSK is the source simulation choice. General QAM changes recovered noise variance through symbol-dependent magnitudes; null subcarriers require an explicitly different masked model
- The finite-tap basis uses the first L DFT columns with `L <= N*T_cp/T`. Its last retained integer delay is `(L-1)T/N`, so even the CP endpoint is not automatically represented. Treat the declared channel support as an additional modeling restriction
- Lemma 1 uses sufficient block size, symbol covariance assumptions, and negligible cross-target inner products in delay or slow-time Doppler. A finite empirical SCM is not exactly delay/Doppler independent. Coherent/overlapping targets can violate the approximation; our constructed coherent example differs from the diagonal-target covariance by relative 0.580
- MUSIC requires a chosen signal-subspace rank strictly below N_R. With repeated target angles, spatial rank counts distinct independent directions, not total targets. Source peak picking and model-order selection are not specified enough to reconstruct a unique production procedure. State whether rank is supplied, estimated by MDL, or otherwise chosen; supplied rank is a disclosed oracle parameter
- “Arbitrary symbols” does not guarantee CFO identifiability for every X. With all-one symbols, Xbar selects time taps and multiplication by D changes their phases without changing their span, making the profiled CFO spectrum flat. Our projector differences are approximately 1.6e-14 across separated CFOs

The continuous-time Eq. 1 uses an absolute-time carrier phase, while Eq. 5 omits deterministic subcarrier/symbol epoch phases. For reference code, take Eq. 5/10 as the canonical sampled model. A separately built continuous-time/CP test must establish the symbol phase-reset or equivalent X rephasing convention instead of treating all omitted factors as one scalar gain.

## Algorithms 1–3 and faithful stopping

### Algorithm 1

MUSIC produces candidate angles. Each candidate enters angle-constrained APES CFO/channel fitting. The recovered frequency/slow-time channel is searched for delay/Doppler peaks and fitted gains; CFO then supplies an ambiguity-zone correction. CFO comes from fast-time phase, not the slow-time FFT or ground-truth velocity. A bounded CFO grid, optional scalar refinement, angular grid, delay/Doppler grid, and interpolation choices should be recorded as numerical choices rather than source-prescribed values.

### Algorithm 2

At iteration p, form `R_p=sum residual_m^H residual_m`. At each CFO, form the residual null covariance `Q_p=sum residual_m^H D P_Xbar_perp D^H residual_m`. The candidate is the largest reciprocal profiled APES cost, equivalently the lowest profiled cost. The unnormalized statistic is `(cost_H0-cost_H1)/sigma^2` (Eq. 49), not simply a periodogram peak.

After acceptance, append the complete L-column CFO block to every symbol's selected atom matrix. Build the joint null covariance from original Y and that expanded atom span. Refit all selected channel coefficients through the joint spatial beamformer. Set `residual=original_Y-Phi*h*a.T` for every symbol. Store channel estimates from the most recent joint fit; earlier accepted channels have changed.

The algorithm box uses conflicting zero-based iteration and selected-count superscripts. Implement an unambiguous selected-list count: after the first acceptance there is one block and L coefficients; after P accepted CFOs there are P blocks and PL coefficients. The narrative Eqs. 52–57 give the usable dimension contract.

Stop when the detector does not cross its threshold or accepted count reaches P_max. Distinguish stopping because the detector rejected from stopping because a configured budget, rank/conditioning guard, repeated CFO, or search boundary was reached. Returning a cap-limited result is not evidence of complete scene recovery.

The source's illustrative Eq. 65 uses a heuristic 0.3 threshold on `1-cost_H1/cost_H0`. It is invariant to an overall observation scale but has no calibrated false-alarm guarantee. This normalized rule is not the same numerical threshold as 0.3 applied to Eq. 49. Its relationship to Eq. 49 is multiplication by `cost_H0/sigma^2`.

Useful invariants:

- `a.T @ z=1`
- `Phi_m^H @ residual_m @ z=0` to numerical tolerance
- Joint profiled APES cost cannot increase when a nested atom set is expanded and the optimization is solved exactly
- Residual is rebuilt from original data and the current complete joint model

Full-cube residual Frobenius energy need not decrease: the fitted objective is beamformed error with an adaptive beam, not the unconstrained full-cube least-squares error. Do not enforce a false monotonicity test. CFO estimates are not reoptimized jointly in the source's channel refit.

Beyond checking rank(Phi)=PL, Q needs residual sample degrees of freedom: generically its rank cannot exceed `M*(N-PL)`. At equality PL=N, Q is zero. For a finite invertible Q, require enough residual dimension for N_R and check conditioning rather than relying solely on the dimension count. Noiseless exact model fits can also produce a singular Q at the true CFO.

### Algorithm 3

Run a channel delay-Doppler map separately for each returned CFO/channel component. Multiple targets in one angle/CFO cell can remain at different delays. The source uses CA-CFAR and no further interference-cancellation loop in this stage. Peaks should be selected and associated explicitly so a broad lobe is not counted as many targets.

For independently exponential cell powers, a CA-CFAR window with T training cells has multiplier `T*(P_fa**(-1/T)-1)` on the training mean. That distribution is only a reference design assumption here. Specify guards, training window, tested support, edge handling, wrap policy, local-maximum suppression, and any zero-padding. None of those detailed window choices are fixed by the source.

Even with a fixed beam and QPSK, the recovered per-symbol frequency noise covariance is proportional to `F_L F_L^H`, rank L. After an unpadded delay FFT, noise is structurally zero outside the L retained taps. CFAR training must not silently use these structural zero cells as ordinary noise samples. Adaptive beams and oversampling further complicate the nominal false-alarm model. Measure empirical H0 behavior and report trial counts/uncertainty separately from nominal P_fa.

## Doppler aliases, gains, baselines, and metrics

The slow-time velocity alias period is `c/(2*f_c*T_sym)`; the fast-time CFO alias period in velocity is `c*N/(2*f_c*T)`. Their ratio is `N*T_sym/T`, which only approaches N when CP is negligible. Table I's numeric fast-time bound is consistent with Eq. 34, but its N-times label is approximate despite a 25% CP fraction. The enormous formal fast-time velocity range does not remove the physical validity restrictions on the underlying narrowband model.

Equation 36 assigns the CFO estimate's half-open alias zone to the slow-time estimate. A slight CFO error across a zone edge can add the wrong whole alias period. In normalized units, true/slow value 0.49 and CFO estimate 0.51 yield 1.49 with the printed floor rule. A nearest-alias rule using both estimates yields 0.49, but is an explicitly declared robustness extension, not the printed formula. Preserve a literal-rule test plus boundary cases of both signs.

Source SNR is `|alpha_k|^2/sigma^2`, excluding transmit beam gain, receive gain, and coherent integration. Source f_T is unnormalized conjugated steering, with norm sqrt(N_T). Changing it to unit norm changes effective received target power by N_T at fixed alpha; unnormalized receive summation in Eq. 62 also changes amplitude/noise scaling. The gain recovered by Eq. 33 includes the transmit beam factor. State whether output reports this effective gain or divides by a known, nonzero transmit beam gain to estimate physical alpha.

For ordinary known-X FFT benchmarks, use the same MUSIC angle estimates and ordinary receive steering as the source, then frequency transform, remove X, and form the delay-Doppler map. Document any receive normalization. The ICI-free data oracle retains the same slow-time Doppler; it cannot resolve slow-time aliases without additional information and therefore is not an absolute upper bound for unambiguous velocity estimation.

The source uses 100 independent noise realizations for its numerical sweep; these do not specify a unique seed or full implementation. Its range/velocity RMSE is conditional on detection. Misses therefore need their own detection rate; do not encode a miss as zero error. Its reported FDR pools false detections and successful reference-target detections, so do not silently equate this to per-cell false alarm probability or an averaged per-frame false discovery ratio. Association tolerances and one-to-one matching remain implementation choices. Benchmark detection matching uses ambiguous velocity, whereas APES matching requires resolved velocity; disclose that asymmetry when recreating those metrics.

## Required reference tests and expected evidence

1. Direct sample sum vs Eq. 10, positive/negative Doppler, unitary energy preservation, known timing epoch
2. Array steering sign and MUSIC mirror-angle negative control; distinct-angle rank plus repeated-angle test
3. Xbar construction versus direct FFT operations, unit-modulus Gram identity, projected channel scale sqrt(N)
4. Single-CFO APES direct constrained objective versus profiled solve; correct gain and conjugation
5. Zero/small CFO where corrected FFT and APES agree within declared modeling/estimation tolerances
6. Nonzero CFO suppression with identical X/noise across APES, conventional FFT, and ICI-free oracle
7. Same-angle multiple-CFO recovery with joint channel refitting; normals and exact residual reconstruction
8. Same-angle/same-CFO multiple-delay detection in Algorithm 3, separate from CFO resolution
9. On-grid exactness and off-grid mismatch diagnostics, with no post-hoc truth correction
10. Positive/negative ambiguity zones and Eq. 36 near-boundary failures; CFO-grid/search-bound disclosures
11. H0 runs; false alarm counts/trials and uncertainty; structural-support/CFAR-window tests
12. Failure controls: all-one X, coherent angular sources, zero/null symbols, insufficient residual rank, duplicate CFOs, P_max reached, singular noiseless Q
13. Literal versus repaired Eq. 63, correct versus printed supplementary Eq. 76, and CP-retained velocity bounds
14. Noise generation verifies E|z|^2=sigma^2 (each real component variance sigma^2/2), post-beam variance, and pilot division effects
15. Deterministic configuration and seed manifest, hardware/runtime budget, dependency versions, raw detections, per-stage timings, and full numerical-choice record

These tests establish a bounded reference's claims. They do not establish digitized agreement with the paper figures, production robustness, real-world self-interference performance, or calibrated end-to-end sensing/communications trade-offs.

## Implementation review addendum

The first focused source-fidelity review of `ici_reference.py` found no mismatch in the covered sampled model, conjugation, finite-tap pilot operator, single-CFO profile, joint original-data refit, FFT/gain map, or literal unwrap rule. Eight lightweight implementation tests passed. The independent oracle solves a full simultaneous constrained least-squares KKT system over the beam and every channel coefficient; it does not reuse the implementation's profiled covariance or constrained solver. Results are in `independent-receiver-tests.log`; reviewed core SHA-256: `edf3688586e76dccd5423cd3e49b4abad83f08d79db4e6ee966f924dbb8c9e5c`. This is bounded coverage, not an end-to-end performance or release certification.

Figure 3 values were recovered by visual inspection and PDF vector-coordinate interpolation. The source-compatible interpretation is recorded in `figure3-source-reconstruction.json`; its numerical target velocities are inferred from the plotted markers and exact alias-period spacing, not supplied as author data. Figure 6's 39, 141, and -106 m/s labels are estimated CFOs and must not be used as exact scene truth. Reflection phases are unspecified in the source; assigning zero phases to all alpha values is a declared implementation choice.

The proposed Table II scaling from N=2048,M=64 to N=128,M=16, with B and CP ratio fixed and velocity multiplied by 16, correctly preserves epsilon=f_D*T and slow-time phase per symbol. It reduces dwell and NM by 64, makes physical velocity bins 64 times wider (epsilon bins four times wider), and reduces CP-supported range from 1536 m to 96 m. Range resolution stays 3 m. An 80 m target therefore sits much closer to the truncated channel boundary. At unchanged source per-sample SNR, the 64-fold smaller observation count corresponds to 18.06 dB less ideal coherent sample-count gain. This is a bounded normalized-CFO mechanism study, not a dynamically equivalent miniature or direct curve reproduction.
