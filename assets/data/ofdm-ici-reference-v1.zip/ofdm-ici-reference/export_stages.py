"""Real bounded full-stage replay evidence; no maps synthesized from detections.
The compact JSON is preserved. Arrays are separate lazy-load .npz artifacts.
Each OMP iterate is recomputed at its actually selected support using the same
original observation, then independently checked against final results.
"""
import json,pathlib,hashlib
from dataclasses import fields
import numpy as np
from ici_reference import *
from ici_reference import _constrained

ROOT=pathlib.Path(__file__).resolve().parent

def main():
    source=ROOT/'results'/'mechanism.json'; saved=json.loads(source.read_text()); cfg=Config(**saved['config'])
    data=np.load(ROOT/'results'/'mechanism-input.npz'); x=data['x'];y=data['y'];noise=data['noise']
    receiver=receive(y,x,cfg)
    arrays={'input_x':x,'input_y':y,'input_noise':noise,'music_scm':covariance(y)}
    manifest={'kind':'actual-rerun-fixed-input-full-stage-evidence','replay_is_not_fresh_input_execution':True,'source_config':saved['config'],'source_json_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'core_sha256':hashlib.sha256((ROOT/'ici_reference.py').read_bytes()).hexdigest(),'entries':[],'stage_invariants':[],'reference_detections':receiver['detections']}
    pilot=PilotProjector(x,cfg); fast=np.arange(cfg.n)/cfg.n
    for ai,angle in enumerate(receiver['angles']):
        a=steering(angle['angle_deg'],cfg.nr); prefix=f'angle_{ai}';arrays[prefix+'_steering']=a
        residual=y.copy(); eps=[]
        for trace in angle['traces']:
            it=trace['iteration'];p=f'{prefix}_iteration_{it}'; arrays[p+'_input_residual']=residual;arrays[p+'_R']=covariance(residual)
            search=trace.get('search')
            if search and search['ok']:
                ep=search['epsilon'];comp=residual*np.exp(-2j*np.pi*ep*fast)[None,:,None];q=covariance(pilot.residual(comp));info,v=_constrained(q,a,cfg.rank_rtol)
                arrays[p+'_selected_cfo_Q']=q; arrays[p+'_selected_cfo_v']=v
                arrays[p+'_cfo_grid_epsilon']=np.array([r['epsilon'] for r in search['evaluations'] if r['kind']=='grid'])
                arrays[p+'_cfo_grid_profile_cost']=np.array([np.nan if r['cost'] is None else r['cost'] for r in search['evaluations'] if r['kind']=='grid'])
            if trace['accepted']:
                eps.append(search['epsilon']);fit,h,residual=joint_refit(y,a,eps,pilot,cfg)
                if not fit['ok']:raise AssertionError('Recomputed accepted refit failed')
                arrays[p+'_joint_channels']=h;arrays[p+'_output_residual']=residual
                phis=np.concatenate([pilot.matrices()*np.exp(2j*np.pi*e*fast)[None,:,None] for e in eps],axis=2)
                null=np.array([ym-ph@np.linalg.lstsq(ph,ym,rcond=None)[0] for ym,ph in zip(y,phis)])
                qj=covariance(null);_,vj=_constrained(qj,a,cfg.rank_rtol);arrays[p+'_joint_Q']=qj;arrays[p+'_joint_v']=vj
                normals=np.array([ph.conj().T@rm@vj for ph,rm in zip(phis,residual)])
                models=np.einsum('mnl,ml->mn',phis,h.transpose(1,0,2).reshape(cfg.m,-1))
                reconstruction=float(np.max(abs(residual-(y-models[:,:,None]*a))))
                manifest['stage_invariants'].append({'angle_index':ai,'iteration':it,'constraint_error':float(abs(a@vj-1)),'joint_normal_max_abs':float(np.max(abs(normals))),'residual_reconstruction_max_abs':reconstruction,'reported_joint_cost':fit['cost'],'recomputed_profile_cost':float(np.linalg.norm(np.einsum('mnr,r->mn',residual,vj))**2)})
        if angle['channels'] is not None:
            np.testing.assert_allclose(residual,angle['residual'],rtol=1e-11,atol=1e-10)
            for ci,(ep,h) in enumerate(zip(angle['epsilons'],angle['channels'])):
                p=f'{prefix}_component_{ci}'; fs=pilot.fnl@h.T;rec=recover(fs,cfg,angle['angle_deg'],ep)
                arrays[p+'_channel_FS']=fs;arrays[p+'_rd_power']=rec['power'];arrays[p+'_cfar_threshold']=rec['threshold'];arrays[p+'_cfar_training_count']=rec['training_cells']
    targets=saved['truth_evaluation_only']; yf,_=simulate(cfg,x,targets,1,0,ici=False,noise=noise);arrays['input_y_ici_free_counterfactual']=yf
    for label,yy in [('fft_known_x',y),('fft_ici_free_counterfactual',yf)]:
        baseline=fft_baseline(yy,x,receiver['music']['angles'],cfg)
        for ai,rec in enumerate(baseline['maps']):
            for name,key in [('rd_power','power'),('cfar_threshold','threshold'),('cfar_training_count','training_cells')]:arrays[f'{label}_angle_{ai}_{name}']=rec[key]
    for name,array in arrays.items():manifest['entries'].append({'key':name,'shape':list(array.shape),'dtype':str(array.dtype),'uncompressed_bytes':array.nbytes})
    path=ROOT/'results'/'mechanism-full-stages.npz';np.savez_compressed(path,**arrays)
    manifest['archive_sha256']=hashlib.sha256(path.read_bytes()).hexdigest();manifest['archive_bytes']=path.stat().st_size;manifest['uncompressed_bytes']=sum(a.nbytes for a in arrays.values())
    (ROOT/'results'/'mechanism-full-stages.json').write_text(json.dumps(jsonable(manifest),indent=2,allow_nan=False)+'\n')
    print(json.dumps({'arrays':len(arrays),'compressed_bytes':manifest['archive_bytes'],'uncompressed_bytes':manifest['uncompressed_bytes'],'max_joint_normal':max(i['joint_normal_max_abs'] for i in manifest['stage_invariants'])}))
if __name__=='__main__':main()
