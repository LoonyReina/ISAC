import json,gzip,pathlib,itertools
import numpy as np
p=pathlib.Path(__file__).parent
rows=[json.load(gzip.open(f)) for f in sorted((p/'main').glob('*.json.gz'))]
assert len(rows)==32
names=['communication','isac','isacS','cap_saturated_communication']; out={'designs':32,'worlds':16,'requestedAllocations':128,'acceptedAllocations':sum(len(r.get('results',[])) for r in rows),'restarts':{},'byFit':{},'pairedFit':{},'rankComparisons':{}}
for family in ['isac','isacS']:
 rr=[z for r in rows for z in r['solver'].get(family,{}).get('restarts',[])];count={}
 for z in rr:count[z['termination']]=count.get(z['termination'],0)+1
 out['restarts'][family]={'attempts':len(rr),'accepted':sum(z['accepted'] for z in rr),'terminations':count}
def cross(a):return any(a['holdout']['nominalCrossings']['communication']) or any(a['holdout']['nominalCrossings']['perAP'])
for n in [64,512]:
 rr=[r for r in rows if r['settings']['channelSamples']==n];out['byFit'][n]={}
 reversals=ties=total=world_reversals=0
 for r in rr:
  rev=0
  for a,b in itertools.combinations(r['results'],2):
   ds=a['fitted']['sensing_sinr']-b['fitted']['sensing_sinr'];dp=a['detectors']['AP']['pd']-b['detectors']['AP']['pd'];total+=1
   if ds*dp<0:reversals+=1;rev+=1
   if ds==0 or dp==0:ties+=1
  world_reversals+=rev>0
 out['rankComparisons'][n]={'availablePairs':total,'strictReversals':reversals,'ties':ties,'worldsWithStrictReversal':world_reversals,'worlds':16,'warning':'Descriptive measured-Pd ordering, includes binomial noise and unequal used power; no significance claim'}
 for name in names:
  aa=[a for r in rr for a in r['results'] if a['name']==name];d=[a['detectors']['AP'] for a in aa]
  out['byFit'][n][name]={'availableWorlds':len(aa),'unavailableWorlds':16-len(aa),'anyHoldoutCrossing':sum(cross(a) for a in aa),'communicationCrossing':sum(any(a['holdout']['nominalCrossings']['communication']) for a in aa),'powerCrossing':sum(any(a['holdout']['nominalCrossings']['perAP']) for a in aa),'meanPd':np.mean([x['pd'] for x in d]),'meanPfa':np.mean([x['pfa'] for x in d]),'meanUsedFittedW':np.mean([a['fitted']['total_power_w'] for a in aa]),'meanSensingStreamW':np.mean([a['p'][0]**2 for a in aa]),'meanUsedHoldoutW':np.mean([a['holdout']['total_power_w'] for a in aa])}
rng=np.random.default_rng(18102026)
for name in names:
 pairs=[]
 for seed in sorted({r['settings']['seed'] for r in rows}):
  rr=sorted([r for r in rows if r['settings']['seed']==seed],key=lambda r:r['settings']['channelSamples']); aa=[next((a for a in r['results'] if a['name']==name),None) for r in rr]
  if all(a is not None for a in aa):pairs.append([int(cross(aa[1]))-int(cross(aa[0])),aa[1]['detectors']['AP']['pd']-aa[0]['detectors']['AP']['pd']])
 x=np.array(pairs);bs=x[rng.integers(len(x),size=(10000,len(x)))].mean(axis=1)
 out['pairedFit'][name]={'pairedWorlds':len(x),'unavailablePairs':16-len(x),'meanCrossingChange512Minus64':x[:,0].mean(),'meanPdChange512Minus64':x[:,1].mean(),'wholeWorldBootstrap95':np.quantile(bs,[.025,.975],axis=0).tolist(),'bootstrapSeed':18102026,'bootstrapResamples':10000,'scope':'Conditional on pair availability; unavailable worlds explicitly counted, excluded from paired estimand; no imputation. Resample whole world pairs.'}
(p/'RESULTS.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
