"""Lossless solid archive. New generation; no old archive identity claim."""
import pathlib,tarfile,gzip,io,hashlib,json
p=pathlib.Path(__file__).parent;out=p.parent/'recomputed-maprt-robustness-evidence.tar.xz';manifest={}
with tarfile.open(out,'w:xz',preset=6) as tar:
 for f in sorted(p.rglob('*')):
  if not f.is_file() or '__pycache__' in f.parts:continue
  name=str(f.relative_to(p));data=f.read_bytes()
  if name.endswith('.gz'):data=gzip.decompress(data);name=name[:-3]
  manifest[name]=hashlib.sha256(data).hexdigest();info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;tar.addfile(info,io.BytesIO(data))
 data=json.dumps(manifest,indent=2).encode();info=tarfile.TarInfo('EVIDENCE-SHA256.json');info.size=len(data);tar.addfile(info,io.BytesIO(data))
print(json.dumps({'archive':str(out),'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'members':len(manifest)}))
