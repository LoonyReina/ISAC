# NEW independently accepted MAPRT robustness regeneration

This is newly computed evidence from recovered and independently source-reviewed code, not restoration of the lost original archive. The old final adapter identity remains unverified. Precompute FREEZE.json SHA256:82608e71dfc28cb0f7a754981b856fae0a3446c505095acc4a4d2459761e41e7. All frozen files and fresh data identities verified after computation.

## Fresh results
32 designs from16 master worlds; nested fit64/512,fixed geometry,independent512-draw holdout.124/128 allocations available;192 CCP attempts,180 accepted and12 iteration caps. All unavailable/failed/nonselected outcomes retained. No historical-outcome filtering or post-outcome tuning.507,904 AP scores:124×(2048 calibration+1024 H0+1024 H1).

Any nominal holdout constraint crossing,fit64→512:
- communication12/16→11/16
- isac11/15→11/15;one unavailable world each fit
- isacS10/15→13/15;one unavailable world each fit
- cap-saturated communication6/16→8/16

Increasing fit size did not uniformly reduce finite-holdout crossings. Exact nominal boundary crossings do not establish population infeasibility or statistical significance. Geometry is fixed; only fits/designs and detector streams vary.

Each fit has12 strict source-surrogate/measured-Pd reversals among90 available allocation pairs,in8/16 worlds. This is descriptive at unequal actual used power,with finite binomial detection uncertainty; no significant reversal or uniform ranking claim. All actual fitted/holdout powers and sensing stream powers are retained. No forced positive sensing allocation.

RESULTS.json retains equal-world means,explicit unavailable counts,paired available-world changes and10,000 whole-world bootstrap summaries. Paired means condition on15 or16 available pairs,without imputing unavailable worlds. Calibration beta and evaluationClopper–Pearson intervals remain separate. No pooled-trial population inference.

## Fresh independent acceptance
See independent/NEW-REGENERATION-REVIEW.md. All507,904 score threshold/count/interval checks,2,225 convex certificates and1,116 independent NumPy max-prior replay scores pass. Nesting/split/geometry checks and all aggregate/paired/bootstrap counts pass. Five mutation probes reject altered score,certificate,allocation absence,selected restart and failure status. This validates the reduced finite experiment,not UI,source curves,global CCP optimality or whole-paper reproduction.

## Recovery and resources
Six unchanged numerical/codec modules match historical module hashes. Historical final adapter hash/raw data/archive are unavailable. Recovered checker sources are transcriptions with disclosed recovery changes,not byte-exact original checkers. This execution had no separate numerical pilot; prior source/contract review authorized the full new regeneration. Main sum of design wall times20.910900019seconds;max loggedRSS356028416bytes,not peak instrumentation. One numerical Node process,BLAS/OpenMP1,TMPDIR on workspace disk. Outputs retained without trimming.

TEACHING-DATA.json is freshly generated and explicitly labeled NEW independently reviewed output. The frozen historical teaching generator is unchanged; added provenance/mode fields mark the new generation. Existing live MAPRT/CCP remains separate from offline selectors and true observation rescoring. No baseline/UI/remote/Codex changes.

## Reproduction
After extracting the solid archive,run node restore.mjs to recreate original fresh per-file gzip layout and verify DATA-SHA256.txt. EVIDENCE-SHA256.json covers archive member bytes. For fresh checks,set MAPRT_STUDY to extracted root; run independent/review-contract.mjs and three independent Python review scripts with BLAS/OpenMP1. NumPy/SciPy required for Python. The prepare.py path is original recovery construction metadata; do not rerun it from this relocated study. driver.mjs uses bundled frozen runtime directly. Reruns produce new timing-dependent record hashes and must be labeled separately.
