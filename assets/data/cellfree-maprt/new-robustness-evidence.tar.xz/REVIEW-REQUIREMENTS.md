# Required fresh independent review
Not a recovered acceptance certificate. Original independent script bodies must come from their author if available; otherwise label any replacement review implementation NEW.

1. Source delta: only fixed512 holdout,explicit calibration/H0/H1 streams,AP-only,pilot exit,schema/pairing and legacy replay removal. Baseline solver,scenario,linear algebra,statistics and MAPRT unchanged.
2. Seed96 uniqueness; exact fit64 prefix512 raw estimates/errors/precoders/effective/sensingLeak across all16 worlds. Geometry/design identical across nested fits.512 holdout each.
3. Output-only independent NumPy complex covariance oracle: y0=X chol(Rh)h+sqrt(noise)z;y1 addsG chol(Ra)alpha. In whitened coordinates C0=I+UU^H,C1=C0+VV^H,score=yw^H(C0^-1-C1^-1)yw -q log(pi)-logdet(Ra). Must use max-prior constant, not marginal logdet ratio. Reconstruct3 columns each substream/design; check log constants and observations.
4. Recompute every recorded score threshold,decisions,counts/rates,calibration beta/evaluation CP intervals and retain all H0/H1 trials.
5. Recompute fitted/holdout metrics,constraints,source surrogate,full CCP certificate arithmetic including Jacobians/multipliers/bounds,gaps,tangent steps and selected accepted restart. Retain failure/cap/unavailable statuses. Validate all requested4 allocation cells/design explicitly.
6. Recompute world means,paired available-world denominators,strict rank reversals/ties and whole-world bootstrap. Missing worlds counted but not imputed into paired estimand.
7. Mutation rejection:changed score,certificate,missing allocation,wrong selected restart,failed restart relabeled accepted. Hash all fresh outputs.
