# MAPRT robustness source recovery

Recovery location:/workspace/shared/recovery/maprt-robustness-reference
Source of transcription: this author's available conversation and explicit prior tool-call bodies, never session logs or hidden notes.

Recovered:
- Six unchanged numerical/codec modules copied from recovered public baseline; original runtime adapter reproduced from the visible replacement instructions
- driver.mjs,timing.mjs,split-test.mjs,summarize.py,make-teaching-data.py from visible original command bodies
- prepare.py is the original replacement procedure with baseline path relocated and an explicit substitution-success assertion
- Protocol and teaching-integration documents reconstructed from visible original documents; byte identity not claimed

Original RUNTIME-SHA256/DATA-SHA256 contents were written in the lost environment but not printed in this author's available history. Thus original-study identity is UNVERIFIED. RECOVERY-MANIFEST.json hashes current recovered source only, not original source. Public module equality can be checked against the provided public baseline.

Missing, not invented:
- Original evidence.tar.xz, formerly5,067,468bytes,SHA256 e77e9fc84dfb5dad269f88720ffa02c4ffacd5dcab76f9070e077812aa410cbc
- All original507,904 raw score values,32 main design records,RESULTS.json,TEACHING-DATA.json and raw fixtures
- Original review scripts were authored independently by reviewer; their source text was not present in this author's conversation. Parent has been asked to recover them from that reviewer. Review-harness plan is a requirement, not recovered validation evidence

Historical reports described32 designs,124/128 available allocations,192 CCP starts with12 caps, independent numerical acceptance and5 mutation probes. These are historical messages only; they are not reproduced acceptance claims in this recovery. Fresh deterministic reruns must be separately labeled,reviewed and hashed. Do not use observed historical totals as a filter to discard new differences.

New checks so far: Node syntax for driver/adapter, Python compile for preparation/summary/generator, source-copy identity checks. No numerical pilot or main executed. Main execution is held pending parent's source/protocol check. One-process BLAS/OpenMP1 limits apply to eventual authorized execution.
