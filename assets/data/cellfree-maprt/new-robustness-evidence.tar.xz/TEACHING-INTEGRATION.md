# Recovered teaching integration contract; no current results

This recovered source package has no original main records, raw scores or teaching JSON. Do not fabricate them or display historical review claims as current acceptance. The generator is recovered only. Independently review fresh deterministic reruns before integration.

Reuse existing cell-free MAPRT route and actual live MAPRT/CCP runtime. A separate offline finite-study panel can inspect16 master worlds and nested fits64/512. Keep all4 requested allocation names visible, including unavailable families and all3 restart outcomes. Show fitted versus independent512-holdout communication SINR, per-AP expected power against gamma3dB/cap1W, source sensing surrogate, actual used total power, sensing-stream amplitude squared, calibratedAP Pd/Pfa with1024-trial denominators and separate calibration/evaluation intervals. Offline selectors do not rerun optimization or MonteCarlo.

The existing live runtime has different holdout/evaluation coupling and is not bit-identical to this study adapter. A live rescore feature must actually reconstruct observations and invoke MAPRT.score; rescoring alone is not fresh calibration/Pd. Study-specific live adapter changes require their own worker/cancel/import/dataflow review.

Keep fixed geometry,finite-sample uncertainty,unavailable pairs,nominal boundary crossings and unequal used power explicit. Larger sample size need not uniformly reduce observed crossings; surrogate/Pd reversal counts are descriptive and may reflect finite binomial noise. No uniform superiority,population guarantee,global optimum,source-curve or full-paper claim. Final observed counts must come from reviewed fresh outputs, not this recovered contract.

Use compact teaching JSON for selectors; do not embed every raw score,latent or certificate in the page. Preserve live export/import/cancel semantics. No UI/browser/publication acceptance is supplied by this package.
