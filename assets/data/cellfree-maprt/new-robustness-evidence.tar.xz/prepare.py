from pathlib import Path
p=Path(__file__).parent
s=(p.parent/'public-baseline/labs/cellfree-maprt/runtime/runtime.mjs').read_text()
s=s.replace('let s=makeScenario({seed:o.seed,channel_samples:o.channelSamples});','let s=makeScenario({seed:o.seed,channel_samples:o.channelSamples}); if(o.channelSamples!==512)s.holdout=makeScenario({seed:o.seed,channel_samples:512}).holdout;s.settings.holdout_channel_samples=512;')
s=s.replace("let random=rng((o.seed^0x85ebca6b)>>>0),raw={calibration:latent(random,o.calibrationTrials),evaluation:latent(random,o.evaluationTrials)},results=[];", "if(hooks.pilot)return {settings:o,solver,powerProblem,scenario:s,allocations};let raw={calibration:latent(rng((o.seed^0x85ebca6b)>>>0),o.calibrationTrials),evaluation0:latent(rng((o.seed^0xc2b2ae35)>>>0),o.evaluationTrials),evaluation1:latent(rng((o.seed^0x27d4eb2f)>>>0),o.evaluationTrials)},results=[];")
s=s.replace('observation(d,raw.evaluation,false)','observation(d,raw.evaluation0,false)').replace('observation(d,raw.evaluation,true)','observation(d,raw.evaluation1,true)')
s=s.replace('AP:new MAPRT(d.g,d.x,d.rAlpha,d.rH,d.noise),SP:new MAPRT(d.g,mat(40,0),d.rAlpha,mat(0,0),d.noise)','AP:new MAPRT(d.g,d.x,d.rAlpha,d.rH,d.noise)')
s=s.split('\nfunction recordMatrix')[0]+'\n'
s=s.replace("AP/SP identical observations; across allocations common latent draws and different observations","AP-only study; across allocations common latent draws and different observations; H0/H1 independent latent substreams").replace("schema:'cellfree-maprt-run-v1'","schema:'cellfree-maprt-robustness-v1'")
assert 'evaluation0' in s and 'hooks.pilot' in s and 'holdout_channel_samples=512' in s
(p/'runtime/runtime.mjs').write_text(s)
