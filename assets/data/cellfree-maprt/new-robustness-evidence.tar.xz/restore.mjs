// After extraction restore original per-file gzip layout; verify new data hashes.
import fs from 'node:fs';import zlib from 'node:zlib';import crypto from 'node:crypto';
const root=new URL('.',import.meta.url).pathname;
for(const name of fs.readdirSync(root+'main'))if(name.endsWith('.json')||name.endsWith('.f64'))fs.writeFileSync(root+'main/'+name+'.gz',zlib.gzipSync(fs.readFileSync(root+'main/'+name)));
for(const line of fs.readFileSync(root+'DATA-SHA256.txt','utf8').trim().split('\n')){const [hash,path]=line.split(/\s+/);const name=path.split('/').at(-1);if(crypto.createHash('sha256').update(fs.readFileSync(root+'main/'+name)).digest('hex')!==hash)throw Error('gzip identity mismatch '+name);}console.log('All NEW compressed data hashes restored');
