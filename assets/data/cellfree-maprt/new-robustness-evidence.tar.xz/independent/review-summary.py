# Reconstructed visible original checker. Relocated path; no historical result targets.
import pathlib,json,gzip,numpy as np,itertools,collections,os
P=pathlib.Path(os.environ.get('MAPRT_STUDY',str(pathlib.Path(__file__).parent.parent/'maprt-robustness-reference')));rs=[json.load(gzip.open(f)) for f in (P/'main').glob('*.json.gz')];S=json.loads((P/'RESULTS.json').read_text());assert len(rs)==32
worlds={r['settings']['seed'] for r in rs};assert worlds=={2026101801+104729*i for i in range(16)}
by={(r['settings']['seed'],r['settings']['channelSamples']):{a['name']:a for a in r['results']} for r in rs};assert len(by)==32
assert set(by)=={(w,n) for w in worlds for n in [64,512]}
def cross(a):return int(any(a['holdout']['nominalCrossings']['communication']+a['holdout']['nominalCrossings']['perAP']))
def close(a,b):assert np.allclose(a,b,rtol=0,atol=1e-14),(a,b)
assert S['acceptedAllocations']==sum(len(r['results']) for r in rs)
for name in ['isac','isacS']:
 t=[t for r in rs for t in r['solver'][name]['restarts']];assert S['restarts'][name]==dict(attempts=len(t),accepted=sum(t0['accepted'] for t0 in t),terminations=dict(collections.Counter(t0['termination'] for t0 in t)))
for fit in [64,512]:
 pairs=rev=ties=wr=0
 for seed in worlds:
  rv=0
  for a,b in itertools.combinations(by[seed,fit].values(),2):
   ds=np.sign(a['fitted']['sensing_sinr']-b['fitted']['sensing_sinr']);dp=np.sign(a['detectors']['AP']['pd']-b['detectors']['AP']['pd']);pairs+=1;rev+=int(ds!=0 and dp!=0 and ds!=dp);rv+=int(ds!=0 and dp!=0 and ds!=dp);ties+=int(ds==0 or dp==0)
  wr+=int(rv>0)
 for k,v in dict(availablePairs=pairs,strictReversals=rev,ties=ties,worldsWithStrictReversal=wr,worlds=16).items():assert S['rankComparisons'][str(fit)][k]==v
 for name,z in S['byFit'][str(fit)].items():
  aa=[by[seed,fit][name] for seed in worlds if name in by[seed,fit]];assert z['availableWorlds']==len(aa);assert z['unavailableWorlds']==16-len(aa);assert z['anyHoldoutCrossing']==sum(map(cross,aa));assert z['communicationCrossing']==sum(any(a['holdout']['nominalCrossings']['communication']) for a in aa);assert z['powerCrossing']==sum(any(a['holdout']['nominalCrossings']['perAP']) for a in aa)
  for k,v in dict(meanPd=np.mean([a['detectors']['AP']['pd'] for a in aa]),meanPfa=np.mean([a['detectors']['AP']['pfa'] for a in aa]),meanUsedFittedW=np.mean([a['fitted']['total_power_w'] for a in aa]),meanSensingStreamW=np.mean([a['p'][0]**2 for a in aa]),meanUsedHoldoutW=np.mean([a['holdout']['total_power_w'] for a in aa])).items():close(z[k],v)
rng=np.random.default_rng(18102026)
for name,z in S['pairedFit'].items():
 seeds=[w for w in sorted(worlds) if name in by[w,64] and name in by[w,512]];d=np.array([[cross(by[w,512][name])-cross(by[w,64][name]),by[w,512][name]['detectors']['AP']['pd']-by[w,64][name]['detectors']['AP']['pd']] for w in seeds]);assert z['pairedWorlds']==len(seeds);assert z['unavailablePairs']==16-len(seeds);close(d.mean(axis=0),[z['meanCrossingChange512Minus64'],z['meanPdChange512Minus64']]);draws=rng.integers(0,len(d),(10000,len(d)));boot=np.stack([d[idx].sum(axis=0)/len(d) for idx in draws]);close(np.quantile(boot,[.025,.975],axis=0),z['wholeWorldBootstrap95'])
report={'pass':True,'newRecoveryCheck':True,'designs':len(rs),'worlds':len(worlds),'allocations':S['acceptedAllocations'],'summary':'All means, crossing/rank counts, paired denominators and whole-world bootstrap intervals independently matched.'};(pathlib.Path(__file__).parent/'review-summary.json').write_text(json.dumps(report,indent=2));print(report)
