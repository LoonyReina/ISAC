# Reconstructed from visible original checker; paths configurable; reject empty input.
import gzip,json,pathlib,numpy as np,os
from scipy.stats import beta
P=pathlib.Path(os.environ.get('MAPRT_STUDY',str(pathlib.Path(__file__).parent.parent/'maprt-robustness-reference')))
OUT=pathlib.Path(__file__).parent
C={'records':0,'allocations':0,'scores':0,'replayScores':0,'certificates':0,'failedRestarts':0}; errors={}
def eq(a,b,label,tol=1e-8):
 a=np.asarray(a);b=np.asarray(b);e=float(np.max(np.abs(a-b),initial=0));errors[label]=max(errors.get(label,0),e);assert np.allclose(a,b,rtol=tol,atol=tol),(label,e)
def m(x):return (np.array(x['re'])+1j*np.array(x['im'])).reshape(x['rows'],x['cols'])
def metrics(p,A,B,N,b,a,F):
 power=F@p**2;return dict(sensing_sinr=p@A@p/(N+p@B@p),communication_sinr=(b*p[1:])**2/(1+(a*a)@p**2),per_ap_power_w=power,total_power_w=sum(power))
def constraints(p,b,a,F,g,cap):return np.r_[b*p[1:]/np.sqrt(g)-np.sqrt(1+(a*a)@p**2),cap-F@p**2]
def cert(x,Q,lin,b,a,F,g,cap):
 C['certificates']+=1;p=np.array(x['p']);c=x['certificate'];free=c['free_indices'];z=p[free];u=np.min(np.where(F[:,free]>0,np.sqrt(cap/np.maximum(F[:,free],1e-300)),np.inf),axis=0)
 sl=constraints(p,b,a,F,g,cap);J=-(a*a)*p/np.sqrt(1+(a*a)@p**2)[:,None];J[np.arange(len(b)),np.arange(len(b))+1]+=b/np.sqrt(g);J=np.vstack([J,-2*F*p])[:,free];allsl=np.r_[sl,z,u-z];J=np.vstack([J,np.eye(len(free)),-np.eye(len(free))]);lam=np.array(c['multipliers']);assert np.all(lam>=0);res=(2*Q@p+lin)[free]-J.T@lam;obj=p@Q@p+lin@p;lower=obj-lam@allsl+np.minimum(-res*z,res*(u-z)).sum();eq([obj,lower,obj-lower,min(0,min(allsl)),max(abs(res)),max(abs(lam*allsl))],[c[k] for k in ['objective','lagrange_box_lower_bound','global_subproblem_gap_upper','minimum_primal_slack','stationarity_infinity','complementarity_infinity']],'certificate');eq(allsl,c['constraint_slacks'],'constraint_slacks');eq(u,c['amplitude_box_upper'],'amplitude_box');assert c['global_subproblem_gap_accepted']==(np.isfinite(obj-lower) and obj-lower<=2e-6*max(1,abs(obj)));assert x['accepted']==(x['solver_success'] and min(0,min(allsl))>=-2e-7 and c['global_subproblem_gap_accepted']);assert x['iterations']<=400
files=sorted((P/'main').glob('*.json.gz'));assert files,'No new main records: acceptance unavailable'
for file in files:
 r=json.load(gzip.open(file));C['records']+=1;assert r['schema']=='cellfree-maprt-robustness-v1';o=r['settings'];s=r['scenario'];pp=r['powerProblem'];A=np.array(pp['A']);B=np.array(pp['B']);N=pp['noise_energy'];An=A/N;Bn=B/N;b=np.array(pp['b']);a=np.array(pp['a']);F=np.array(pp['power_coeff']);g=pp['gamma'];cap=pp['cap'];assert s['holdout']['samples']==512
 cert(r['solver']['communication'],np.diag(F.sum(axis=0)),np.zeros(3),b,a,F,g,cap)
 failures=[];names=['communication','cap_saturated_communication']
 for name in ['isac','isacS']:
  q=r['solver'][name];assert len(q['restarts'])==3;best=None
  for i,t in enumerate(q['restarts']):
   assert len(t['iterations'])<=50
   for x in t['iterations']:
    old=np.array(x['p_previous']);p=np.array(x['p']);den=1+old@Bn@old;num=old@An@old;cert(x,num/den**2*Bn,-2*An@old/den,b,a,F,g,cap);gain=(2*(p-old)-((1+p@Bn@p)-den)/den*old)@An@old/den;actual=p@An@p/(1+p@Bn@p)-num/den;eq([gain,actual],[x['source_tangent_improvement'],x['actual_sinr_improvement']],'ccp_gain')
   if t['accepted']:
    assert t['termination']=='source_tangent_tolerance';assert t['iterations'][-1]['source_tangent_improvement']<=1e-8
    if best is None or t['final']['metrics']['sensing_sinr']>q['restarts'][best]['final']['metrics']['sensing_sinr']:best=i
   else:failures.append(dict(name=name,restart=i,termination=t['termination']));C['failedRestarts']+=1
  assert q['selectedRestart']==best;assert q['accepted']==(best is not None)
  if q['accepted']:names.append(name)
 assert r['failures']==failures;assert set(names)=={x['name'] for x in r['results']};assert r['allRequestedAllocationsAccepted']==all(r['solver'][k]['accepted'] for k in ['isac','isacS'])
 for x in r['results']:
  C['allocations']+=1;p=np.array(x['p']);assert min(p)>=0
  if x['name']!='isacS':assert p[0]==0
  for key,mom in [('fitted',s['fit']),('holdout',s['holdout'])]:
   mm=metrics(p,A,B,N,np.array(mom['b']),np.array(mom['a']),np.array(mom['powerCoeff']))
   for k,v in mm.items():eq(v,x[key][k],'metrics')
  eq(min(constraints(p,b,a,F,g,cap)),x['fitted']['minimumConstraintSlack'],'min_slack');assert x['holdout']['nominalCrossings']==dict(communication=[v<g for v in x['holdout']['communication_sinr']],perAP=[v>cap for v in x['holdout']['per_ap_power_w']])
  assert list(x['detectors'])==['AP'];d=x['detectors']['AP'];scores=np.frombuffer(gzip.open(P/'main'/x['scoreFile'],'rb').read(),dtype='<f8');assert len(scores)==4096 and np.isfinite(scores).all();C['scores']+=len(scores);cal,h0,h1=np.split(scores,[2048,3072]);k=int(np.ceil(2049*.95));thr=np.sort(cal)[k-1];assert len(np.unique(cal))==2048;eq(thr,d['threshold']['threshold'],'threshold');assert d['threshold']['order_k']==k;eq(beta.ppf([.025,.975],2049-k,k),d['threshold']['calibration_tail_interval'],'beta_interval')
  for vals,ct,rate,iv in [(h0,'falseAlarms','pfa','pfaInterval'),(h1,'detections','pd','pdInterval')]:
   hits=int(sum(vals>=thr));assert hits==d[ct];eq(hits/1024,d[rate],'rate');eq([0 if hits==0 else beta.ppf(.025,hits,1025-hits),1 if hits==1024 else beta.ppf(.975,hits+1,1024-hits)],d[iv],'binomial_interval')
  D=x['design'];G=m(D['g']);X=m(D['x']);Ra=m(D['rAlpha']);Rh=m(D['rH']);noise=D['noise'];Lh=np.linalg.cholesky(Rh);La=np.linalg.cholesky(Ra);W=np.column_stack([G@La,X@Lh])/np.sqrt(noise);W0=X@Lh/np.sqrt(noise);C0=np.eye(40)+W0@W0.conj().T;C1=np.eye(40)+W@W.conj().T;constant=-G.shape[1]*np.log(np.pi)-np.linalg.slogdet(Ra)[1];eq(constant,d['logC3'],'prior_constant')
  for key,vals,present in [('calibration',cal,False),('evaluation0',h0,False),('evaluation1',h1,True)]:
   Z={k:m(v) for k,v in r['rawReplay'][key].items()};Y=X@Lh@Z['h']+np.sqrt(noise)*Z['noise'];
   if present:Y+=G@La@Z['alpha']
   Y/=np.sqrt(noise);q=np.real(np.sum(Y.conj()*(np.linalg.solve(C0,Y)-np.linalg.solve(C1,Y)),axis=0))+constant;eq(q,vals[:3],'numpy_replay',2e-7);C['replayScores']+=3
report=dict(pass_review=True,counts=C,maxAbsoluteErrors=errors,scope='NEW output-only NumPy max-prior oracle for first 3 columns each stream; every saved score statistically checked, all certificates reconstructed. No historical acceptance reuse.')
(OUT/'review-numeric.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
