# Reconstructed original mutation probes with explicit relocated input path.
import pathlib,tempfile,shutil,gzip,json,subprocess,os,copy,struct,sys
HERE=pathlib.Path(__file__).parent;P=pathlib.Path(os.environ.get('MAPRT_STUDY',str(HERE.parent/'maprt-robustness-reference')));files=sorted((P/'main').glob('*.json.gz'));assert files,'Missing NEW output';out=[]
for mutation in ['bad_score','bad_certificate','missing_allocation','wrong_selected_restart','rejected_marked_accepted']:
 with tempfile.TemporaryDirectory(prefix='maprt-audit-') as t:
  q=pathlib.Path(t);(q/'main').mkdir();shutil.copy(HERE/'review-numeric.py',q/'review-numeric.py');f=files[0];r=json.load(gzip.open(f))
  if mutation=='rejected_marked_accepted':
   candidates=[(f,json.load(gzip.open(f))) for f in files];f,r=next((f,r) for f,r in candidates if any(not t['accepted'] for name in ['isac','isacS'] for t in r['solver'][name]['restarts']))
  for file in (P/'main').glob('*.f64.gz'):(q/'main'/file.name).symlink_to(file)
  if mutation=='bad_score':
   path=q/'main'/r['results'][0]['scoreFile'];buf=bytearray(gzip.open(path,'rb').read());v=struct.unpack_from('<d',buf,0)[0];struct.pack_into('<d',buf,0,v+1);path.unlink();gzip.open(path,'wb').write(buf)
  if mutation=='bad_certificate':r['solver']['communication']['certificate']['lagrange_box_lower_bound']+=1
  if mutation=='missing_allocation':r['results'].pop()
  if mutation=='wrong_selected_restart':r['solver']['isac']['selectedRestart']=-1
  if mutation=='rejected_marked_accepted':next(t for name in ['isac','isacS'] for t in r['solver'][name]['restarts'] if not t['accepted'])['accepted']=True
  with gzip.open(q/'main'/f.name,'wt') as h:json.dump(r,h)
  z=subprocess.run([sys.executable,str(q/'review-numeric.py')],capture_output=True,text=True,env={**os.environ,'MAPRT_STUDY':str(q),'OPENBLAS_NUM_THREADS':'1'});assert z.returncode!=0,mutation;assert 'AssertionError' in z.stderr,(mutation,z.stderr);out.append({'mutation':mutation,'rejected':True})
(HERE/'review-mutations.json').write_text(json.dumps(out,indent=2));print(out)
