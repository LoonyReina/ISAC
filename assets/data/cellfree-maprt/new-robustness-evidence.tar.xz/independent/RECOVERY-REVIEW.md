# Recovery source review, 2026-10-18

Verdict: APPROVE NEW regeneration under a fresh precompute source freeze. This is a source/contract decision, not numerical acceptance. Do not reuse historical acceptance of the lost 507,904 scores. No main/pilot solver execution was performed by this recovery reviewer.

## Available evidence

The reviewer retained visible tool-call bodies in the current conversation. No denied session logs were accessed. Restored checker logic from that visible history into review-contract.mjs, review-numeric.py, review-summary.py, review-mutations.py. These are transcriptions with path relocation, explicit nonempty-input checks and minor recovery hardening, not byte-exact recovered originals. Historical expected allocation count124 was removed as an acceptance target. Historical counts and numerical acceptance must never filter new outcomes.

HISTORICAL-RUNTIME-SHA256.txt is transcribed from the original manifest printed in the reviewer's tool output. All six unchanged modules (codec,linalg,maprt,power,scenario,statistics) match those historical hashes exactly. The listed old runtime hash6581bf... predates the original schema/pairing/replay fixes and MUST NOT be used as the final historical adapter hash. The current adapter hash113418acfd356e6924529f09700161099469678b7821ee176e6e686b76e2902c is a NEW recovered-source hash. The original final adapter hash, old data manifest contents and original binary data are unavailable.

The recovered adapter was read in full against visible earlier code and original intended corrections: fixed512 holdout replacement; independently seeded calibration/evaluation0/evaluation1; AP-only detector; pilot early return; distinct robustness schema; corrected pairing convention; removal of incompatible legacy replay. No CCP/power acceptance gate change found. The driver matches visible original control/data layout. Recovered summary retains all available families and paired missing-world counts; bootstrap samples whole paired worlds and no longer claims unavailable worlds enter paired mean denominators.

## Protocol verified for NEW execution

- Exactly16 masters2026101801+104729*i,i=0..15, each fit64/512; fixed4TX/2RX/2antenna/2UE geometry, covariance, pilot and QPSK conventions
- Fit seed master, holdout XOR0x9e3779b9, design XOR0xd1b54a35, calibration XOR0x85ebca6b, evaluation H0 XOR0xc2b2ae35, evaluation H1 XOR0x27d4eb2f, unsigned32bit
- New lightweight scenario-only check passed: all96 seeds distinct and5,120 exact raw matrix comparisons establish first64 nesting for all16 worlds. Shared design/geometry/covariances across nested fits checked. This is deterministic stream separation, not proof of statistical independence
- 512 holdout,2048 calibration,1024 evaluationH0,1024 evaluationH1; RCS0dBsm,clutter1,gamma3dB,cap1W,Pfa.05; unchanged3starts(.1,.45,.85),sensing fractions(.2,.6,.9),50/400caps,tolerance1e-8
- MAPRT score adds max-prior constant logC3, not marginalized-logLRT determinant constant. New study AP-only; unchanged public baseline still supports SP
- Retain all accepted/rejected/nonselected starts and unavailable families; no detector-outcome selection/tuning. Float64 little-endian output assumption requires little-endian execution host (verify before freeze); calibration order1947 and >= decisions; independent calibration beta and evaluation Clopper–Pearson intervals
- Equal-world summaries; available-world paired estimand with missing counts; measured-Pd rank reversals descriptive at unequal used power; no source curve/population feasibility/global optimality claim

## Remaining gates / limitations

Author must hash all executable/protocol files into a NEW FREEZE before computation, verify little-endian host, label every rerun as newly generated, and retain all outputs even if historical totals differ. Numerical checkers await new records; only syntax checks passed for recovered Python checkers. The numeric checker deliberately fails empty input and does not silently accept missing data. If communication solver failure occurs, its current checker/summary assume successful communication and require explicit diagnostic review; do not discard or rerun-to-success that record. Mutation harness needs a genuine rejected restart for its fifth test; absence is a review coverage issue, not a reason to manufacture/reject experiment outcomes. Full score reconstruction remains out of scope: all scores get statistical/count checks and first3 columns per stream get independent NumPy max-prior observation reconstruction.

Original raw results, original review byte hashes and binary evidence cannot be restored from the available history. New acceptance requires fresh numeric/summary/mutation passes, source/data manifests and an updated review report. No remote mutation, Codex, heavy simulation or publication occurred in this review.
