# Independent review of NEW MAPRT regeneration

Verdict: ACCEPT newly regenerated local numerical evidence at ../recomputed-maprt-robustness. This is new acceptance after fresh checks, not restoration or reuse of the lost original evidence/acceptance. Original final adapter identity and old archive remain unavailable/unverified.

Frozen source SHA256: FREEZE.json = 82608e71dfc28cb0f7a754981b856fae0a3446c505095acc4a4d2459761e41e7. Independently verified every source hash in FREEZE and every entry in DATA-SHA256.txt after computation. No source changes, detector tuning or numerical rerun by the reviewer.

Fresh checks, with single-thread BLAS/OpenMP:
- Exactly32 requested seed/fit records across16 fixed worlds;124 available allocations, all12 failed restarts retained. Totals were observed, not used as a filter or predetermined pass condition.
- 96 distinct seeds and5,120 exact first64 raw sample matrix comparisons across all16 worlds. All32 output records share holdout512, design and detector latent fixtures within nested-fit world pairs. H0 calibration/evaluation and H1 evaluation use separate declared seeds and distinct fixtures. Pseudorandom stream separation is not mathematical independence proof.
- All507,904 saved Float64 scores checked for finite values, calibration order/threshold, decisions/counts/rates and independent beta/Clopper–Pearson intervals. Maximum interval discrepancy8.14e-15.
- Independent NumPy observation/covariance oracle reconstructed1,116 first-three-column max-prior MAPRT scores: maximum absolute error2.56e-13. AP-only; max-prior normalizer checked, not marginalized determinant normalization.
- All2,225 convex certificates independently reconstructed; maximum certificate discrepancy2.67e-15. CCP tangent gain, accepted/best restart selection, iteration caps, constraints and fitted/held-out metrics checked; maximum metric discrepancy3.56e-15.
- Independent summary checker matched all crossing/rank/tie counts, equal-world means, missing-world counts and available-pair whole-world bootstrap intervals. Paired missing worlds excluded from estimand, counted explicitly, never imputed.
- Five mutation tests rejected changed score, certificate, missing allocation, incorrect selected restart and rejected restart marked accepted.

Scope limits: conditional reduced model, fixed geometry and AP-only study. No full-paper/source-curve reproduction, global nonconvex optimality, population feasibility, distribution-free CFAR, significant rank reversal, website/deployment or actual-browser acceptance. Only first3 observation columns per stream are independently reconstructed; remaining saved scores receive statistical consistency checks. Convex certificates use double precision, not directed rounding. No new pilot records were present; review-contract reports zero pilot runs honestly, while main traces were fully checked.

Checkers and current results: review-contract.mjs/json, review-numeric.py/json, review-summary.py/json, review-mutations.py/json. Set MAPRT_STUDY to the new study directory; Python requires NumPy/SciPy. Source recovery rationale remains in RECOVERY-REVIEW.md. Copy these sources/results and this report into the new archive. Do not relabel the archive as original recovered bytes.
