"""Validate persisted results and independently recompute finite CP residuals.

This verifier reuses only the deterministic observation generator, not the
receiver update, reconstruction or parameter recovery functions.
"""
import argparse,hashlib,json
from pathlib import Path
import numpy as np
from run_experiment import scene,pair_observations
from sync_core import Config


def complex_array(x):return np.array(x['real'])+1j*np.array(x['imag'])


def direct_reconstruction(factors):
    a,b,c=[complex_array(f) if isinstance(f,dict) else f for f in factors]
    result=np.zeros((len(a),len(b),len(c)),complex)
    # Independent outer products; no production reconstruct/khatri_rao/einsum.
    for l in range(a.shape[1]):
        result+=a[:,l,None,None]*b[None,:,l,None]*c[None,None,:,l]
    return result


def verify(directory):
    directory=Path(directory);cfg=Config();count=0;checks=0;max_residual_error=0.;max_parameter_error=0.
    for line in (directory/'raw-trials.jsonl').open():
        r=json.loads(line);rank=r['rank'];trial=r['trial'];pair=r['pair'];snr=r['snr_db']
        data=scene(cfg,rank,trial)
        yy,_,_,_,info=pair_observations(cfg,data,rank,trial,pair,snr)
        for i in range(2):
            assert info[i]['normalized_observation_sha256']==r['observations'][i]['normalized_observation_sha256']
            checks+=1
        for name,run in r['methods'].items():
            if 'failure' in run:continue
            for i,link in enumerate(run['links']):
                model=direct_reconstruction(link['factors'])
                residual=float(np.sqrt(np.sum(abs(model-yy[i])**2)))
                err=abs(residual-link['residual_norm'])/max(residual,1)
                assert err<2e-12,(count,name,i,err)
                max_residual_error=max(max_residual_error,err);checks+=1
                if name=='scpd':
                    trace=link['trace']
                    assert len(trace)==link['iterations']+1
                    assert abs(trace[-1]['residual_norm']-residual)<max(residual,1)*2e-12
                    assert link['iterations']<=cfg.iterations
                    states=[complex_array(f) for f in r['methods']['smoothed_cp_variant']['links'][i]['factors']]
                    for record in trace[1:]:
                        assert [x['axis'] for x in record['substeps']]==[0,1,2]
                        for step in record['substeps']:
                            axis=step['axis'];q=states[axis].shape[0]
                            states[axis]=np.column_stack([(p['amplitude_real']+1j*p['amplitude_imag'])*
                                np.exp(1j*np.arange(q)*p['phase_rad']) for p in step['projections']])
                            step_residual=float(np.linalg.norm(direct_reconstruction(states)-yy[i]))
                            assert abs(step_residual-step['residual_norm'])<max(step_residual,1)*2e-12
                            checks+=1
                        # Reproduce the documented tensor-preserving gauge normalization.
                        for axis in (1,2):
                            scale=states[axis][0].copy();states[axis]/=scale;states[0]*=scale
                    checks+=3
            p1=np.array(run['links'][0]['phases']);p2=np.array(run['links'][1]['phases'])
            e=run['estimate'];perm=e['permutation'];pp2=p2[:,perm]
            expected=np.r_[np.mean(p1[1]-p2[1])/(4*np.pi*cfg.df),
                           np.mean(p2[2]-p1[2])/(4*np.pi*cfg.symbol_s),
                           -(p1[1]+pp2[1])/(4*np.pi*cfg.df),
                           (p1[2]+pp2[2])/(4*np.pi*cfg.symbol_s)]
            actual=np.r_[e['offset2_s'],e['cfo2_hz'],e['delay_s'],e['doppler_hz']]
            err=float(np.max(abs(expected-actual)));assert err<1e-10
            max_parameter_error=max(max_parameter_error,err);checks+=len(actual)
        count+=1
    result={'pair_trials_verified':count,'assertions':checks,'max_relative_residual_error':max_residual_error,
            'max_parameter_formula_error':max_parameter_error,'observation_regeneration_hashes':'all matched',
            'scope':'Finite persisted evidence and deterministic generators; not an independent scientific peer review'}
    (directory/'verification.json').write_text(json.dumps(result,indent=2));return result


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('directory',nargs='?',default='evidence');args=parser.parse_args()
    print(json.dumps(verify(args.directory),indent=2))
