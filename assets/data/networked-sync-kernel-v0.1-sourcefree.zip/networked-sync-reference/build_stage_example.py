"""Recompute actual preprojection LS columns and full sampled correlations.

The example is tied to a saved receiver run, not synthesized from its accepted
frequency. Every stage residual is compared to the original recorded run.
"""
import json
from pathlib import Path
import numpy as np
from run_experiment import jsonable,scene,pair_observations,digest
from sync_core import Config


def cx(x):return np.array(x['real'])+1j*np.array(x['imag'])


def tensor(fs):
    y=np.zeros(tuple(len(f) for f in fs),complex)
    for l in range(fs[0].shape[1]):y+=fs[0][:,l,None,None]*fs[1][None,:,l,None]*fs[2][None,None,:,l]
    return y


def main(directory='evidence'):
    root=Path(directory);cfg=Config()
    row=next(json.loads(line) for line in (root/'raw-trials.jsonl').open()
             if (lambda x:x['rank']==2 and x['trial']==0 and x['pair']==0 and x['snr_db']==-10)(json.loads(line)))
    data=scene(cfg,2,0);yy,_,_,_,_=pair_observations(cfg,data,2,0,0,-10);y=yy[0]
    fs=[cx(f) for f in row['methods']['smoothed_cp_variant']['links'][0]['factors']]
    output={'example_id':{'rank':2,'trial':0,'pair':0,'snr_db':-10,'link':0},
            'core_sha256':'88a161d7d7d55ad4a2e703b0afb590c69644b0c61eaf370c2f6f519fc650f10e',
            'observation_file':'observations-L2-snr-10.npz','observation_key':'link1',
            'normalized_observation_sha256':digest(y),'initial_factors':fs,
            'scope':'Full actual A/B/C projection stages for one selected saved SCPD link run',
            'recompute':'python build_stage_example.py; direct LS using input factors, then full FFT correlation grid from each LS column',
            'curve_definition':'abs(v(phi)^H xbar)/(sqrt(Q)*norm(xbar)); v[q]=exp(+j*q*phi); not a curve synthesized from the selected phase',
            'stages':[]}
    for iteration in row['methods']['scpd']['links'][0]['trace'][1:]:
        for recorded in iteration['substeps']:
            axis=recorded['axis'];other=[a for a in range(3) if a!=axis]
            # Independent Khatri-Rao construction, with explicit C-order.
            d=np.column_stack([np.outer(fs[other[0]][:,l],fs[other[1]][:,l]).ravel() for l in range(2)])
            e=np.moveaxis(y,axis,-1).reshape(-1,y.shape[axis])
            bar=np.linalg.lstsq(d,e,rcond=1e-12)[0].T
            q=len(bar);size=cfg.projection_oversampling*(1<<int(np.ceil(np.log2(q))))
            phase=(2*np.pi*np.arange(size)/size+np.pi)%(2*np.pi)-np.pi
            order=np.argsort(phase)
            columns=[];updated=[]
            for l in range(2):
                x=bar[:,l];meta=recorded['projections'][l]
                curve=np.abs(np.fft.fft(x,n=size))/(np.sqrt(q)*np.linalg.norm(x))
                v=np.exp(1j*np.arange(q)*meta['phase_rad'])
                projected=(meta['amplitude_real']+1j*meta['amplitude_imag'])*v
                amplitude=np.vdot(v,x)/q
                assert abs(amplitude-projected[0])<1e-10
                updated.append(projected)
                columns.append({'column':l,'unconstrained_ls_column':x,'grid_phase_rad':phase[order],
                    'grid_normalized_correlation':curve[order],
                    'accepted_phase_rad':meta['phase_rad'],'accepted_amplitude':amplitude,
                    'accepted_normalized_correlation':float(abs(np.vdot(v,x))/(np.sqrt(q)*np.linalg.norm(x))),
                    'projected_column':projected})
            stage={'iteration':iteration['iteration'],'axis':axis,'input_factors':fs,
                   'design_shape':list(d.shape),'rhs_shape':list(e.shape),'columns':columns}
            fs=[f.copy() for f in fs];fs[axis]=np.column_stack(updated)
            residual=float(np.linalg.norm(tensor(fs)-y))
            assert abs(residual-recorded['residual_norm'])<max(residual,1)*2e-12
            stage.update({'residual_norm':residual,'recorded_residual_norm':recorded['residual_norm']})
            output['stages'].append(stage)
        for axis in (1,2):
            scale=fs[axis][0].copy();fs[axis]/=scale;fs[0]*=scale
    output['final_factors']=fs;output['stage_count']=len(output['stages'])
    (root/'full-stage-example.json').write_text(json.dumps(jsonable(output),indent=2,allow_nan=False))
    print(json.dumps({'stage_count':output['stage_count'],'all_recorded_residuals_match':True,
                      'full_stage_example_bytes':(root/'full-stage-example.json').stat().st_size},indent=2))


if __name__=='__main__':main()
