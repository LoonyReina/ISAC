"""Freeze only original code, factual audits and generated evidence; no paper."""
import hashlib,json,zipfile
from pathlib import Path

ROOT=Path(__file__).resolve().parent


def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    eligible=[]
    for p in ROOT.rglob('*'):
        if not p.is_file() or '__pycache__' in p.parts:continue
        if p.name in ('FREEZE.json','freeze-result.json') or p.suffix=='.zip':continue
        if p.suffix.lower() in ('.pdf','.png','.jpg','.jpeg','.html','.tex'):
            raise RuntimeError(f'Unexpected source/visual file in source-free package: {p.relative_to(ROOT)}')
        eligible.append(p)
    files=[{'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(eligible)]
    summary=json.loads((ROOT/'evidence/summary.json').read_text())
    validation=json.loads((ROOT/'evidence/verification.json').read_text())
    manifest={'package':'networked-sync-reference-v0.1','date_utc':'2026-10-12',
              'source':'https://arxiv.org/html/2607.18680v1','source_pdf_sha256':'e8da91552c32d61dd40cbc3c0224c7b654df04e9a4c3e85c0781d58f66853f02',
              'core_sha256':sha(ROOT/'sync_core.py'),'claim':'Bounded source-derived Algorithm1 receiver and original-dimension reduced-Monte-Carlo slice',
              'not_claimed':['exact published curves','full paper','exact author CPVDM baseline','SOE-MP','tracking/adaptive beams','hardware','live/browser latency'],
              'pair_trials':summary['pair_trials'],'persisted_verification':validation,
              'source_free':True,'paper_or_third_party_code_redistributed':False,'files':files}
    freeze=ROOT/'FREEZE.json';freeze.write_text(json.dumps(manifest,indent=2)+'\n')
    archive=ROOT.parent/'networked-sync-kernel-v0.1-sourcefree.zip'
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in sorted(eligible+[freeze]):
            info=zipfile.ZipInfo(str(Path(ROOT.name)/p.relative_to(ROOT)),date_time=(2026,10,12,0,0,0))
            info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o644<<16
            z.writestr(info,p.read_bytes())
    print(json.dumps({'freeze_sha256':sha(freeze),'archive':str(archive),'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive),'files':len(files)+1},indent=2))


if __name__=='__main__':main()
