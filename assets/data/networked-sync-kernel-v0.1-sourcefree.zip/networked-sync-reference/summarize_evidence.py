"""Descriptive summary and scene-cluster bootstrap; no trial filtering hidden."""
import json
from collections import defaultdict
from pathlib import Path
import numpy as np


def main(directory='evidence'):
    root=Path(directory);rows=[json.loads(x) for x in (root/'raw-trials.jsonl').read_text().splitlines()]
    groups=defaultdict(list)
    stats={'pair_trials':len(rows),'sampling_interval_violations':0,'cp_violations':0,
           'rank_condition_violations':0,'scpd_links':0,'source_stopping_test_met':0,
           'iteration_cap':0,'nonmonotone_full_sweeps':0,'nonmonotone_substeps':0,
           'ambiguous_associations':0,'numerical_failures':{},'max_doppler_over_subcarrier_spacing':0.,
           'max_delay_s':0.,'min_effective_gain_magnitude':None}
    mingain=np.inf
    for row in rows:
        s=row['sampling_diagnostics']
        stats['sampling_interval_violations']+=not s['alias_free_composites']
        stats['cp_violations']+=not s['cp_contains_positive_delays']
        stats['max_doppler_over_subcarrier_spacing']=max(stats['max_doppler_over_subcarrier_spacing'],s['max_doppler_over_subcarrier_spacing'])
        stats['max_delay_s']=max(stats['max_delay_s'],s['max_composite_delay_s'])
        for ident in row['identifiability_evaluation_only']:
            stats['rank_condition_violations']+=not ident['sufficient_condition_numerically_met']
        for ob in row['observations']:
            g=ob['effective_gains'];mingain=min(mingain,float(np.min(abs(np.array(g['real'])+1j*np.array(g['imag'])))))
        for method,result in row['methods'].items():
            groups[(row['rank'],row['snr_db'],method)].append((row['trial'],result))
            if 'failure' in result:
                stats['numerical_failures'][method]=stats['numerical_failures'].get(method,0)+1;continue
            stats['ambiguous_associations']+=result['estimate']['ambiguous_association']
            if method!='scpd':continue
            for link in result['links']:
                stats['scpd_links']+=1
                stats['source_stopping_test_met']+=link['stopping_condition_met']
                stats['iteration_cap']+=not link['stopping_condition_met']
                previous=link['trace'][0]['residual_norm']
                for rec in link['trace'][1:]:
                    stats['nonmonotone_full_sweeps']+=rec['residual_norm']>previous*(1+1e-12)
                    before=previous
                    for step in rec['substeps']:
                        stats['nonmonotone_substeps']+=step['residual_norm']>before*(1+1e-12)
                        before=step['residual_norm']
                    previous=rec['residual_norm']
    stats['min_effective_gain_magnitude']=mingain
    rng=np.random.default_rng(901371);intervals=[]
    for (rank,snr,method),items in sorted(groups.items()):
        bytrial=defaultdict(list)
        for trial,result in items:bytrial[trial].append(result)
        keys=sorted(bytrial);success=[];rmse=[]
        for _ in range(500):
            sampled=[r for key in rng.choice(keys,len(keys),replace=True) for r in bytrial[key]]
            success.append(np.mean([r.get('evaluation',{}).get('source_geometry_success',False) for r in sampled]))
            errors=[r['evaluation']['errors']['offset_ns'] for r in sampled if 'evaluation' in r]
            rmse.append(np.sqrt(np.mean(np.square(errors))) if errors else np.nan)
        intervals.append({'rank':rank,'snr_db':snr,'method':method,'independent_scene_clusters':len(keys),
                          'success_fraction_bootstrap95':np.quantile(success,[.025,.975]).tolist(),
                          'all_solved_offset_rmse_ns_bootstrap95':np.nanquantile(rmse,[.025,.975]).tolist()})
    result={'diagnostics':stats,'bootstrap':{'replicates':500,'seed':901371,'unit':'whole network scene; all six pairs kept together',
        'warning':'Descriptive percentile intervals with few clusters; not original-paper uncertainty and not a formal accuracy certification','intervals':intervals}}
    (root/'diagnostic-summary.json').write_text(json.dumps(result,indent=2))
    print(json.dumps(stats,indent=2))


if __name__=='__main__':main()
