"""Seeded Fig2/3-inspired slice, original tensor dimensions, source-free outputs.

Run single-threaded: OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
python run_experiment.py --trials 12 --output evidence
"""
from __future__ import annotations
import argparse, hashlib, json, platform, sys, time
from dataclasses import asdict
from itertools import combinations, permutations
from pathlib import Path
import numpy as np
import scipy
from sync_core import *

BS=np.array([[80.,80.],[-80.,-80.],[80.,-80.],[-80.,80.]])
PAIRS=list(combinations(range(4),2))
ROOT_SEED=260718680


def jsonable(x):
    if isinstance(x,np.ndarray):
        if np.iscomplexobj(x):return {'real':x.real.tolist(),'imag':x.imag.tolist()}
        return jsonable(x.tolist())
    if isinstance(x,np.generic):return jsonable(x.item())
    if isinstance(x,complex):return {'real':x.real,'imag':x.imag}
    if isinstance(x,dict):return {str(k):jsonable(v) for k,v in x.items()}
    if isinstance(x,(tuple,list)):return [jsonable(v) for v in x]
    if isinstance(x,float) and not np.isfinite(x):return None
    return x


def digest(x):
    return hashlib.sha256(np.asarray(x,dtype='<c16').tobytes(order='C')).hexdigest()


def geometry(cfg,positions,velocities):
    rays=positions[None,:,:]-BS[:,None,:]
    distances=np.linalg.norm(rays,axis=2)
    units=rays/distances[:,:,None]
    # Declared implementation choice: array broadside points toward square center.
    broadside=-BS/np.linalg.norm(BS,axis=1)[:,None]
    tangent=np.column_stack([-broadside[:,1],broadside[:,0]])
    angles=np.arcsin(np.clip(np.einsum('dlc,dc->dl',units,tangent),-1,1))
    delays=np.array([(distances[a]+distances[b])/cfg.light_mps for a,b in PAIRS])
    # Source Eq53 convention: nu = positive range-rate / wavelength.
    dopplers=np.array([np.sum((units[a]+units[b])*velocities,axis=1)/cfg.wavelength_m for a,b in PAIRS])
    return angles,delays,dopplers


def scene(cfg,rank,index):
    rng=np.random.default_rng(np.random.SeedSequence([ROOT_SEED,rank,index,1]))
    attempts=0
    while True:
        attempts+=1
        positions=rng.uniform(-80,80,(rank,2))
        speeds=rng.uniform(0,30,rank);directions=rng.uniform(-np.pi,np.pi,rank)
        velocities=speeds[:,None]*np.column_stack([np.cos(directions),np.sin(directions)])
        angles,delays,dopplers=geometry(cfg,positions,velocities)
        if rank==1 or (np.min(np.abs(np.diff(angles,axis=1)))>=np.deg2rad(12)
                        and np.min(np.abs(np.diff(delays,axis=1)))*cfg.light_mps>=12):break
        if attempts>100000:raise RuntimeError('Separation rejection budget exceeded')
    beam=np.exp(1j*rng.uniform(-np.pi,np.pi,(4,cfg.M)))/np.sqrt(cfg.M)
    alpha=np.exp(1j*rng.uniform(-np.pi,np.pi,(6,2,rank)))
    offsets=rng.normal(0,10e-9,6);cfos=rng.normal(0,100,6)
    return {'positions_m':positions,'velocities_mps':velocities,'angles_rad':angles,
            'delay_s':delays,'doppler_hz':dopplers,'beamformers':beam,'alpha':alpha,
            'offset2_s':offsets,'cfo2_hz':cfos,'generation_attempts':attempts}


def pair_observations(cfg,data,rank,index,pair,snr_db):
    # Noise seed excludes SNR, so the SNR sweep scales the same unit noise.
    rng=np.random.default_rng(np.random.SeedSequence([ROOT_SEED,rank,index,pair,2]))
    pilots=np.exp(.5j*np.pi*rng.integers(0,4,(2,cfg.N,cfg.K)))
    a,b=PAIRS[pair];observations=[];gains=[];variances=[];summaries=[]
    for link,(rx,tx,sign) in enumerate(((a,b,-1),(b,a,1))):
        alpha=data['alpha'][pair,link]
        variance=float(np.sum(abs(alpha)**2)/10**(snr_db/10))
        noise=np.sqrt(variance/2)*(rng.normal(size=cfg.shape)+1j*rng.normal(size=cfg.shape))
        txsteer=vandermonde(cfg.M,2*np.pi*cfg.spacing_wavelengths*np.sin(data['angles_rad'][tx]))
        gain=alpha*(txsteer.T@data['beamformers'][tx]);gains.append(gain);variances.append(variance)
        args=(cfg,data['delay_s'][pair],data['doppler_hz'][pair],data['angles_rad'][rx],
              data['angles_rad'][tx],alpha,data['beamformers'][tx],pilots[link],
              sign*data['offset2_s'][pair],sign*data['cfo2_hz'][pair])
        observation=observed_link(*args,noise)
        noiseless=observed_link(*args,np.zeros(cfg.shape,complex))
        normalized=remove_pilots(observation,pilots[link]);observations.append(normalized)
        summaries.append({'raw_observation_sha256':digest(observation),'normalized_observation_sha256':digest(normalized),
                          'pilot_sha256':digest(pilots[link]),'variance_per_complex_entry':variance,
                          'received_clean_power_mean':float(np.mean(abs(noiseless)**2)),
                          'received_snr_db':float(10*np.log10(np.mean(abs(noiseless)**2)/variance)),
                          'effective_gains':gain})
    return observations,pilots,gains,variances,summaries


def evaluate(estimate,data,pair,cfg):
    a,b=PAIRS[pair];rank=len(estimate['delay_s'])
    # Truth is used ONLY here, after estimation, for component labels and error.
    costs=[]
    for perm in permutations(range(rank)):
        p=np.array(perm)
        vector=np.concatenate([(estimate['delay_s'][p]-data['delay_s'][pair])*2*np.pi*cfg.df,
                               (estimate['doppler_hz'][p]-data['doppler_hz'][pair])*2*np.pi*cfg.symbol_s,
                               estimate['angles1_rad'][p]-data['angles_rad'][a],
                               estimate['angles2_rad'][p]-data['angles_rad'][b]])
        costs.append((float(vector@vector),p))
    _,p=min(costs,key=lambda x:x[0])
    errors={'offset_ns':float((estimate['offset2_s']-data['offset2_s'][pair])*1e9),
            'cfo_hz':float(estimate['cfo2_hz']-data['cfo2_hz'][pair]),
            'delay_ns':(estimate['delay_s'][p]-data['delay_s'][pair])*1e9,
            'doppler_hz':estimate['doppler_hz'][p]-data['doppler_hz'][pair],
            'angle_deg':np.rad2deg(np.concatenate([estimate['angles1_rad'][p]-data['angles_rad'][a],
                                                estimate['angles2_rad'][p]-data['angles_rad'][b]]))}
    baseline=np.linalg.norm(BS[a]-BS[b])
    success=bool(np.all(estimate['delay_s']*cfg.light_mps>=baseline))
    return {'truth_evaluation_permutation':p,'errors':errors,
            'source_geometry_success':success,'minimum_range_margin_m':float(np.min(estimate['delay_s']*cfg.light_mps-baseline)),
            'gross_error_diagnostic':bool(abs(errors['cfo_hz'])>500 or np.max(abs(errors['delay_ns']))>100 or np.max(abs(errors['angle_deg']))>10)}


def summarized_result(result):
    # Factor matrices are small and let independent checks reconstruct the
    # exact final model, including non-Vandermonde ESPRIT rank-one factors.
    return dict(result)


def aggregate(records):
    groups={}
    for rec in records:
        for method,run in rec['methods'].items():
            key=(rec['rank'],rec['snr_db'],method)
            groups.setdefault(key,[]).append(run)
    out=[]
    for (rank,snr,method),runs in sorted(groups.items()):
        solved=[r for r in runs if 'evaluation' in r]
        success=[r for r in solved if r['evaluation']['source_geometry_success']]
        item={'rank':rank,'snr_db':snr,'method':method,'total_trials':len(runs),'numerical_failures':len(runs)-len(solved),
              'source_geometry_successes':len(success),'success_rate':len(success)/len(runs),
              'gross_error_diagnostics':sum(r['evaluation']['gross_error_diagnostic'] for r in solved)}
        for label,values in [('all_solved_rmse',solved),('source_success_conditioned_rmse',success)]:
            item[label]={metric:float(np.sqrt(np.mean(np.concatenate([np.atleast_1d(r['evaluation']['errors'][metric]) for r in values])**2))) if values else None
                         for metric in ['offset_ns','cfo_hz','delay_ns','doppler_hz','angle_deg']}
        out.append(item)
    return out


def run(trials,output,snrs=(-25,-10,5)):
    cfg=Config();out=Path(output);out.mkdir(parents=True,exist_ok=True)
    records=[];start=time.perf_counter()
    config={'source_url':'https://arxiv.org/html/2607.18680v1','source_pdf_sha256':'e8da91552c32d61dd40cbc3c0224c7b654df04e9a4c3e85c0781d58f66853f02',
            'claim':'Original-dimension, reduced-Monte-Carlo, source-derived Fig2/3 experiment; not exact curve reproduction',
            'config':asdict(cfg),'ranks':[1,2],'snrs_db':list(snrs),'network_draws_per_rank':trials,
            'pairs':PAIRS,'root_seed':ROOT_SEED,'numpy_version':np.__version__,'scipy_version':scipy.__version__,'python_version':sys.version,
            'source_baselines_implemented':['ESPRIT-LS-AppendixB'],
            'adapted_baseline':'three-axis-smoothed-CP-variant from main-paper Eqs29-35; official CP-VDM figure variant unverified',
            'missing_baselines':['SOE-MP','exact author CP-VDM'],
            'choices':{'alpha':'unit amplitude, independent uniform phase per target/direction/pair',
                       'beamformer':'constant modulus random phases, norm1, one beam per physical BS shared across pairs',
                       'pilots':'known unit-modulus QPSK; independent per pair and direction',
                       'array_axes':'broadside points toward square center; tangent is counter-clockwise perpendicular',
                       'separation':'L2 rejection until >=12 degrees at all four BSs and >=12 m at all six pairs',
                       'projection':'FFT16-times-power-of-two grid, bounded refinement of every sampled local maximum',
                       'initialization':'same-observation three-axis-smoothed CP variant, window4x8x5; no truth',
                       'phase_extraction':'adjacent slope; exact for structured columns, not a separate PUMA implementation',
                       'noise':'iid circular Gaussian, variance=sum(abs(alpha)^2)/10^(SNR/10) before pilot division',
                       'offsets':'per-pair independent source Gaussian; no enforced network cycle consistency'},
            'excluded':['Algorithm2 tracking/fusion/adaptive beams','full Monte Carlo500','all SNR points','time-domain ICI/ISI','communication decoding','hardware data','live latency'],
            'estimator_inputs':['complex normalized observations','known rank L','sampling configuration','declared initialization/search settings']}
    (out/'experiment-config.json').write_text(json.dumps(jsonable(config),indent=2))
    with (out/'raw-trials.jsonl').open('w') as stream:
        for rank in (1,2):
            for trial in range(trials):
                data=scene(cfg,rank,trial)
                for snr in snrs:
                    for pair,(a,b) in enumerate(PAIRS):
                        observations,pilots,gains,variances,obs_info=pair_observations(cfg,data,rank,trial,pair,snr)
                        ids={'rank':rank,'trial':trial,'snr_db':snr,'pair':pair}
                        record={**ids,'scene':data,'observations':obs_info,'methods':{}}
                        truth_fs=[model_factors(cfg,data['delay_s'][pair],data['doppler_hz'][pair],data['angles_rad'][rx],gains[i],s*data['offset2_s'][pair],s*data['cfo2_hz'][pair])
                                  for i,(rx,s) in enumerate(((a,-1),(b,1)))]
                        record['identifiability_evaluation_only']=[identifiability(fs,(4,8,5)) for fs in truth_fs]
                        phases=np.concatenate([factor_phases(fs)[1:].ravel() for fs in truth_fs])
                        composite_delays=np.concatenate([data['delay_s'][pair]+s*data['offset2_s'][pair] for s in (-1,1)])
                        composite_dopplers=np.concatenate([data['doppler_hz'][pair]+s*data['cfo2_hz'][pair] for s in (-1,1)])
                        record['sampling_diagnostics']={'max_composite_delay_s':float(np.max(composite_delays)),
                            'delay_principal_half_period_s':.5/cfg.df,'cp_assumption_s':.5/cfg.df,
                            'max_composite_doppler_hz':float(np.max(abs(composite_dopplers))),
                            'doppler_principal_half_period_hz':.5/cfg.symbol_s,
                            'max_doppler_over_subcarrier_spacing':float(np.max(abs(composite_dopplers))/cfg.df),
                            'alias_free_composites':bool(np.max(abs(composite_delays))*cfg.df<.5 and np.max(abs(composite_dopplers))*cfg.symbol_s<.5),
                            'cp_contains_positive_delays':bool(np.min(composite_delays)>=0 and np.max(composite_delays)<.5/cfg.df)}
                        initial=[];initial_elapsed=None
                        try:
                            initial_start=time.perf_counter()
                            initial=[cpvdm_smooth(y,rank) for y in observations]
                            initial_elapsed=time.perf_counter()-initial_start
                            record['methods']['smoothed_cp_variant']={'links':[summarized_result(r) for r in initial],
                                'estimate':pair_parameters(*initial,cfg),'offline_solver_elapsed_s':initial_elapsed,
                                'timing_scope':'both links; tensor estimator only, excludes reciprocal extraction and generation'}
                        except Exception as exc:record['methods']['smoothed_cp_variant']={'failure':str(exc),'exception':type(exc).__name__}
                        for method in ('esprit_ls','scpd'):
                            t0=time.perf_counter()
                            try:
                                results=[esprit_ls(y,rank) for y in observations] if method=='esprit_ls' else [scpd(y,rank,cfg,initial=initial[i]) for i,y in enumerate(observations)]
                                solve_elapsed=time.perf_counter()-t0
                                record['methods'][method]={'links':[summarized_result(r) for r in results],
                                    'estimate':pair_parameters(*results,cfg),
                                    'offline_solver_elapsed_s':solve_elapsed+(initial_elapsed if method=='scpd' else 0),
                                    'timing_scope':'both links; tensor estimator including initializer, excludes reciprocal extraction and generation'}
                                if method=='scpd':record['methods'][method].update({'offline_initialization_elapsed_s':initial_elapsed,
                                    'offline_refinement_elapsed_s':solve_elapsed})
                            except Exception as exc:record['methods'][method]={'failure':str(exc),'exception':type(exc).__name__}
                        for result in record['methods'].values():
                            if 'estimate' in result:result['evaluation']=evaluate(result['estimate'],data,pair,cfg)
                        # Exact finite observations for a small audit subset; all others regen from manifest.
                        if trial==0 and pair==0:
                            np.savez_compressed(out/f'observations-L{rank}-snr{snr}.npz',link1=observations[0],link2=observations[1],pilots=pilots)
                        stream.write(json.dumps(jsonable(record),separators=(',',':'),allow_nan=False)+'\n');stream.flush()
                        records.append(record)
                print(json.dumps({'rank':rank,'completed_network_draws':trial+1,'total_pair_trials':len(records),'elapsed_s':time.perf_counter()-start}),flush=True)
    summary={'elapsed_s':time.perf_counter()-start,'pair_trials':len(records),'aggregate':aggregate(records)}
    (out/'summary.json').write_text(json.dumps(jsonable(summary),indent=2,allow_nan=False))
    return summary


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--trials',type=int,default=12);parser.add_argument('--output',default='evidence')
    parser.add_argument('--snrs',type=int,nargs='+',default=[-25,-10,5]);args=parser.parse_args()
    print(json.dumps(jsonable(run(args.trials,args.output,args.snrs)),indent=2))
