"""Independent finite-equation, algebra and receiver regression checks."""
import unittest
from itertools import permutations
import numpy as np
from sync_core import *


def literal_observation(cfg,tau,nu,rx,tx,alpha,w,pilot,dt,df,noise):
    """Independent Eq1/2 scalar loops; does not call production CP/model code."""
    y=np.array(noise,copy=True)
    for m,n,k in np.ndindex(cfg.shape):
        for l in range(len(tau)):
            for t in range(cfg.M):
                phase=(2*np.pi*cfg.spacing_wavelengths*(m*np.sin(rx[l])+t*np.sin(tx[l]))
                       -2*np.pi*cfg.df*n*(tau[l]+dt)
                       +2*np.pi*cfg.symbol_s*k*(nu[l]+df))
                y[m,n,k]+=alpha[l]*w[t]*pilot[n,k]*np.exp(1j*phase)
    return y


class CoreTests(unittest.TestCase):
    def setUp(self):
        self.cfg=Config(M=6,N=12,K=8,iterations=20)
        # The reduced N changes df; keep both composite delays inside 1/(2df).
        self.tau=np.array([.17e-6,.43e-6]);self.nu=np.array([-730.,1220.])
        self.angles=np.array([[-.44,.37],[.18,-.52]])
        self.gains=np.array([[1+.2j,.8-.1j],[.6+.3j,-.4+.9j]])
        self.dt=13e-9;self.df=-170.
        self.fs=[model_factors(self.cfg,self.tau,self.nu,self.angles[i],self.gains[i],s*self.dt,s*self.df)
                 for i,s in enumerate((-1,1))]
        self.y=[reconstruct(f) for f in self.fs]

    def test_scalar_observation(self):
        rng=np.random.default_rng(31);cfg=Config(M=3,N=5,K=4)
        pilot=np.exp(1j*rng.uniform(-np.pi,np.pi,(cfg.N,cfg.K)))
        w=np.exp(1j*rng.uniform(-np.pi,np.pi,cfg.M))/np.sqrt(cfg.M)
        noise=(rng.normal(size=cfg.shape)+1j*rng.normal(size=cfg.shape))*.02
        args=(cfg,self.tau,self.nu,self.angles[0],self.angles[1],self.gains[0],w,pilot,self.dt,self.df,noise)
        np.testing.assert_allclose(observed_link(*args),literal_observation(*args),atol=1e-13)
        np.testing.assert_allclose(remove_pilots(observed_link(*args),pilot)*pilot[None],observed_link(*args),atol=1e-14)

    def test_nonzero_pilot_required(self):
        with self.assertRaises(ValueError):remove_pilots(self.y[0],np.zeros((12,8)))

    def test_direct_tensor_sum(self):
        out=np.empty(self.cfg.shape,complex)
        for m,n,k in np.ndindex(self.cfg.shape):
            out[m,n,k]=sum(self.fs[0][0][m,l]*self.fs[0][1][n,l]*self.fs[0][2][k,l] for l in range(2))
        np.testing.assert_allclose(out,self.y[0],atol=2e-15)

    def test_each_unfolding_update(self):
        for axis in range(3):
            answer,_=mode_update(self.y[0],self.fs[0],axis,False)
            np.testing.assert_allclose(answer,self.fs[0][axis],atol=2e-14)

    def test_scale_and_permutation_invariance(self):
        fs=[x[:,[1,0]].copy() for x in self.fs[0]]
        s=np.array([.3+.7j,-2+1j]);t=np.array([3-1j,.2-.4j])
        fs[0]*=s;fs[1]*=t;fs[2]/=s*t
        np.testing.assert_allclose(reconstruct(fs),self.y[0],atol=3e-15)
        np.testing.assert_allclose(reconstruct(normalize_scales(fs)),self.y[0],atol=3e-15)
        np.testing.assert_allclose(factor_phases(fs),factor_phases(self.fs[0])[:,[1,0]],atol=1e-14)

    def test_projection_single_tone(self):
        for phase in (-np.pi+.001,-.519,0,.417,np.pi-.001):
            x=(.4-.7j)*np.exp(1j*np.arange(19)*phase)
            actual,p,_=project_column(x)
            self.assertLess(abs(wrap(p-phase)),4e-8)
            np.testing.assert_allclose(actual,x,atol=8e-7)

    def test_projection_dense_grid_lower_bound(self):
        rng=np.random.default_rng(88)
        x=rng.normal(size=11)+1j*rng.normal(size=11)
        actual,p,_=project_column(x)
        dense=2*np.pi*np.arange(32768)/32768
        correlations=np.abs(x.conj()@np.exp(1j*np.arange(11)[:,None]*dense))**2
        self.assertGreaterEqual(abs(np.vdot(x,np.exp(1j*np.arange(11)*p)))**2+1e-9,correlations.max())

    def test_projection_zero_column_fails(self):
        with self.assertRaises(ValueError):project_column(np.zeros(5))

    def test_smoothed_initializer_noiseless(self):
        for y in self.y:
            result=cpvdm_smooth(y,2,window=(3,5,4))
            self.assertLess(np.linalg.norm(reconstruct(result['factors'])-y)/np.linalg.norm(y),1e-10)

    def test_esprit_noiseless_and_right_conjugation(self):
        for y in self.y:
            result=esprit_ls(y,2)
            self.assertLess(result['residual_norm']/np.linalg.norm(y),1e-10)

    def test_reciprocal_signs_and_association(self):
        p1=factor_phases(self.fs[0]);p2=factor_phases(self.fs[1])[:,[1,0]]
        result=pair_parameters({'phases':p1},{'phases':p2},self.cfg)
        self.assertEqual(result['permutation'],[1,0])
        self.assertAlmostEqual(result['offset2_s'],self.dt,places=15)
        self.assertAlmostEqual(result['cfo2_hz'],self.df,places=9)
        np.testing.assert_allclose(result['delay_s'],self.tau,atol=1e-15)
        np.testing.assert_allclose(result['doppler_hz'],self.nu,atol=1e-9)

    def test_alias_not_truth_unwrapped(self):
        fs=model_factors(self.cfg,self.tau+1/self.cfg.df,self.nu,self.angles[0],self.gains[0],-self.dt,-self.df)
        np.testing.assert_allclose(reconstruct(fs),self.y[0],atol=8e-14)
        # No sampled receiver can distinguish delay plus an integer sample period.
        np.testing.assert_allclose(factor_phases(fs),factor_phases(self.fs[0]),atol=1e-13)

    def test_half_period_reciprocal_offset_ambiguity(self):
        tau2=self.tau+.5/self.cfg.df;dt2=self.dt+.5/self.cfg.df
        for i,sign in enumerate((-1,1)):
            fs=model_factors(self.cfg,tau2,self.nu,self.angles[i],self.gains[i],sign*dt2,sign*self.df)
            np.testing.assert_allclose(reconstruct(fs),self.y[i],atol=1e-13)

    def test_identifiability_rank_and_degenerate_failure(self):
        self.assertTrue(identifiability(self.fs[0],(3,5,4))['sufficient_condition_numerically_met'])
        identical=[np.repeat(x[:,:1],2,axis=1) for x in self.fs[0]]
        report=identifiability(identical,(3,5,4))
        self.assertFalse(report['sufficient_condition_numerically_met'])
        self.assertEqual(report['ranks'],[1,1])

    def test_pair_ambiguity_reported(self):
        p=np.array([[.2,-.3],[-.1,-.1],[.05,.05]])
        self.assertTrue(pair_parameters({'phases':p},{'phases':p},self.cfg)['ambiguous_association'])

    def test_algorithm1_noiseless_end_to_end(self):
        results=[scpd(y,2,self.cfg) for y in self.y]
        result=pair_parameters(*results,self.cfg)
        order=np.argsort(result['delay_s'])
        np.testing.assert_allclose(result['delay_s'][order],self.tau,atol=1e-13)
        np.testing.assert_allclose(result['doppler_hz'][order],self.nu,atol=.002)
        self.assertLess(abs(result['offset2_s']-self.dt),1e-13)
        self.assertLess(abs(result['cfo2_hz']-self.df),.002)

    def test_noisy_algorithm_retains_all_substeps(self):
        rng=np.random.default_rng(3)
        y=self.y[0]+.15*(rng.normal(size=self.cfg.shape)+1j*rng.normal(size=self.cfg.shape))
        result=scpd(y,2,self.cfg)
        self.assertEqual(len(result['trace']),result['iterations']+1)
        for record in result['trace'][1:]:
            self.assertEqual([x['axis'] for x in record['substeps']],[0,1,2])
            self.assertTrue(np.isfinite(record['residual_norm']))

    def test_nuisance_fim_rank(self):
        result=nuisance_fim(self.cfg,self.tau,self.nu,self.angles,self.gains,self.dt,self.df,[1,1])
        self.assertEqual(result['rank'],18)
        np.testing.assert_allclose(result['matrix'],result['matrix'].T,atol=1e-11)
        self.assertGreater(np.linalg.eigvalsh(result['covariance']).min(),0)

    def test_nuisance_fim_finite_difference(self):
        cfg=Config(M=3,N=5,K=4)
        tau=np.array([.21e-6]);nu=np.array([820.]);angles=np.array([[-.3],[.41]])
        gains=np.array([[.6+.4j],[-.7+.2j]])
        dt=11e-9;df=83.
        p=np.array([-2*np.pi*cfg.df*tau[0],2*np.pi*cfg.symbol_s*nu[0],
                    2*np.pi*cfg.spacing_wavelengths*np.sin(angles[0,0]),
                    2*np.pi*cfg.spacing_wavelengths*np.sin(angles[1,0]),
                    -2*np.pi*cfg.df*dt,2*np.pi*cfg.symbol_s*df,
                    gains[0,0].real,gains[0,0].imag,gains[1,0].real,gains[1,0].imag])
        def direct(v):
            out=[]
            for link,sign in enumerate((-1,1)):
                g=v[6+2*link]+1j*v[7+2*link]
                for m,n,k in np.ndindex(cfg.shape):
                    out.append(g*np.exp(1j*(m*v[2+link]+n*(v[0]+sign*v[4])+k*(v[1]+sign*v[5]))))
            return np.array(out)
        eps=2e-6;j=np.column_stack([(direct(p+eps*e)-direct(p-eps*e))/(2*eps) for e in np.eye(len(p))])
        numeric=2*np.real(j.conj().T@j)
        analytic=nuisance_fim(cfg,tau,nu,angles,gains,dt,df,[1,1])['matrix']
        np.testing.assert_allclose(analytic,numeric,rtol=2e-9,atol=1e-6)


if __name__=='__main__':unittest.main(verbosity=2)
