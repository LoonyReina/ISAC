# Development and verification record

This record distinguishes test-fixture mistakes, actual receiver outcomes and
pending acceptance stages. It is not a log of user-visible website changes.

- 2026-10-12: Read the current repository collaboration rules and paper
  backlog read-only. Confirmed this paper had no existing CP/CFO receiver.
- Verified official arXiv v1 identity and PDF hash. The independent audit
  viewed rendered PDF pages rather than relying only on extracted text.
- Implemented the separable complex observation model and source-derived
  Algorithm 1 from the documented equations. No author source code was used.
- Initial 19-test smoke had two failures: its reduced N=12 fixture retained a
  0.83 μs delay while keeping bandwidth fixed, exceeding the reduced fixture's
  0.55 μs principal delay bound. The receiver correctly returned the aliased
  delay. The fixture was changed to 0.17/0.43 μs; the original failure log is
  retained as `unit-tests-initial.log`. No receiver correction or truth-based
  phase unwrapping was made to force this test to pass.
- The 19-test suite then passed. Explicit alias/half-period ambiguity tests
  remain, so aliasing is not concealed by the corrected recovery fixture.
- An independent reviewer passed 11 additional tests, including high-precision
  LS/Fisher derivatives and polynomial-stationary projection maxima. Its
  separate report is owned by that reviewer and is not replaced by this log.
- The review identified an ambiguity in diagnostic timing scope. The runner
  now records SCPD initialization and refinement separately and sums them for
  estimator timing. All methods exclude generation and reciprocal extraction,
  and no browser or comparative runtime claim is made.
- A trace-only addition records complex projection amplitudes, allowing every
  intermediate structured factor to be reconstructed. All 19 author tests
  and 11 independent tests re-passed on that core revision.
- Main original-size sweep and stress probes are run only after the previous
  paper's heavy verification window, with BLAS/OpenMP restricted to one
  thread. Completed run manifests and verification files are authoritative;
  an absent file is not a passing stage.

Integration, browser acceptance, publication and live profiling are outside
this package. Full-paper reproduction remains unestablished.
