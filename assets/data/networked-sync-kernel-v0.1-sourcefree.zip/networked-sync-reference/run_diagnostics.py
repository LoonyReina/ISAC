"""Stress probes with all starts/outcomes retained; truth only in evaluation."""
import json
from pathlib import Path
import numpy as np
from sync_core import *
from run_experiment import scene,pair_observations,evaluate,jsonable,BS,PAIRS


def main(output='diagnostics'):
    out=Path(output);out.mkdir(exist_ok=True)
    cfg=Config();data=scene(cfg,2,0)
    yy,_,gains,variances,_=pair_observations(cfg,data,2,0,0,-10)
    report={'probe':'Same observations, observable-only restarts; no winner selected using truth','runs':[]}
    for name in ['subspace','random-0','random-1','random-2','random-3','random-4']:
        initial=[]
        for i,y in enumerate(yy):
            if name=='subspace':initial.append(cpvdm_smooth(y,2))
            else:
                rng=np.random.default_rng([14173,int(name[-1]),i])
                phase=rng.uniform(-np.pi,np.pi,(3,2))
                initial.append({'factors':factors_from_phases(y,phase),'method':name})
        record={'start':name,'methods':{}}
        for structured in (True,False):
            label='scpd' if structured else 'unstructured_als_diagnostic'
            try:
                results=[scpd(y,2,cfg,initial=initial[i],structured=structured) for i,y in enumerate(yy)]
                est=pair_parameters(*results,cfg)
                record['methods'][label]={'estimate':est,'evaluation':evaluate(est,data,0,cfg),
                    'links':results}
            except Exception as exc:record['methods'][label]={'failure':str(exc),'exception':type(exc).__name__}
        report['runs'].append(record)
    a,b=PAIRS[0]
    fim=nuisance_fim(cfg,data['delay_s'][0],data['doppler_hz'][0],data['angles_rad'][[a,b]],gains,
                     data['offset2_s'][0],data['cfo2_hz'][0],variances)
    report['evaluation_only_nuisance_fim']=fim
    # Exact duplicate paths: tensor rank drops although the requested L is two.
    fs=model_factors(cfg,[.6e-6,.6e-6],[500,500],[.3,.3],[1+.2j,.3-.5j],12e-9,100)
    report['duplicate_path_rank_diagnostic']=identifiability(fs,(4,8,5))
    try:
        rec=scpd(reconstruct(fs),2,cfg)
        report['duplicate_path_receiver']=rec
    except Exception as exc:report['duplicate_path_receiver']={'failure':str(exc),'exception':type(exc).__name__}
    (out/'stress-probes.json').write_text(json.dumps(jsonable(report),indent=2,allow_nan=False))
    print(json.dumps({'runs':len(report['runs']),'fim_rank':fim['rank'],'fim_size':fim['parameter_count']},indent=2))


if __name__=='__main__':main()
