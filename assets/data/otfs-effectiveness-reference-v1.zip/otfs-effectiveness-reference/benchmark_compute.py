"""Offline reference costs only; do not mislabel as browser measurements."""
from dataclasses import asdict
from pathlib import Path
import hashlib
import time
import numpy as np
from otfs_reference import *
from run_experiments import write


def main():
    rows=[];c,_=qam(16)
    for N,M in [(3,4),(4,8),(6,8),(4,16)]:
        f=Frame(N,M);rng=np.random.default_rng(87233)
        times=[];status=[];edges=[]
        for repeat in range(7):
            x=c[rng.integers(0,16,f.size)]
            start=time.perf_counter()
            H=channel_operator(f,[(.37,-.23,1),(min(M-1.1,2.63),.87,.5*np.exp(.7j))])
            y=H@x+noise(rng,f.size,10**(-12/10))
            out=mp_g(H,y,10**(-12/10),c,max_iter=30)
            times.append(1000*(time.perf_counter()-start));status.append(out["status"]);edges.append(out["edge_count"])
        rows.append({"frame":asdict(f),"paths":2,"constellation":16,"iterations_cap":30,"repeats":7,
                     "milliseconds":{"median":float(np.median(times)),"p95":float(np.quantile(times,.95)),"worst":max(times),"all":times},
                     "statuses":status,"edge_counts":edges,
                     "pair_potential_bytes":max(edges)*16*16*8,
                     "directed_message_bytes":max(edges)*2*16*8})
        print(N,M,rows[-1]["milliseconds"],flush=True)
    D=3200;E=D*(D-1)//2
    write("offline-compute-benchmarks.json",{"cpu":"AMD EPYC 9V74 80-Core Processor in container; single-thread OpenBLAS",
          "measurement":"Python generation plus 30-cap full-pair MP-G; fresh seeded data/noise per repeat",
          "not_browser_latency":True,"rows":rows,
          "source_dense_storage_upper_bound":{"N":50,"M":64,"D":D,"max_undirected_edges":E,
              "channel_complex128_bytes":D*D*16,"Gram_complex128_bytes":D*D*16,
              "16QAM_pair_potential_float64_bytes":E*16*16*8,"directed_messages_float64_bytes":E*2*16*8,
              "not_measured":"Dense worst-case storage, no source-size detector execution claimed"},
          "browser_gate":"Start port profiling at N=3,M=4 and N=4,M=8 only. Do not approve larger UI domains or claim real time until actual JavaScript Worker/cancellation/control-to-result tests are measured.",
          "core_sha256":hashlib.sha256(Path('otfs_reference.py').read_bytes()).hexdigest()})


if __name__=="__main__": main()
