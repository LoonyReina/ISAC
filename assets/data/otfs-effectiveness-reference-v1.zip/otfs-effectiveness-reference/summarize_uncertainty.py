"""Paired frame bootstrap and non-degenerate zero-error uncertainty."""
from collections import defaultdict
import json
from pathlib import Path
import numpy as np
from scipy.stats import beta
from run_experiments import write


def main():
    data=json.loads(Path('results/communication-sweep.json').read_text());groups=defaultdict(dict)
    for row in data['all_trials']:
        key=tuple(row[k] for k in ['regime','paths','snr_db','method'])
        groups[key][row['trial']]=row
    zeros=[]
    for key,trials in groups.items():
        n=len(trials);errors=sum(r['bit_error_rate']>0 for r in trials.values())
        if errors==0:
            upper=1-.05**(1/n)
            zeros.append({'regime':key[0],'paths':key[1],'snr_db':key[2],'method':key[3],
                'observed_error_frames':0,'frames':n,'bits':n*12*4,
                'one_sided_95_frame_error_probability_upper':upper,
                'conservative_one_sided_95_mean_BER_upper':upper,
                'reason':'BER within a frame is at most the indicator of any error; no bit-independence assumption'})
    rng=np.random.default_rng(107221);paired=[]
    for regime in ['integer','fractional']:
      for P in [1,2]:
       for snr in [0,6,12,18]:
        a=groups[(regime,P,snr,'MP-G')]
        for comparator in ['MP-Psi-full-CSI','block-LMMSE']:
            b=groups[(regime,P,snr,comparator)]
            d=np.array([b[i]['bit_error_rate']-a[i]['bit_error_rate'] for i in sorted(a)])
            boot=d[rng.integers(0,len(d),(5000,len(d)))].mean(axis=1)
            paired.append({'regime':regime,'paths':P,'snr_db':snr,'comparison':comparator+' minus MP-G BER',
                           'mean_paired_difference':float(d.mean()),'bootstrap_percentile_95':np.quantile(boot,[.025,.975]).tolist(),
                           'frames':len(d),'bootstrap_draws':5000})
    write('communication-uncertainty.json',{'zero_error_cases':zeros,'paired_BER_comparisons':paired,
          'limitations':['Original summary normal_95_interval is a plug-in large-sample interval, not an exact coverage guarantee',
                        'Zero observed errors give sample SE=0 and a degenerate plug-in interval; they do not prove population BER=0. Use the explicitly conservative frame-event bound here',
                        'Within-cell inference uses independent frames. Common standardized data/noise across SNR cells makes the sweep correlated, so do not treat points as independent replications',
                        'Bootstrap intervals are finite-Monte-Carlo uncertainty, not source-model, optimization, discretization or uncalibrated-posterior uncertainty']})


if __name__=='__main__': main()
