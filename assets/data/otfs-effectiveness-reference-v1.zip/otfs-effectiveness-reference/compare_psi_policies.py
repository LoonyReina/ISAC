"""Saved-input sensitivity; never silently equate soft retention with Eq41."""
import hashlib
from pathlib import Path
import numpy as np
from otfs_reference import *
from run_experiments import write


def main():
    f=Frame(3,4);c,labels=qam(16);cases=[]
    for seed,snr,nominal in [(410000,0,"full"),(410001,0,"full"),
                             (410000,6,"full"),(410001,12,"full"),
                             (410000,0,"rounded-delay"),(410000,6,"rounded-delay"),
                             (410000,12,"rounded-delay"),(410000,18,"rounded-delay")]:
        rng=np.random.default_rng(seed);frac=rng.uniform(0,1,(2,2))
        paths=[(float([0,2][p]+frac[p,0]),float([-1,1][p]+frac[p,1]-.5),complex([1,.5*np.exp(.7j)][p])) for p in range(2)]
        Htrue=channel_operator(f,paths)
        H=Htrue if nominal=="full" else channel_operator(f,[(float(np.floor(q+.5)),a,g) for q,a,g in paths])
        ids=rng.integers(0,16,f.size);variance=10**(-snr/10)
        y=Htrue@c[ids]+noise(rng,f.size,1)*np.sqrt(variance)
        inputs={"H":H,"y":y,"noise_variance":variance,"constellation":c,"max_iter":30,"damping":.7,"confidence":.99,"drop_threshold":.2}
        outputs={}
        for policy in ["strict-best-confidence","best-confidence-latest-tie","last"]:
            out=mp_psi(H,y,variance,c,soft_output_retention=policy)
            outputs[policy]={**out,"hard_symbol_indices":out["probabilities"].argmax(axis=1),**soft_metrics(out,ids,labels)}
        # Independently exercise every prefix to save actual current-iteration
        # hard decisions; retained-policy outputs are not used as iteration truth.
        previous_eta=0.;source_hard=None;history=[]
        for iteration in range(1,outputs["last"]["iterations"]+1):
            out=mp_psi(H,y,variance,c,max_iter=iteration,soft_output_retention="last")
            eta=out["trace"][-1]["confident_fraction"]
            hard=out["probabilities"].argmax(axis=1)
            update=eta>previous_eta
            if update: source_hard=hard.copy()
            history.append({"iteration":iteration,"eta":eta,"current_hard_symbol_indices":hard,
                            "source_Eq41_update":update,"source_retained_hard_symbol_indices":source_hard})
            previous_eta=eta
        a=outputs["strict-best-confidence"];b=outputs["best-confidence-latest-tie"]
        cases.append({"seed":seed,"snr_db":snr,"nominal_CSI":nominal,
                      "receiver_input":inputs,"evaluation_only":{"true_symbol_indices":ids,"true_channel":Htrue,"paths":paths},
                      "outputs":outputs,"iteration_history":history,
                      "source_Eq41_hard_final":source_hard,
                      "source_Eq41_initial_eta_assumption":0,
                      "source_Eq41_hard_initialization":"not specified in cited algorithm; null means no update occurred",
                      "strict_vs_latest_tie_hard_disagreements":int(np.sum(a["hard_symbol_indices"]!=b["hard_symbol_indices"])),
                      "strict_vs_latest_tie_max_probability_difference":float(np.max(abs(a["probabilities"]-b["probabilities"]))),
                      "retention_does_not_change_message_updates_or_stopping":len({(v["status"],v["iterations"]) for v in outputs.values()})==1})
    write("mp-psi-policy-sensitivity.json",{"source":"https://arxiv.org/pdf/1802.05242v2",
          "locators":"Algorithm1 p16; Eqs35–41 pp17–18; main 1910.01896v1 §V-B omits these details",
          "classification":"Explicit soft-output engineering policies, not uniquely source-specified",
          "cases":cases,"core_sha256":hashlib.sha256(Path('otfs_reference.py').read_bytes()).hexdigest()})


if __name__=="__main__": main()
