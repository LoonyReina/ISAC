#!/usr/bin/env python3
"""Independent arXiv:1910.01896v1 rectangular-pulse convention audit.
Only numpy is required. Run: python probe_conventions.py
All physical operators multiply h'=h exp(2pi i nu tau). T=Delta_f=1.
No import of the production/reference implementation. No source PDF copying.
"""
from pathlib import Path
import json
import numpy as np
PI2 = 2j*np.pi


def grid(N, M):
    return np.unravel_index(np.arange(N*M), (N,M), order='F')


def transform(N, M, tone_sign=1, delay_origin=0, ksign=1, lsign=1):
    """Unitary Eq3; Eq9 is its adjoint. Common normalization cancels."""
    n, m = grid(N,M); k,l = grid(N,M)
    return np.exp(PI2*(ksign*n[:,None]*k/N-lsign*tone_sign*m[:,None]*(l+delay_origin)/M))/np.sqrt(N*M)


def integral(f, a, b):
    w=max(0.,b-a)
    return w*np.sinc(f*w)*np.exp(PI2*f*(a+b)/2)


def physical(N, M, q, alpha, cyclic=False, nodes=None, endpoint='left',
             tone_sign=1, delay_origin=0, eq11_literal=False):
    """Eq8 using exact local pulse overlap or explicitly selected quadrature.
    finite: Eq4 zero outside n'=0..N-1; cyclic: extend X[-1]=X[N-1].
    left rect convention: [0,1); right convention: (0,1].
    """
    tau,nu=q/M,alpha/N
    tones=tone_sign*np.arange(M)
    f=tones[None,:]-tones[:,None]+(-nu if eq11_literal else nu)
    H=np.zeros((N*M,N*M),complex)
    for n in range(N):
        for nt in (n,n-1):
            if not cyclic and nt<0: continue
            lo=max(0.,n-nt-tau); hi=min(1.,n+1-nt-tau)
            if hi<=lo: continue
            if nodes is None:
                I=integral(f,lo,hi)
            else:
                u=(np.arange(nodes)+(1 if endpoint=='right' else 0))/nodes
                # Evaluate pulse membership without floating ambiguity at nodes.
                if endpoint=='right':
                    active=(u>lo+1e-12)&(u<=hi+1e-12)
                else:
                    active=(u>=lo-1e-12)&(u<hi-1e-12)
                I=np.exp(PI2*f[...,None]*u[active]).sum(axis=-1)/nodes
            block=np.exp(PI2*nu*nt)*np.exp(-PI2*tones[:,None]*tau)*I
            rows=n+N*np.arange(M); cols=(nt%N)+N*np.arange(M)
            H[np.ix_(rows,cols)]+=block
    U=transform(N,M,tone_sign,delay_origin)
    return U.conj().T@H@U


def D(L,z):
    return np.exp(PI2*np.asarray(z)[...,None]*np.arange(L)/L).mean(axis=-1)


def literal14(N,M,q,alpha,delay_sign=1,support='ceil',finite=False):
    k,l=grid(N,M)
    b=l>=M-int(np.ceil(q) if support=='ceil' else np.floor(q))
    arg=k[None,:]-k[:,None]+alpha
    delay=D(M,delay_sign*(l[None,:]-l[:,None]+q))
    phase=np.exp(PI2*alpha*l/(N*M))
    if finite:
        # Sum only actual TX indices; n=n'+b must be a receive symbol.
        dop=np.empty((N*M,N*M),complex)
        for j in range(N*M):
            dop[:,j]=np.exp(PI2*arg[:,j,None]*np.arange(N-int(b[j]))/N).sum(axis=-1)/N
        return dop*delay*phase[None,:]*np.exp(-PI2*k[:,None]*b[None,:]/N)
    phase*=np.exp(-PI2*(k+alpha)*b/N)
    return D(N,arg)*delay*phase[None,:]


def waveform(N,M,q,alpha,x,cyclic=False,order=48):
    """Independent direct Eqs3-6 waveform integral by split Gauss quadrature."""
    tau,nu=q/M,alpha/N
    U=transform(N,M)
    X=(U@x).reshape((N,M),order='F')
    Z=np.zeros((N,M),complex)
    z,w=np.polynomial.legendre.leggauss(order)
    tones=np.arange(M)
    for n in range(N):
        for a,b in ((0.,tau),(tau,1.)):
            if b<=a: continue
            v=(a+b)/2+(b-a)/2*z
            t=n+v
            nt=n-1 if b<=tau else n
            if nt<0 and not cyclic: continue
            u=t-tau-nt
            s=np.exp(PI2*u[:,None]*tones)@X[nt%N]
            r=s*np.exp(PI2*nu*t)*np.exp(-PI2*nu*tau)
            Z[n]+=((b-a)/2*w*r)@np.exp(-PI2*t[:,None]*tones)
    return U.conj().T@Z.reshape(-1,order='F')


def rel(A,B): return float(np.linalg.norm(A-B)/np.linalg.norm(B))

def fit(A,B):
    """Best complex gain multiplying A to fit B, relative to norm(B)."""
    c=np.vdot(A,B)/np.vdot(A,A)
    return float(np.linalg.norm(c*A-B)/np.linalg.norm(B)), [float(c.real),float(c.imag)]


def main():
    N,M=4,8
    cases=[(0.,0.),(0.,1.),(0.,.37),(2.,0.),(2.,1.),(2.,.37),(1.3,0.),(1.3,.37),(1e-8,0.)]
    out={'parameters':{'N':N,'M':M,'T':1,'column_index':'k+N*l'},'cases':[]}
    rng=np.random.default_rng(641926)
    x=rng.normal(size=N*M)+1j*rng.normal(size=N*M)
    for q,a in cases:
        E=physical(N,M,q,a)
        C=physical(N,M,q,a,cyclic=True)
        Q=physical(N,M,q,a,cyclic=True,nodes=M)
        F=physical(N,M,q,a,nodes=M)
        L=literal14(N,M,q,a)
        K=literal14(N,M,q,a,delay_sign=-1,support='floor')
        KF=literal14(N,M,q,a,delay_sign=-1,support='floor',finite=True)
        right_negative=physical(N,M,q,a,cyclic=True,nodes=M,endpoint='right',tone_sign=-1,delay_origin=1)
        gauge=np.exp(-PI2*grid(N,M)[1]/M)
        c=np.exp(-PI2*q*(M-1)/M)
        signonly=literal14(N,M,q,a,delay_sign=-1)
        G=c*gauge[:,None]*L*gauge.conj()[None,:]
        row={'delay_bin':q,'doppler_bin':a,
             'exact_vs_direct_waveform':rel(E@x,waveform(N,M,q,a,x)),
             'exact_cyclic_vs_direct_waveform':rel(C@x,waveform(N,M,q,a,x,True)),
             'literal_vs_exact_finite':rel(L,E),'literal_vs_exact_finite_gain_fitted':fit(L,E)[0],
             'exact_cyclic_vs_exact_finite':rel(C,E),
             'tx_left_cyclic_vs_exact_cyclic':rel(Q,C),
             'floor_minus_closed_vs_tx_left_cyclic':rel(K,Q),
             'floor_minus_finite_closed_vs_tx_left_finite':rel(KF,F),
             'literal_vs_right_negative_shifted_gain_corrected':rel(np.exp(-PI2*a/(N*M))*right_negative,L),
             'sign_only_gauge_identity':rel(G,signonly),
             'ceil_minus_vs_floor_minus':rel(signonly,K),
             'literal_unitarity_error':rel(L.conj().T@L,np.eye(N*M)),
             'exact_singular_value_min':float(np.linalg.svd(E,compute_uv=False)[-1]),
             'exact_singular_value_max':float(np.linalg.svd(E,compute_uv=False)[0])}
        out['cases'].append(row)
    # Uniform quadrature convergence with physical waveform and both endpoints.
    q,a=1.3,.37
    E=physical(N,M,q,a)
    out['quadrature_convergence']=[{'nodes_per_symbol':Q,
      'left_error':rel(physical(N,M,q,a,nodes=Q),E),
      'right_error':rel(physical(N,M,q,a,nodes=Q,endpoint='right'),E)} for Q in (M,2*M,8*M,32*M,128*M,512*M)]
    out['eq11_vs_eq8']=[{'delay_bin':q,'doppler_bin':a,'relative_error':rel(physical(N,M,q,a,eq11_literal=True),physical(N,M,q,a))} for q,a in ((0.,0.),(0.,.37),(1.3,.37))]
    # Carrier offset alone is a path gain phase; FFT sign/stack order are basis changes.
    # Show that no scalar can repair general fractional-delay same-coordinate sign.
    out['gain_only_sign_repair']=fit(literal14(N,M,1.3,.37),literal14(N,M,1.3,.37,delay_sign=-1))[0]
    # Grid delay demonstrates finite/cyclic mismatch analytically sqrt(q/(NM-q)).
    out['grid_finite_cyclic']={'measured':rel(physical(N,M,2,0,True,nodes=M),physical(N,M,2,0,nodes=M)),
      'predicted':float(np.sqrt(2/(N*M-2)))}
    # Equation 14 jumps at zero, while exact integral is continuous.
    out['zero_delay_right_limit']={'literal_jump':rel(literal14(N,M,1e-10,0),literal14(N,M,0,0)),
      'predicted_jump':float(np.sqrt(2/M)),
      'exact_change':rel(physical(N,M,1e-10,0),physical(N,M,0,0)),
      'literal_trace_magnitude_over_dimension':float(abs(np.trace(literal14(N,M,1e-10,0)))/(N*M))}
    # Raw norms at larger M distinguish fixed-M quadrature from exact integral.
    out['M_scaling']=[{'M':m,'delay_bin':1.3,
      'cyclic_tx_left_vs_exact':rel(physical(N,m,1.3,.37,True,nodes=m),physical(N,m,1.3,.37,True))} for m in (8,16,32,64)]
    out['additional_grid_checks']=[]
    for nn,mm,qq,aa in ((5,7,1.3,-1.23),(3,5,4.2,.31),(5,7,2.,1.),(1,7,1.3,.37)):
        xx=rng.normal(size=nn*mm)+1j*rng.normal(size=nn*mm)
        ee=physical(nn,mm,qq,aa)
        ll=literal14(nn,mm,qq,aa)
        rr=physical(nn,mm,qq,aa,cyclic=True,nodes=mm,endpoint='right',tone_sign=-1,delay_origin=1)
        out['additional_grid_checks'].append({'N':nn,'M':mm,'delay_bin':qq,'doppler_bin':aa,
            'exact_vs_waveform':rel(ee@xx,waveform(nn,mm,qq,aa,xx)),
            'literal_vs_consistent_surrogate':rel(np.exp(-PI2*aa/(nn*mm))*rr,ll)})
    ee=physical(N,M,1.3,.37); ll=literal14(N,M,1.3,.37); uu=transform(N,M)
    out['fourier_and_stacking_invariance']=[]
    for ks in (-1,1):
        for ls in (-1,1):
            v=uu.conj().T@transform(N,M,ksign=ks,lsign=ls)
            out['fourier_and_stacking_invariance'].append({'doppler_fft_sign':ks,'delay_fft_sign':ls,
                'both_models_in_same_new_basis_error':rel(v.conj().T@ll@v,v.conj().T@ee@v)})
    perm=np.array([k+N*l for k in range(N) for l in range(M)])
    out['row_stacking_both_models_error']=rel(ll[np.ix_(perm,perm)],ee[np.ix_(perm,perm)])
    out['unitary_vs_source_transform_error']=rel(uu.conj().T@(uu@ee@uu.conj().T)@uu,
        (uu.conj().T/np.sqrt(N*M))@(uu@ee@uu.conj().T)@(np.sqrt(N*M)*uu))
    for row in out['additional_grid_checks']:
        assert row['exact_vs_waveform']<1e-11, row
        assert row['literal_vs_consistent_surrogate']<1e-11, row
    for row in out['cases']:
        assert row['exact_vs_direct_waveform']<1e-11, row
        assert row['exact_cyclic_vs_direct_waveform']<1e-11, row
        assert row['floor_minus_closed_vs_tx_left_cyclic']<1e-11, row
        assert row['floor_minus_finite_closed_vs_tx_left_finite']<1e-11, row
        assert row['literal_vs_right_negative_shifted_gain_corrected']<1e-11, row
        assert row['sign_only_gauge_identity']<1e-11, row
    Path(__file__).with_name('results.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))

if __name__=='__main__': main()
