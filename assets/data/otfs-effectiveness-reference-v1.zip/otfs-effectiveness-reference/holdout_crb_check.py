"""Predeclared holdout after anomalously favorable original 48-noise sample.

Purpose: evaluate high-SNR CRB scaling with a disjoint larger simulation.
Fixed before execution: 256 trials, SNR=30dB, SeedSequence entropy=906221,
same frame/true target/search bounds, no early stopping or seed replacement.
Original 48-trial sweep remains untouched. This is confirmatory diagnostic,
not an excuse to claim every Monte Carlo curve equals a local lower bound.
"""
import hashlib
from pathlib import Path
from collections import Counter
import numpy as np
from scipy.stats import chi2
from otfs_reference import *
from run_experiments import write


def main():
    f=Frame(4,8);c,_=qam(4);q,a,h=1.37,.43,np.exp(.31j);variance=.001
    bounds=((.05,3.8),(-1.4,1.4));records=[]
    for trial,seed in enumerate(np.random.SeedSequence(906221).spawn(256)):
        rng=np.random.default_rng(seed);x=c[rng.integers(0,4,f.size)]
        y=h*eq14_operator(f,q,a)@x+noise(rng,f.size,variance)
        fit=radar_ml(f,x,y,bounds=bounds,grid_shape=(13,17))
        crb=fisher_single(f,x,q,a,h,variance);C=crb["covariance"][2:,2:]
        err=np.array([fit["delay_bin"]-q,fit["doppler_bin"]-a])
        records.append({"trial":trial,"spawn_key":seed.spawn_key,"estimate":[fit["delay_bin"],fit["doppler_bin"]],
                        "errors_bin":err,"crb_covariance_bins":C,"normalized_quadratic_error":float(err@np.linalg.solve(C,err)),
                        "status":fit["status"],"residual":fit["residual"],"elapsed_ms":fit["elapsed_ms"]})
        if (trial+1)%32==0:print(trial+1,flush=True)
    e=np.array([r["errors_bin"] for r in records]);C=np.array([r["crb_covariance_bins"] for r in records]);s=sum(r["normalized_quadratic_error"] for r in records)
    write("holdout-crb-check.json",{"purpose":"Disjoint larger high-SNR diagnostic after unusually favorable primary 48-noise realization",
          "fixed_plan":{"trials":256,"SNR_dB":30,"seed_sequence_entropy":906221,"early_stopping":False,"seed_replacement":False,
                        "N":4,"M":8,"truth_evaluation_only":[q,a],"bounds":bounds},
          "summary":{"status_counts":dict(Counter(r["status"] for r in records)),"rmse_bins":np.sqrt(np.mean(e*e,axis=0)),
                      "sqrt_mean_crb_variances_bins":np.sqrt(np.diagonal(C.mean(axis=0))),
                      "mean_errors_bins":e.mean(axis=0),"normalized_quadratic_error_sum":s,"asymptotic_chi_square_df":512,
                      "asymptotic_lower_tail_probability":float(chi2.cdf(s,512))},
          "interpretation":"Chi-square comparison is a local high-SNR asymptotic diagnostic, not exact finite-SNR distribution or a proof of unbiasedness/global ML.",
          "all_trials":records,"core_sha256":hashlib.sha256(Path('otfs_reference.py').read_bytes()).hexdigest(),
          "plan_script_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest()})


if __name__=="__main__":main()
