"""Reproducible selected experiments; all outcomes retained, no figure fitting.

Run with single-thread BLAS to avoid small-matrix oversubscription:
OPENBLAS_NUM_THREADS=1 python run_experiments.py --trials 48
"""
import argparse
from collections import Counter
from dataclasses import asdict
from pathlib import Path
import json
import hashlib
import platform
import time
import numpy as np
import scipy
from otfs_reference import *


def jsonable(value):
    if isinstance(value,np.ndarray): return jsonable(value.tolist())
    if isinstance(value,(complex,np.complexfloating)): return {"re":float(value.real),"im":float(value.imag)}
    if isinstance(value,dict): return {str(k):jsonable(v) for k,v in value.items()}
    if isinstance(value,(list,tuple)): return [jsonable(v) for v in value]
    if isinstance(value,(np.integer,)): return int(value)
    if isinstance(value,(np.floating,float)):
        return float(value) if np.isfinite(value) else None
    return value


def write(name,data):
    Path("results").mkdir(exist_ok=True)
    Path("results",name).write_text(json.dumps(jsonable(data),indent=2,allow_nan=False)+"\n")


def ci_mean(values):
    a=np.asarray(values,float);mean=float(a.mean())
    se=float(a.std(ddof=1)/np.sqrt(len(a))) if len(a)>1 else None
    return {"mean":mean,"standard_error_across_frames":se,
            "normal_95_interval":None if se is None else [mean-1.96*se,mean+1.96*se]}


def communications(trials):
    f=Frame(3,4);c,labels=qam(16);rows=[]
    snrs=[0,6,12,18]
    for regime in ["integer","fractional"]:
      for P in [1,2]:
        for snr_db in snrs:
          for trial in range(trials):
            # Channel/data/noise coupling across SNR and regimes is recorded.
            seed=410000+trial
            rng=np.random.default_rng(seed)
            frac=rng.uniform(0,1,(2,2))
            paths=[(float([0,2][p]+(frac[p,0] if regime=="fractional" else 0)),
                    float([-1,1][p]+(frac[p,1]-.5 if regime=="fractional" else 0)),
                    complex([1.,.5*np.exp(.7j)][p])) for p in range(P)]
            H=channel_operator(f,paths)
            # Source MP-Psi nominal model rounds delays, retaining Doppler.
            rounded=[(float(np.floor(q+.5)),a,g) for q,a,g in paths]
            Hround=channel_operator(f,rounded)
            ids=rng.integers(0,len(c),f.size);x=c[ids]
            variance=10**(-snr_db/10)
            w=noise(rng,f.size,1)*np.sqrt(variance)
            y=H@x+w
            methods={"MP-G":mp_g(H,y,variance,c,max_iter=30),
                     "MP-Psi-full-CSI":mp_psi(H,y,variance,c,max_iter=30),
                     "MP-Psi-rounded-delay":mp_psi(Hround,y,variance,c,max_iter=30),
                     "block-LMMSE":lmmse(H,y,variance,c)}
            for method,out in methods.items():
                rows.append({"regime":regime,"paths":P,"snr_db":snr_db,"trial":trial,"seed":seed,
                             "channel":paths,"nominal_delay_rounded":method=="MP-Psi-rounded-delay",
                             "method":method,**soft_metrics(out,ids,labels),
                             "status":out["status"],"iterations":out["iterations"],"elapsed_ms":out["elapsed_ms"],
                             "edge_count":out.get("edge_count"),
                             "soft_output_retention":out.get("soft_output_retention"),
                             "trace":out.get("trace",[])})
          print("communication",regime,P,snr_db,flush=True)
    summary=[]
    for regime,P,snr_db,method in product(["integer","fractional"],[1,2],snrs,
                                         ["MP-G","MP-Psi-full-CSI","MP-Psi-rounded-delay","block-LMMSE"]):
        group=[r for r in rows if (r["regime"],r["paths"],r["snr_db"],r["method"])==(regime,P,snr_db,method)]
        summary.append({"regime":regime,"paths":P,"snr_db":snr_db,"method":method,
                        "frames":len(group),"symbols":len(group)*f.size,"status_counts":dict(Counter(r["status"] for r in group)),
                        **{key:ci_mean([r[key] for r in group]) for key in ["bit_error_rate","symbol_error_rate","entropy_proxy_bits","truth_log_score_bits","iterations","elapsed_ms"]}})
    out={"experiment":"Reduced-dimension selected slice of Fig6/7 detector comparison",
         "source_model":"literal Eq14, including ceil and both ICI/ISI branches",
         "frame":asdict(f),"constellation":"unit-average-energy Gray-labelled 16-QAM",
         "noise":"circular complex AWGN; variance E|w|^2=10^(-LoS_SNR_dB/10)",
         "CSI":"perfect full channel for MP-G/LMMSE/MP-Psi-full; rounded-delay nominal channel for MP-Psi-rounded",
         "resources":"All detectors receive the same y, noise variance, dimension, constellation and underlying channel per row; LoS gain=1 and path2 amplitude=.5 increase total channel power as in source. No equal-total-power claim across P.",
         "deviations":["N=3,M=4 instead of 50,64; paths 1/2 only; explicitly chosen path powers/positions because source does not disclose complete multipath realization",
                       "30-iteration cap; MP-G undamped flooding; MP-Psi damping=.7 and best-confidence/latest-tie soft-output retention are explicitly recorded; strict-best sensitivity is separately preserved",
                       "No low-complexity LMMSE26 curve, original fullsize Monte Carlo or finite channel-code decoding",
                       "Eq54 entropy quantity is an entropy proxy for approximate/mismatched marginals; truth log-score is separate, negative values retained"],
         "summary":summary,"all_trials":rows}
    write("communication-sweep.json",out)
    return summary


def radar(trials):
    f=Frame(4,8);c,labels=qam(4);q,a,h=1.37,.43,np.exp(.31j)
    bounds=((.05,3.8),(-1.4,1.4));snrs=[-20,-10,0,10,20,30]
    rows=[]
    for snr in snrs:
      for trial in range(trials):
        seed=720000+trial;rng=np.random.default_rng(seed)
        x=c[rng.integers(0,4,f.size)]
        variance=10**(-snr/10);w=noise(rng,f.size,1)*np.sqrt(variance)
        y=h*path_operator(f,q,a)@x+w
        fit=radar_ml(f,x,y,bounds=bounds,grid_shape=(13,17),starts_per_delay_cell=2)
        crb=fisher_single(f,x,q,a,h,variance)
        grid=fit["grid_initialization"]
        rows.append({"trial":trial,"seed":seed,"snr_db":snr,"truth_for_evaluation_only":[q,a],
                     "estimate":[fit["delay_bin"],fit["doppler_bin"]],"grid_estimate":[grid["delay_bin"],grid["doppler_bin"]],
                     "delay_error_bin":fit["delay_bin"]-q,"doppler_error_bin":fit["doppler_bin"]-a,
                     "grid_delay_error_bin":grid["delay_bin"]-q,"grid_doppler_error_bin":grid["doppler_bin"]-a,
                     "threshold_failure":abs(fit["delay_bin"]-q)>.5 or abs(fit["doppler_bin"]-a)>.5,
                     "status":fit["status"],"residual":fit["residual"],"evaluations":fit["evaluations"],"elapsed_ms":fit["elapsed_ms"],
                     "local_optimizer_failed_candidates":sum(v["status"]=="optimizer-failed" for v in fit["candidates"]),
                     "crb_delay_variance_bin":crb.get("variance_delay_bin"),"crb_doppler_variance_bin":crb.get("variance_doppler_bin")})
      print("radar",snr,flush=True)
    summary=[]
    bootstrap=np.random.default_rng(88431)
    for snr in snrs:
        group=[r for r in rows if r["snr_db"]==snr]
        item={"snr_db":snr,"trials":len(group),"threshold_failures":sum(r["threshold_failure"] for r in group),
              "status_counts":dict(Counter(r["status"] for r in group)),
              "mean_crb_delay_variance_bin":float(np.mean([r["crb_delay_variance_bin"] for r in group])),
              "mean_crb_doppler_variance_bin":float(np.mean([r["crb_doppler_variance_bin"] for r in group]))}
        for key in ["delay_error_bin","doppler_error_bin","grid_delay_error_bin","grid_doppler_error_bin"]:
            e=np.array([r[key] for r in group]);boot=e[bootstrap.integers(0,len(e),(2000,len(e)))]
            item[key.replace("error","rmse")]={"value":float(np.sqrt(np.mean(e*e))),
                "bootstrap_percentile_95":np.quantile(np.sqrt(np.mean(boot*boot,axis=1)),[.025,.975]).tolist()}
        item["range_rmse_m"]=item["delay_rmse_bin"]["value"]*299792458/(2*f.bandwidth)
        item["velocity_rmse_mps"]=item["doppler_rmse_bin"]["value"]*299792458/(2*f.fc*f.N*f.T)
        summary.append(item)
    write("radar-sweep.json",{"experiment":"Reduced single-path Fig4-style RMSE/CRB and grid-only ablation",
          "frame":asdict(f),"truth_for_evaluation_only":{"delay_bin":q,"doppler_bin":a,**f.physical(q,a)},
          "bounds":bounds,"model":"eq14_literal","summary":summary,"all_trials":rows,
          "limits":["N=4,M=8 and dimensionless off-grid target differ from original table; no original Fig4 top/middle reproduction claim",
                    "Source p11 uses a fine discrete grid; our continuous per-cell optimization is an extension of the same ML objective; no certified global continuum optimum",
                    "Known symbols and known P=1; unknown complex gain profiled analytically",
                    "Same observations compare grid and continuous estimate; CRB evaluation alone sees true parameters",
                    "No OFDM/FMCW comparative radar claim; their CP/chirp/window models and source inconsistencies remain separate work",
                    "All max-iteration/optimizer failures and threshold errors remain in RMSE; bootstrap measures Monte Carlo uncertainty only"]})
    return summary


def model_diagnostics():
    f=Frame(4,8);rng=np.random.default_rng(99319);c,_=qam(4);x=c[rng.integers(0,4,f.size)]
    q,a=1.37,.43;bounds=((.05,3.8),(-1.4,1.4));records=[]
    for generated in ["eq14_literal","exact_rect_finite"]:
        y=path_operator(f,q,a,generated)@x
        for fitted in ["eq14_literal","eq14_negative_delay_cyclic","exact_rect_finite"]:
            fit=radar_ml(f,x,y,bounds=bounds,model=fitted,grid_shape=(13,17))
            records.append({"generated_model":generated,"fitted_model":fitted,"held_observation":True,
                            "fit":fit,"truth_for_evaluation_only":[q,a],
                            "relative_residual_norm":np.sqrt(fit["residual"])/np.linalg.norm(y)})
    two=channel_operator(f,[(.37,-.7,1),(2.37,.8,.6j)])@x
    multi=[multipath_eq21(f,x,two,path_count=2,bounds=bounds,initialization=init,grid_shape=(25,25))
           for init in ["source-zero","distinct-peaks"]]
    write("model-diagnostics.json",{"noiseless_cross_model_fits":records,"multipath_initialization":multi})


def source_rates():
    N,M,T=50,64,6.4e-6
    # Eq14 = product of two unitary Dirichlet matrices and unitary diagonal.
    # This analytic simplification is independently checked at small frames.
    rows=[{"snr_db":s,"otfs_bits_s_hz":N/(N+.25)*np.log2(1+10**(s/10)),
           "ofdm_bits_s_hz":1/1.25*np.log2(1+10**(s/10))} for s in range(0,51,5)]
    write("figure4-rate-checkpoints.json",{"experiment":"Original TableI and Fig4 bottom Eq52/53 deterministic checkpoints",
         "frame":{"N":N,"M":M,"T_s":T,"B_hz":10e6,"fc_hz":5.89e9},"P":1,
         "guard_s":T/4,"otfs_total_duration_s":(N+.25)*T,"ofdm_total_duration_s":N*1.25*T,
         "interpretation":"Same number of useful symbols, energy per useful symbol and bandwidth; unequal total duration from source guard accounting. This is Gaussian-input ideal-joint-decoding rate, not finite-code throughput.",
         "method":"Unitary Eq14 determinant identity, not a large dense 3200x3200 numerical determinant",
         "rows":rows})


if __name__=="__main__":
    p=argparse.ArgumentParser();p.add_argument("--trials",type=int,default=48);p.add_argument("--only",choices=["all","communication","radar","diagnostics"],default="all")
    args=p.parse_args();start=time.perf_counter()
    if args.trials<2: raise ValueError("At least 2 trials for uncertainty estimates")
    source_rates()
    if args.only in ["all","communication"]: communications(args.trials)
    if args.only in ["all","radar"]: radar(args.trials)
    if args.only in ["all","diagnostics"]: model_diagnostics()
    write("run-environment.json",{"python":platform.python_version(),"numpy":np.__version__,"scipy":scipy.__version__,
         "platform":platform.platform(),"command":f"OPENBLAS_NUM_THREADS=1 python run_experiments.py --trials {args.trials} --only {args.only}",
         "core_sha256":hashlib.sha256(Path('otfs_reference.py').read_bytes()).hexdigest(),
         "script_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
         "elapsed_s":time.perf_counter()-start})
    print("complete",time.perf_counter()-start,flush=True)
