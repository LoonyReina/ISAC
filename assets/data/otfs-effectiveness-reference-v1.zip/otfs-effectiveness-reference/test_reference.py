"""Deterministic owner checks, independent reviewers supply separate oracles."""
import inspect
import json
import unittest
import numpy as np
from numpy.testing import assert_allclose
from otfs_reference import *


class ReferenceTests(unittest.TestCase):
    def setUp(self):
        self.f=Frame(3,4);self.rng=np.random.default_rng(270612)
        self.c,self.labels=qam(4)
        self.x=self.c[self.rng.integers(0,4,self.f.size)]

    def test_isfft_inverse(self):
        assert_allclose(sfft(isfft(self.x,self.f),self.f),self.x,atol=3e-15)

    def test_zero_channel_identity(self):
        for model in MODEL_NAMES:
            assert_allclose(path_operator(self.f,0,0,model),np.eye(self.f.size),atol=4e-15)

    def test_eq14_unitary_fractional(self):
        for q,a in [(0,0),(1,.43),(1.37,-.91),(3.7,2.99)]:
            H=eq14_operator(self.f,q,a)
            assert_allclose(H.conj().T@H,np.eye(self.f.size),atol=4e-15)

    def test_eq14_integer_shift(self):
        H=eq14_operator(self.f,1,1)
        for l in range(self.f.M):
            for k in range(self.f.N):
                column=H[:,k+self.f.N*l]
                self.assertEqual(np.argmax(abs(column)),(k+1)%self.f.N+self.f.N*((l+1)%self.f.M))

    def test_frame_edge_energy(self):
        H=exact_rect_operator(self.f,1.37,.43)
        self.assertLessEqual(np.linalg.svd(H,compute_uv=False)[0],1+1e-14)
        self.assertGreater(np.linalg.norm(H.conj().T@H-np.eye(self.f.size)),.1)

    def test_integer_boundary_discontinuous_only_approximation(self):
        f=Frame(4,8);eps=1e-8
        Hp=eq14_operator(f,1+eps,.4);Hm=eq14_operator(f,1-eps,.4)
        self.assertAlmostEqual(np.linalg.norm(Hp-Hm)/np.sqrt(f.size),np.sqrt(2/f.M),places=6)
        self.assertLess(np.linalg.norm(exact_rect_operator(f,1+eps,.4)-exact_rect_operator(f,1-eps,.4)),1e-6)

    def test_mp_g_single_path_matches_exhaustive(self):
        f=Frame(2,2);H=eq14_operator(f,.37,.23)
        y=H@self.x[:4]+noise(self.rng,4,.4)
        a=mp_g(H,y,.4,self.c);b=exact_marginals(H,y,.4,self.c)
        assert_allclose(a["probabilities"],b["probabilities"],atol=3e-15)
        self.assertEqual(a["edge_count"],0)
        self.assertEqual(a["status"],"converged")

    def test_mp_g_tree_matches_exhaustive(self):
        G=np.array([[1,.2+.1j,0],[.2-.1j,1,-.15j],[0,.15j,1]],complex)
        H=np.linalg.cholesky(G).conj().T
        y=H@self.x[:3]+noise(self.rng,3,.7)
        a=mp_g(H,y,.7,self.c);b=exact_marginals(H,y,.7,self.c)
        assert_allclose(a["probabilities"],b["probabilities"],atol=3e-15)

    def test_mp_psi_and_lmmse_identity(self):
        H=np.eye(self.f.size);y=self.x+noise(self.rng,self.f.size,.4)
        exact=np.exp(_norm(-abs(y[:,None]-self.c)**2/.4))
        for fn in [mp_psi,lmmse]: assert_allclose(fn(H,y,.4,self.c)["probabilities"],exact,atol=4e-15)

    def test_iteration_cap_not_success(self):
        H=self.rng.normal(size=(4,4))+1j*self.rng.normal(size=(4,4))
        out=mp_g(H,self.x[:4],.5,self.c,max_iter=1)
        self.assertEqual(out["status"],"max-iterations")

    def test_higher_noise_softens_identity_posterior(self):
        p=mp_g(np.eye(2),self.x[:2],.1,self.c)["probabilities"]
        q=mp_g(np.eye(2),self.x[:2],3.,self.c)["probabilities"]
        self.assertGreater(p.max(),q.max())

    def test_literal_and_sign_variant_differ_offgrid(self):
        self.assertGreater(np.linalg.norm(path_operator(self.f,1.37,.43)-path_operator(self.f,1.37,.43,"eq14_negative_delay_cyclic")),1.)
        assert_allclose(path_operator(self.f,1,.43),path_operator(self.f,1,.43,"eq14_negative_delay_cyclic"),atol=4e-15)

    def test_noiseless_offgrid_search(self):
        q,a,g=1.37,.43,.8+.3j
        y=g*eq14_operator(self.f,q,a)@self.x
        out=radar_ml(self.f,self.x,y,bounds=((.1,2.8),(-1.1,1.1)),grid_shape=(9,11))
        self.assertLess(abs(out["delay_bin"]-q),1e-5)
        self.assertLess(abs(out["doppler_bin"]-a),1e-5)
        self.assertLess(out["residual"],1e-10)
        self.assertGreater(abs(out["grid_initialization"]["delay_bin"]-q),1e-3)

    def test_fisher_boundaries(self):
        self.assertEqual(fisher_single(self.f,self.x,1,.4,1,.1)["status"],"undefined-at-delay-branch")
        f=fisher_single(self.f,self.x,1.37,.43,1,.1)
        self.assertEqual(f["status"],"computed")
        self.assertGreater(f["variance_delay_bin"],0)

    def test_truth_blind_signatures(self):
        for fn in [radar_ml,mp_g,mp_psi,lmmse,multipath_eq21]:
            for word in ["truth","seed","rng","simulation"]:
                self.assertNotIn(word,inspect.signature(fn).parameters)

    def test_source_zero_init_retains_failure(self):
        H=channel_operator(self.f,[(.37,.43,1),(2.3,-.9,.5j)])
        out=multipath_eq21(self.f,self.x,H@self.x,path_count=2,bounds=((.1,2.8),(-1.1,1.1)),grid_shape=(9,11))
        self.assertEqual(out["status"],"singular-gain-system")
        assert_allclose(out["parameters"][0],out["parameters"][1])

    def test_invalid_inputs(self):
        for q,a in [(-.1,0),(4,0),(1,3),(np.nan,0)]:
            with self.assertRaises(ValueError): eq14_operator(self.f,q,a)
        with self.assertRaises(ValueError): mp_g(np.eye(2),np.ones(2),0,self.c)
        with self.assertRaises(ValueError): exact_marginals(np.eye(20),np.ones(20),1,self.c)

    def test_rate_matches_unitary_closed_form(self):
        H=eq14_operator(self.f,1.37,.43)
        out=gaussian_rates(self.f,H,10)
        self.assertAlmostEqual(out["otfs_bits_s_hz"],self.f.N/(self.f.N+.25)*np.log2(11),places=13)

    def test_noise_complex_variance(self):
        w=noise(self.rng,400000,.7)
        self.assertLess(abs(np.mean(abs(w)**2)-.7),.005)
        self.assertLess(abs(np.mean(w**2)),.005)


def _norm(z): return z-logsumexp(z,axis=-1,keepdims=True)


if __name__=="__main__": unittest.main(verbosity=2)
