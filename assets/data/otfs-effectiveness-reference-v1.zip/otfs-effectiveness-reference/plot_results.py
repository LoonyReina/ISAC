"""Plots only computed numeric results; no digitized or copied source artwork."""
import json
import os
from pathlib import Path
os.environ.setdefault("MPLCONFIGDIR",str(Path(".mpl-cache").resolve()))
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


def main():
    target=Path("figures");target.mkdir(exist_ok=True)
    plt.rcParams.update({"font.size":10,"axes.grid":True,"grid.alpha":.2})
    c=json.loads(Path("results/communication-sweep.json").read_text())
    methods=["MP-G","MP-Psi-full-CSI","MP-Psi-rounded-delay","block-LMMSE"]
    colors=["#117a65","#2e86c1","#b03a2e","#7d3c98"]
    fig,axes=plt.subplots(1,3,figsize=(15,4.8))
    for method,color in zip(methods,colors):
        group=[r for r in c["summary"] if r["regime"]=="fractional" and r["paths"]==2 and r["method"]==method]
        x=[r["snr_db"] for r in group]
        for ax,key in zip(axes,["bit_error_rate","entropy_proxy_bits","truth_log_score_bits"]):
            ax.errorbar(x,[r[key]["mean"] for r in group],yerr=[1.96*r[key]["standard_error_across_frames"] for r in group],
                        label=method,color=color,marker="o",capsize=3)
            ax.set_xlabel("LoS communication SNR (dB)")
    axes[0].set_ylabel("Uncoded bit error fraction")
    axes[1].set_ylabel("Eq54 entropy proxy (bits/symbol)")
    axes[2].set_ylabel("Truth log score (bits/symbol; may be negative)")
    axes[0].legend(fontsize=8)
    fig.suptitle("Reduced literal-Eq14 experiment: fractional P=2, N=3, M=4, 16-QAM\n48 paired frames/cell; bars = frame-level mean ±1.96 SE; capped/failed iterations remain included")
    fig.tight_layout(rect=[0,0,1,.88]);fig.savefig(target/"reduced-detectors.svg");fig.savefig(target/"reduced-detectors.png",dpi=150);plt.close(fig)
    r=json.loads(Path("results/radar-sweep.json").read_text());rows=r["summary"];x=[a["snr_db"] for a in rows]
    fig,axes=plt.subplots(1,3,figsize=(15,4.8))
    for ax,dim in zip(axes[:2],["delay","doppler"]):
        for prefix,label,color in [("","Continuous extension","#117a65"),("grid_","Coarse grid-only ablation","#b03a2e")]:
            keys=[a[prefix+dim+"_rmse_bin"] for a in rows];y=np.array([v["value"] for v in keys]);intervals=np.array([v["bootstrap_percentile_95"] for v in keys])
            ax.errorbar(x,y,yerr=[y-intervals[:,0],intervals[:,1]-y],label=label,color=color,marker="o",capsize=3)
        ax.plot(x,np.sqrt([a["mean_crb_"+dim+"_variance_bin"] for a in rows]),"k--",label="sqrt(mean local CRB)")
        ax.set_yscale("log");ax.set_ylabel(f"{dim.capitalize()} RMSE (normalized bins)");ax.set_xlabel("Radar SNR (dB)")
    axes[0].legend(fontsize=8)
    axes[2].plot(x,[a["threshold_failures"] for a in rows],"o-",label="Error > 0.5 bin in either parameter")
    axes[2].plot(x,[a["status_counts"].get("optimizer-failed",0) for a in rows],"s--",label="Selected optimizer-failed result")
    axes[2].set_ylabel("Outcomes per 48 trials");axes[2].set_xlabel("Radar SNR (dB)");axes[2].legend(fontsize=8)
    fig.suptitle("Reduced literal-Eq14 sensing experiment: N=4, M=8, q=1.37, a=0.43\nSame y for grid/continuous estimates; 95% bootstrap RMSE intervals; all outcomes retained")
    fig.tight_layout(rect=[0,0,1,.88]);fig.savefig(target/"reduced-sensing.svg");fig.savefig(target/"reduced-sensing.png",dpi=150);plt.close(fig)
    data=json.loads(Path("results/figure4-rate-checkpoints.json").read_text());rows=data["rows"]
    fig,ax=plt.subplots(figsize=(7,4.5))
    for key,label in [("otfs_bits_s_hz","OTFS: one guard per frame"),("ofdm_bits_s_hz","OFDM: CP per symbol")]:
        ax.plot([r["snr_db"] for r in rows],[r[key] for r in rows],"o-",label=label)
    ax.set_xlabel("Communication SNR (dB)");ax.set_ylabel("Gaussian-input rate (bits/s/Hz)");ax.legend()
    ax.set_title("Original Eq52/53 checkpoints, N=50, M=64, guard=T/4\nDifferent total durations; ideal joint decoding, not coded throughput")
    fig.tight_layout();fig.savefig(target/"source-rate-checkpoints.svg");fig.savefig(target/"source-rate-checkpoints.png",dpi=150);plt.close(fig)


if __name__=="__main__": main()
