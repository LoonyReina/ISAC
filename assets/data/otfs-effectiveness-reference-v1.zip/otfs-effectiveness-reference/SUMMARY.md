# Numerical result and acceptance summary

2026-10-12. Core SHA-256: `92b997201493a3187b5ddb37026672ef44e163131e422bdf8618f11b17aa235f`.

## What is established

- Literal Eq14 and the finite physical rectangular-pulse operator are independently checked against separate derivations. Direct waveform integration agrees with the finite operator within 9.04e-15
- A complete cyclic/right-endpoint/negative-carrier/one-sample-origin convention reproduces literal Eq14 within 2.72e-15. This is an explicit alternate convention, not proof that the original positive-carrier finite equations are all identical
- MP-G is the actual Gram-matrix pair-factor sum-product algorithm. Its tree posteriors agree with independent exact enumeration within 2.23e-16; a converged loopy case still has a 0.01175 posterior discrepancy, correctly demonstrating approximate inference
- Four noiseless continuous single-path searches recover bins/gain within 1.1e-8. Source fine-grid search is separately implemented; continuous refinement is explicitly an extension of its objective
- The MP-Psi Gaussian-message implementation agrees with a separate scalar-loop implementation, including the declared retention policy. Independent saved-input replay is within 5.2e-15
- 19 owner test methods pass. The saved-artifact checker passes 13,569 assertions. Two independent review suites and saved-result audits pass

## Selected experiments and complete outcomes

### Detector sweep

`results/communication-sweep.json`: 768 held observations, 48 frames per integer/fractional × P=1/2 × SNR=0/6/12/18 dB cell, 3,072 detector rows. Frame N=3,M=4, 16-QAM; LoS gain 1 and added path amplitude .5. Every within-frame comparison shares the exact observation and noise; path powers, total added energy and CSI mismatch are declared.

All statuses remain included:

| Method | Outcomes across 768 observations |
|---|---|
| MP-G | 717 converged, 51 iteration caps |
| MP-Psi, full CSI | 181 confidence-converged, 587 caps |
| MP-Psi, rounded-delay nominal CSI | 96 confidence-converged, 654 caps, 18 confidence drops |
| Full block LMMSE | 768 solved |

At fractional P=2, 12 dB, observed BER is .02821 MP-G, .03776 full-CSI MP-Psi and .04123 LMMSE. Paired-frame bootstrap 95% intervals for comparator-minus-MP-G BER are [.00304,.01606] and [.00651,.01997], respectively. These are results of this reduced disclosed model and budget, not unconditional superiority claims.

At 18 dB, rounded-delay MP-Psi has BER .33073 while its entropy proxy is 3.6711 bits/symbol; its truth log score is −47.6906. This demonstrates why confidently wrong marginals cannot be called achieved capacity by entropy alone. The log score is not clipped or relabelled measured mutual information.

The strict-best-retention initial run is preserved separately with its full 3,072 rows. Eight saved-input policy cases compare strict best, latest tie and last posterior. Seven cases change 2–8 hard decisions out of 12 symbols. The soft-output policy is an engineering choice because the cited source specifies hard-decision updates but not the later paper's retained soft output. The revised stronger comparator, not the stale first-iteration curve, is the default result.

Zero observed error at high SNR is not proof of zero population BER. `communication-uncertainty.json` supplies conservative frame-event uncertainty, in addition to descriptive sample SE and paired bootstrap intervals. Within-frame bits are not assumed independent.

### Sensing sweep and held-out check

`results/radar-sweep.json`: 288 trials, 48 at each of −20/−10/0/10/20/30 dB, N=4,M=8. q=1.37,a=.43 are evaluation truth only; x is known and complex gain is unknown. This is a normalized reduced-model stress case, not the original 20 m/80 km/h scene: physical conversion at this reduced bandwidth is 164.286 m and 427.468 m/s.

- Threshold failures (>0.5 bin in either parameter): 43/48 at −20 dB, 25/48 at −10 dB, none at 0 dB and above
- Five selected optimizer-failed finite fits remain in the primary RMSE; 65 failed local candidates appear across 59 trials
- At 30 dB, delay RMSE is .002049 bins versus .07 for the coarse-grid ablation. A larger source-style fine grid is separately benchmarked; the coarse grid is never called the authors' undisclosed fine Γ
- The original 48 standardized noise directions happen to be unusually favorable. They are reused across SNR, so the below-CRB-looking high-SNR curve is correlated across its points. Independent linearized estimation predicts those errors; no FIM/noise factor-of-two bug was found. The finite sample is not a claim to beat or equal the local unbiased CRB
- A separately predeclared holdout used 256 disjoint SeedSequence children, entropy906221, fixed 30 dB and unchanged model/search settings. All 256 were retained, including three optimizer failures. Delay/Doppler RMSE is .002366/.002438; corresponding sqrt(mean local CRB) is .002283/.002280. Independent bootstrap intervals are [.002146,.002582] and [.002222,.002647], and ratio intervals include one. The χ-square diagnostic is asymptotic, not an exact finite-SNR requirement

The literal zero-gain multipath initialization produces duplicate peaks and a singular gain system. An explicitly augmented distinct-peak/real-part grid iteration is implemented and independently checked; a noiseless on-grid counterexample stops with residual .26256 although the true-parameter residual is approximately zero. This branch is not accepted as continuous multipath ML.

### Original-setting rate checkpoints

`figure4-rate-checkpoints.json` reproduces 11 Eq52/53 checkpoints using original N=50,M=64, T=6.4 microseconds, B=10 MHz, P=1 and guard=T/4. The unitary literal channel gives an exact determinant simplification. OTFS total duration is 321.6 microseconds and OFDM is 400 microseconds. This is original Gaussian-input rate accounting, not dense source-size detection, finite-code throughput or an equal-total-duration radar comparison.

## Resource and latency findings

All figures are original plots of the saved numerical records. Small-frame CPU timings come from Python on an AMD EPYC 9V74 container with single-thread OpenBLAS in a shared environment; they are not isolated benchmarks or browser latency.

- N3×M4 P2 16-QAM construction+30-cap MP-G: median441 ms, p95563 ms over seven fresh frames
- N4×M8: median3.61 s, p953.98 s; N6×M8: median7.96 s; N4×M16: median13.79 s
- N4×M8 continuous sensing: median325 ms, p95387 ms, worst399 ms over 12 held-observation repeats
- Source-style 257×257 grid: 66,049 candidates, about29–31 s; continuous extension uses586–736 objective evaluations on the same benchmark observations. These are deliberately unequal compute budgets

First port recommendation: fixed N3×M4 communication MP-G with P1/P2, QPSK/16-QAM and same-y calibrated LMMSE. Profile N4×M8 only afterward. Sensing follows with source-grid and clearly separate continuous-extension paths. Actual JavaScript/Worker tests determine live limits.

## Gate status

| Gate | Status |
|---|---|
| Fixed source, locators and hashes | Audited with explicit convention/normalization choices |
| Literal and finite physical models | Independently validated as different models |
| Bounded P1 sensing and MP-G receiver | Implemented and independently checked |
| Reduced experiments | Reproducible, all outcomes retained, uncertainty disclosed |
| Original fullsize Fig4–7 | Not reproduced; only original rate checkpoints completed |
| General continuous multipath sensing | Not established; initialization/objective gaps and failed adaptation retained |
| OFDM/FMCW radar comparison, waterfall bound, LMMSE-LC | Open |
| JavaScript, browser latency, teaching UI, export and deployment | Not implemented or accepted in this task |

No shared repository was edited, no browser was used and nothing was published. Next work is a separate bounded port checked against this reference, not immediate integration.
