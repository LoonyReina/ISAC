"""Artifact integrity checks; recompute aggregates without importing core code."""
from collections import Counter,defaultdict
from pathlib import Path
import json
import math
import statistics


def main():
    checks=0
    def check(ok,message):
        nonlocal checks
        if not ok: raise AssertionError(message)
        checks+=1
    root=Path("results")
    comm=json.loads((root/"communication-sweep.json").read_text())
    rows=comm["all_trials"];groups=defaultdict(list);paired=defaultdict(dict)
    for row in rows:
        key=tuple(row[k] for k in ["regime","paths","snr_db","method"])
        groups[key].append(row)
        paired[tuple(row[k] for k in ["regime","paths","snr_db","trial"])][row["method"]]=row
        check(0<=row["bit_error_rate"]<=1,"BER range")
        check(-1e-10<=row["entropy_proxy_bits"]<=4+1e-10,"entropy proxy range")
        check(math.isfinite(row["truth_log_score_bits"]),"unclipped finite log score")
    for summary in comm["summary"]:
        key=tuple(summary[k] for k in ["regime","paths","snr_db","method"]);group=groups[key]
        check(len(group)==summary["frames"],"frame count")
        check(dict(Counter(r["status"] for r in group))==summary["status_counts"],"all failure statuses retained")
        check(len(set(r["trial"] for r in group))==len(group),"unique trials")
        for metric in ["bit_error_rate","symbol_error_rate","entropy_proxy_bits","truth_log_score_bits"]:
            check(abs(statistics.mean(r[metric] for r in group)-summary[metric]["mean"])<1e-12,"raw mean matches summary")
    for key,methods in paired.items():
        check(len(methods)==4,"all paired methods present")
        check(len({json.dumps(r["channel"],sort_keys=True) for r in methods.values()})==1,"held paired channel")
        check(len({r["seed"] for r in methods.values()})==1,"held paired seed")
        if key[1]==1:
            for metric in ["bit_error_rate","symbol_error_rate","entropy_proxy_bits","truth_log_score_bits"]:
                check(abs(methods["MP-G"][metric]-methods["block-LMMSE"][metric])<1e-10,"P1 literal MP-G=LMMSE calibration")
    radar=json.loads((root/"radar-sweep.json").read_text())
    for summary in radar["summary"]:
        group=[r for r in radar["all_trials"] if r["snr_db"]==summary["snr_db"]]
        check(len(group)==summary["trials"],"all radar trials retained")
        check(sum(r["threshold_failure"] for r in group)==summary["threshold_failures"],"threshold count")
        check(dict(Counter(r["status"] for r in group))==summary["status_counts"],"radar status count")
        for metric in ["delay","doppler","grid_delay","grid_doppler"]:
            value=math.sqrt(statistics.mean(r[metric+"_error_bin"]**2 for r in group))
            check(abs(value-summary[metric+"_rmse_bin"]["value"])<1e-12,"unfiltered radar RMSE")
    diagnostics=json.loads((root/"model-diagnostics.json").read_text())
    check(diagnostics["multipath_initialization"][0]["status"]=="singular-gain-system","literal multipath failure not hidden")
    rates=json.loads((root/"figure4-rate-checkpoints.json").read_text())
    for row in rates["rows"]:
        r=math.log2(1+10**(row["snr_db"]/10))
        check(abs(row["otfs_bits_s_hz"]-50/50.25*r)<1e-13,"rate OTFS")
        check(abs(row["ofdm_bits_s_hz"]-.8*r)<1e-13,"rate OFDM")
    print(json.dumps({"status":"passed","checks":checks,"communication_trial_method_rows":len(rows),"radar_trials":len(radar["all_trials"])}))


if __name__=="__main__": main()
