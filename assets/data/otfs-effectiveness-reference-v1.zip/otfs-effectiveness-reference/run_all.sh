#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export OPENBLAS_NUM_THREADS=1
python -m unittest -v test_reference.py
python independent-review/independent_audit.py
python independent-review/review_parent.py
python second-review/probe_conventions.py
python run_experiments.py --trials 48
python compare_psi_policies.py
python holdout_crb_check.py
python benchmark_search.py
python benchmark_compute.py
python check_results.py
# Optional figure generation needs matplotlib==3.10.8:
# python plot_results.py
