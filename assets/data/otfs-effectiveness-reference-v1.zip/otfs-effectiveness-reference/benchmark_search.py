"""Source-style fine-grid versus continuous-extension, same observation.

Separate from sweep so adding grid sizes never changes the observation trials.
The source does not disclose Γ spacing; none of these is called its exact Γ.
"""
import hashlib
from pathlib import Path
import time
import numpy as np
from otfs_reference import *
from run_experiments import write


def grid_ml(frame,x,y,bounds,shape,model="eq14_literal"):
    start=time.perf_counter();best=None;count=0
    # Same source profile objective; endpoints and spacing are explicit.
    for q,a in product(np.linspace(*bounds[0],shape[0]),np.linspace(*bounds[1],shape[1])):
        s=path_operator(frame,q,a,model)@x;h,score,residual=profile_gain(s,y);count+=1
        if best is None or score>best["score"]:
            best={"delay_bin":float(q),"doppler_bin":float(a),"gain":h,"score":score,"residual":residual}
    return {**best,"evaluations":count,"grid_shape":shape,"status":"grid-exhausted",
            "global_on_declared_grid":True,"global_on_continuum":False,
            "spacing_bins":[(bounds[j][1]-bounds[j][0])/(shape[j]-1) for j in range(2)],
            "elapsed_ms":1000*(time.perf_counter()-start)}


def main():
    f=Frame(4,8);c,_=qam(4);q,a=1.37,.43;bounds=((.05,3.8),(-1.4,1.4));rows=[]
    for seed,snr in [(820001,-10),(820002,10),(820003,30)]:
        rng=np.random.default_rng(seed);x=c[rng.integers(0,4,f.size)]
        y=np.exp(.31j)*eq14_operator(f,q,a)@x+noise(rng,f.size,10**(-snr/10))
        obs_hash=hashlib.sha256(np.concatenate([x,y]).astype('<c16').tobytes()).hexdigest()
        for shape in [(13,17),(65,65),(257,257)]:
            out=grid_ml(f,x,y,bounds,shape)
            rows.append({"seed":seed,"snr_db":snr,"observation_sha256":obs_hash,"method":"source-style-grid",
                         "result":out,"truth_for_evaluation_only":[q,a],
                         "errors_bin":[out["delay_bin"]-q,out["doppler_bin"]-a]})
            print(seed,snr,shape,out["elapsed_ms"],flush=True)
        out=radar_ml(f,x,y,bounds=bounds,grid_shape=(13,17))
        rows.append({"seed":seed,"snr_db":snr,"observation_sha256":obs_hash,"method":"continuous-per-cell-extension",
                     "result":out,"truth_for_evaluation_only":[q,a],
                     "errors_bin":[out["delay_bin"]-q,out["doppler_bin"]-a]})
    # Timing repeats use a held observation, not accuracy/training trials.
    timings=[]
    for repeat in range(12):
        fit=radar_ml(f,x,y,bounds=bounds,grid_shape=(13,17))
        timings.append(fit["elapsed_ms"])
    write("search-budget-comparison.json",{"rows":rows,"bounds":bounds,"frame":{"N":f.N,"M":f.M,"T":f.T},
          "source_locator":"arXiv:1910.01896v1 p11 after Eq25; p12 P=1 grid qualification",
          "method_boundary":"Same x,y,noise model and bounds. Grid candidates versus objective evaluations are disclosed; compute budgets are intentionally unequal. Finest grid is an implemented reference grid, not the source's undisclosed Γ.",
          "cpu":"AMD EPYC 9V74 80-Core Processor (container /proc/cpuinfo); OPENBLAS_NUM_THREADS=1",
          "python_only_latency":{"repetitions":12,"median_ms":float(np.median(timings)),"p95_ms":float(np.quantile(timings,.95)),"worst_ms":max(timings),"all_ms":timings},
          "not_browser_latency":True,"core_sha256":hashlib.sha256(Path('otfs_reference.py').read_bytes()).hexdigest()})


if __name__=="__main__": main()
