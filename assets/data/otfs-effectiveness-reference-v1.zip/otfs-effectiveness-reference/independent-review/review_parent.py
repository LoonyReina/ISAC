"""Black-box verification of parent's otfs_reference.py against independent oracles."""
from pathlib import Path
import sys, json, hashlib
import numpy as np
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent))
import otfs_reference as r
from independent_audit import continuous_waveform_projection, eq14, posterior_enumeration

def scalar_gaussian_mp(H,y,c,variance,iterations=5,damping=.7):
    """Dense tiny-system oracle, explicit loops and no confidence retention."""
    R,D=H.shape;Q=len(c)
    p=np.full((R,D,Q),1/Q)
    def normalize(logp):
        v=np.exp(logp-np.max(logp));return v/v.sum()
    for it in range(iterations):
        logs=np.empty((R,D,Q))
        for obs in range(R):
            for target in range(D):
                mean=0j;var=variance
                for other in range(D):
                    if other==target:continue
                    symbol_mean=sum(p[obs,other,a]*c[a] for a in range(Q))
                    symbol_second=sum(p[obs,other,a]*abs(c[a])**2 for a in range(Q))
                    mean+=H[obs,other]*symbol_mean
                    var+=abs(H[obs,other])**2*(symbol_second-abs(symbol_mean)**2)
                for a in range(Q):logs[obs,target,a]=-abs(y[obs]-mean-H[obs,target]*c[a])**2/var
        posterior=np.array([normalize(logs[:,target,:].sum(axis=0)) for target in range(D)])
        updates=np.empty_like(p)
        for obs in range(R):
            for target in range(D):
                cavity=normalize(sum((logs[other,target] for other in range(R) if other!=obs),np.zeros(Q)))
                updates[obs,target]=damping*cavity+(1-damping)*p[obs,target]
        p=updates
    return posterior

def run():
    rng=np.random.default_rng(1873)
    source=HERE.parent/'otfs_reference.py'
    out={'reviewed_sha256':hashlib.sha256(source.read_bytes()).hexdigest()}
    exact_cases=[]; literal_cases=[]
    for N,M,q,a in [(1,1,0.,.13),(2,3,0.,-.32),(3,5,1.38,.64),(4,7,1.,-.79),(2,4,3.71,1.23)]:
        f=r.Frame(N,M)
        E=continuous_waveform_projection(N,M,q,a/N)
        xerr=float(abs(E-r.exact_rect_operator(f,q,a)).max())
        lerr=float(abs(eq14(N,M,q,a/N)-r.eq14_operator(f,q,a)).max())
        exact_cases.append({'N':N,'M':M,'q':q,'a':a,'max_error':xerr})
        literal_cases.append({'N':N,'M':M,'q':q,'a':a,'max_error':lerr})
        assert xerr<1e-12 and lerr<1e-12
    out['exact_finite_vs_independent_waveform_projection']=exact_cases
    out['literal_vs_independent_formula']=literal_cases
    c,_=r.qam(4);v=.7
    receiver=[]
    for kind,D in [('diagonal',4),('two-variable',2),('chain-tree',4),('loopy',3)]:
        if kind=='diagonal': H=np.diag(np.array([.3+.7j,1.2-.3j,-.2+.4j,0]))
        elif kind=='two-variable':H=(rng.normal(size=(3,D))+1j*rng.normal(size=(3,D)))/np.sqrt(6)
        elif kind=='chain-tree':
            G=2*np.eye(D,dtype=complex)
            for i in range(D-1):G[i,i+1]=.37+.29j;G[i+1,i]=G[i,i+1].conjugate()
            H=np.linalg.cholesky(G).conj().T
        else:H=(rng.normal(size=(D,D))+1j*rng.normal(size=(D,D)))/np.sqrt(2*D)
        y=rng.normal(size=H.shape[0])+1j*rng.normal(size=H.shape[0])
        oracle=posterior_enumeration(H,y,c,v)
        exact=r.exact_marginals(H,y,v,c)['probabilities']
        got=r.mp_g(H,y,v,c,max_iter=100,tolerance=1e-12)
        err=float(abs(got['probabilities']-oracle).max())
        receiver.append({'case':kind,'G_max_marginal_error':err,'G_status':got['status'],'G_iterations':got['iterations'],'enumeration_max_error':float(abs(exact-oracle).max())})
        assert abs(exact-oracle).max()<1e-12
        if kind!='loopy':assert err<1e-11
        if kind=='diagonal':
            for label,fun in [('MP-Psi',r.mp_psi),('LMMSE',r.lmmse)]:
                p=fun(H,y,v,c)['probabilities'];err=float(abs(p-oracle).max())
                receiver.append({'case':'diagonal','detector':label,'max_marginal_error':err})
                assert err<1e-11
    out['receivers']=receiver
    H=np.zeros((2,3),complex);y=np.ones(2,dtype=complex)
    out['no_information_max_uniform_errors']={name:float(abs(fn(H,y,v,c)['probabilities']-.25).max()) for name,fn in [('MP-G',r.mp_g),('MP-Psi',r.mp_psi),('LMMSE',r.lmmse)]}
    assert max(out['no_information_max_uniform_errors'].values())<1e-12
    w=r.noise(rng,200_000,v)
    out['noise_moments']={'target_complex_variance':v,'measured_complex_variance':float(np.mean(abs(w)**2)),'measured_real_variance':float(w.real.var()),'measured_imag_variance':float(w.imag.var())}
    assert abs(np.mean(abs(w)**2)-v)<.01
    radar=[]
    f=r.Frame(3,4);x=c[rng.integers(len(c),size=f.size)];h=.63-.42j
    for model,q,a in [('eq14_literal',1.31,.43),('eq14_literal',1.,-.37),('eq14_literal',0.,.29),('exact_rect_finite',1.31,.43)]:
        y=h*r.path_operator(f,q,a,model)@x
        z=r.radar_ml(f,x,y,bounds=((0.,2.5),(-1.,1.)),model=model,grid_shape=(13,17),starts_per_delay_cell=3)
        row={'model':model,'true_q':q,'true_a':a,'estimated_q':z['delay_bin'],'estimated_a':z['doppler_bin'],'gain_error':float(abs(z['gain']-h)),'residual':z['residual'],'status':z['status']}
        radar.append(row)
        assert abs(z['delay_bin']-q)<1e-5 and abs(z['doppler_bin']-a)<1e-5 and abs(z['gain']-h)<1e-5
    out['noiseless_ml']=radar
    # Opposite delay signs are gauge-equivalent for exactly the same mask.
    f=r.Frame(4,7);q,a=1.37,.76
    L=r.eq14_operator(f,q,a);P=r.eq14_operator(f,q,a,physical_delay_sign=True)
    ll=np.repeat(np.arange(f.M),f.N);rotation=np.exp(-2j*np.pi*ll/f.M)
    gain_rotation=np.exp(-2j*np.pi*q*(f.M-1)/f.M)
    gauge_error=float(abs(P-gain_rotation*rotation[:,None]*L*rotation.conj()[None,:]).max())
    out['delay_coordinate_gauge_max_error']=gauge_error
    assert gauge_error<1e-12
    # Deliberately audit the printed multipath iteration, not a substituted
    # residual-based coordinate optimizer. Check failure and adaptation limits.
    f=r.Frame(4,6);rr=np.random.default_rng(777)
    x=c[rr.integers(4,size=f.size)]
    paths=[(.6,-.5,1+.2j),(2.2,.75,.55-.2j)]
    y=r.channel_operator(f,paths)@x
    kwargs=dict(path_count=2,bounds=((0.,3.),(-1.,1.)),grid_shape=(31,17),max_iter=5)
    failed=r.multipath_eq21(f,x,y,initialization='source-zero',**kwargs)
    assert failed['status']=='singular-gain-system' and failed['gains'] is None
    assert np.array_equal(failed['parameters'][0],failed['parameters'][1])
    augmented=r.multipath_eq21(f,x,y,initialization='distinct-peaks',**kwargs)
    candidates=np.array([(q,a) for q in np.linspace(0,3,31) for a in np.linspace(-1,1,17)])
    vectors=[r.path_operator(f,*p)@x for p in candidates]
    norms=np.array([np.vdot(v,v).real for v in vectors])
    b=np.array([np.vdot(v,y) for v in vectors]);scores=abs(b)**2/norms
    indices=[]
    for index in np.argsort(scores)[::-1]:
        if all(np.linalg.norm((candidates[index]-candidates[j])/[.5,.5])>=1 for j in indices):indices.append(index)
        if len(indices)==2:break
    gains=np.linalg.lstsq(np.column_stack([vectors[j] for j in indices]),y,rcond=None)[0]
    trace_errors=[]
    for step in augmented['trace']:
        chosen=[]
        for pth in range(2):
            other=1-pth
            objective=np.array([scores[i]-np.real(gains[other]*np.vdot(v,vectors[indices[other]])*np.vdot(y,v))/norms[i] for i,v in enumerate(vectors)])
            chosen.append(int(np.argmax(objective)))
        param_error=float(abs(candidates[chosen]-np.asarray(step['parameters'])).max())
        assert param_error<1e-12
        B=np.column_stack([vectors[j] for j in chosen])
        gains=np.linalg.lstsq(B,y,rcond=None)[0]
        residual=float(np.linalg.norm(y-B@gains)**2)
        residual_error=abs(residual-step['residual'])
        assert residual_error<1e-12
        trace_errors.append({'parameter_max_error':param_error,'residual_error':residual_error})
        indices=chosen
    truth_A=np.column_stack([r.path_operator(f,q,a)@x for q,a,h in paths])
    truth_fit=np.linalg.lstsq(truth_A,y,rcond=None)[0]
    truth_residual=float(np.linalg.norm(y-truth_A@truth_fit)**2)
    out['multipath_audit']={
        'source_zero_status':failed['status'],
        'source_zero_duplicate_parameters':failed['parameters'].tolist(),
        'augmented_status':augmented['status'],
        'augmented_parameters':augmented['parameters'].tolist(),
        'augmented_final_residual':augmented['trace'][-1]['residual'],
        'true_grid_parameters':[[q,a] for q,a,h in paths],
        'true_grid_residual':truth_residual,
        'independent_iteration_checks':trace_errors,
        'interpretation':'Iteration implemented correctly; grid-stationary does not imply joint ML even on noiseless on-grid data.'}
    # A zero-confidence plateau must not freeze the default soft output at t=1.
    H=np.array([[1,.8+.2j,.3-.1j],[.2+.1j,1,.6+.2j],[.4-.2j,.3+.1j,1]],complex)
    y=np.array([.9+.2j,-.4+.8j,.6-.1j]);v=2.
    first=r.mp_psi(H,y,v,c,max_iter=1)['probabilities']
    results={mode:r.mp_psi(H,y,v,c,max_iter=5,soft_output_retention=mode) for mode in ['best-confidence-latest-tie','strict-best-confidence','last']}
    latest=results['best-confidence-latest-tie']['probabilities']
    strict=results['strict-best-confidence']['probabilities']
    last=results['last']['probabilities']
    oracle=scalar_gaussian_mp(H,y,c,v,iterations=5)
    assert all(all(row['confident_fraction']==0 for row in item['trace']) for item in results.values())
    assert abs(latest-last).max()<1e-12
    assert abs(strict-first).max()<1e-12
    assert abs(latest-oracle).max()<1e-12
    assert abs(latest-strict).max()>.05
    out['mp_psi_tie_retention']={
        'all_five_confidences_zero':True,
        'latest_tie_vs_last_max_error':float(abs(latest-last).max()),
        'strict_best_vs_first_max_error':float(abs(strict-first).max()),
        'latest_tie_vs_scalar_gaussian_oracle_max_error':float(abs(latest-oracle).max()),
        'latest_tie_vs_strict_best_max_difference':float(abs(latest-strict).max()),
        'first_probabilities':first.tolist(),'final_probabilities':latest.tolist()}
    # Invalid inputs should fail explicitly before likelihood divisions.
    validation=[]
    f=r.Frame(2,3);x=np.ones(f.size,complex);y=np.zeros(f.size,complex)
    for label,fn,kw in [
        ('zero-radar-waveform',r.radar_ml,dict(x=np.zeros_like(x),y=y,bounds=((0,2),(-1,1)))),
        ('zero-multipath-waveform',r.multipath_eq21,dict(x=np.zeros_like(x),y=y,path_count=2,bounds=((0,2),(-1,1)))),
        ('noninteger-path-count',r.multipath_eq21,dict(x=x,y=y,path_count=1.5,bounds=((0,2),(-1,1)))),
        ('zero-multipath-iterations',r.multipath_eq21,dict(x=x,y=y,path_count=2,bounds=((0,2),(-1,1)),max_iter=0)),
        ('too-small-multipath-grid',r.multipath_eq21,dict(x=x,y=y,path_count=2,bounds=((0,2),(-1,1)),grid_shape=(1,5)))]:
        try:fn(f,**kw)
        except ValueError:validation.append(label)
        else:raise AssertionError('Missing invalid-input rejection: '+label)
    out['invalid_inputs_rejected']=validation
    out['source_unchanged_during_review']=(hashlib.sha256(source.read_bytes()).hexdigest()==out['reviewed_sha256'])
    assert out['source_unchanged_during_review']
    (HERE/'parent_review_results.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))
if __name__=='__main__':run()
