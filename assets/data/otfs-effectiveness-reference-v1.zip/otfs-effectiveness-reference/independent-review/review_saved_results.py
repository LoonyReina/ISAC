"""Independent checks of saved results; does not rerun the sweep or optimize."""
from pathlib import Path
from collections import Counter,defaultdict
import hashlib,json,sys,statistics
import numpy as np
from scipy.stats import chi2
ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'independent-review'))
import otfs_reference as r
from review_parent import scalar_gaussian_mp

def decode(x):
    if isinstance(x,dict):
        if set(x)=={'re','im'}:return complex(x['re'],x['im'])
        return {k:decode(v) for k,v in x.items()}
    if isinstance(x,list):return [decode(v) for v in x]
    return x

def load(name):return json.loads((ROOT/'results'/name).read_text())

def run():
    out={'core_sha256':hashlib.sha256((ROOT/'otfs_reference.py').read_bytes()).hexdigest(),
         'input_sha256':{name:hashlib.sha256((ROOT/'results'/name).read_bytes()).hexdigest() for name in ['communication-sweep.json','radar-sweep.json','mp-psi-policy-sensitivity.json','figure4-rate-checkpoints.json','model-diagnostics.json','holdout-crb-check.json']}}
    comm=load('communication-sweep.json');radar=load('radar-sweep.json');pol=decode(load('mp-psi-policy-sensitivity.json'))
    groups=defaultdict(list);held=defaultdict(dict)
    for row in comm['all_trials']:
        groups[tuple(row[k] for k in ['regime','paths','snr_db','method'])].append(row)
        held[tuple(row[k] for k in ['regime','paths','snr_db','trial'])][row['method']]=row
    max_mean_error=0.;max_se_error=0.
    for s in comm['summary']:
        group=groups[tuple(s[k] for k in ['regime','paths','snr_db','method'])]
        assert len(group)==s['frames']==48 and s['symbols']==48*12
        assert dict(Counter(row['status'] for row in group))==s['status_counts']
        for metric in ['bit_error_rate','symbol_error_rate','entropy_proxy_bits','truth_log_score_bits','iterations','elapsed_ms']:
            vals=[row[metric] for row in group]
            err=abs(statistics.mean(vals)-s[metric]['mean']);max_mean_error=max(max_mean_error,err)
            se=statistics.stdev(vals)/np.sqrt(len(vals));seerr=abs(se-s[metric]['standard_error_across_frames']);max_se_error=max(max_se_error,seerr)
            assert err<1e-11 and seerr<1e-11
    p1max=0.
    for key,methods in held.items():
        assert len(methods)==4
        assert len({json.dumps(row['channel'],sort_keys=True) for row in methods.values()})==1
        if key[1]==1:
            for metric in ['bit_error_rate','symbol_error_rate','entropy_proxy_bits','truth_log_score_bits']:
                p1max=max(p1max,abs(methods['MP-G'][metric]-methods['block-LMMSE'][metric]))
    assert p1max<1e-10
    out['communication']={'method_rows':len(comm['all_trials']),'held_observations':len(held),'summary_groups':len(groups),
        'mean_max_error':max_mean_error,'standard_error_max_error':max_se_error,'single_path_G_vs_LMMSE_metric_max_difference':p1max,
        'statuses':{m:dict(Counter(z['status'] for z in comm['all_trials'] if z['method']==m)) for m in ['MP-G','MP-Psi-full-CSI','MP-Psi-rounded-delay','block-LMMSE']},
        'minimum_truth_log_score_bits':min(z['truth_log_score_bits'] for z in comm['all_trials'])}
    rms_error=0.
    for s in radar['summary']:
        rows=[z for z in radar['all_trials'] if z['snr_db']==s['snr_db']]
        assert len(rows)==s['trials']==48
        assert sum(z['threshold_failure'] for z in rows)==s['threshold_failures']
        assert dict(Counter(z['status'] for z in rows))==s['status_counts']
        for metric in ['delay','doppler','grid_delay','grid_doppler']:
            val=np.sqrt(np.mean([z[metric+'_error_bin']**2 for z in rows]))
            rms_error=max(rms_error,abs(val-s[metric+'_rmse_bin']['value']))
        for z in rows:
            err=np.asarray(z['estimate'])-np.asarray(z['truth_for_evaluation_only'])
            assert np.max(abs(err-[z['delay_error_bin'],z['doppler_error_bin']]))<1e-12
            assert bool(np.max(abs(err))>.5)==z['threshold_failure']
    assert rms_error<1e-12
    out['radar']={'trials':len(radar['all_trials']),'RMSE_max_error':float(rms_error),
        'selected_statuses':dict(Counter(z['status'] for z in radar['all_trials'])),
        'failed_local_candidates':sum(z['local_optimizer_failed_candidates'] for z in radar['all_trials']),
        'trials_with_any_failed_candidate':sum(z['local_optimizer_failed_candidates']>0 for z in radar['all_trials']),
        'threshold_failures_by_snr':{str(s['snr_db']):s['threshold_failures'] for s in radar['summary']}}
    policychecks=[]
    for index,case in enumerate(pol['cases']):
        args=case['receiver_input'];H=np.asarray(args['H']);y=np.asarray(args['y']);c=np.asarray(args['constellation']);v=args['noise_variance']
        errors={}
        for mode,stored in case['outputs'].items():
            got=r.mp_psi(H,y,v,c,max_iter=args['max_iter'],damping=args['damping'],confidence=args['confidence'],drop_threshold=args['drop_threshold'],soft_output_retention=mode)
            errors[mode]=float(abs(got['probabilities']-np.asarray(stored['probabilities'])).max())
            assert errors[mode]<1e-12 and got['status']==stored['status'] and got['iterations']==stored['iterations']
            assert np.array_equal(got['probabilities'].argmax(axis=1),stored['hard_symbol_indices'])
        # Check the source Eq41 rule using current decisions, not soft-retained decisions.
        previous_eta=0.;decision=None
        for step in case['iteration_history']:
            update=step['eta']>previous_eta
            assert update==step['source_Eq41_update']
            if update:decision=step['current_hard_symbol_indices']
            assert decision==step['source_retained_hard_symbol_indices']
            previous_eta=step['eta']
        assert decision==case['source_Eq41_hard_final']
        assert len({(z['status'],z['iterations']) for z in case['outputs'].values()})==1
        method='MP-Psi-full-CSI' if case['nominal_CSI']=='full' else 'MP-Psi-rounded-delay'
        sweep=held[('fractional',2,case['snr_db'],case['seed']-410000)][method]
        metric_error=max(abs(sweep[k]-case['outputs']['best-confidence-latest-tie'][k]) for k in ['bit_error_rate','symbol_error_rate','entropy_proxy_bits','truth_log_score_bits'])
        assert metric_error<1e-12
        # A separately looped recursion for two held inputs checks the tensor implementation.
        oracle_error=None
        if index in [0,7]:
            oracle=scalar_gaussian_mp(H,y,c,v,iterations=case['outputs']['last']['iterations'],damping=args['damping'])
            oracle_error=float(abs(oracle-np.asarray(case['outputs']['last']['probabilities'])).max())
            assert oracle_error<1e-10
        policychecks.append({'case':index,'seed':case['seed'],'snr_db':case['snr_db'],'nominal_CSI':case['nominal_CSI'],
            'saved_replay_max_error':max(errors.values()),'paired_sweep_metric_error':metric_error,'scalar_oracle_error':oracle_error,
            'hard_disagreements_strict_vs_latest':case['strict_vs_latest_tie_hard_disagreements'],'source_decision_undefined':decision is None})
    out['held_input_policy_comparison']=policychecks
    rates=load('figure4-rate-checkpoints.json');f=rates['frame'];T=f['T_s'];N=f['N'];GI=rates['guard_s']
    assert f['M']/T==f['B_hz'] and GI==T/4 and N==50 and f['M']==64
    rate_error=0.
    for row in rates['rows']:
        log=np.log2(1+10**(row['snr_db']/10))
        rate_error=max(rate_error,abs(row['otfs_bits_s_hz']-(N*T)/(N*T+GI)*log),abs(row['ofdm_bits_s_hz']-T/(T+GI)*log))
    assert rate_error<1e-12
    out['source_setting_rates']={'checkpoints':len(rates['rows']),'max_formula_error':float(rate_error),'OTFS_overhead_factor':N*T/(N*T+GI),'OFDM_overhead_factor':T/(T+GI),'classification':'Original-setting analytical Eq52/53 checkpoints, not full figure or finite-code throughput reproduction'}
    # CRB scaling diagnosis at 30 dB without rerunning any estimator.
    f=r.Frame(4,8);c,_=r.qam(4);q,a,h=1.37,.43,np.exp(.31j);variance=.001
    actual={z['seed']:[z['delay_error_bin'],z['doppler_error_bin']] for z in radar['all_trials'] if z['snr_db']==30}
    errors=[];linear=[];diags=[];quadratic=[]
    for trial in range(48):
        seed=720000+trial;rng=np.random.default_rng(seed);x=c[rng.integers(0,4,f.size)];w=r.noise(rng,f.size,1)*np.sqrt(variance)
        s=r.path_operator(f,q,a)@x;eps=1e-5
        dq=h*(r.path_operator(f,q+eps,a)@x-r.path_operator(f,q-eps,a)@x)/(2*eps)
        da=h*(r.path_operator(f,q,a+eps)@x-r.path_operator(f,q,a-eps)@x)/(2*eps)
        J=np.column_stack([s,1j*s,dq,da]);A=np.vstack([J.real,J.imag])
        e=np.linalg.lstsq(A,np.r_[w.real,w.imag],rcond=None)[0][2:];C=variance/2*np.linalg.inv(A.T@A)[2:,2:]
        errors.append(actual[seed]);linear.append(e);diags.append(C.diagonal());quadratic.append(e@np.linalg.solve(C,e))
    Q=float(sum(quadratic))
    out['high_snr_CRB_diagnostic']={'actual_mean_squared_errors':np.mean(np.asarray(errors)**2,axis=0).tolist(),'linearized_mean_squared_errors':np.mean(np.asarray(linear)**2,axis=0).tolist(),
        'mean_CRB_variances':np.mean(diags,axis=0).tolist(),'joint_normalized_quadratic_sum':Q,'local_Gaussian_reference_df':96,'reference_lower_tail_probability':float(chi2.cdf(Q,96)),
        'interpretation':'No variance-scaling error identified. Fixed draws give unusually favorable errors; SNR coupling reuses them. Do not claim CRB beating or statistical equality from this small sweep.'}
    diagnostics=decode(load('model-diagnostics.json'));rng=np.random.default_rng(99319);x=c[rng.integers(0,4,f.size)];cross=[]
    for case in diagnostics['noiseless_cross_model_fits']:
        fit=case['fit'];y=r.path_operator(f,q,a,case['generated_model'])@x
        z=fit['gain']*r.path_operator(f,fit['delay_bin'],fit['doppler_bin'],case['fitted_model'])@x
        residual=float(np.linalg.norm(y-z)/np.linalg.norm(y))
        assert abs(residual-case['relative_residual_norm'])<1e-12
        cross.append({'generated':case['generated_model'],'fitted':case['fitted_model'],'relative_residual':residual})
    assert diagnostics['multipath_initialization'][0]['status']=='singular-gain-system'
    out['cross_model_saved_fits']=cross
    # Fixed-size holdout: recompute all summaries and add paired-frame bootstrap.
    hold=load('holdout-crb-check.json');rows=hold['all_trials'];plan=hold['fixed_plan'];summary=hold['summary']
    assert len(rows)==plan['trials']==256 and plan['SNR_dB']==30
    assert plan['early_stopping'] is False and plan['seed_replacement'] is False
    assert [z['trial'] for z in rows]==list(range(256))
    assert [z['spawn_key'] for z in rows]==[[j] for j in range(256)]
    assert hold['core_sha256']==out['core_sha256']
    assert hold['plan_script_sha256']==hashlib.sha256((ROOT/'holdout_crb_check.py').read_bytes()).hexdigest()
    E=np.asarray([z['errors_bin'] for z in rows]);C=np.asarray([z['crb_covariance_bins'] for z in rows]);V=np.diagonal(C,axis1=1,axis2=2)
    rmse=np.sqrt(np.mean(E*E,axis=0));crb_root=np.sqrt(V.mean(axis=0));means=E.mean(axis=0)
    quadratic=np.array([e@np.linalg.solve(cov,e) for e,cov in zip(E,C)])
    assert np.max(abs(rmse-summary['rmse_bins']))<1e-12
    assert np.max(abs(crb_root-summary['sqrt_mean_crb_variances_bins']))<1e-12
    assert np.max(abs(means-summary['mean_errors_bins']))<1e-12
    assert abs(quadratic.sum()-summary['normalized_quadratic_error_sum'])<1e-10
    assert abs(chi2.cdf(quadratic.sum(),512)-summary['asymptotic_lower_tail_probability'])<1e-12
    assert dict(Counter(z['status'] for z in rows))==summary['status_counts']
    # Distinct RNG states and regenerated waveforms/noise fingerprints establish
    # no reuse of primary trials; they do not constitute proof of independence.
    primary_states={tuple(np.random.SeedSequence(720000+j).generate_state(4)) for j in range(48)}
    holdseeds=np.random.SeedSequence(plan['seed_sequence_entropy']).spawn(256)
    holdstates=[tuple(seed.generate_state(4)) for seed in holdseeds]
    assert len(set(holdstates))==256 and not primary_states.intersection(holdstates)
    fingerprints=[];max_residual_error=0.;max_covariance_error=0.
    f=r.Frame(4,8);c,_=r.qam(4);q,a=plan['truth_evaluation_only'];h=np.exp(.31j);variance=.001
    for seed,z in zip(holdseeds,rows):
        rng=np.random.default_rng(seed);x=c[rng.integers(0,4,f.size)];w=r.noise(rng,f.size,variance)
        fingerprints.append(hashlib.sha256(np.r_[x,w].astype('<c16').tobytes()).hexdigest())
        y=h*r.eq14_operator(f,q,a)@x+w
        template=r.eq14_operator(f,*z['estimate'])@x
        _,_,residual=r.profile_gain(template,y)
        max_residual_error=max(max_residual_error,abs(residual-z['residual']))
        cov=r.fisher_single(f,x,q,a,h,variance)['covariance'][2:,2:]
        max_covariance_error=max(max_covariance_error,float(abs(cov-np.asarray(z['crb_covariance_bins'])).max()))
    primary_fingerprints=[]
    for j in range(48):
        rng=np.random.default_rng(720000+j);x=c[rng.integers(0,4,f.size)];w=r.noise(rng,f.size,1)*np.sqrt(variance)
        primary_fingerprints.append(hashlib.sha256(np.r_[x,w].astype('<c16').tobytes()).hexdigest())
    assert len(set(fingerprints))==256 and not set(fingerprints).intersection(primary_fingerprints)
    assert max_residual_error<1e-12 and max_covariance_error<1e-12
    boot_seed=20261012;B=10000;brng=np.random.default_rng(boot_seed)
    ids=brng.integers(0,len(E),size=(B,len(E)))
    boot_rmse=np.sqrt(np.mean(E[ids]**2,axis=1))
    boot_crb=np.sqrt(np.mean(V[ids],axis=1));boot_ratio=boot_rmse/boot_crb
    out['holdout_CRB']={
        'trials':len(rows),'status_counts':summary['status_counts'],'seed_entropy':plan['seed_sequence_entropy'],
        'unique_spawn_keys_and_rng_states':True,'rng_states_and_sample_fingerprints_disjoint_from_primary':True,
        'regenerated_residual_max_error':max_residual_error,'regenerated_CRB_covariance_max_error':max_covariance_error,
        'rmse_bins':rmse.tolist(),'sqrt_mean_crb_variances_bins':crb_root.tolist(),'mean_errors_bins':means.tolist(),
        'quadratic_error_sum':float(quadratic.sum()),'asymptotic_df':512,'asymptotic_lower_tail_probability':float(chi2.cdf(quadratic.sum(),512)),
        'bootstrap':{'method':'Paired-frame percentile; all outcomes retained','resamples':B,'audit_seed':boot_seed,
            'rmse_95_interval_by_parameter':np.quantile(boot_rmse,[.025,.975],axis=0).T.tolist(),
            'sqrt_mean_CRB_95_interval_by_parameter':np.quantile(boot_crb,[.025,.975],axis=0).T.tolist(),
            'RMSE_over_sqrt_mean_CRB_95_interval_by_parameter':np.quantile(boot_ratio,[.025,.975],axis=0).T.tolist()},
        'interpretation':'Separate fixed-size diagnostic retained in full. No sample-level requirement to exceed CRB, no seed selection, and no proof of unbiasedness or globally optimal ML.'}
    out['source_unchanged']=hashlib.sha256((ROOT/'otfs_reference.py').read_bytes()).hexdigest()==out['core_sha256']
    assert out['source_unchanged']
    dest=ROOT/'independent-review'/'saved_results_review.json';dest.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
if __name__=='__main__':run()
