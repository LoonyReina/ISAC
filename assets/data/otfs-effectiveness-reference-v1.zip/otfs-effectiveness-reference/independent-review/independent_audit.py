"""Independent cross-checks of arXiv:1910.01896v1, normalized T=1.
No source PDF content is included. Run this file to write audit_results.json.
"""
from __future__ import annotations
import importlib.util
import json
from pathlib import Path
import numpy as np
from numpy.polynomial.legendre import leggauss


def dsum(z, Q):
    z = np.asarray(z)
    return np.exp(2j*np.pi*z[..., None]*np.arange(Q)/Q).mean(axis=-1)


def dd_basis(times, N, M):
    """Rows: times; columns: DD synthesis functions (k fastest, paper stacking)."""
    t = np.asarray(times)
    n = np.floor(t).astype(int)
    u = t - n
    a = np.exp(2j*np.pi*n[:,None]*np.arange(N)/N)
    c = M*dsum(M*u[:,None]-np.arange(M)[None,:], M)
    S = (c[:,:,None]*a[:,None,:]).reshape(len(t), N*M)
    S[(t<0)|(t>=N)] = 0
    return S


def continuous_waveform_projection(N, M, q, b, order=80):
    """Direct Eqs4--9 integration with h'=1, delay q/M, Doppler b.
    Independent of Eq8 ambiguity functions and closed-form Eq14.
    Split at all transmit/receive window edges, integrate DD basis products.
    """
    tau = q/M
    cuts = sorted(set([0., float(N)] + [float(v) for v in range(1,N)] +
                      [float(v+tau) for v in range(N) if 0 < v+tau < N]))
    nodes, weights = leggauss(order)
    A = np.zeros((N*M, N*M), complex)
    for lo, hi in zip(cuts[:-1], cuts[1:]):
        t = lo+(nodes+1)*(hi-lo)/2
        w = weights*(hi-lo)/2
        R = dd_basis(t,N,M)
        S = dd_basis(t-tau,N,M)
        # Physical h=e^(-j2πντ) when paper effective h'=1.
        A += R.conj().T @ ((w*np.exp(2j*np.pi*b*(t-tau)))[:,None]*S)/(N*M)
    return A


def eq14(N, M, q, b, physical_delay_sign=False, finite_frame=False, endpoint="printed_ceil"):

    k = np.tile(np.arange(N),M)
    l = np.repeat(np.arange(M),N)
    dn = dsum(k[None,:]-k[:,None]+b*N,N)
    dmarg = l[None,:]-l[:,None]+q
    if physical_delay_sign:
        dmarg = -dmarg
    dm = dsum(dmarg,M)
    n_isi = int(np.ceil(q)) if endpoint == "printed_ceil" else int(np.floor(q))
    isi = l >= M-n_isi
    phase = np.exp(2j*np.pi*b*l/M)
    phase[isi] *= np.exp(-2j*np.pi*(k[isi]/N+b))
    if finite_frame:
        dn = dn.copy()
        dn[:,isi] -= 1/N
    return dm*dn*phase[None,:]


def tx_quadrature_operator(N,M,q,b):
    """Independent Eq8 Tx-grid rectangle quadrature using DD waveforms."""
    tau=q/M
    A=np.zeros((N*M,N*M),complex)
    for nt in range(N):
        # Tx pulse half-open sample nodes; receive position t=nt+i/M+tau.
        u=nt+np.arange(M)/M
        t=u+tau
        S=dd_basis(u,N,M)
        R=dd_basis(t,N,M)
        A+=R.conj().T @ (np.exp(2j*np.pi*b*u)[:,None]*S)/(N*M*M)
    return A


def posterior_enumeration(A,y,constellation,noise_variance):
    Q=len(constellation); D=A.shape[1]
    ids=np.indices((Q,)*D).reshape(D,-1).T
    states=np.asarray(constellation)[ids]
    logp=-np.sum(np.abs(y[:,None]-A@states.T)**2,axis=0)/noise_variance
    logp-=logp.max(); p=np.exp(logp); p/=p.sum()
    marg=np.array([[p[ids[:,i]==q].sum() for q in range(Q)] for i in range(D)])
    return marg


def pairwise_log_weight(A,y,states,noise_variance):
    z=A.conj().T@y; G=A.conj().T@A
    # Standard proper-complex likelihood: unary gets 2/v, pair gets -2/v.
    ans=((2*np.real(states.conj()*z)-np.abs(states)**2*np.diag(G).real).sum(axis=1)/noise_variance)
    for i in range(A.shape[1]):
        for j in range(i):
            ans-=2*np.real(np.conj(states[:,i])*G[i,j]*states[:,j])/noise_variance
    return ans


def main():
    N,M,q,b=4,7,1.37,.19
    A=continuous_waveform_projection(N,M,q,b)
    A2=continuous_waveform_projection(N,M,q,b,order=120)
    L=eq14(N,M,q,b)
    P=eq14(N,M,q,b,True)
    F=eq14(N,M,q,b,True,True)
    Q=tx_quadrature_operator(N,M,q,b)
    FL=eq14(N,M,q,b,True,True,endpoint="left_floor")
    unitary=lambda C: float(np.linalg.norm(C.conj().T@C-np.eye(N*M),2))
    edge_sv=np.linalg.svd(P-F,compute_uv=False)
    delay_coordinate=np.repeat(np.arange(M),N)
    gauge=np.exp(-2j*np.pi*delay_coordinate/M)
    gain_gauge=np.exp(-2j*np.pi*q*(M-1)/M)
    gauge_error=float(abs(P-gain_gauge*gauge[:,None]*L*gauge.conj()[None,:]).max())
    jump=eq14(N,M,1+1e-10,b)-eq14(N,M,1,b)
    rng=np.random.default_rng(81219)
    Ac=(rng.normal(size=(3,3))+1j*rng.normal(size=(3,3)))/np.sqrt(6)
    y=rng.normal(size=3)+1j*rng.normal(size=3)
    states=np.array(np.meshgrid(*([[-1,1]]*3))).reshape(3,-1).T
    v=.73
    direct=-np.sum(np.abs(y[:,None]-Ac@states.T)**2,axis=0)/v
    factor=pairwise_log_weight(Ac,y,states,v)
    out={
        'dimensions':[N,M], 'delay_bins':q,'doppler_per_slot':b,
        'direct_quadrature_order_80_vs_120_max_error':float(abs(A-A2).max()),
        'tx_quadrature_vs_physical_sign_finite_floor_max_error':float(abs(Q-FL).max()),
        'tx_quadrature_vs_physical_sign_finite_ceil_max_error':float(abs(Q-F).max()),
        'literal_eq14_unitarity_spectral_error':unitary(L),
        'opposite_delay_sign_gauge_equivalence_max_error':gauge_error,
        'physical_sign_periodic_unitarity_spectral_error':unitary(P),
        'physical_exact_unitarity_spectral_defect':unitary(A),
        'literal_vs_physical_signed_periodic_relative_F':float(np.linalg.norm(L-P)/np.linalg.norm(P)),
        'literal_vs_finite_exact_relative_F':float(np.linalg.norm(L-A)/np.linalg.norm(A)),
        'physical_signed_finite_printed_ceil_vs_exact_relative_F':float(np.linalg.norm(F-A)/np.linalg.norm(A)),
        'physical_signed_finite_left_floor_vs_exact_relative_F':float(np.linalg.norm(FL-A)/np.linalg.norm(A)),
        'periodic_minus_finite_rank':int(np.sum(edge_sv>1e-10)),
        'periodic_minus_finite_nonzero_singular_values':edge_sv[edge_sv>1e-10].tolist(),
        'ceil_jump_relative_F':float(np.linalg.norm(jump)/np.sqrt(N*M)),
        'ceil_jump_relative_F_theory':float(np.sqrt(2/M)),
        'ceil_jump_spectral_norm':float(np.linalg.norm(jump,2)),
        'pairwise_vs_complex_likelihood_centered_max_error':float(np.max(abs((factor-factor[0])-(direct-direct[0])))),
        'zero_channel_uniform_posterior':posterior_enumeration(np.zeros((2,2)),np.ones(2),np.array([-1,1]),1).tolist(),
    }
    assert out['direct_quadrature_order_80_vs_120_max_error']<1e-12
    assert out['tx_quadrature_vs_physical_sign_finite_floor_max_error']<1e-12
    assert out['literal_eq14_unitarity_spectral_error']<1e-12
    assert gauge_error<1e-12
    assert out['periodic_minus_finite_rank']==int(np.ceil(q))
    assert np.allclose(edge_sv[:int(np.ceil(q))],1)
    assert abs(out['ceil_jump_relative_F']-out['ceil_jump_relative_F_theory'])<1e-8
    assert out['pairwise_vs_complex_likelihood_centered_max_error']<1e-12
    dest=Path(__file__).with_name('audit_results.json')
    dest.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))

if __name__=='__main__':
    main()
