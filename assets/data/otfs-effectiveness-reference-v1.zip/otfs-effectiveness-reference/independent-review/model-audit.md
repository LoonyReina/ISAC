# Independent numerical audit: arXiv:1910.01896v1

This audit uses the supplied, fixed v1 source. The source PDF and rendered page are private inputs and must not be redistributed. The equations below are independently derived explanations and checks, not replacements silently attributed to the paper.

## High-impact findings

1. **The literal printed Eq. (14) is not the finite-window physical operator of Eqs. (4)–(9).** There are separable delay-coordinate conventions, sample-endpoint, frame-boundary, and quadrature issues. The delay-sign difference alone is not proof of an irreconcilable typo: the two versions are gauge-equivalent when coordinates and gains are transformed consistently. These should be exposed as model variants, never hidden by replacing Eq. (14) with a generic circular FFT channel.
2. **Each single-path literal Eq. (14) matrix is unitary**, including arbitrary fractional delay/Doppler, but has discontinuities when the printed ceiling changes. Exact finite-window pulse projection is continuous in delay and generally nonunitary.
3. **MP-G has several printed typographical/convention inconsistencies.** The correct pairwise factorization can be calibrated to a proper-complex noise variance explicitly, and verified against exact enumeration on a small system.
4. **The entropy-only Eq. (54) statistic needs calibrated posterior outputs.** A confident incorrect detector can score nearly the constellation ceiling. Label-aware log scores and exact tiny-system checks are essential.

## Independently derived physical operator

Use T = 1, subcarrier spacing = 1, delay a = q/M and Doppler b = νT. Unit-energy rectangular pulses have support [0,1). Use paper column-major stacking: d = k + Nl. Let B_d(t) be the DD synthesis function obtained directly from Eq. (3) and Eq. (4):

B_(k,l)(t) = exp(2πi n k/N) Σ_(m=0)^(M−1) exp(2πi m (t−n−l/M))

for the unique slot n in {0,…,N−1} containing t, and zero outside [0,N). Because h′ = h exp(2πiντ), the physical h for an operator with h′=1 is exp(−2πiba). Consequently,

A_(d,d′) = (NM)^−1 ∫_0^N conjugate(B_d(t)) B_d′(t−a) exp(2πib(t−a)) dt.

The implementation `continuous_waveform_projection` computes this projection using high-order Gauss–Legendre quadrature split at every transmit and receive pulse edge. It does not use ambiguity functions, Eq. (14), or the parent's implementation. At N=4, M=7, q=1.37, b=.19, increasing quadrature order from 80 to 120 changes the operator by at most 1.33e−14.

### Eq. (8) is consistent with this direct derivation

For u=t−n′T−τ, the phase outside the ambiguity integral is

h′ exp(2πiνn′T) exp(−2πimΔfτ),

and the ambiguity arguments are ((n−n′)T−τ, (m−m′)Δf−ν), with the transmit pulse first. These are exactly the structure of Eq. (8).

### Printed discrepancies around Eqs. (11), (13), (15)

- Eq. (11) changes the ambiguity pulse labels and changes the Doppler argument from −ν to +ν, without compensating phase changes. It cannot simultaneously be the direct insertion of Eq. (8).
- The left-hand label in Eq. (13) reverses the pulse order from its right-hand integral. Identical rectangular pulses hide the label issue, but not all sign issues.
- Eq. (15) changes the exponential sign from Eq. (13), starts its sum at zero without the translation phase needed for a positive-delay overlap, and is not a general expression for both signs of the ambiguity delay. It cannot be applied blindly to both ICI and ISI overlaps.
- Pulse normalization must be declared. The disappearance of T in Eq. (15) corresponds to unit-energy rectangular pulses (height 1/sqrt(T)), or an equivalent normalization. Unit-height physical pulses would retain T.

## Separating Eq. (14) from sampled and exact physical models

Define D_Q(z)=Q^−1 Σ_(r=0)^(Q−1) exp(2πirz/Q), evaluated as a stable finite sum or stable Dirichlet kernel, including removable singularities.

The printed Eq. (14) uses D_N(k′−k+bN), D_M(l′−l+q), the phase exp(2πib l′/M), and an extra factor exp(−2πi(k′/N+b)) on the printed ISI branch l′≥M−ceil(q).

### Delay-coordinate convention mismatch and gauge equivalence

Directly discretizing Eq. (8) on the transmit-pulse grid produces D_M(l−l′−q), the conjugate of the printed delay factor. The integer-grid cases do not distinguish these factors because a Dirichlet kernel is 0 or 1 there. Off-grid cases do distinguish them. The exponential in printed Eqs. (24)/(25) also has the physically derived delay sign, differing from Eq. (14) under the same declared coordinates; the sign of the printed Eq. (24) delay derivative itself must still be checked rather than copied.

However, the two delay kernels obey D_M(−z)=exp(−2πi(M−1)z/M)D_M(z). For exactly the same branch mask, set R_(k,l)=exp(−2πil/M) and c(q)=exp(−2πiq(M−1)/M). Then Ψ_minus=c(q) R Ψ_literal R^H. An independent numerical check confirms this identity within 3.0e−15. The sign difference is therefore a coordinate-convention mismatch, not sufficient standalone proof of a physically inequivalent channel or an irreconcilable source typo. To maintain the same physical model, transform x_minus=R x_literal, y_minus=R y_literal, and h_minus=h_literal/c(q). The fixed Eqs. (3)–(9) coordinates still require this transformation; merely switching the operator while holding x, y, and gains fixed changes the forward map. Circular complex Gaussian noise is invariant under R. A fixed shared QAM constellation generally needs its per-coordinate rotations accounted for. This gauge equivalence does not remove the frame-edge or ceiling/floor discrepancies.

### Endpoint issue

For the literal left-endpoint grid in Eq. (13), u=i/M. The ICI condition is i/M+a<1 and the ISI condition is i/M+a≥1. For noninteger q this means ISI i≥M−floor(q), not M−ceil(q). At integer q they agree. An endpoint convention has zero effect on the continuous integral but can change this finite quadrature by a whole sample. The code keeps `printed_ceil` and `left_floor` explicit.

At the representative dimensions above, independent transmit-grid waveform projection and the physically signed finite operator with `left_floor` agree to 2.70e−15. Substituting the printed ceiling instead gives a maximum entry error of 1.286. Thus a mere sign correction is insufficient to identify Eq. (14) with the stated quadrature.

### Finite-frame issue

For ICI, the n sum includes n=0,…,N−1. For ISI, a finite isolated frame with n′≥0 only includes n=1,…,N−1. Hence its Doppler factor is D_N(k′−k+bN)−1/N, followed by the usual preceding-slot phase. Eq. (14) retains the full D_N also on the ISI branch, effectively adding a predecessor at n′=−1 using a periodically extended transmitted frame. Such an extension/CP assumption is absent from the finite sums in Eq. (7).

For either chosen endpoint convention, the periodic physically signed sampled operator minus its finite counterpart has rank equal to the number of ISI delay columns, with each nonzero singular value equal to one. For the printed ceiling in the example, its rank is 2 and singular values are (1,1). This isolates a frame-boundary effect from the separate delay-coordinate convention.

### Unitarity and discontinuity

The two complete Dirichlet factors form unitary circulant matrices; all remaining phases multiply input columns by unit-modulus values. Thus the literal Eq. (14) operator is unitary. At an integer q=j, moving from q=j to q=j+epsilon changes the branch of one input-delay group. For N>1 the limit of the relative Frobenius jump is sqrt(2/M), independent of b. The spectral jump is max_(k′) |exp(−2πi(k′/N+b))−1| and can approach 2. This discontinuity does not vanish as epsilon goes to zero.

In the N=4, M=7 example the relative jump is 0.53452248 and spectral jump is 1.9645745. Literal Eq. (14) unitarity error is 2.92e−15; the exact finite physical operator has a largest eigenvalue defect of about 1 because some time-concentrated inputs have almost all their energy in the discarded tail. This does not imply its average energy loss is one.

The physical exact model additionally includes finite-band projection effects absent from the M-point sampled model. Therefore even the physically signed finite sampled model need not equal the continuous integral. A sequence with large M alone does not justify every quadrature use uniformly: the highest subcarrier differences also grow with M.

## Continuous ML: Eqs. (19)–(21)

- For trial parameters form columns a_p=Ψ_p x, solve least squares for h′ using QR/SVD or a guarded Hermitian solve, and evaluate the residual. Avoid explicitly inverting the Gram matrix, especially for close paths.
- For P=1 the variable-projected objective is |a^H y|²/(a^H a); h′=(a^H y)/(a^H a). This is exact under the chosen matrix model and proper-complex Gaussian noise. If a is unitary-model output, its energy is fixed; do not assume this under the finite physical model.
- The aggregate expression Eq. (20) is real when Eq. (19) holds, but an individual interference term I_p is generally complex. Eq. (21)'s maximization therefore needs an explicit real-part convention or a separately derived real residual objective. The paper does not specify that resolution.
- Initializing every h′ to zero makes every path maximize the same useful-signal objective on the first pass, so all paths can select the same peak. Distinct-peak initialization or deflation is an added implementation choice that must be labeled.
- Coordinate descent on a profiled residual is a defensible alternative but is not automatically the printed Eq. (21) algorithm. Residual-based path re-estimation includes an interference-squared term not present in a naively separated Eq. (20) term.
- A fine grid only produces grid ML. Continuous refinement is additional. For the literal ceiling model the objective has discontinuities at integer delays; optimize within cells and explicitly test integer boundaries/one-sided limits. Generic smooth gradient optimization across boundaries can fail.
- The parameters in the matrix model are effective gains h′; physical h differs by the delay-Doppler phase. For radar range/velocity reporting, round-trip τ=2r/c and ν=2v fc/c are distinct from communication's one-way conversions.

## MP-G: likelihood and indexing audit

Let v=E|w_i|² be the proper-complex noise variance. The normalized likelihood is proportional to exp(−||y−Ax||²/v). Define z=A^H y and G=A^H A. Correct factors are

log F_i(x_i) = [2 Re(conj(x_i) z_i) − G_ii |x_i|²]/v

log I_ij(x_i,x_j) = −2 Re(conj(x_i) G_ij x_j)/v.

The independent code checks that these factors reproduce the direct residual log likelihood up to a constant to 1.1e−14.

Printed problems and faithful resolutions:

- Eq. (12) calls σ_w² the complex covariance, but Eqs. (36), (39), (40) behave as if σ_w² were the variance of each real component, i.e. v=2σ_w². Declare the convention and map it explicitly; otherwise curves shift by 3.0103 dB.
- Eq. (36)'s displayed normalizing power is also wrong; it is irrelevant only when likelihoods are used proportionally. For v=E|w|², the correct complex density constant is (πv)^(-NM).
- Eq. (38) prints x^H G z instead of x^H G x. Resolve from Eq. (37).
- Eq. (42)'s incoming message must be a function of x_i, not x_j.
- Eq. (44) requires the opposite directed cavity message, μ_(j→i)(x_j), not the same-direction μ_(i→j). Track directed edges explicitly.
- Eq. (46) elsewhere drops the minus sign in a Gaussian residual exponent; a positive exponent is not a valid likelihood.
- Implement message updates with log-sum-exp, explicit normalization, and prior factors. A damping choice, pruning threshold, iteration count, or stopping criterion is an implementation choice, not specified by Eqs. (36)–(44).
- Exact factor-node summation is exact locally, but loopy BP marginals remain approximate. A dense Gram graph can be poorly behaved even though the bipartite factor graph has no 4-cycle.
- Computing one output-message value costs O(Q), but producing a full Q-component message costs O(Q²) in a generic pairwise potential. Sparsity and parallel hardware alter practical cost, not that generic arithmetic count.

## Marginal and capacity validation

Required minimum checks:

1. Zero channel / no information gives the supplied prior, uniform if no prior is supplied.
2. A diagonal Gram matrix makes every marginal exactly its scalar Gaussian posterior.
3. A two-variable model, or tree-structured Gram graph realized by a positive-definite matrix, matches exact enumeration after messages have propagated across the graph.
4. A small loopy model is compared to enumeration without demanding universal exact equality; report marginal error and log loss.
5. Verify that generated proper-complex noise has E|w|²=v and each real component has variance v/2.
6. Report BER/SER and a label-aware score alongside the paper's entropy-only quantity.

The statistic log2(Q)−mean H(q_i) is mutual information only when q_i is the calibrated posterior of X_i conditional on the reported detector statistic. Loopy BP, pruning, nominal-channel mismatch, or noise normalization can break that condition. A useful label-aware auxiliary score is log2(Q)+mean log2 q_i(x_i,true), which equals actual information minus a posterior KL penalty and can legitimately be negative. Clipping it hides miscalibration. Optional temperature calibration must use separate calibration data and normalize the transformed probabilities before evaluating held-out data.

A binary detector always reporting (0.999,0.001), independent of balanced ground-truth symbols, yields an entropy-only score of about 0.9886 bit, but its true information is zero and its label-aware score is about −3.9843 bits. Thus Eq. (54) alone cannot establish good detector performance.

## Runnable deliverable

Run:

`python independent-review/independent_audit.py`

It writes `independent-review/audit_results.json` and checks direct continuous projection convergence, the left-endpoint sampled physical formula, literal unitarity, frame-edge rank, ceiling discontinuity, pairwise likelihood factorization, and the zero-channel marginal.

These are representative small-system verification results, not a reproduction of the paper's publication-scale plots.

## Black-box review of the parent implementation

`review_parent.py` independently checks `otfs_reference.py`; its JSON records the exact SHA-256 of the reviewed file. On the reviewed version all strict checks pass:

- Direct waveform integration versus `exact_rect_operator`: maximum error 3.21e−15 across five cases, including zero delay, integer/fractional delay, negative Doppler, a one-sample system, and delay near the slot length
- Independent literal Eq. (14) formula versus implementation: maximum error 6.76e−16
- MP-G versus independently enumerated posterior: error below 2.23e−16 for diagonal, two-variable, and complex-valued chain-tree graphs
- Diagonal MP-Psi and calibrated LMMSE posteriors: agree with enumeration below 4.45e−16
- All three detectors: exactly uniform outputs for a zero channel
- Generated noise at target complex variance 0.7: measured 0.70342 across 200,000 samples, with real and imaginary variances approximately 0.3516 and 0.3518
- Noiseless single-path ML: fractional literal, integer literal, zero-delay literal, and fractional physical-model cases recover delay/Doppler within 6.2e−9 and effective gain within 1.1e−8
- A representative converged loopy MP-G graph has maximum marginal error 0.01175, as expected for approximate global inference

Receiver APIs do not accept ground-truth symbols; truth is isolated in the metric scorer. This is appropriate. The independent checks are not a guarantee of global optimization, universal BP convergence, or full publication-scale reproduction.

### MP-Psi comparator source audit

The supplied comparator source is arXiv:1802.05242v2, Eqs. (35)–(41). The parent's means, variances, Gaussian likelihood, cavity update, and damping implement those recursions. The source's Eq. (40) needs final normalization across symbols after multiplication, which the code correctly performs. Differences that must remain explicit:

- Eq. (41) updates the hard decision on a confidence increase relative to the previous iteration. The initial reviewed code retained soft output at the highest confidence ever seen, preserving the first posterior on ties. These differ after a confidence dip and partial rebound. The current code explicitly exposes retention alternatives; see the final review below.
- The source returns hard decisions, so returning a particular iteration's probability vector is a soft-output extension, not completely prescribed by that source.
- Strict-best ties at low confidence can retain the first iteration even while later probabilities change. This can affect low-SNR soft scores and must not be mistaken for posterior convergence. The current default uses the latest tied posterior to avoid this stale-output behavior.
- The threshold comparison is printed inclusive (≥). The initial code used strict >; the current code uses ≥ and matches the source.

### Single-path consequence for communication comparisons

For a single literal Eq. (14) path, G=|h′|²I, so MP-G has no pairwise edges and is the scalar AWGN posterior after a unitary transform. Calibrated full LMMSE soft outputs give exactly the same posterior. Any observed separation between those single-path curves requires a different model, soft-output approximation, or other implementation detail; it cannot follow from this literal operator alone.

### Additional local-derivative transcription warnings

Printed Eq. (24) combines the physical negative-delay exponential with a positive delay-derivative prefactor. Differentiating that exponential gives a negative prefactor; differentiating literal Eq. (14) gives the printed positive prefactor but the opposite exponential. It is internally mixed. Printed Eq. (25) labels both case branches as ISI; the branch without the preceding-slot correction should be ICI. Away from ceiling boundaries, differentiate the explicitly selected implemented operator rather than copying these mixed formulas. At literal delay boundaries a conventional differentiable-model CRLB does not apply.

## Second-pass multipath and coordinate review

The gauge identity above was independently cross-checked and added as a strict runnable assertion. It changes the interpretation of the sign discrepancy: it is a mismatch under the fixed printed coordinates that can be resolved by a known coordinate and gain transformation, not by itself proof of a physically distinct channel.

The added `multipath_eq21` implementation correctly forms I_p, uses old-iteration parameters for every path update, and solves Eq. (19) after the round. An independent scalar-loop contraction reproduces both iterations of a representative example exactly in selected grid coordinates, and reproduces their residuals within 1.2e−16. The source-zero option correctly selects identical first peaks and reports a singular gain system.

The distinctly initialized Re(I) adaptation is not a joint-ML solver, even on noiseless grid-aligned data. A stored counterexample uses N=4, M=6 with two true paths (q,a)=(0.6,−0.5) and (2.2,0.75). Both are on the searched grid. The adapted algorithm becomes grid-stationary at (0.6,−0.5) and (2.3,0.75), with residual 0.2625613; fitting gains at the true grid coordinates gives residual 5.95e−30. This is not a coding failure of the stated iteration. It establishes why its result must be called an approximate, interpretation-dependent multipath iteration rather than exact multipath ML.

The final review verifies that zero-energy waveforms, noninteger path counts, zero iteration budgets, and undersized grids are explicitly rejected. The fixed 0.5-bin peak-separation choice remains an added initialization hyperparameter and should stay documented.


## Final review after MP-Psi soft-output correction

Reviewed core SHA-256: `92b997201493a3187b5ddb37026672ef44e163131e422bdf8618f11b17aa235f`. The source hash was checked again at the end of the test run and was unchanged. All earlier waveform, marginal, noise, ML, gauge, and multipath assertions still pass.

The MP-Psi API now explicitly offers `best-confidence-latest-tie` (default), `strict-best-confidence`, and `last`. This is an appropriate explicit treatment of the source's underspecified soft-output retention. The default does not mislabel a zero-confidence plateau as converged and avoids retaining stale first-iteration probabilities.

A deterministic independent test uses a dense complex 3×3 channel, QPSK, proper-complex noise variance 2, and five iterations. Every confidence fraction stays zero. Results:

- Default latest-tie output equals `last` exactly
- Strict-best output equals the first iteration exactly
- Default final probabilities match a separate scalar-loop Gaussian-MP recursion to 1.12e−16
- Default versus strict-best probabilities differ by up to 0.09963423

The counterexample and full initial/final probability arrays are saved in `parent_review_results.json`. It demonstrates a material soft-output choice, not a universal performance claim about which iteration is optimal. Keeping the original strict-best experiment as a labeled historical/sensitivity output and rerunning comparisons with the documented default is appropriate.

## Saved experiment outputs: independent final audit

`review_saved_results.py` recomputes aggregate checks and selected held-input calculations without rerunning the Monte Carlo sweep or radar optimizers. `saved_results_review.json` records the frozen core hash and SHA-256 hashes of all audited result inputs.

### Counts and retained failures

- Communication: 3,072 detector-method rows, representing 768 held observations and 64 summary groups; each group contains 48 frames / 576 symbols
- MP-G: 717 converged, 51 iteration-cap outcomes
- Full-CSI MP-Psi: 181 confidence-converged, 587 iteration-cap outcomes
- Rounded-delay MP-Psi: 96 confidence-converged, 654 iteration-cap outcomes, 18 confidence drops
- LMMSE: all 768 linear systems solved
- Radar: all 288 trials retained, including five selected optimizer-failed fits
- Radar search additionally records 65 failed local candidates across 59 trials; these are distinct from failure of the final selected candidate
- Radar threshold failures: 43 of 48 at −20 dB, 25 of 48 at −10 dB, and zero at 0/10/20/30 dB

Every communication mean and frame-level standard error agrees with independent recomputation within 7.2e−15; every radar RMSE and failure count agrees exactly. Single-path MP-G versus calibrated LMMSE metrics agree within 4.45e−15 as required by literal-model unitarity. Negative truth log scores remain present, down to approximately −191.17 bits in a severely mismatched sample; they are a log-score diagnostic, not negative mutual information.

### Held-input policy comparison

All eight saved cases contain explicit H, y, constellation, and complex noise variance. Replaying all three policy outputs matches saved probabilities exactly, and the default-policy metrics match the corresponding communication sweep rows within 8.9e−16. Two selected cases also match an independent scalar-loop Gaussian-MP recurrence within 5.2e−15.

The strict versus latest-tie policies change 2–8 of the 12 hard decisions in seven cases, and zero in the eighth. The independently audited Eq. (41) local-improvement decision history is null in the first seven cases under the explicitly documented initial-confidence assumption η(0)=0. This correctly exposes the source's unspecified hard-decision initialization rather than substituting a soft-policy decision and calling it exact Eq. (41). All three policies retain identical message-iteration counts and stopping statuses on these held inputs.

### Original-setting analytical rates

All eleven checkpoints agree exactly with the fixed source's Eqs. (52)/(53) and Table I: N=50, M=64, T=6.4 microseconds, B=10 MHz, T_GI=T/4. The OTFS overhead factor is 50/50.25 and OFDM's is 0.8. These are original-setting analytical Gaussian-input checkpoints under the single-path unitary model. They are not a full figure reproduction, a common-total-duration comparison, or finite-code throughput measurements.

### Cross-model and CRB interpretation

Every saved cross-model residual was independently recomputed from the fixed seed's reconstructed x/y and saved fit. Matched noiseless models have relative residuals near 2e−8; fixed-coordinate mismatches have residuals approximately 0.58–0.75. The opposite-delay-sign comparison holds x/y fixed and does not apply the gauge transformation, so it demonstrates coordinate misuse under that held observation, not physical inequivalence after a correct transformation.

At 30 dB, the saved delay/Doppler MSEs are approximately (4.199e−6, 2.085e−6), below the mean local CRB variances (5.295e−6, 5.163e−6). A separate real-valued linearized least-squares calculation, using exactly the saved waveforms and noise draws, predicts (4.181e−6, 2.077e−6). Thus this audit identified no factor-of-two or variance-scaling bug. The fixed small sample is unusually favorable: the sum of joint CRB-normalized linearized errors is 58.82, compared with 96 expected under the local Gaussian reference, with lower-tail probability about 0.001. Reusing the same draws across SNR propagates that favorable sample to multiple high-SNR points. This exploratory diagnostic is a reason to avoid claiming CRB beating or statistical equality to the bound from this 48-trial-per-SNR sweep, not a reason to remove trials or tune replacement seeds.

### Audited fixed-plan holdout addendum

The separate 30 dB holdout contains all 256 planned trials: 253 converged and three optimizer-failed fits, all retained. Trial IDs and spawn keys cover 0–255 exactly. SeedSequence entropy 906221 reproduces 256 unique states; those states and regenerated waveform/noise fingerprints are disjoint from the primary 48 trials. Every saved residual and CRB covariance reproduces exactly without rerunning optimization. The declared fixed plan and script contain no early-stopping or seed-replacement branch.

Recomputed delay/Doppler RMSEs are 0.00236633 / 0.00243751 bins, versus square-root mean CRB variances 0.00228259 / 0.00228009. A paired-frame percentile bootstrap with 10,000 resamples, audit seed 20261012, gives 95% RMSE intervals [0.00214555, 0.00258205] / [0.00222238, 0.00264668]. The corresponding RMSE-to-root-CRB ratio intervals are [0.9413, 1.1316] / [0.9751, 1.1604]; both include one.

The normalized quadratic-error sum independently recomputes to 577.1053 for 512 asymptotic degrees of freedom, CDF 0.975855. These are diagnostic uncertainty statements, not a requirement that an empirical sample exceed the CRB or proof of unbiasedness/global ML. Both the original sample and this disjoint fixed-size holdout remain unchanged and separately labeled. The final saved review includes the holdout input hash and bootstrap results; no further expansion is part of this audit.
