# OTFS effectiveness: independently checked bounded reference

Fixed source: [arXiv:1910.01896v1](https://arxiv.org/pdf/1910.01896v1). This package implements real OTFS channel operators, gain-profile sensing, Gram-factor message passing and matched comparison receivers. It is not a generic FFT range–Doppler substitute, a website integration or a claim to reproduce every original figure.

## Start here

1. `SUMMARY.md`: numerical outcomes, failures and gate status
2. `SOURCE-AUDIT.md`: source hashes, exact equation map, models/conventions and unresolved choices
3. `otfs_reference.py`: numerical core, receiver information boundaries and explicit statuses
4. `independent-review/model-audit.md` and `second-review/JUDGEMENT.md`: two independent audits, direct waveform integration, independent posterior checks and alternative-convention resolution
5. `LIVE-SCOPE-HANDOFF.md`: proposed bounded port scope and uncompleted runtime gates

## Reproduce

Python 3.12, NumPy 2.3.5 and SciPy 1.17.0 were used. Core dependencies are in `requirements.txt`; plotting additionally uses Matplotlib 3.10.8.

```sh
export OPENBLAS_NUM_THREADS=1
python -m unittest -v test_reference.py
python independent-review/independent_audit.py
python independent-review/review_parent.py
python second-review/probe_conventions.py
python run_experiments.py --trials 48
python compare_psi_policies.py
python holdout_crb_check.py
python summarize_uncertainty.py
python benchmark_search.py
python benchmark_compute.py
python check_results.py
python independent-review/review_saved_results.py
python plot_results.py  # optional plots
```

The default sweeps are deliberately small and still take minutes. Fine-grid timing and larger dense message-passing profiling take additional minutes. Original source-size Monte Carlo is not hidden inside these commands.

The initial strict-best MP-Psi result is retained separately in `historical-strict-best-output/`. Rerunning the default sweep creates the final latest-tie-policy result; it does not silently overwrite that history. Policy sensitivity saves complete H/y/constellation/noise-variance inputs and true data in a separate evaluation section.

`run_all.sh` covers the core, experiments and main validation. `check_results.py` verifies saved row counts, all-outcome aggregates, source rate identities and the P=1 matched-posterior equality. Each independent review can run without reading the source PDF.

## Model IDs

- `eq14_literal`: exactly the printed Eq14/16 finite-sum expression; continuous delay/Doppler arguments, ICI/ISI branches and ceiling retained. A consistent sampled-cyclic convention is independently established
- `exact_rect_finite`: exact finite-window continuous rectangular-pulse projection derived from Eq3–9, with zero prehistory and no hidden tail folding
- `eq14_negative_delay_cyclic`: diagnostic sign-only variant; not a replacement physical model or a live-selector recommendation

These operators are not silently equated. Frame stacking, h′ gain phase and complex noise convention are explicit. Simulation truth is not an input to any receiver.

## Sharing

Use the explicit `DELIVERY-MANIFEST.json` allowlist or the generated reference archive. Never add private PDFs, extracted source text, source-page screenshots, cache directories or temporary files to a public package. The reference archive contains original code, original computed data/plots and source citations only.
