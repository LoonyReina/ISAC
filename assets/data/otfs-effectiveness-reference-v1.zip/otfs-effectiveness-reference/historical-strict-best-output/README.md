# Preserved initial experiment

The first 48-frame-per-cell communication run used strict best-confidence
soft-output retention in the MP-Psi adaptation. At low SNR, the fraction of
symbols above the .99 confidence threshold can remain zero for many iterations.
Strict retention then leaves first-iteration marginals, even when later messages
improve. Independent review identified this as a consequential adaptation choice,
not a well-specified soft-output rule from Raviteja's hard-decision algorithm.

The final run explicitly uses best-confidence/latest-tie retention and labels it.
Current `mp_psi(..., soft_output_retention="strict-best-confidence")` exposes the
earlier retention behavior for sensitivity checks. Earlier raw outcomes are
preserved here rather than dropped. The reviewed initial core hash was
ff95b86964a41d922cb3650fe1d8d54f9c76497bc82c9eae6e0c30137cc907b5.

These are historical results, not the accepted default comparison. Do not use
their weaker MP-Psi curve to infer an unconditional MP-G performance advantage.
