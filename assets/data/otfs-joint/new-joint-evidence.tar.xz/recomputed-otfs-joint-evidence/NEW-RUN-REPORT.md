# NEW OTFS recovery recomputation

Status: numerical recomputation completed and independently ACCEPTED as new finite evidence. This is not recovery of the original lost raw archive.

Exactly 2100 frozen frames, 6300 method rows, 66 cell/method groups and 44 paired summaries. New main time 537.017s; peak RSS 61736KiB. NumPy2.3.5/SciPy1.17.0; BLAS/OMP1. Source, test, dependency, runner and contract match all five original hashes;28 tiny gates passed before the run.

Historical aggregate comparisons: 91 checked, all match=True. This corroborates reported aggregate history only. Original full raw rows/archive remain unavailable; no original-byte identity is claimed for any regenerated output.

## New per-cell all-path recovery

|Scene|SNR|Joint|Sequential|
|---|---:|---:|---:|
|well_separated|0|38/100|33/100|
|well_separated|5|85/100|78/100|
|well_separated|10|100/100|100/100|
|well_separated|15|100/100|100/100|
|well_separated|20|100/100|100/100|
|close_delay|0|0/100|0/100|
|close_delay|5|0/100|0/100|
|close_delay|10|1/100|0/100|
|close_delay|15|1/100|0/100|
|close_delay|20|6/100|0/100|
|close_doppler|0|0/100|0/100|
|close_doppler|5|0/100|0/100|
|close_doppler|10|2/100|0/100|
|close_doppler|15|4/100|0/100|
|close_doppler|20|9/100|0/100|
|unequal_amplitudes|0|3/100|7/100|
|unequal_amplitudes|5|1/100|10/100|
|unequal_amplitudes|10|0/100|32/100|
|unequal_amplitudes|15|0/100|73/100|
|unequal_amplitudes|20|0/100|98/100|
|three_path_stress|5|7/50|1/50|
|three_path_stress|15|50/50|0/50|

## New status and timing accounting

- joint_known_P: available 2100/2100; attempts 8400; optimizer status {'CONVERGENCE: RELATIVE REDUCTION OF F <= FACTR*EPSMCH': 4246, 'CONVERGENCE: NORM OF PROJECTED GRADIENT <= PGTOL': 3859, 'ABNORMAL: ': 275, 'STOP: TOTAL NO. OF ITERATIONS REACHED LIMIT': 20}; rejected candidate evaluations {'rank_deficient': 240, 'ls_numerical_failure': 128, 'ill_conditioned': 22}; selected optimizer-nonsuccess 47; total 450.923s, mean 0.214725s/frame
- single_target_shared_grid: available 2100/2100; attempts 8400; optimizer status {'0': 8346, '2': 54}; rejected candidate evaluations {}; selected optimizer-nonsuccess 42; total 25.940s, mean 0.012352s/frame
- sequential_cancellation_known_P: available 2100/2100; attempts 17200; optimizer status {'0': 17071, '2': 129}; rejected candidate evaluations {}; selected optimizer-nonsuccess stage-specific; total 56.221s, mean 0.026772s/frame

All failures/caps/abnormal and condition outcomes remain in the data. Available, conditioned and accurately recovered are different properties. Selected optimizer-nonsuccess estimates are finite numerical estimates, not certified stationary/converged. Methods have unequal computational work.

The weak-path failure is preserved: in unequal-amplitude high-SNR frames, initializations confined to the first delay cell cannot reach weak delay1.45. No initialization repair, scene change, added starts, seed replacement or post-outcome tuning was performed. The P1 baseline inherently cannot achieve all-path success for true P>1; use its conditional and unrestricted errors with explicit denominators.

Source scope: project joint variable projection from arXiv:1910.01896v1 likelihood Eqs17–19, not literal Eq21 and not Eq26 (waterfall MSE bound). Known P, literal-Eq14 pulse caveat, tiny8×8 domain, finite four-start/cell-limited search; no full-source curves, unknown-order model, physical data or global-optimum claim.

## New output identity

Decoded records SHA256 bbc6229195c65190e707ef6398bb33b96e035cc420b8977c80e99a3db916e36f
xz file SHA256 9832ac92c33f31999d82d830e15aa167c4b8cd930e83d7f4fa7ff11115cdee6f
xz bytes 4356684; raw replay bytes 54547

Full records retain every result/attempt/diagnostic/history and exact seeds. Raw replay stores22 scene/SNR frame0 panels. SUMMARY.json retains Wilson intervals, matched and unrestricted RMSE, and44 paired whole-frame bootstrap summaries. NEW-HISTORICAL-COMPARISON.json records all comparisons and any differences without filtering. Independent new-output acceptance is recorded in NEW-INDEPENDENT-ACCEPTANCE.md; it does not imply original archive recovery.


## New independent acceptance

/workspace/shared/recovery/otfs-independent/NEW-INDEPENDENT-ACCEPTANCE.md verifies all2100frames/6300records/66groups/44paired summaries/22raw panels,15 actual estimator replays and additional300/2300-support SVD enumerations of selected initialization supports. Checker provenance is explicitly recreated after reset; implementation sources retain their five original hashes. This new reviewed evidence preserves all negative findings and all solver/conditioning failures.
