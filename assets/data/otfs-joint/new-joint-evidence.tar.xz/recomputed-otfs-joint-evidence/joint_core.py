"""Project joint variable projection; source Eq17–19 objective, NOT Eq21/Eq26."""
from itertools import combinations
from pathlib import Path
import importlib.util
import math
import numpy as np
from scipy.linalg import qr, solve_triangular
from scipy.optimize import minimize
BASE=Path('/workspace/shared/isac-paper-execution/otfs-continuous-estimation-20261017/otfs_core.py')
spec=importlib.util.spec_from_file_location('accepted_otfs',BASE)
accepted=importlib.util.module_from_spec(spec); spec.loader.exec_module(accepted)
LiteralOTFS=accepted.LiteralOTFS
VERSION='joint-qr-variable-projection-v1'
RANK_RTOL=1e-10
MAX_CONDITION=1e8
MAX_NORMAL_DEFECT=1e-10

def joint_profile(y,U,rtol=RANK_RTOL):
    y=np.asarray(y,complex);U=np.asarray(U,complex)
    if U.ndim!=2 or y.shape!=(U.shape[0],) or not 1<=U.shape[1]<=3 or not np.isfinite(U).all() or not np.isfinite(y).all():
        raise ValueError('finite observation and one to three matching columns required')
    if not np.isfinite(rtol) or not 0<rtol<1: raise ValueError('rank tolerance')
    Q,R,piv=qr(U,mode='economic',pivoting=True)
    diagonal=np.abs(np.diag(R)); scale=diagonal.max(initial=0.)
    rank=int(np.count_nonzero(diagonal>rtol*scale)) if scale>0 else 0
    if rank<U.shape[1]:
        return {'ok':False,'status':'rank_deficient','rank':rank,'rank_rtol':rtol,'qr_diagonal':diagonal,'h':None,'residual':None}
    singular_values=np.linalg.svd(U,compute_uv=False)
    condition=float(singular_values[0]/singular_values[-1])
    diagnostics={'condition':condition,'max_condition':MAX_CONDITION,'qr_diagonal':diagonal,'rank':rank,'rank_rtol':rtol}
    if not np.isfinite(condition) or condition>MAX_CONDITION:
        return {**diagnostics,'ok':False,'status':'ill_conditioned','h':None,'residual':None}
    hp=solve_triangular(R,Q.conj().T@y)
    h=np.empty(U.shape[1],complex);h[piv]=hp
    r=y-U@h; residual=float(np.vdot(r,r).real)
    normal_defect=float(np.linalg.norm(U.conj().T@r)/max(singular_values[0]*np.linalg.norm(y),np.finfo(float).tiny))
    diagnostics.update({'scaled_normal_defect':normal_defect,'max_normal_defect':MAX_NORMAL_DEFECT})
    if not np.isfinite(residual) or not np.isfinite(normal_defect) or normal_defect>MAX_NORMAL_DEFECT:
        return {**diagnostics,'ok':False,'status':'ls_numerical_failure','h':None,'residual':None}
    return {**diagnostics,'ok':True,'status':'full_rank_conditioned','rank':rank,'rank_rtol':rtol,'qr_diagonal':diagonal,'h':h,'r':r,'residual':residual,'score':float(np.vdot(y,y).real-residual)}

def evaluate(model,y,theta,gradient=False):
    theta=np.asarray(theta,float).reshape(-1,2)
    if gradient:
        actions=[model.action(*t,True) for t in theta]; U=np.column_stack([v[0] for v in actions])
    else: U=np.column_stack([model.action(*t) for t in theta])
    out=joint_profile(y,U)
    if out['ok'] and gradient:
        out['gradient']=np.array([-2*np.real(np.vdot(out['r'],out['h'][p]*actions[p][k])) for p in range(len(theta)) for k in (1,2)])
    return out

def grid_supports(model,y,grid,P,limit=4):
    """Truth-blind finite support seed selection, exhaustive only for bounded grids."""
    if P not in (1,2,3) or not 1<=limit<=32: raise ValueError('P/limit')
    grid=np.asarray(grid,float)
    if grid.ndim!=2 or grid.shape[1]!=2 or len(grid)<P or not np.isfinite(grid).all() or np.any(grid[:,0]<0) or np.any(grid[:,0]>2) or np.any(grid[:,0]>=model.M) or np.any(abs(grid[:,1])>1):
        raise ValueError('public grid needs at least P finite points with q in [0,2], q<M and a in [-1,1]')
    U=np.column_stack([model.action(*t) for t in grid])
    candidates=[]; failed=0; failures={}
    for ids in combinations(range(len(grid)),P):
        out=joint_profile(y,U[:,ids])
        if not out['ok']:
            failed+=1;failures[out['status']]=failures.get(out['status'],0)+1;continue
        candidates.append((out['residual'],ids))
    candidates.sort(key=lambda c:(c[0],c[1]))
    return [grid[list(ids)].copy() for _,ids in candidates[:limit]], {'support_count':math.comb(len(grid),P),'rejected_supports':failed,'failure_counts':failures,'best_grid_residual':candidates[0][0] if candidates else None}

def fit(model,y,grid,P,starts=4,maxiter=120):
    """Known P; observation-derived starts; smooth refinement stays in initial open cells.
    Full grid supports retained as baseline including exact cell boundaries.
    Every objective evaluation jointly fits all complex gains using pivoted QR.
    """
    if not isinstance(maxiter,int) or not 0<=maxiter<=1000:raise ValueError('maxiter')
    seeds,grid_status=grid_supports(model,y,grid,P,starts)
    best=None; attempts=[]
    for initial in seeds:
        baseline=evaluate(model,y,initial)
        if best is None or baseline['residual']<best['residual']:
            best={**baseline,'theta':initial.copy(),'origin':'grid'}
        if maxiter==0:
            attempts.append({'status':'iteration_limit_zero_budget','code':1,'success':False,'iterations':0,'evaluations':0,'rank_failures':0,'initial':initial.tolist(),'theta':initial.tolist(),'accepted_residuals':[],'residual':baseline['residual']})
            continue
        bounds=[]
        for q,a in initial:
            cell=max(0,math.ceil(q)-1)
            bounds.extend([(cell+1e-8,min(cell+1-1e-8,model.M-1e-8,2.)),(-1.,1.)])
        x0=np.array([np.clip(v,*b) for v,b in zip(initial.ravel(),bounds)])
        seen=[];rank_failures=0; evaluation_failures={}
        objective_scale=max(float(np.vdot(y,y).real),1.)
        def objective(t):
            nonlocal rank_failures
            out=evaluate(model,y,t,True)
            if not out['ok']:
                rank_failures+=int(out['status']=='rank_deficient')
                evaluation_failures[out['status']]=evaluation_failures.get(out['status'],0)+1
                return 1e6,np.zeros_like(t)
            return out['residual']/objective_scale,out['gradient']/objective_scale
        start_eval=evaluate(model,y,x0)
        if not start_eval['ok']:
            attempts.append({'status':start_eval['status']+'_start','success':False,'rank_failures':int(start_eval['status']=='rank_deficient'),'evaluation_failure_counts':{start_eval['status']:1},'initial':initial.tolist()});continue
        seen.append(start_eval['residual'])
        def callback(t):
            out=evaluate(model,y,t)
            if out['ok']:seen.append(out['residual'])
        opt=minimize(objective,x0,jac=True,bounds=bounds,method='L-BFGS-B',callback=callback,options={'maxiter':maxiter,'maxls':30,'ftol':1e-14,'gtol':1e-9})
        final=evaluate(model,y,opt.x)
        attempts.append({'status':str(opt.message),'code':int(opt.status),'success':bool(opt.success),'iterations':int(opt.nit),'evaluations':int(opt.nfev),'rank_failures':rank_failures,'evaluation_failure_counts':evaluation_failures,'initial':initial.tolist(),'theta':opt.x.reshape(P,2).tolist(),'accepted_residuals':seen,'residual':final['residual']})
        if final['ok'] and final['residual']<best['residual']:
            best={**final,'theta':opt.x.reshape(P,2),'origin':'continuous','solver_success':bool(opt.success)}
    return {'status':'available' if best is not None else 'no_identifiable_support','best':best,'attempts':attempts,'grid_status':grid_status,'method':VERSION}
