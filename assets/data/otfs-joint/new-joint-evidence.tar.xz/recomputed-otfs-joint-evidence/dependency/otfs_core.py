"""P=1 literal Eq14, fixed cyclic numerical convention; no physical equivalence claim."""
import math
import numpy as np
from scipy.optimize import minimize
TAU=2*np.pi

class LiteralOTFS:
    def __init__(self,x):
        x=np.asarray(x)
        if x.ndim!=2 or min(x.shape)<2 or not np.isfinite(x).all() or not np.any(x):
            raise ValueError('finite nonzero N by M known signal required')
        self.x=x.astype(complex); self.N,self.M=x.shape
        if max(x.shape)>64: raise ValueError('bounded dimensions <=64')
        N,M=self.N,self.M
        self.dk=np.arange(N)[None,:]-np.arange(N)[:,None]
        self.dl=np.arange(M)[None,:]-np.arange(M)[:,None]
    def action(self,q,a,derivatives=False):
        N,M=self.N,self.M
        if not np.isfinite([q,a]).all() or not 0<=q<M or not abs(a)<N:
            raise ValueError('require 0<=q<M and |a|<N')
        if derivatives and q==math.floor(q):
            raise ValueError('delay cell boundary: ordinary local derivative not supplied')
        en=np.exp(1j*TAU*(self.dk[:,:,None]+a)*np.arange(N)/N)
        em=np.exp(1j*TAU*(self.dl[:,:,None]+q)*np.arange(M)/M)
        D=en.mean(axis=2); E=em.mean(axis=2)
        kp=np.arange(N)[:,None]; lp=np.arange(M)[None,:]
        isi=lp>=M-math.ceil(q)
        slope=lp/(N*M)-isi/N
        phase=np.exp(1j*TAU*(a*slope-isi*kp/N))
        z=self.x*phase
        u=D@z@E.T
        if not derivatives:return u.ravel(order='F')
        D_a=(en*(1j*TAU*np.arange(N)/N)).mean(axis=2)
        E_q=(em*(1j*TAU*np.arange(M)/M)).mean(axis=2)
        uq=D@z@E_q.T
        ua=D_a@z@E.T+D@(z*(1j*TAU*slope))@E.T
        return tuple(v.ravel(order='F') for v in (u,uq,ua))

def profile(y,u):
    y=np.asarray(y);u=np.asarray(u)
    if y.ndim!=1 or y.shape!=u.shape or not np.isfinite(y).all() or not np.isfinite(u).all():
        raise ValueError('finite matching observation/template vectors required')
    e=float(np.vdot(u,u).real)
    if not np.isfinite(e) or e<=0:raise ValueError('template energy')
    h=np.vdot(u,y)/e
    return {'score':float(abs(np.vdot(u,y))**2/e),'h':h,'residual':float(np.vdot(y-h*u,y-h*u).real)}

def fisher(model,q,a,h,variance):
    if not np.isfinite(variance) or variance<=0:raise ValueError('variance positive')
    u,uq,ua=model.action(q,a,True)
    # Re h, Im h, q, a. Equivalent nuisance parameterization to source amplitude/phase.
    J=np.column_stack([u,1j*u,h*uq,h*ua])
    F=2/variance*(J.conj().T@J).real
    eig=np.linalg.eigvalsh(F)
    if eig[0]<=np.finfo(float).eps*eig[-1]*100:raise ValueError('singular/ill-conditioned FIM')
    C=np.linalg.inv(F)
    V=np.column_stack([h*uq,h*ua]); V=V-u[:,None]*(u.conj()@V)[None,:]/np.vdot(u,u).real
    Fe=2/variance*(V.conj().T@V).real
    return F,C,Fe

def refine(model,y,starts,qbounds=(0.,2.),abounds=(-1.,1.),maxiter=100):
    """Local extension: cell-constrained profile ML; all failures retained, no global claim."""
    y=np.asarray(y); starts=list(starts)
    if y.shape!=(model.N*model.M,) or not np.isfinite(y).all() or not starts:
        raise ValueError('finite observation and nonempty receiver starts required')
    if not 0<=qbounds[0]<qbounds[1]<model.M or not -model.N<abounds[0]<abounds[1]<model.N:
        raise ValueError('invalid search bounds')
    attempts=[]; best=None
    for q,a in starts:
        p=profile(y,model.action(q,a))
        cand={'q':float(q),'a':float(a),'score':p['score'],'h':[p['h'].real,p['h'].imag],'residual':p['residual'],'origin':'grid'}
        if best is None or cand['score']>best['score']:best=cand
        cell=max(0,math.ceil(q)-1)
        lo=max(qbounds[0],cell+1e-8);hi=min(qbounds[1],cell+1-1e-8)
        if not lo<hi:continue
        def obj(t):
            u,uq,ua=model.action(*t,True); e=np.vdot(u,u).real;c=np.vdot(u,y)
            dc=np.array([np.vdot(uq,y),np.vdot(ua,y)])
            de=2*np.array([np.vdot(u,uq).real,np.vdot(u,ua).real])
            score=abs(c)**2/e
            grad=2*np.real(np.conj(c)*dc)/e-score*de/e
            return -score,-grad
        r=minimize(obj,[np.clip(q,lo,hi),a],jac=True,bounds=[(lo,hi),abounds],method='L-BFGS-B',options={'maxiter':maxiter,'ftol':1e-13,'gtol':1e-9,'maxls':30})
        p=profile(y,model.action(*r.x))
        attempts.append({'start':[float(q),float(a)],'result':r.x.tolist(),'success':bool(r.success),'status':int(r.status),'message':str(r.message),'iterations':int(r.nit),'score':p['score']})
        # Retain finite feasible candidates even if iteration/line-search status is false, explicitly flagged.
        if p['score']>best['score']:
            best={'q':float(r.x[0]),'a':float(r.x[1]),'score':p['score'],'h':[p['h'].real,p['h'].imag],'residual':p['residual'],'origin':'local','solver_success':bool(r.success)}
    return best,attempts
