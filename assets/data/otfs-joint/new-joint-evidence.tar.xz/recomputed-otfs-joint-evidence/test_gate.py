import hashlib,json,itertools,time,resource,sys
from pathlib import Path
import numpy as np
from joint_core import LiteralOTFS,joint_profile,evaluate,fit,VERSION
ROOT=Path(__file__).parent
rng=np.random.default_rng(191001896)
x=(rng.choice([-1,1],(3,4))+1j*rng.choice([-1,1],(3,4)))/np.sqrt(2)
model=LiteralOTFS(x)
grid=np.array(list(itertools.product([.25,.75,1.25],[-.75,-.25,.25,.75])))
checks={}; records={}; start=time.perf_counter()
def check(name,value):
    checks[name]=bool(value)
    if not value:raise AssertionError(name)
def dense(q,a):
    N,M=x.shape; U=np.zeros((N*M,N*M),complex)
    for l in range(M):
      for k in range(N):
       for lp in range(M):
        for kp in range(N):
         D=sum(np.exp(2j*np.pi*n*(kp-k+a)/N) for n in range(N))/N
         E=sum(np.exp(2j*np.pi*m*(lp-l+q)/M) for m in range(M))/M
         isi=int(lp>=M-np.ceil(q))
         ph=np.exp(2j*np.pi*(a*lp/(N*M)-isi*(kp+a)/N))
         U[k+N*l,kp+N*lp]=D*E*ph
    return U@x.ravel(order='F')
A=np.column_stack([dense(*t) for t in grid]); B=np.column_stack([model.action(*t) for t in grid])
records['dense_action_max_error']=float(np.max(abs(A-B)))
check('independent_dense_action',np.max(abs(A-B))<1e-12)
truth=grid[[1,10]]; h=np.array([1+.3j,.6-.4j]); noiseless=A[:,[1,10]]@h
noise=(rng.normal(size=12)+1j*rng.normal(size=12))/np.sqrt(2)*.08
y=noiseless+noise
oracle=[];maxerr=0;maxgain=0
for ids in itertools.combinations(range(12),2):
    U=A[:,ids]; h0,_,rank,s=np.linalg.lstsq(U,y,rcond=1e-10);rr=float(np.linalg.norm(y-U@h0)**2)
    out=joint_profile(y,B[:,ids]);check('all_pairs_full_rank',rank==2 and out['ok'])
    maxerr=max(maxerr,abs(rr-out['residual']));maxgain=max(maxgain,float(np.max(abs(h0-out['h']))))
    oracle.append({'ids':list(ids),'residual':rr,'h':[[z.real,z.imag] for z in h0]})
oracle.sort(key=lambda r:r['residual']);records['oracle']=oracle
records['oracle_max_residual_error']=maxerr;records['oracle_max_gain_error']=maxgain
check('all_66_pairs_independent_svd_ls',len(oracle)==66 and maxerr<1e-11 and maxgain<1e-11)
out=evaluate(model,y,truth);perm=evaluate(model,y,truth[::-1]);check('permutation_residual',abs(out['residual']-perm['residual'])<1e-12);check('permutation_gain',np.max(abs(out['h'][::-1]-perm['h']))<1e-12)
check('coincident_rank_failure',evaluate(model,y,[truth[0],truth[0]])['status']=='rank_deficient')
check('zero_columns_rank_failure',not joint_profile(y,np.zeros((12,2),complex))['ok'])
near=evaluate(model,y,[truth[0],truth[0]+[1e-13,0]])
check('nearly_coincident_rank_failure',not near['ok']);records['nearly_coincident_rank']=near['rank']
# Joint LS differs from independently estimating gains against the unmodified y.
independent=np.array([np.vdot(A[:,i],y)/np.vdot(A[:,i],A[:,i]) for i in [1,10]])
check('joint_not_separate_gain_fits',np.linalg.norm(out['h']-independent)>1e-3)
check('normal_equations',np.max(abs(B[:,[1,10]].conj().T@out['r']))<1e-11)
# Analytic profile residual derivative includes complex h and conjugated inner product.
theta=np.array([[.37,-.42],[1.31,.58]])
grad=evaluate(model,y,theta,True)['gradient']; errors=[]
for eps in [1e-4,1e-5,1e-6]:
    fd=[]
    for j in range(4):
        d=np.zeros(4);d[j]=eps
        fd.append((evaluate(model,y,theta.ravel()+d)['residual']-evaluate(model,y,theta.ravel()-d)['residual'])/(2*eps))
    errors.append(float(np.max(abs(np.array(fd)-grad))))
records['profile_gradient_errors']=errors;check('complex_profile_derivative',min(errors)<1e-7 and errors[1]<errors[0]/10)
# Full mean derivatives, with independent dense sums rather than the accepted derivative routine.
mean_derivative_errors=[]
for p,t in enumerate(theta):
    u,uq,ua=model.action(*t,True)
    for j,du in enumerate([uq,ua]):
        d=np.zeros(2);d[j]=1e-6
        fd=h[p]*(dense(*(t+d))-dense(*(t-d)))/(2e-6)
        mean_derivative_errors.append(float(np.max(abs(fd-h[p]*du))))
records['mean_derivative_errors']=mean_derivative_errors;check('complex_mean_derivatives',max(mean_derivative_errors)<1e-8)
# Known P2/P3 end-to-end receiver has no truth argument and seeds only from y + public grid.
fixtures=[]
for P,tt,hh in [(2,truth,h),(2,theta,h),(3,np.array([[.34,-.63],[.82,.15],[1.31,.65]]),np.array([1+.2j,.7-.3j,.4+.5j]))]:
    yy=np.column_stack([dense(*t) for t in tt])@hh
    f=fit(model,yy,grid,P,starts=4,maxiter=180)
    check(f'P{P}_{len(fixtures)}_noiseless_observation_fit',f['best']['residual']<1e-11)
    for attempt in f['attempts']:
        hist=attempt.get('accepted_residuals',[])
        check('accepted_step_monotonic',all(b<=a+1e-10 for a,b in zip(hist,hist[1:])))
    fixtures.append({'P':P,'truth':tt.tolist(),'h':[[z.real,z.imag] for z in hh],'best_theta':f['best']['theta'].tolist(),'residual':f['best']['residual'],'grid_status':f['grid_status'],'attempts':f['attempts']})
records['noiseless_fixtures']=fixtures
noisy_fit=fit(model,y,grid,2,starts=4,maxiter=120)
check('noisy_fit_no_worse_than_exhaustive_grid',noisy_fit['best']['residual']<=oracle[0]['residual']+1e-12)
cap=fit(model,y,grid,2,starts=1,maxiter=0)
check('iteration_cap_retained',not cap['attempts'][0]['success'])
check('zero_budget_no_nonlinear_steps',cap['attempts'][0]['iterations']==0 and cap['attempts'][0]['evaluations']==0 and cap['attempts'][0]['accepted_residuals']==[])
check('zero_budget_exact_grid_baseline',cap['best']['origin']=='grid' and abs(cap['best']['residual']-oracle[0]['residual'])<1e-12)
positive_cap=fit(model,y,grid,2,starts=1,maxiter=1)
check('positive_iteration_cap_retained',positive_cap['attempts'][0]['iterations']<=1 and not positive_cap['attempts'][0]['success'])
records['positive_forced_cap']=positive_cap['attempts']
records['forced_cap']=cap['attempts'];records['noisy_fit']={'theta':noisy_fit['best']['theta'].tolist(),'residual':noisy_fit['best']['residual'],'attempts':noisy_fit['attempts']}
# Rank is not numerical conditioning; deterministic columns expose a full-rank unstable solve.
conditioned=np.column_stack([np.ones(12),np.ones(12)+1e-9*np.arange(12)]).astype(complex)
ill=joint_profile(y,conditioned)
check('full_rank_ill_conditioned_rejected',ill['status']=='ill_conditioned' and ill['rank']==2 and ill['condition']>ill['max_condition'])
zero=joint_profile(np.zeros(12),A[:,:2])
check('zero_observation_safe',zero['ok'] and zero['scaled_normal_defect']==0 and zero['residual']==0)
check('accepted_scaled_normal_defect',out['scaled_normal_defect']<=out['max_normal_defect'] and out['condition']<=out['max_condition'])
all_failed=fit(model,y,np.array([[.25,.25],[.25,.25],[.25,.25]]),2,starts=1)
check('all_grid_failed_retained',all_failed['best'] is None and all_failed['status']=='no_identifiable_support' and all_failed['grid_status']['rejected_supports']==3)
records['ill_conditioned_fixture']={k:(v.tolist() if isinstance(v,np.ndarray) else v) for k,v in ill.items()}
records['all_grid_failed']=all_failed
for badgrid in [np.array([[.25,1.1],[.75,0]]),np.array([[2.1,0],[.75,0]])]:
    try:fit(model,y,badgrid,2);check('out_of_domain_grid_rejected',False)
    except ValueError:check('out_of_domain_grid_rejected',True)
# Explicit boundary prohibition of derivatives, unchanged accepted model.
try:model.action(1,.1,True);check('boundary_derivative_rejected',False)
except ValueError:check('boundary_derivative_rejected',True)
for yy,UU in [(y[:-1],A[:,:2]),(y,np.full((12,2),np.nan)),(y,A[:,:4])]:
    try:joint_profile(yy,UU);check('invalid_input_rejected',False)
    except ValueError:check('invalid_input_rejected',True)
np.savez(ROOT/'tiny_raw.npz',x=x,grid=grid,truth=truth,h=h,y=y,noise=noise,noise_free=noiseless)
records.update({'version':VERSION,'seed':191001896,'dimensions':[3,4],'grid_size':12,'known_orders':[2,3],'checks':checks,'check_count':len(checks),'wall_seconds':time.perf_counter()-start,'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'numpy':np.__version__})
(ROOT/'C1-RESULTS.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps({k:records[k] for k in ['check_count','checks','wall_seconds','peak_rss_kib','oracle_max_residual_error','profile_gradient_errors']},indent=2))
