# NEW recovery recomputation

This directory is a new run of the exact recovered OTFS joint study sources, authorized after the filesystem reset. It is NOT the lost original evidence archive. Original reference directory /workspace/shared/recovery/otfs-joint-reference remains untouched.

NEW-RUN-PROVENANCE.json records actual versions, exact source identity and the explicit dependency alias. The five recorded source hashes match the pre-reset versions. The28 C1 gates passed afresh in NEW-C1-gates.log. Main outputs under c2/main are newly generated from the frozen2100 seed tuples/scenes/budgets; no retuning, changed initialization or favorable trial filtering is authorized.

Files RECOVERY.md and review-transcripts/C2-FINAL-REVIEW.md are inherited historical source-recovery/review records. Their descriptions of missing original evidence and old acceptance remain historical; neither is a claim of independent acceptance of this new run. A separate new-output review is required.

Main runtime/timings, raw archive container metadata and complete record hash will be NEW. Even agreement of scientific aggregate values does not recover the old archive hash. New numerical evidence will be summarized and independently checked before any integration claim.

No publication, upload, Git, UI edits or Codex use are part of this run.
