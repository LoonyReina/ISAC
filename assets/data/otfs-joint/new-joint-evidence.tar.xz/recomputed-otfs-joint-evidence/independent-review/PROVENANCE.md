# Independent checker provenance

These checkers are RECREATED from this review agent's available tool-call history after a filesystem reset. They are not recovered original checker bytes, and no historical checker hash is claimed. Paths and output reporting are adapted for the NEW recomputation. Their algorithmic checks reproduce the prior review procedure and add explicit source-hash verification. Original acceptance and old counts are historical context only; fresh acceptance requires checks against completed NEW outputs.

The implementation under review is separate: five recovered source files have recorded pre-reset hashes, independently verified by the checker. C1-replay copies the exact recovered author core/gate files into this directory, so running author gates does not overwrite the new study's outputs. Additional independent C1 Fourier oracle/permutation/gradient/degeneracy checks and C2 all-record matching/error/residual accounting remain checker-authored work.

No original raw outcome archive was recovered. NEW outputs, timestamps, hashes and audit results must not be presented as the lost archive. No denied session directory was read.
