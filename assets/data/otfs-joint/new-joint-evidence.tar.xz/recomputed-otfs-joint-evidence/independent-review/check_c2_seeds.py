"""NEW independent SVD support-ranking check; truth never enters support ranking."""
import sys,json,gzip,itertools,numpy as np
from pathlib import Path
root=Path('/workspace/shared/recovery/recomputed-otfs-joint');sys.path.insert(0,str(root/'c2'));import run_study as r
rows=[json.loads(x) for x in gzip.open(root/'c2/main/records.jsonl.gz','rt')];out=[]
for frameid in [1900,2050]:
 row=next(x for x in rows if x['frame_id']==frameid);y,_,_,_=r.make_observation('main',row['scene_index'],row['snr_db'],row['frame']);grid=r.GRID;A=np.column_stack([r.MODEL.action(*t) for t in grid]);scores=[]
 for ids in itertools.combinations(range(len(grid)),row['P']):
  U=A[:,ids];h,_,rank,s=np.linalg.lstsq(U,y,rcond=1e-10)
  if rank<row['P'] or s[0]/s[-1]>1e8:continue
  res=y-U@h;defect=np.linalg.norm(U.conj().T@res)/max(s[0]*np.linalg.norm(y),np.finfo(float).tiny)
  if defect>1e-10:continue
  scores.append((float(np.linalg.norm(res)**2),ids))
 scores.sort();stored=row['methods']['joint_known_P']['attempts'];assert len(stored)==4
 for a,(_,ids) in zip(stored,scores[:4]):assert np.array_equal(np.array(a['initial']),grid[list(ids)])
 out.append({'frame_id':frameid,'P':row['P'],'ranked_supports':len(scores),'top_four_match':True,'best_four_ids':[list(t[1]) for t in scores[:4]]})
print(json.dumps(out,indent=2))
