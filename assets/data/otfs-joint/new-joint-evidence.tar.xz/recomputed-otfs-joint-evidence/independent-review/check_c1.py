"""RECREATED checker from available reviewer tool-call history; not original bytes."""
import sys,itertools,json,numpy as np
from pathlib import Path
ROOT=Path('/workspace/shared/recovery/recomputed-otfs-joint');sys.path.insert(0,str(ROOT))
from joint_core import LiteralOTFS,joint_profile,evaluate,grid_supports,fit
z=np.load(ROOT/'tiny_raw.npz');x=z['x'];y=z['y'];g=z['grid'];N,M=x.shape;model=LiteralOTFS(x)
def direct(q,a):
 v=np.zeros((N,M),complex)
 for k,l,kp,lp in itertools.product(range(N),range(M),range(N),range(M)):
  wrap=lp>=M-np.ceil(q);phase=np.exp(2j*np.pi*(a*lp/(N*M)-wrap*(kp+a)/N))
  v[k,l]+=x[kp,lp]*phase*sum(np.exp(2j*np.pi*(kp-k+a)*n/N) for n in range(N))*sum(np.exp(2j*np.pi*(lp-l+q)*m/M) for m in range(M))/(N*M)
 return v.ravel(order='F')
A=np.column_stack([direct(*t) for t in g]);B=np.column_stack([model.action(*t) for t in g]);scores=[];errs=[]
for ids in itertools.combinations(range(12),2):
 U=A[:,ids];h=np.linalg.lstsq(U,y,rcond=1e-10)[0];rr=float(np.linalg.norm(y-U@h)**2);v=joint_profile(y,B[:,ids]);assert v['ok'];scores.append((rr,ids));errs.append(abs(rr-v['residual']))
scores.sort();seeds,status=grid_supports(model,y,g,2,4);assert all(np.array_equal(seed,g[list(rec[1])]) for seed,rec in zip(seeds,scores[:4]));assert max(errs)<1e-11
th=np.array([[.34,-.63],[.82,.15],[1.31,.65]]);v=evaluate(model,y,th,True);pe=[]
for p in itertools.permutations(range(3)):
 u=evaluate(model,y,th[list(p)],True);pe.extend([abs(u['residual']-v['residual']),max(abs(u['h']-v['h'][list(p)])),max(abs(u['gradient'].reshape(3,2)-v['gradient'].reshape(3,2)[list(p)]).ravel())])
fd=[]
for i in range(6):
 d=np.zeros(6);d[i]=1e-6;fd.append((evaluate(model,y,th.ravel()+d)['residual']-evaluate(model,y,th.ravel()-d)['residual'])/2e-6)
ge=float(max(abs(fd-v['gradient'])));assert max(pe)<1e-10 and ge<1e-7
ranks={}
for name,t in [('triple',np.repeat(th[:1],3,axis=0)),('pair',np.vstack([th[0],th[0],th[2]])),('near_pair',np.vstack([th[0],th[0]+[1e-13,0],th[2]]))]:
 u=evaluate(model,y,t);assert not u['ok'];ranks[name]=u['rank']
cap=fit(model,y,g,2,starts=4,maxiter=0);assert all(a['iterations']==0 and a['evaluations']==0 and not a['success'] for a in cap['attempts'])
print(json.dumps({'identity':'NEW independent C1 checks, recreated checker','pairs':66,'dense_error':float(np.max(abs(A-B))),'max_qr_svd_error':max(errs),'P3_permutation_error':max(pe),'P3_gradient_error':ge,'degenerate_ranks':ranks,'zero_budget_verified':True},indent=2))
