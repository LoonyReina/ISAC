# NEW recomputation: independent acceptance

Decision: ACCEPT the NEW 2,100-frame recomputation as finite scenario-conditional evidence for the frozen project estimator. This is fresh acceptance based on the new complete outputs, not inherited acceptance of a recovered archive. The original raw archive is unavailable.

## Provenance distinctions

The five implementation files match known pre-reset SHA256 identities: joint_core.py, test_gate.py, dependency/otfs_core.py, c2/run_study.py, c2/contract.json. Actual hashes are retained in NEW-C2-INDEPENDENT.json. The original absolute operator dependency resolves through the documented alias to the exact recovered dependency file.

The independent checker files were recreated from the review agent's available historical tool-call text, adapted to current paths and combined reporting. No original checker-byte identity is claimed. See PROVENANCE.md. The copied author gates in c1-replay are exact recovered implementation files, separate from these checker-authored scripts.

Historical C0 source inspection is historical only. This fresh review did not recover or re-read the lost primary PDF. It preserves the explicit project-method label: source Eqs17–19 likelihood extension, not literal Eq21 or Eq26.

## Fresh checks passed

- Author28 C1 gates replayed in an isolated copy; independent66-pair direct Fourier/SVD oracle, exact four-seed ordering, P3 permutation/derivative/degenerate-rank and strict zero-budget checks passed.
- Every expected2,100 main frame key and unique seed is present, disjoint from16 prescribed pilot seed tuples. All2,100 observation hashes and noise variances independently regenerate. All22 raw replay panels are bit-exact.
- All6,300 method records: independent injective threshold matching, matched and unrestricted error vectors, actual-estimator-gain residuals and search-domain checks pass. Maximum residual disagreement8.53e-14.
- All66 group counts, failure/profile statuses, conditional/unrestricted RMSE, residual summaries and Wilson intervals reconcile. All44 paired whole-frame bootstrap summaries reproduce.
- All34,000 saved final attempt profiles satisfy recorded condition<=1e8 and scaled normal defect<=1e-10. Optimizer status is separately retained.
-15 actual estimator reruns covering all five scenes reproduce estimates and residuals, including unequal amplitudes20dB and P3 stress15dB.
- Independent NumPy SVD enumeration of300 P2 supports and2300 P3 supports on representative weak-path/P3 frames reproduces the exact four public observation-ranked starts; truth is not used to select supports.
- gzip and xz decode identically. NEW decoded-record SHA256 is bbc6229195c65190e707ef6398bb33b96e035cc420b8977c80e99a3db916e36f. This is a new output identity, not the historical raw hash.

## Retained failures and limitations

Joint8,400 attempts retain275 abnormal terminations and20 caps;390 rejected evaluations comprise240 rank,128 numerical and22 conditioning failures. Standalone P1 retains54 unsuccessful attempts of8,400; sequential retains129 of17,200.47 selected joint outputs and42 standalone P1 outputs have unsuccessful optimizer termination. Describe them as finite numerical estimates, never guaranteed stationary/converged solutions.

At each10/15/20dB unequal-amplitude cell, all100 frames select all four joint starts in the first delay cell. Frozen cell-constrained refinement cannot reach weak-path delay1.45. Joint all-path success is0/100 versus sequential32/73/98. This is a reproducible limitation of the frozen initialization/search domain, not a core implementation mismatch or license to retune this experiment. Keep the negative result prominent. Close-pair success remains low; P3 success is scenario-specific. Known P, literal-Eq14 caveat, different computational costs and conditional-error denominators remain mandatory interpretation limits.

No gating discrepancy found. No main rerun, outcome tuning, UI/site edit, upload, Git action, Codex call or denied-session read was performed by this reviewer. Representative replays are tiny verification work, not replacement trials.

Evidence: NEW-author-gates.log, NEW-C1-independent.json, NEW-C2-INDEPENDENT.json, NEW-C2-SEED-CHECK.json, check_c1.py, check_main.py and check_c2_seeds.py.
