"""RECREATED independent checker from prior tool-call text; new paths/output schema."""
import sys,json,gzip,lzma,hashlib,itertools,collections,time,numpy as np
from pathlib import Path
ROOT=Path('/workspace/shared/recovery/recomputed-otfs-joint');sys.path.insert(0,str(ROOT/'c2'))
import run_study as r
p=ROOT/'c2/main';start=time.perf_counter()
expected_hashes={'joint_core.py':'c671ee34b8a702eb5622a579cd5b32f4a7a0396845cc2269bc1575dbe262987c','test_gate.py':'9c824ccbacce985fca6bb2ccf2f0ceb8205dbaecdfc288be9581c6a9fcacbca2','dependency/otfs_core.py':'41e9f0620e923ac63fe08cf80599ca2bd892218a45e5aed0290805bb6b394f4e','c2/run_study.py':'2f706e6b6488bc937e479bc12126dbfed53abe5b4bf9d14eacf08307f3757da7','c2/contract.json':'179b59f8d08c71242724e20c4f473fc11e5d2cd035e6bdd76cd4a41a5144256c'}
for f,h in expected_hashes.items():assert hashlib.sha256((ROOT/f).read_bytes()).hexdigest()==h
assert r.MODEL.__class__.__module__=='accepted_otfs'
data=gzip.decompress((p/'records.jsonl.gz').read_bytes());assert lzma.decompress((p/'records.jsonl.xz').read_bytes())==data
rows=[json.loads(x) for x in data.splitlines()];summary=json.loads((p/'SUMMARY.json').read_text());res=json.loads((p/'RESULTS.json').read_text());z=np.load(p/'raw_replay.npz')
expected=set(r.plan('main'));actual={(v['scene_index'],v['snr_db'],v['frame']) for v in rows};assert actual==expected and len(rows)==len(expected)==2100
assert len({tuple(v['seed_sequence']) for v in rows})==2100
pilot={tuple([901,*v]) for v in r.plan('pilot')};assert not pilot&{tuple(v['seed_sequence']) for v in rows}
for key,path in [('contract_sha256',r.ROOT/'contract.json'),('core_sha256',ROOT/'joint_core.py'),('runner_sha256',r.ROOT/'run_study.py')]:assert res[key]==hashlib.sha256(path.read_bytes()).hexdigest()
agg={};attempts=collections.Counter();statuses={n:collections.Counter() for n in r.CONTRACT['methods']};rejects=collections.Counter();maxerr=0;raw=0;selected_false=collections.Counter();profiles=collections.Counter()
def match(truth,theta):
 P=len(truth);K=len(theta);best=(0,0.,[])
 for n in range(1,min(P,K)+1):
  for ti in itertools.combinations(range(P),n):
   for ei in itertools.permutations(range(K),n):
    d=np.asarray([theta[j]-truth[i] for i,j in zip(ti,ei)])
    if (abs(d)<=.1+1e-14).all():
     cost=float(np.sum((d/.1)**2))
     if n>best[0] or (n==best[0] and cost<best[1]):best=(n,cost,list(zip(ti,ei)))
 return best
for row in rows:
 y,var,seed,w=r.make_observation('main',row['scene_index'],row['snr_db'],row['frame']);assert hashlib.sha256(y.tobytes()).hexdigest()==row['y_sha256'];assert seed==row['seed_sequence'] and var==row['noise_variance']
 if row['frame']==0:assert np.array_equal(y,z[f"y_{row['scene_index']}_{row['snr_db']}"]);raw+=1
 truth=np.array(r.CONTRACT['scenes'][row['scene_index']]['theta'])
 for name,m in row['methods'].items():
  b=m.get('best');theta=np.array([] if b is None else b['theta']).reshape(-1,2);n,c,pairs=match(truth,theta);met=m['metrics'];assert met['matched']==n and met['missed']==len(truth)-n and met['false']==len(theta)-n;assert met['all_target_success']==(n==len(truth)==len(theta))
  assert np.all((theta[:,0]>=0)&(theta[:,0]<=2)&(abs(theta[:,1])<=1))
  matched=np.array([theta[j]-truth[i] for i,j in met['matched_pairs']]).reshape(-1,2);assert np.allclose(matched,np.array(met['matched_errors']).reshape(-1,2),rtol=0,atol=1e-15)
  nr=min(len(truth),len(theta));ds=[theta[list(ei)]-truth[list(ti)] for ti in itertools.combinations(range(len(truth)),nr) for ei in itertools.permutations(range(len(theta)),nr)];full=min(ds,key=lambda d:np.sum((d/.1)**2));assert np.allclose(full,np.array(met['unrestricted_assignment_errors']).reshape(-1,2),rtol=0,atol=1e-15)
  if b is not None:
   U=np.column_stack([r.MODEL.action(*t) for t in theta]);h=np.array([complex(*v) for v in b['h']]);rr=float(np.linalg.norm(y-U@h)**2);maxerr=max(maxerr,abs(rr-b['residual']));assert abs(rr-b['residual'])<1e-9;assert abs(rr/np.vdot(y,y).real-m['normalized_fit_residual'])<1e-10
   if b.get('solver_success') is False:selected_false[name]+=1
  aa=m.get('attempts',[]) if 'stages' not in m else [a for stage in m['stages'] for a in stage['attempts']];attempts[name]+=len(aa)
  for a in aa:
   statuses[name][str(a['status'])]+=1;v=a['final_profile'];profiles[v['status']]+=1;assert v['ok'] and v['condition']<=1e8 and v['scaled_normal_defect']<=1e-10
   if name=='joint_known_P':rejects.update(a.get('evaluation_failure_counts',{}))
  key=f"{row['scene']}/{row['snr_db']}/{name}";g=agg.setdefault(key,{'frames':0,'matched':0,'missed':0,'false':0,'success':0,'attempts':0,'errors':[],'full':[],'fit':[],'profiles':collections.Counter(),'statuses':collections.Counter()});g['frames']+=1;g['attempts']+=len(aa);g['success']+=met['all_target_success'];g['errors'].extend(matched.tolist());g['full'].extend(full.tolist());g['fit'].append(m.get('normalized_fit_residual'));g['profiles'].update(a['final_profile']['status'] for a in aa);g['statuses'].update(str(a['status']) for a in aa)
  for k in ['matched','missed','false']:g[k]+=met[k]
for key,g in agg.items():
 s=summary['groups'][key]
 for k in ['frames','matched','missed','false']:assert s[k]==g[k]
 assert s['all_target_success_count']==g['success'] and s['optimizer_attempts']==g['attempts'];assert s['final_profile_status_counts']==dict(g['profiles']) and s['optimizer_status_counts']==dict(g['statuses'])
 assert len(g['errors'])==s['matched_error_count'] and len(g['full'])==s['unrestricted_assignment_error_count']
 if g['errors']:assert np.allclose(np.sqrt(np.mean(np.array(g['errors'])**2,axis=0)),s['matched_conditional_rmse_qa'],atol=1e-14,rtol=0)
 assert np.allclose(np.sqrt(np.mean(np.array(g['full'])**2,axis=0)),s['unrestricted_assignment_rmse_qa'],atol=1e-14,rtol=0);assert abs(np.mean(g['fit'])-s['mean_normalized_fit_residual'])<1e-14
 # Independent Wilson formula.
 n=g['frames'];k=g['success'];z95=1.959963984540054;q=k/n;den=1+z95*z95/n;center=(q+z95*z95/(2*n))/den;width=z95*np.sqrt(q*(1-q)/n+z95*z95/(4*n*n))/den
 assert np.allclose([max(0,center-width),min(1,center+width)],s['all_target_success_wilson95'],atol=1e-14,rtol=0)
paired=0
for si,snr in sorted({(v['scene_index'],v['snr_db']) for v in rows}):
 rr=[v for v in rows if v['scene_index']==si and v['snr_db']==snr];rg=np.random.default_rng(np.random.SeedSequence([903,si,snr]));indices=rg.integers(0,len(rr),(2000,len(rr)))
 for other in r.CONTRACT['methods'][1:]:
  d=np.array([int(v['methods']['joint_known_P']['metrics']['all_target_success'])-int(v['methods'][other]['metrics']['all_target_success']) for v in rr]);s=summary['paired'][f"{rr[0]['scene']}/{snr}/joint_minus_{other}"];assert np.array_equal(np.quantile(d[indices].mean(axis=1),[.025,.975]),s['success_difference_paired_bootstrap95']);assert d.mean()==s['success_difference'];paired+=1
replays=[]
for si,snr in [(0,20),(1,20),(2,20),(3,20),(4,15)]:
 row=next(v for v in rows if v['scene_index']==si and v['snr_db']==snr and v['frame']==0);y,_,_,_=r.make_observation('main',si,snr,0)
 for name,fn in [('joint_known_P',lambda:r.joint(y,row['P'])),('single_target_shared_grid',lambda:r.single(y)),('sequential_cancellation_known_P',lambda:r.sequential(y,row['P']))]:
  v=fn();saved=row['methods'][name];assert np.allclose(v['best']['theta'],saved['best']['theta'],atol=1e-12,rtol=0);assert abs(v['best']['residual']-saved['best']['residual'])<1e-10;replays.append([row['frame_id'],name])
negative={}
for snr in [10,15,20]:
 rr=[v for v in rows if v['scene']=='unequal_amplitudes' and v['snr_db']==snr];negative[snr]={'frames':len(rr),'all_four_starts_first_cell_frames':sum(all(all(t[0]<=1 for t in a['initial']) for a in v['methods']['joint_known_P']['attempts']) for v in rr),'joint_success':sum(v['methods']['joint_known_P']['metrics']['all_target_success'] for v in rr),'sequential_success':sum(v['methods']['sequential_cancellation_known_P']['metrics']['all_target_success'] for v in rr)}
print(json.dumps({'identity':'NEW recomputation independently accepted; checker recreated from tool history','source_hashes':expected_hashes,'frames':len(rows),'method_rows':sum(v['frames'] for v in agg.values()),'groups':len(agg),'paired_bootstrap_groups':paired,'raw_panels':raw,'actual_gain_residual_max_error':maxerr,'attempts':dict(attempts),'statuses':{k:dict(v) for k,v in statuses.items()},'final_profile_statuses':dict(profiles),'rejected_joint_evaluations':dict(rejects),'selected_unsuccessful':dict(selected_false),'representative_replays':replays,'weak_path_initialization_limitation':negative,'decoded_new_records_sha256':hashlib.sha256(data).hexdigest(),'checker_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'seconds':time.perf_counter()-start},indent=2))
