"""Compare NEW-run aggregates with exact integer values visible in historical outputs.
This does not recover original raw records or verify old whole-file hashes.
"""
import json,gzip
from pathlib import Path
R=Path(__file__).parent
pairs={
 'well_separated':([0,5,10,15,20],[38,85,100,100,100],[33,78,100,100,100]),
 'close_delay':([0,5,10,15,20],[0,0,1,1,6],[0,0,0,0,0]),
 'close_doppler':([0,5,10,15,20],[0,0,2,4,9],[0,0,0,0,0]),
 'unequal_amplitudes':([0,5,10,15,20],[3,1,0,0,0],[7,10,32,73,98]),
 'three_path_stress':([5,15],[7,50],[1,0])}
s=json.loads((R/'c2/main/SUMMARY.json').read_text());rows=[json.loads(x) for x in gzip.open(R/'c2/main/records.jsonl.gz','rt')]
checks=[]
def compare(label,actual,historical):checks.append({'label':label,'new_run_value':actual,'historical_reported_value':historical,'matches':actual==historical})
for scene,(snrs,joints,seqs) in pairs.items():
 for snr,j,q in zip(snrs,joints,seqs):
  for method,expected in [('joint_known_P',j),('sequential_cancellation_known_P',q),('single_target_shared_grid',0)]:
   compare(f'{scene}/{snr}/{method}/all_path_success',s['groups'][f'{scene}/{snr}/{method}']['all_target_success_count'],expected)
for method,expected in [('joint_known_P',47),('single_target_shared_grid',42)]:
 compare(method+'/selected_solver_success_false',sum(r['methods'][method]['best'].get('solver_success') is False for r in rows),expected)
for method,expected in [('joint_known_P',{'optimizer_attempts':8400,'optimizer_success_count':8105,'matched':2465,'missed':1835,'false':1835}),('single_target_shared_grid',{'optimizer_attempts':8400,'optimizer_success_count':8346,'matched':1936,'missed':2364,'false':164}),('sequential_cancellation_known_P',{'optimizer_attempts':17200,'optimizer_success_count':17071,'matched':2695,'missed':1605,'false':1605})]:
 groups=[v for k,v in s['groups'].items() if k.endswith('/'+method)]
 for key,value in expected.items():compare(method+'/'+key,sum(g[key] for g in groups),value)
joint_attempts=[a for r in rows for a in r['methods']['joint_known_P']['attempts']]
compare('joint_abnormal',sum(a['status']=='ABNORMAL: ' for a in joint_attempts),275)
compare('joint_iteration_caps',sum(a['status']=='STOP: TOTAL NO. OF ITERATIONS REACHED LIMIT' for a in joint_attempts),20)
for kind,n in [('rank_deficient',240),('ls_numerical_failure',128),('ill_conditioned',22)]:compare('joint_rejected_'+kind,sum(a.get('evaluation_failure_counts',{}).get(kind,0) for a in joint_attempts),n)
for snr in [10,15,20]:
 rr=[r for r in rows if r['scene']=='unequal_amplitudes' and r['snr_db']==snr]
 compare('unequal_amplitudes/'+str(snr)+'/frames_no_start_reaches_second_cell',sum(all(all(t[0]<=1 for t in a['initial']) for a in r['methods']['joint_known_P']['attempts']) for r in rr),100)
result={'identity':'NEW comparison with historical transcript values, not old raw evidence recovery','comparison_count':len(checks),'all_match':all(c['matches'] for c in checks),'checks':checks}
(R/'NEW-HISTORICAL-COMPARISON.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'comparisons':len(checks),'all_match':result['all_match'],'differences':[c for c in checks if not c['matches']]}))
