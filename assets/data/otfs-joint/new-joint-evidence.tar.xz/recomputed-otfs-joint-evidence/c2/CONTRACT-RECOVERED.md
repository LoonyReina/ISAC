# Recovered C2 contract notes

The frozen contract.json and run_study.py have been restored to their original SHA256 hashes. This explanatory document is reconstructed, not byte-verified against the lost original prose.

Main: four P2 scenes×five SNRs×100 frames=2000, plus one P3 stress scene×two SNRs×50=100. Pilot:12P2+4P3=16. Known path count supplied. Public25-point grid, four starts,120iterations. All exact scenes, complex gains, seed namespace tuples, matching tolerances and numerical thresholds are in contract.json. Seed namespace901 pilot,902 main. Frozen waveform seed19100189620261018, NumPy PCG64 QPSK8×8. Noise CN real/imag variance1/2; observation variance ||signal||²/(64*10^(SNR/10)); every method receives identical y in each frame.

Joint uses full profile gain refitting every nonlinear candidate. P1 reuses accepted single-profile/per-cell refinement on the same25-point grid (not the earlier6561-point browser grid). Sequential applies that P1 receiver P times to residuals and subtracts its fitted path each time; no final joint gain refit changes the sequential estimator. A separate joint-profile diagnostic at its final supports is only diagnostic.

Matching enumerates partial injective assignments, maximizes number with |dq|<=0.1 and |da|<=0.1, then minimizes tolerance-scaled squared error. All-path success requires exactly P estimates and P matches. Misses=P-matches, false=estimates-matches. Conditional matched errors are separated from unrestricted assignment errors. All trial outcomes including unavailable estimates, exceptions, capped and abnormal refinement remain. Optimizer success, profile conditioning and path recovery are distinct. Source multipath components do not necessarily represent separate physical targets.

Output-only summaries use Wilson95% intervals and2000 deterministic whole-frame bootstrap replicates with SeedSequence([903,scene_index,snr]). No favorable/converged filter. P1 all-path success is necessarily zero for P>1 and is not a standalone accuracy ranking. Compute cost is not equal across methods.

Historical main execution used NumPy2.3.5,SciPy1.17.0,OPENBLAS_NUM_THREADS=1,OMP_NUM_THREADS=1. Main378.7578141989652seconds,peak RSS61740KiB. This recovery has not rerun the main study or regenerated its output records. Historical full review acceptance applies to the original lost evidence, not to nonexistent reconstructed raw outcomes.
