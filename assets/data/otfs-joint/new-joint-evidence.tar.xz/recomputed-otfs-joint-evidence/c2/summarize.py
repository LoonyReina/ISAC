"""Output-only reconstruction; no estimator execution and no favorable-trial filter."""
import gzip,json,math,hashlib,lzma,itertools,sys
from pathlib import Path
import numpy as np
ROOT=Path(__file__).parent

def wilson(k,n):
    if n==0:return None
    z=1.959963984540054;p=k/n;d=1+z*z/n;c=(p+z*z/(2*n))/d;w=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/d
    return [max(0,c-w),min(1,c+w)]
def attempts(method):
    if 'stages' in method:return [a for s in method['stages'] for a in s['attempts']]
    return method.get('attempts',[])
def counts(values):
    out={}
    for v in values:out[str(v)]=out.get(str(v),0)+1
    return out

def summarize(mode):
    folder=ROOT/mode;data=gzip.decompress((folder/'records.jsonl.gz').read_bytes());rows=[json.loads(x) for x in data.splitlines()]
    contract=json.loads((ROOT/'contract.json').read_text()); groups={}; paired={}
    for key in sorted({(r['scene_index'],r['snr_db']) for r in rows}):
        rr=[r for r in rows if (r['scene_index'],r['snr_db'])==key];si,snr=key;P=contract['scenes'][si]['P'];expected=contract[mode]['P2_frames_per_cell' if P==2 else 'P3_frames_per_cell']
        if len(rr)!=expected:raise ValueError('missing/duplicate group denominator')
        names=contract['methods'];label=f"{contract['scenes'][si]['name']}/{snr}"
        for name in names:
            mm=[r['methods'][name] for r in rr];metrics=[m['metrics'] for m in mm];aa=[a for m in mm for a in attempts(m)];matched=np.array([e for m in metrics for e in m['matched_errors']]).reshape(-1,2);unrestricted=np.array([e for m in metrics for e in m['unrestricted_assignment_errors']]).reshape(-1,2)
            k=sum(m['all_target_success'] for m in metrics)
            s={'frames':len(rr),'available':sum(m.get('best') is not None for m in mm),'all_target_success_count':k,'all_target_success_rate':k/len(rr),'all_target_success_wilson95':wilson(k,len(rr)),'truth_count':sum(m['truth_count'] for m in metrics),'estimate_count':sum(m['estimate_count'] for m in metrics),'matched':sum(m['matched'] for m in metrics),'missed':sum(m['missed'] for m in metrics),'false':sum(m['false'] for m in metrics),'matched_error_count':len(matched),'matched_conditional_rmse_qa':np.sqrt(np.mean(matched**2,axis=0)).tolist() if len(matched) else None,'unrestricted_assignment_error_count':len(unrestricted),'unrestricted_assignment_rmse_qa':np.sqrt(np.mean(unrestricted**2,axis=0)).tolist() if len(unrestricted) else None,'status_counts':counts(m['status'] for m in mm),'optimizer_attempts':len(aa),'optimizer_success_count':sum(bool(a['success']) for a in aa),'optimizer_status_counts':counts(a['status'] for a in aa),'final_profile_status_counts':counts(a['final_profile']['status'] for a in aa),'evaluation_failure_counts':{},'selected_origin_counts':counts(m['best']['origin'] for m in mm if m.get('best') is not None),'fit_available_count':sum('normalized_fit_residual' in m for m in mm),'mean_normalized_fit_residual':float(np.mean([m['normalized_fit_residual'] for m in mm if 'normalized_fit_residual' in m])) if any('normalized_fit_residual' in m for m in mm) else None}
            for a in aa:
                for status,n in a.get('evaluation_failure_counts',{}).items():s['evaluation_failure_counts'][status]=s['evaluation_failure_counts'].get(status,0)+n
            groups[label+'/'+name]=s
        # Whole-frame paired bootstrap. Never resample paths or successful trials separately.
        rg=np.random.default_rng(np.random.SeedSequence([903,si,snr]));indices=rg.integers(0,len(rr),(2000,len(rr)))
        for other in names[1:]:
            d=np.array([int(r['methods'][names[0]]['metrics']['all_target_success'])-int(r['methods'][other]['metrics']['all_target_success']) for r in rr])
            boot=d[indices].mean(axis=1)
            fits=[r['methods'][names[0]]['normalized_fit_residual']-r['methods'][other]['normalized_fit_residual'] for r in rr if 'normalized_fit_residual' in r['methods'][names[0]] and 'normalized_fit_residual' in r['methods'][other]]
            paired[label+'/joint_minus_'+other]={'all_frames':len(rr),'success_difference':float(d.mean()),'success_difference_paired_bootstrap95':np.quantile(boot,[.025,.975]).tolist(),'discordant_joint_only':int(np.count_nonzero(d==1)),'discordant_other_only':int(np.count_nonzero(d==-1)),'paired_fit_available':len(fits),'mean_fit_difference':float(np.mean(fits)) if fits else None,'bootstrap_seed_sequence':[903,si,snr],'bootstrap_replicates':2000}
    seeds=[tuple(r['seed_sequence']) for r in rows]
    if len(set(seeds))!=len(rows):raise ValueError('duplicate seeds')
    expected=contract[mode]['P2_frames']+contract[mode]['P3_frames']
    if len(rows)!=expected:raise ValueError('missing total frames')
    result={'mode':mode,'frames':len(rows),'method_rows':len(rows)*3,'unique_seeds':len(set(seeds)),'groups':groups,'paired':paired,'decoded_records_sha256':hashlib.sha256(data).hexdigest()}
    (folder/'SUMMARY.json').write_text(json.dumps(result,indent=2)+'\n')
    xz=lzma.compress(data,preset=6)
    if lzma.decompress(xz)!=data:raise AssertionError('lossless compression')
    (folder/'records.jsonl.xz').write_bytes(xz)
    print(json.dumps({'frames':len(rows),'groups':len(groups),'paired_groups':len(paired),'xz_bytes':len(xz),'decoded_sha256':result['decoded_records_sha256']}))
if __name__=='__main__':summarize(sys.argv[1] if len(sys.argv)>1 else 'pilot')
