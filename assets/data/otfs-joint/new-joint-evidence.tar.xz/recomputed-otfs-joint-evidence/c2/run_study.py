"""Finite C2 study; pilot and main have disjoint seeds, frozen contract."""
import sys,json,gzip,time,resource,hashlib,itertools,math,os
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from joint_core import LiteralOTFS,evaluate,fit,accepted
ROOT=Path(__file__).parent
CONTRACT=json.loads((ROOT/'contract.json').read_text())
GRID=np.array(list(itertools.product(CONTRACT['grid_q'],CONTRACT['grid_a'])))
rng=np.random.default_rng(CONTRACT['x_seed'])
X=(rng.choice([-1,1],(8,8))+1j*rng.choice([-1,1],(8,8)))/np.sqrt(2)
MODEL=LiteralOTFS(X)
TEMPLATES=np.column_stack([MODEL.action(*t) for t in GRID])

def plain(x):
    if isinstance(x,np.ndarray):return plain(x.tolist())
    if isinstance(x,complex):return [x.real,x.imag]
    if isinstance(x,(np.floating,np.integer)):return x.item()
    if isinstance(x,dict):return {k:plain(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)):return [plain(v) for v in x]
    return x

def profile_summary(p):
    return {k:plain(v) for k,v in p.items() if k not in ['r','gradient']}

def joint(y,P):
    f=fit(MODEL,y,GRID,P,starts=CONTRACT['starts'],maxiter=CONTRACT['maxiter'])
    for a in f['attempts']:
        a['final_profile']=profile_summary(evaluate(MODEL,y,a.get('theta',a['initial'])))
    if f['best'] is not None:f['best']=profile_summary(f['best'])
    return plain(f)

def single(y):
    scores=[accepted.profile(y,TEMPLATES[:,i])['residual'] for i in range(len(GRID))]
    indices=sorted(range(len(GRID)),key=lambda i:(scores[i],i))[:CONTRACT['starts']]
    best,attempts=accepted.refine(MODEL,y,GRID[indices],maxiter=CONTRACT['maxiter'])
    theta=np.array([[best['q'],best['a']]])
    prof=evaluate(MODEL,y,theta)
    for a in attempts:
        a['theta']=[a['result']]
        a['final_profile']=profile_summary(evaluate(MODEL,y,[a['result']]))
    return {'status':'available' if prof['ok'] else prof['status'],'best':{**profile_summary(prof),'theta':theta.tolist(),'origin':best['origin'],'solver_success':best.get('solver_success')},'attempts':attempts,'grid_status':{'support_count':len(GRID),'best_grid_residual':min(scores)},'method':'accepted_single_profile_refine_shared25_grid'}

def sequential(y,P):
    r=y.copy();stages=[];theta=[];gains=[]
    for k in range(P):
        f=single(r);stages.append(f)
        if not f['best']['ok']:
            return {'status':'stage_failure','best':None,'stages':stages,'method':'sequential_single_target_cancellation'}
        t=np.array(f['best']['theta'][0]);z=complex(*f['best']['h'][0])
        theta.append(t);gains.append(z);r-=z*MODEL.action(*t)
    prof=evaluate(MODEL,y,theta)
    # The diagnostic joint fit is never used as sequential-cancellation gains.
    return {'status':'available','best':{'theta':plain(theta),'h':plain(gains),'residual':float(np.vdot(r,r).real),'origin':'sequential','ok':True},'final_joint_profile_diagnostic':profile_summary(prof),'stages':stages,'method':'sequential_single_target_cancellation_no_joint_refit'}

def matching(truth,estimated):
    truth=np.asarray(truth);estimated=np.asarray(estimated).reshape(-1,2)
    P=len(truth);K=len(estimated);tol=np.array([CONTRACT['match_tolerance_q'],CONTRACT['match_tolerance_a']])
    best=(-1,float('inf'),[])
    # All partial injective assignments: cardinality first, squared scaled error second.
    for count in range(min(P,K)+1):
      for ti in itertools.combinations(range(P),count):
       for ei in itertools.permutations(range(K),count):
        pairs=list(zip(ti,ei));delta=np.array([estimated[j]-truth[i] for i,j in pairs]).reshape(-1,2)
        if np.any(abs(delta)>tol+1e-14):continue
        cost=float(np.sum((delta/tol)**2))
        if count>best[0] or (count==best[0] and cost<best[1]):best=(count,cost,pairs)
    n,c,pairs=best
    errors=[(estimated[j]-truth[i]).tolist() for i,j in pairs]
    # Separate unrestricted min-distance assignment retains catastrophic errors.
    full=[];fullcost=float('inf')
    for ti in itertools.combinations(range(P),min(P,K)):
      for ei in itertools.permutations(range(K),min(P,K)):
        delta=[(estimated[j]-truth[i]).tolist() for i,j in zip(ti,ei)];cost=float(np.sum((np.array(delta)/tol)**2)) if delta else 0.
        if cost<fullcost:fullcost=cost;full=delta
    return {'truth_count':P,'estimate_count':K,'matched':n,'missed':P-n,'false':K-n,'all_target_success':n==P and K==P,'matched_pairs':pairs,'matched_errors':errors,'unrestricted_assignment_errors':full}

def make_observation(mode,scene_index,snr,frame):
    scene=CONTRACT['scenes'][scene_index];theta=np.array(scene['theta']);h=np.array([complex(*z) for z in scene['h']])
    signal=np.column_stack([MODEL.action(*t) for t in theta])@h
    variance=float(np.vdot(signal,signal).real/(64*10**(snr/10)))
    seed=[CONTRACT[mode]['namespace'],scene_index,snr,frame];rng=np.random.default_rng(np.random.SeedSequence(seed))
    w=(rng.normal(size=64)+1j*rng.normal(size=64))/np.sqrt(2)
    return signal+np.sqrt(variance)*w,variance,seed,w

def plan(mode):
    c=CONTRACT[mode]
    for scene_index,scene in enumerate(CONTRACT['scenes']):
        prefix='P2' if scene['P']==2 else 'P3'
        for snr in c[prefix+'_snr_db']:
            for frame in range(c[prefix+'_frames_per_cell']):yield scene_index,snr,frame

def run(mode):
    begin=time.perf_counter();out=ROOT/mode;out.mkdir(exist_ok=True)
    file=out/'records.jsonl.gz'
    if file.exists():raise RuntimeError('refuse overwrite existing outcomes')
    count=0;timing=[];raw={};summary={}
    with gzip.open(file,'wt',compresslevel=6) as handle:
      for si,snr,frame in plan(mode):
        t=time.perf_counter();scene=CONTRACT['scenes'][si];y,var,seed,w=make_observation(mode,si,snr,frame)
        methods={};durations={}
        for name,call in [('joint_known_P',lambda:joint(y,scene['P'])),('single_target_shared_grid',lambda:single(y)),('sequential_cancellation_known_P',lambda:sequential(y,scene['P']))]:
            mt=time.perf_counter()
            try:
                result=call();estimated=[] if result.get('best') is None else result['best']['theta']
                result['metrics']=matching(scene['theta'],estimated)
                if result.get('best') is not None:result['normalized_fit_residual']=result['best']['residual']/float(np.vdot(y,y).real)
            except Exception as e:
                result={'status':'exception','exception_type':type(e).__name__,'exception_message':str(e),'best':None,'metrics':matching(scene['theta'],[])}
            durations[name]=time.perf_counter()-mt;methods[name]=result
            key=f"{scene['name']}/{snr}/{name}";s=summary.setdefault(key,{'frames':0,'available':0,'all_target_success':0,'matched':0,'missed':0,'false':0,'truths':0,'estimates':0,'exceptions':0})
            s['frames']+=1;s['available']+=int(result.get('best') is not None);s['exceptions']+=int(result['status']=='exception')
            for k in ['all_target_success','matched','missed','false']:s[k]+=int(result['metrics'][k])
            s['truths']+=result['metrics']['truth_count'];s['estimates']+=result['metrics']['estimate_count']
        record={'frame_id':count,'scene_index':si,'scene':scene['name'],'P':scene['P'],'snr_db':snr,'frame':frame,'seed_sequence':seed,'noise_variance':var,'y_sha256':hashlib.sha256(y.tobytes()).hexdigest(),'methods':methods,'seconds_by_method':durations}
        handle.write(json.dumps(plain(record),separators=(',',':'),allow_nan=False)+'\n');count+=1;timing.append(time.perf_counter()-t)
        if frame==0:raw[f'y_{si}_{snr}']=y;raw[f'w_{si}_{snr}']=w
        if count%4==0:print(json.dumps({'mode':mode,'frames':count,'seconds':time.perf_counter()-begin}),flush=True)
    np.savez_compressed(out/'raw_replay.npz',x=X,grid=GRID,**raw)
    result={'mode':mode,'frames':count,'wall_seconds':time.perf_counter()-begin,'frame_seconds':timing,'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'record_bytes':file.stat().st_size,'raw_bytes':(out/'raw_replay.npz').stat().st_size,'summary':summary,'numpy':np.__version__,'contract_sha256':hashlib.sha256((ROOT/'contract.json').read_bytes()).hexdigest(),'core_sha256':hashlib.sha256((ROOT.parent/'joint_core.py').read_bytes()).hexdigest(),'runner_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    (out/'RESULTS.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ['summary','frame_seconds']},indent=2))
if __name__=='__main__':
    mode=sys.argv[1] if len(sys.argv)>1 else 'pilot'
    if mode not in ['pilot','main']:raise ValueError('pilot or main')
    run(mode)
