#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
OPENBLAS_NUM_THREADS=1 python tests/check_python_oracle.py
OPENBLAS_NUM_THREADS=1 python tests/check_high_precision.py
npm test
if [[ "${RUN_BENCHMARKS:-0}" == "1" ]]; then
  node tests/benchmark.mjs
  node tests/stress_worker.mjs
  node tests/profile_zero_pruning.mjs
fi
