# Independent corrected-source protocol / lifecycle review

Run: `node independent-review/protocol-corrected/probe-lifecycle.mjs` (Node v24.19.0)

Result: **passed**. 27/27 probe checks passed; 0 confirmed finding(s).

## Corrected-source findings

None.

## Verified lifecycle behavior

- All four original sparse-array cases now reject as invalid-input before hashing, and sparse channel-path arrays reject cleanly.
- Former tiny-channel failure H=1e-12 with y=64+64i now completes. Both it and the y=64+0i calibration regression agree with independently evaluated scalar posterior probabilities within 1e-12.
- A naturally reachable nonzero H=1e-200 residual-underflow case returns a clear numerical-failure after an actual MP-G iteration, then the Worker accepts a healthy run.
- All actual-Worker message kinds carry inputEncoding=sorted-key-json-js-v1, schemaVersion=otfs-communication-v1 and kernelVersion=0.2.0.
- Actual iterations were observed before cancellation at 1, 4, and 12, each repeated three times. Observed cancel-to-terminal maximum: 10.210 ms on this run, with no completion leakage.
- Cancellation/supersession produced a single terminal, bounded partial state, correct digest, and no subsequent progress. Real-Worker rapid replacement gave 39 superseded jobs and one completed newest job.
- Duplicate IDs were rejected during work and after completed, cancelled, superseded, and invalid jobs. Malformed protocol messages did not interrupt active valid work.
- Invalid-input, numerical-failure, and injected internal-error terminals were followed by successful fresh runs.
- Completion payloads preserved independently constructed receiver values and independently calculated canonical SHA-256 digests.
- Gate rejected stale IDs/digests and non-completed statuses, and immediate invalidation prevented acceptance.

## Edge observations (not asserted as defects without a stronger contract)

- A fresh run supersedes active work before receiver validation; an invalid replacement stops the previous useful run.
- Rejected receivers consume the 1000-job session budget. Beyond that budget a fresh Worker is required; duplicate-ID errors still take precedence.
- The gate is a trusted-object predicate, not schema validation or deduplication: null/undefined throw when an expectation is active; a matching minimal completion and repeated matching completion are accepted.
- Exported controller dependency-fault test injected a rejected timer-yield promise; no production source was mocked or edited.

## Frozen sources

- `src/kernel.mjs`: `80fad52c681d19eaa5d82a6b1d20dd329a6cf40d39c08cd92774f88118d8f1e7`
- `src/protocol.mjs`: `d7242dbe37ed8a060f2b14471538cd0920149aeb0a05aa16064996dfc572be9a`
- `src/node-worker.mjs`: `f7e2fd941ca3959f2d3259554bba36022c2972560c35bbf5e74b2cf147940a5d`

Hashes rechecked unchanged after probes. Full per-case evidence and transcripts: [results.json](results.json).

## Limits

- Real node:worker_threads Worker used unless test name says controller or result gate.
- Fixtures independently constructed; no simulation generator, test fixture, prerecorded numerical result, or browser was used.
- Only independent-review/protocol-corrected/ files were written. No source changes.
- Exactly-one-terminal checks include a 30–40 ms post-terminal observation plus all message order seen; no timing guarantee is inferred for arbitrary deployment hardware.
- Stale-result filter was tested as an exported consumer helper; there is no UI/browser lifecycle claim.
