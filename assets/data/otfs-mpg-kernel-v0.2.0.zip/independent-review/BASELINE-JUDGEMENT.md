# Independent review: original bounded JavaScript numerical port

## Judgement

**Do not accept the original frozen source for the entire advertised raw-input numerical domain yet.** Its ordinary-input equation transcription and real Worker lifecycle are well supported, but the full-LMMSE soft conversion has an inherited absolute variance floor that changes valid probabilities, and log normalization fails on otherwise simple valid inputs. Sparse-array malformed-input classification also needs tightening. These are concrete reproducible defects, not concerns about unimplemented browser/UI work.

Review scope: N≤3, M≤4, literal Eq14 P=1/2 operator construction, canonical QPSK/16-QAM, proper-complex v=E|w|², supplied perfect CSI, exact local MP-G constellation sums and full complex LMMSE with effective-AWGN calibration. Arbitrary raw H matrices test the receiver API; they are not all claimed realizable by two OTFS paths. No MP-Psi, sensing, browser, UI, deployment, or original paper-size claim is accepted here.

## Blocking numerical findings

1. **The 1e-15 denominator floor silently changes full-LMMSE probabilities.** With scalar QPSK H=1e-12, y=64+0i, and v=1e-6, residual variance is 1e-18. The port says `solved` but replaces that variance by 1e-15. Its probabilities differ from the direct scalar likelihood by 2.26049277755e-5. Independent 100-digit mpmath full-LMMSE and direct residual-likelihood calculations agree within 2.98e-92 across the scalar probes. This also occurs with smaller observations (H=2e-11, y=1 gives 4.24e-6 error).
2. **Large common scores cause avoidable normalization failures.** The same tiny H with y=64+64i produces `numerical-failure`; scalar H=16, y=1+0i or 64+0i, v=1e-6 causes both MP-G and LMMSE to fail despite simple exact tied posteriors. The implementation computes `x−(max+logsum)` rather than `(x−max)−logsum`. LMMSE additionally retains the symbol-independent |out|² inside the negative distance score. Among 103 valid raw receiver probes, MP-G returned 101 and failed 2; LMMSE returned 91 and failed 12. Failure statuses are honest, but this is an avoidable valid-domain reliability limitation.
3. **Sparse receiver arrays bypass validation.** Actual Worker structured cloning preserves holes. Sparse H row/cell produces `numerical-failure`, sparse y/constellation produces `internal-error`, instead of `invalid-input`. Worker remains usable afterward. Detailed evidence is in `protocol/README.md` and `protocol/results.json`.

The absolute floor also exists in the accepted frozen Python reference and the owner's independent NumPy formula. Thus numerical parity to that reference does not disprove finding 1. Correcting it should be documented as a bounded numerical correction rather than rewriting the reference or claiming universal unchanged parity.

Recommended repair: max-shift before final log-normalizer subtraction; cancel symbol-independent |out|² algebraically from LMMSE scores; use the actual positive residual variance, with an explicit zero-information branch; require own array indices in receiver validation. Re-review corrected source against these held inputs and high-precision results.

## What passed independently

- 48 fresh arbitrary complex H and independently arbitrary y cases spanning every N=1…3, M=1…4 and Q=4/16. They are neither generator draws nor fixtures. MP-G marginal error ≤5.33e-14, full-LMMSE marginal error ≤4.78e-14, against structurally different NumPy implementations
- The MP-G oracle forms pair factors from received column-symbol inner products and sums incoming cavity messages by neighbor exclusion. All 48 complete stored histories replayed: marginal error ≤5.33e-14, directed-message probability error ≤6.54e-14, delta error ≤1.29e-14. Status/iteration comparisons agreed wherever the port returned
- SVD-based full-LMMSE oracle checks gain, total interference-plus-filtered-noise variance, SINR, log probabilities, and probabilities. 31 selected cases also use independent 100-digit matrix algebra, including rank deficiency and full 12×12 complex systems
- Four independently constructed complex Gram trees (chain/star, QPSK/16-QAM) match exhaustive direct-observation marginals to ≤1.12e-15. Loopy counterexamples retain real gaps: 0.42343 QPSK and 0.0084404 16-QAM. Neither convergence nor a full matrix solve is mislabelled exact multiuser inference
- 58 operator challenges use independent DFT-basis/Kronecker assembly. Maximum entry error 7.95e-16; single-path unitarity error 5.56e-16. Includes negative/fractional Doppler, complex gains, q=0, integer q, both one-sided ceiling limits, near-frame-length delays, N=1/M=1, and column stacking
- Unitary receive-basis transformations, common H/y/noise scaling, and conjugation with QAM-label reversal preserve probabilities within 1.0e-15 in both methods
- Guard endpoints include v=1e-6/1000, H/y component ceilings, zero/rank-one/nearly-rank-one/full dense matrices, tiny columns, and all-pair E=66 budgets. Four explicitly out-of-bound H cases are rejected. Extreme arithmetic has larger floating-point errors than ordinary cases and is retained in the report rather than hidden
- Actual Node Worker cancellation after iterations 1/4/12, repeated three times; supersession after iteration 4; 40-job churn; duplicate IDs; one-terminal behavior; error recovery; receiver digests; and stale-result filtering. All 25 lifecycle checks behaved as expected, with the malformed-array finding retained. Maximum observed cancellation-to-terminal 8.047 ms in this run only

## Evidence and reproducibility

Commands from prototype root:

    OPENBLAS_NUM_THREADS=1 python independent-review/probe_raw_numerics.py
    OPENBLAS_NUM_THREADS=1 python independent-review/probe_high_precision.py
    node independent-review/protocol/probe-lifecycle.mjs

Artifacts:
- `probe-inputs.json`: all 165 held input probes (107 receiver, of which 103 valid, and 58 operator)
- `probe-js-results.json`: original actual JS outputs/errors, with before/after source hashes
- `numerical-report.json`: per-case independent errors, outcomes, exact gaps and invariances
- `high-precision-report.json`: 31 100-digit oracle cases and direct scalar likelihood evidence
- `protocol/`: original independent lifecycle script, actual message transcripts, finding and hashes
- `frozen-source/`: original source snapshot retained before owner correction

Runtime: Node v24.19.0, Python 3.12.14, NumPy 2.3.5, mpmath 1.3.0. Independent numeric seed 202610121638. No source or non-review folder was modified by this reviewer.

## Frozen reviewed source

- kernel.mjs: c5ff00fcfcc24b5006c846620de23d496eddefdba52a8552226936b4a1e4c06c
- protocol.mjs: e7f8c14a160d1ed53c8b96af956766b6c3e2fd0a2f63ea28db58bd9e8b267155
- node-worker.mjs: f7e2fd941ca3959f2d3259554bba36022c2972560c35bbf5e74b2cf147940a5d
- browser-worker.mjs: ddc639f67253409104e101aaef7bad6c5ce7d8ae51290619237c0d6a921d4ee5
- simulation.mjs: c7daa4e7c14e45ee6aa325755916b700c8071e5aaa50ec9dab26c07fb0a7f0fe
- Accepted reference core: 92b997201493a3187b5ddb37026672ef44e163131e422bdf8618f11b17aa235f

Hashes were rechecked unchanged during baseline numerical and protocol execution. `reference/FREEZE.json` and the supplied source/model audits were read; this review preserves their sampled-cyclic versus exact finite-waveform distinction. An owner correction after this freeze requires a separately identified addendum, not replacement of this baseline evidence.
