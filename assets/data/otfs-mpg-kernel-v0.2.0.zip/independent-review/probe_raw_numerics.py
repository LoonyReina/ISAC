"""Independent reviewer: arbitrary raw receivers, SVD-based full soft LMMSE,
column-product MP-G cavity replay, exhaustive tiny-state marginals, operator basis.
No reference implementation or owner oracle imports. Writes only this directory.
"""
import json, hashlib, itertools, math, subprocess, sys, os
from pathlib import Path
import numpy as np
PROBES=Path(__file__).resolve().parent
OUT=Path(os.environ.get("REVIEW_OUTPUT_DIR",str(PROBES))).resolve()
OUT.mkdir(parents=True,exist_ok=True)
ROOT=PROBES.parent
SEED=202610121638
rng=np.random.default_rng(SEED)

def enc(x):
    a=np.asarray(x)
    if a.ndim==0:return {'re':float(a.real),'im':float(a.imag)}
    return [enc(z) for z in a]
def dec(x):
    if isinstance(x,dict):return x['re']+1j*x['im']
    return np.array([dec(z) for z in x])
def norm(logw):
    shifted=logw-np.max(logw,axis=-1,keepdims=True)
    return shifted-np.log(np.exp(shifted).sum(axis=-1,keepdims=True))
def lse(x):
    m=np.max(x)
    return m+np.log(np.exp(x-m).sum())
def symbols(Q):
    levels=np.arange(1-int(np.sqrt(Q)),int(np.sqrt(Q)),2)
    return (levels[:,None]+1j*levels[None,:]).ravel()/np.sqrt(2*(Q-1)/3)
def make(id,N,M,H,y,v=.8,Q=4,**s):
    settings={'maxIterations':7,'tolerance':1e-10,'damping':.63,'edgeTolerance':1e-13,'captureHistory':True};settings.update(s)
    return {'id':id,'receiver':{'frame':{'N':N,'M':M},'H':enc(H),'y':enc(y),'noiseVariance':v,'constellation':enc(symbols(Q)),
       'model':'eq14_literal','csi':'perfect-supplied','settings':settings}}

def lm_svd(r):
    H,y,c=dec(r['H']),dec(r['y']),dec(r['constellation']);v=r['noiseVariance'];E=np.mean(abs(c)**2);D=len(y)
    U,s,Vh=np.linalg.svd(H,full_matrices=False)
    W=(Vh.conj().T*(s/(s*s+v/E)))@U.conj().T
    A=W@H;z=W@y;gain=np.diag(A);res=np.empty(D)
    for i in range(D):res[i]=E*np.sum(abs(np.delete(A[i],i))**2)+v*np.sum(abs(W[i])**2)
    lp=np.empty((D,len(c)));sinr=np.zeros(D)
    for i in range(D):
        if res[i]==0:lp[i]=np.full(len(c),-np.log(len(c)));continue
        # Cancel symbol-independent |z|² algebraically BEFORE score evaluation.
        target=gain[i]*c
        lp[i]=norm((2*np.real(z[i]*target.conj())-abs(target)**2)/res[i])
        sinr[i]=E*abs(gain[i])**2/res[i]
    return {'lp':lp,'p':np.exp(lp),'gain':gain,'res':res,'sinr':sinr,'W':W}

def mp_cavity(r):
    H,y,c=dec(r['H']),dec(r['y']),dec(r['constellation']);v=r['noiseVariance'];s=r['settings'];D=len(y);Q=len(c)
    G=H.conj().T@H;z=H.conj().T@y
    unary=norm((2*np.real(c.conj()[None,:]*z[:,None])-np.diag(G).real[:,None]*abs(c)[None,:]**2)/v)
    cut=s['edgeTolerance']*max(1,np.max(abs(G)))
    edges=[(a,b) for a in range(D) for b in range(a+1,D) if abs(G[a,b])>cut]
    neighbours={a:[] for a in range(D)};potential={}
    for a,b in edges:
        neighbours[a].append(b);neighbours[b].append(a)
        # Direct received symbol-vector inner products, not signed G scalar formula.
        Ha=H[:,a,None]*c[None,:];Hb=H[:,b,None]*c[None,:]
        potential[a,b]=-2*np.real(Ha.conj().T@Hb)/v
    msgs={(b,a):np.full(Q,-np.log(Q)) for a,b in edges for a,b in [(a,b),(b,a)]}
    beliefs=unary.copy();hist=[(beliefs.copy(),dict(msgs))];traces=[]
    status='max-iterations'
    for iteration in range(1,s['maxIterations']+1):
        nxt={}
        for a in range(D):
            for b in neighbours[a]:
                cavity=unary[a].copy()
                for k in neighbours[a]:
                    if k!=b:cavity+=msgs[k,a]
                pair=potential[a,b] if a<b else potential[b,a].T
                vec=norm(np.array([lse(cavity+pair[:,q]) for q in range(Q)]))
                if s['damping']<1:vec=np.logaddexp(np.log(s['damping'])+vec,np.log1p(-s['damping'])+msgs[a,b])
                nxt[a,b]=vec
        delta=max([np.max(abs(np.exp(nxt[e])-np.exp(msgs[e]))) for e in msgs] or [0.])
        nextbelief=unary.copy()
        for a in range(D):
            for b in neighbours[a]:nextbelief[a]+=nxt[b,a]
        nextbelief=norm(nextbelief);md=np.max(abs(np.exp(nextbelief)-np.exp(beliefs)))
        msgs=nxt;beliefs=nextbelief;traces.append([float(delta),float(md)]);hist.append((beliefs.copy(),dict(msgs)))
        if delta<s['tolerance']:status='converged';break
    return {'lp':beliefs,'p':np.exp(beliefs),'history':hist,'trace':traces,'edges':edges,'status':status,'G':G,'z':z}

def exact(r):
    H,y,c=dec(r['H']),dec(r['y']),dec(r['constellation']);D=len(y);v=r['noiseVariance']
    ids=np.array(list(itertools.product(range(len(c)),repeat=D)))
    assert len(ids)<=65536
    hx=H@c[ids].T
    # Direct received vectors with common ||y||² removed, valid even y is unusual.
    ll=norm((2*np.real(y.conj()@hx)-np.sum(abs(hx)**2,axis=0))/v)
    return np.array([[np.exp(lse(ll[ids[:,i]==q])) for q in range(len(c))] for i in range(D)])

def operator_basis(N,M,paths):
    # Kronecker basis synthesis: each DFT conjugation yields one finite-sum
    # circulant. This differs structurally from the port's four index loops.
    def circ(L,t):
        j=np.arange(L);F=np.exp(2j*np.pi*j[:,None]*j[None,:]/L)/np.sqrt(L)
        return F.conj().T@np.diag(np.exp(2j*np.pi*j*t/L))@F
    out=np.zeros((N*M,N*M),complex)
    for p in paths:
        q,a,h=p['delayBin'],p['dopplerBin'],dec(p['gain'])
        phase=[]
        for lp in range(M):
            for kp in range(N):
                crossing=int(lp>=M-math.ceil(q))
                phase.append(np.exp(2j*np.pi*(a*lp/(N*M)-crossing*(kp+a)/N)))
        out+=h*np.kron(circ(M,q),circ(N,a))@np.diag(phase)
    return out

cases=[]
# Independent raw H and y: y is NOT generated from constellation truth or a seed
# exposed to the receiver, and no channel generator is used here.
for N in range(1,4):
  for M in range(1,5):
    D=N*M
    for Q in [4,16]:
      for repeat in range(2):
        H=(rng.uniform(-1.5,1.5,(D,D))+1j*rng.uniform(-1.5,1.5,(D,D)))/np.sqrt(D)
        y=rng.uniform(-3,3,D)+1j*rng.uniform(-3,3,D)
        cases.append(make(f'raw-N{N}-M{M}-Q{Q}-{repeat}',N,M,H,y,v=[.17,4.8][repeat],Q=Q,damping=[1,.27][repeat]))
# Trees: exact Gram sparsity gives exact marginals after flooding reaches diameter.
for kind in ['chain','star']:
 for Q,D in [(4,4),(16,3)]:
    G=np.eye(D,dtype=complex)*1.3
    edges=[(i,i+1) for i in range(D-1)] if kind=='chain' else [(0,i) for i in range(1,D)]
    for i,j in edges:G[i,j]=.19+.17j;G[j,i]=G[i,j].conjugate()
    H=np.linalg.cholesky(G).conj().T;y=rng.normal(size=D)+1j*rng.normal(size=D)
    c=make(f'exact-{kind}-Q{Q}',1,D,H,y,v=.6,Q=Q,maxIterations=100,damping=1,edgeTolerance=1e-12);c['exact']='tree';cases.append(c)
for Q in [4,16]:
 D=3;H=(rng.normal(size=(D,D))+1j*rng.normal(size=(D,D)))/1.8;y=rng.normal(size=D)+1j*rng.normal(size=D)
 c=make(f'loopy-Q{Q}',1,D,H,y,v=.55,Q=Q,maxIterations=100,damping=.7);c['exact']='loopy';cases.append(c)
# LMMSE/MP-G edge and extreme scale. Some are deliberate numerical-failure probes.
for h in [0,1e-150,1e-12,1e-11,2e-11,1e-9,.01,16]:
 for y in [1+0j,64+0j,64+64j]:
    cases.append(make(f'scalar-h{h}-y{y}',1,1,np.array([[h+0j]]),np.array([y]),1e-6,4,maxIterations=2,damping=1))
for Q in [4,16]:
 for v in [1e-6,1000.]:
  for kind in ['rank-zero','rank-one','rank-nearly-one','outside-boundary','max-dense','weak-column']:
    D=12
    H=np.zeros((D,D),complex) if kind=='rank-zero' else np.full((D,D),16+16j)
    if kind=='rank-nearly-one':H+=np.eye(D)*(-1e-9-1e-9j)
    if kind=='outside-boundary':H+=np.eye(D)*(-1e-9+1e-9j)
    if kind=='max-dense':H=16*rng.choice([-1,1],(D,D))+16j*rng.choice([-1,1],(D,D))
    if kind=='weak-column':H=np.eye(D,dtype=complex);H[:,0]*=1e-11
    y=np.full(D,64+64j)
    cases.append(make(f'{kind}-Q{Q}-v{v}',3,4,H,y,v,Q,maxIterations=3,captureHistory=False))
# Invariance transformations use independently arbitrary arrays with well-resolved soft outputs.
base=make('transform-base',2,3,(rng.normal(size=(6,6))+1j*rng.normal(size=(6,6)))/3,rng.normal(size=6)+1j*rng.normal(size=6),.9,16,maxIterations=12,damping=.53)
cases.append(base)
H,y=dec(base['receiver']['H']),dec(base['receiver']['y']);U=np.linalg.qr(rng.normal(size=(6,6))+1j*rng.normal(size=(6,6)))[0]
for name,HH,yy,v in [('unitary-rows',U@H,U@y,.9),('scale-small',H*.01,y*.01,.9e-4),('scale-large',H*10,y*10,90),('conjugation',H.conj(),y.conj(),.9)]:
 cases.append(make(name,2,3,HH,yy,v,16,maxIterations=12,damping=.53))
# Signs, stacking, and both one-sided ceiling limits, including degeneracies N/M=1.
for N,M in [(1,1),(1,4),(3,1),(2,3),(3,4)]:
 for q in sorted(set([0.,1e-10,.3,min(1-1e-10,M-1e-10),min(1.,M-1e-10),min(1+1e-10,M-1e-10),M-1e-10])):
  for P in [1,2]:
    paths=[{'delayBin':q,'dopplerBin':-.71*N,'gain':enc(.71+.23j)}]
    if P==2:paths.append({'delayBin':.7*M,'dopplerBin':.43*N,'gain':enc(-.31+.14j)})
    cases.append({'id':f'operator-N{N}-M{M}-q{q}-P{P}','frame':{'N':N,'M':M},'paths':paths})
(OUT/'probe-inputs.json').write_text(json.dumps(cases,allow_nan=False))
subprocess.run(['node',str(PROBES/'run_probe_cases.mjs'),str(OUT/'probe-inputs.json'),str(OUT/'probe-js-results.json')],check=True)
outputs=json.loads((OUT/'probe-js-results.json').read_text())
assert outputs['before']==outputs['after']
assert outputs['before']['reference/otfs_reference.py']=='92b997201493a3187b5ddb37026672ef44e163131e422bdf8618f11b17aa235f'
findings=[]
def err(a,b):return float(np.max(abs(np.array(a)-np.array(b)))) if np.size(a) else 0.
for case,j in zip(cases,outputs['cases']):
 f={'id':case['id']}
 if 'paths' in case:
    N,M=case['frame'].values();oracle=operator_basis(N,M,case['paths']);f['operatorError']=err(dec(j['channel']['value']),oracle)
    if len(case['paths'])==1:
      h=dec(case['paths'][0]['gain']);f['unitarityError']=err(oracle.conj().T@oracle,abs(h)**2*np.eye(N*M))
 else:
    r=case['receiver'];f['validation']=j['validation']['status'];f['mpgStatus']=j['mpg']['status'];f['lmmseStatus']=j['lmmse']['status'];lm=lm_svd(r)
    if j['lmmse']['status']=='returned':
      l=j['lmmse']['value'];f.update({'lmmseProbabilityError':err(l['probabilities'],lm['p']),'lmmseLogError':err(l['logProbabilities'],lm['lp']),
      'lmmseGainError':err(dec(l['gain']),lm['gain']),'lmmseResidualError':err(l['residualVariance'],lm['res']),
      'lmmseSinrScaledError':err(np.array(l['effectiveSinr'])/(1+lm['sinr']),lm['sinr']/(1+lm['sinr'])),'minimumResidual':float(np.min(lm['res']))})
    else:f['lmmseError']=j['lmmse']
    if j['mpg']['status']=='returned':
      p=j['mpg']['value'];mp=mp_cavity(r);f.update({'mpgProbabilityError':err(p['probabilities'],mp['p']),'mpgLogError':err(p['logProbabilities'],mp['lp']),
         'mpgStatusMatches':p['status']==mp['status'],'mpgIterationsMatches':p['iterations']==len(mp['trace']),'mpgTraceError':err([[t['messageDelta'],t['marginalDelta']] for t in p['trace']],mp['trace']),
         'gramError':err(dec(p['graph']['G']),mp['G']),'zError':err(dec(p['graph']['z']),mp['z']),'edgeCount':p['graph']['edgeCount']})
      assert [(e['i'],e['j']) for e in p['graph']['edges']]==mp['edges']
      if r['settings']['captureHistory']:
        assert len(p['history'])==len(mp['history'])
        hp=[];hm=[]
        for actual,(lp,msg) in zip(p['history'],mp['history']):
          hp.append(err(actual['probabilities'],np.exp(lp)))
          ordered=np.array([msg[a,b] for i,j in mp['edges'] for a,b in [(j,i),(i,j)]])
          hm.append(err(np.exp(actual['incomingLogMessages']),np.exp(ordered)))
        f['historyMarginalError']=max(hp);f['historyMessageError']=max(hm)
      if 'exact' in case:
        e=exact(r);f['exactKind']=case['exact'];f['mpgExactGap']=err(p['probabilities'],e);f['lmmseExactGap']=err(j['lmmse']['value']['probabilities'],e)
    else:f['mpgError']=j['mpg']
 findings.append(f)
lookup={c['id']:c for c in outputs['cases']};invariances={}
base=lookup['transform-base']
for name in ['unitary-rows','scale-small','scale-large','conjugation']:
 p=lookup[name];iv={}
 for method in ['mpg','lmmse']:
    bp=np.array(base[method]['value']['probabilities']);pp=np.array(p[method]['value']['probabilities'])
    if name=='conjugation':pp=pp.reshape(6,4,4)[:,:,::-1].reshape(6,16)
    iv[method]=err(bp,pp)
 invariances[name]=iv
maxima={k:max(f.get(k,0) for f in findings) for k in ['operatorError','unitarityError','mpgProbabilityError','mpgLogError','mpgTraceError','historyMarginalError','historyMessageError','lmmseProbabilityError','lmmseLogError','lmmseGainError','lmmseResidualError','lmmseSinrScaledError']}
report={'sourceHashes':outputs['before'],'seed':SEED,'python':sys.version.split()[0],'numpy':np.__version__,'caseCount':len(cases),'receiverCases':sum('receiver' in c for c in cases),'operatorCases':sum('paths' in c for c in cases),
 'maxima':maxima,'invariances':invariances,'findings':findings,
 'scope':'Independent raw solver validation does not claim every H is realizable by P<=2 OTFS paths. SVD full LMMSE and effective-AWGN probabilities checked without inherited residual floor. No browser execution or release claim.'}
(OUT/'numerical-report.json').write_text(json.dumps(report,indent=2,allow_nan=False))
print(json.dumps({k:v for k,v in report.items() if k not in ['findings','scope']},indent=2))
