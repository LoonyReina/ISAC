"""100-digit direct-likelihood/scalar and full LMMSE challenge, independent of NumPy solve."""
import json,hashlib,os
from pathlib import Path
import mpmath as mp
OUT=Path(os.environ.get("REVIEW_OUTPUT_DIR",str(Path(__file__).resolve().parent))).resolve()
mp.mp.dps=100
cases=json.loads((OUT/'probe-inputs.json').read_text());results=json.loads((OUT/'probe-js-results.json').read_text())
byid={c['id']:c for c in results['cases']}
def c(z):return mp.mpc(mp.mpf(str(z['re'])),mp.mpf(str(z['im'])))
def mat(a):return mp.matrix([[c(z) for z in r] for r in a])
def norm(vals):
 m=max(vals);shift=[z-m for z in vals];lse=mp.log(sum(mp.exp(z) for z in shift));return [z-lse for z in shift]
def error(a,b):return max([abs(mp.mpf(str(x))-y) for x,y in zip(a,b)] or [mp.mpf(0)])
selected=[x for x in cases if x['id'].startswith('scalar-') or x['id'] in ['raw-N3-M4-Q16-0','raw-N2-M3-Q16-1','rank-one-Q4-v1e-06','rank-nearly-one-Q16-v1e-06','max-dense-Q4-v1e-06','exact-chain-Q16','loopy-Q4']]
report=[]
for case in selected:
 r=case['receiver'];H=mat(r['H']);y=mp.matrix([c(z) for z in r['y']]);const=[c(z) for z in r['constellation']];v=mp.mpf(str(r['noiseVariance']));D=H.rows;E=sum(abs(z)**2 for z in const)/len(const)
 W=(H.H*H+v/E*mp.eye(D))**-1*H.H;A=W*H;out=W*y
 lp=[];res=[];gain=[]
 for i in range(D):
  gain.append(A[i,i]);res.append(E*sum(abs(A[i,j])**2 for j in range(D) if j!=i)+v*sum(abs(W[i,j])**2 for j in range(D)))
  if res[-1]==0:lp.append([-mp.log(len(const))]*len(const))
  else:lp.append(norm([(2*mp.re(out[i]*mp.conj(gain[-1]*z))-abs(gain[-1]*z)**2)/res[-1] for z in const]))
 result={'id':case['id'],'decimalPrecision':100,'minimumResidual':str(min(res)),'oracleProbabilities':[[str(mp.exp(z)) for z in row] for row in lp]}
 js=byid[case['id']]
 if js['lmmse']['status']=='returned':
  l=js['lmmse']['value'];result['lmmseProbabilityError']=float(max(error(a,[mp.exp(z) for z in b]) for a,b in zip(l['probabilities'],lp)));result['lmmseLogError']=float(max(error(a,b) for a,b in zip(l['logProbabilities'],lp)))
  result['lmmseLogScaledError']=float(max(abs(mp.mpf(str(a))-b)/(1+abs(b)) for ar,br in zip(l['logProbabilities'],lp) for a,b in zip(ar,br)))
  result['lmmseGainError']=float(max(abs(c(a)-b) for a,b in zip(l['gain'],gain)))
  result['lmmseResidualError']=float(error(l['residualVariance'],res))
 else:result['lmmseError']=js['lmmse']
 if D==1:
  # Independent direct residual, includes |y|²; 100 digits makes that safe.
  direct=norm([-abs(y[0]-H[0,0]*z)**2/v for z in const])
  result['calibratedLMMSEVersusDirectScalar']=str(error([str(mp.exp(z)) for z in lp[0]],[mp.exp(z) for z in direct]))
  result['directProbabilities']=[str(mp.exp(z)) for z in direct]
  if js['mpg']['status']=='returned':result['mpgProbabilityError']=float(error(js['mpg']['value']['probabilities'][0],[mp.exp(z) for z in direct]))
 report.append(result)
(OUT/'high-precision-report.json').write_text(json.dumps({'mpmath':mp.__version__,'sourceHashes':results['before'],'caseCount':len(selected),'findings':report},indent=2))
print(json.dumps({'caseCount':len(selected),'maxLmmseProbabilityError':max(r.get('lmmseProbabilityError',0) for r in report),'caseIds':[r['id'] for r in report]},indent=2))
