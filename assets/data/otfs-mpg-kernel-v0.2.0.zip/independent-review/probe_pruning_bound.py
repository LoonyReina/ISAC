"""Independent check of dropped-Gram exact-density bound; never a BP bound."""
import json,itertools,hashlib
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parent.parent;OUT=ROOT/'independent-review/corrected'
def dec(a):return a['re']+1j*a['im'] if isinstance(a,dict) else np.array([dec(x) for x in a])
def lse(a):
 m=np.max(a);return m+np.log(np.exp(a-m).sum())
def norm(a):
 a=a-np.max(a);return a-np.log(np.exp(a).sum())
def qam(Q):
 n=int(np.sqrt(Q));s=np.arange(1-n,n,2);return (s[:,None]+1j*s[None,:]).ravel()/np.sqrt(2*(Q-1)/3)
results=[]
def assess(name,G,z,v,C,retained,reported=None):
 D=len(z);edges=[(i,j) for i in range(D) for j in range(i+1,D)];drop=[e for e in edges if e not in retained];ids=np.array(list(itertools.product(range(len(C)),repeat=D)));X=C[ids];Cmax2=float(np.max(abs(C)**2))
 F=float(np.sqrt(2*sum(abs(G[i,j])**2 for i,j in drop)));B=2*Cmax2/v*sum(abs(G[i,j]) for i,j in drop);BF=2*Cmax2/v*np.sqrt(len(drop)/2)*F
 # Separate omitted factors directly; this avoids subtracting huge joint energies.
 delta=-2/v*sum([np.real(X[:,i].conj()*G[i,j]*X[:,j]) for i,j in drop],start=np.zeros(len(ids)))
 unary=2/v*np.real(X.conj()@z)-np.sum(abs(X)**2*np.diag(G).real,axis=1)/v
 keep=-2/v*sum([np.real(X[:,i].conj()*G[i,j]*X[:,j]) for i,j in retained],start=np.zeros(len(ids)))
 lp_keep=norm(unary+keep);log_Z_ratio=lse(lp_keep+delta);joint_ratio=delta-log_Z_ratio
 marginal_ratios=[]
 for i in range(D):
  for a in range(len(C)):
   mask=ids[:,i]==a
   # Conditional exponential tilt, stable even if a marginal is tiny.
   cond=norm(lp_keep[mask]);marginal_ratios.append(lse(cond+delta[mask])-log_Z_ratio)
 eps=2e-12*(1+BF)
 assert B<=BF+eps and np.max(abs(delta))<=B+eps
 assert np.max(abs(joint_ratio))<=2*B+eps
 assert max(abs(x) for x in marginal_ratios)<=2*B+eps
 if reported:
  assert len(drop)==D*(D-1)//2-reported['edgeCount']
  assert abs(F-reported['removedGramFrobenius'])<1e-22
 result={'id':name,'Q':len(C),'D':D,'Edrop':len(drop),'CmaxSquared':Cmax2,'removedGramFrobenius':F,'B_direct':float(B),'B_frobenius':float(BF),
 'maxUnnormalizedLogWeightDifference':float(np.max(abs(delta))),'maxNormalizedJointLogRatio':float(np.max(abs(joint_ratio))),'maxNormalizedMarginalLogRatio':float(max(abs(x) for x in marginal_ratios))}
 results.append(result)

inputs=json.loads((OUT/'pruning-inputs.json').read_text());actual=json.loads((OUT/'pruning-js-results.json').read_text())
for case,output in zip(inputs,actual['cases']):
 r=case['receiver'];H,y,C=dec(r['H']),dec(r['y']),dec(r['constellation']);g=output['mpg']['value']['graph'];G=H.conj().T@H
 assess(case['id'],G,H.conj().T@y,r['noiseVariance'],C,[(e['i'],e['j']) for e in g['edges']],g)
# Independent synthetic matrices exercise both QAM radii, tight Cauchy equality,
# general complex phases, partial omission, and no omitted edges.
for Q in [4,16]:
 for kind in ['aligned-tight','complex-partial','none']:
  G=np.eye(3,dtype=complex)*2
  for i,j in [(0,1),(0,2),(1,2)]:G[i,j]=.13 if kind=='aligned-tight' else (.09+.035j)*(i+j+1);G[j,i]=G[i,j].conjugate()
  kept=[] if kind=='aligned-tight' else [(0,2)] if kind=='complex-partial' else [(0,1),(0,2),(1,2)]
  assess('synthetic-'+kind+'-Q'+str(Q),G,np.array([.21+.32j,-.43+.1j,.08-.19j]),.7,qam(Q),kept)
  if kind=='aligned-tight':
   last=results[-1];assert abs(last['B_direct']-last['B_frobenius'])<1e-12;assert abs(last['B_direct']-last['maxUnnormalizedLogWeightDifference'])<1e-12

profile=json.loads((ROOT/'evidence/zero-pruning-runtime.json').read_text());records=profile['records']
assert len(records)==12 and all(r['edgeTolerance']==0 and r['edgeCount']==66 and r['exactUnnormalizedLogWeightBound']==0 for r in records)
summary={'status':'accepted-exact-distribution-bound-not-BP-sensitivity','caseCount':len(results),'findings':results,
 'ownerZeroPruningEvidenceChecked':{'cases':len(records),'maxObservedNodeStartupThroughTransferMs':max(r['startupThroughTransferMs'] for r in records),'retainedCaps':sum(r['status']=='max-iterations' for r in records),
 'maxP1NoiseScaledPairCoefficient':max(r['largestNoiseScaledPairCoefficient'] for r in records if r['P']==1),'maxP1MPvsLMMSE':max(r['singlePathMPvsLMMSE'] for r in records if r['P']==1)},
 'sourceHashes':actual['before'],'zeroPruningProfileSHA256':hashlib.sha256((ROOT/'evidence/zero-pruning-runtime.json').read_bytes()).hexdigest(),
 'note':'Algebraic real-arithmetic bound. Values evaluated in double precision are diagnostics, not outward-rounded interval certificates. No loopy BP output/convergence bound follows.'}
(OUT/'pruning-bound-report.json').write_text(json.dumps(summary,indent=2));print(json.dumps({k:v for k,v in summary.items() if k not in ['findings','sourceHashes']},indent=2))
