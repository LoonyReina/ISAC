"""Check disclosed Gram pruning threshold and removed-coupling ledger, including
an ill-scaled raw receiver where a relatively small G entry matters to likelihood."""
import json,subprocess,itertools
from pathlib import Path
import numpy as np
OUT=Path(__file__).resolve().parent/'corrected'
base=json.loads((OUT/'probe-inputs.json').read_text())[0]['receiver']
def enc(a):
 a=np.asarray(a)
 return {'re':float(a.real),'im':float(a.imag)} if a.ndim==0 else [enc(x) for x in a]
def dec(a):return a['re']+1j*a['im'] if isinstance(a,dict) else np.array([dec(x) for x in a])
def norm(a):
 a=a-np.max(a);return a-np.log(np.exp(a).sum())
cases=[]
for rel in [0,.5,.99,1.01]:
 for tol in [0,1e-12]:
  r=json.loads(json.dumps(base));r['frame']={'N':1,'M':2};r['H']=enc(np.array([[16,16*1e-12*rel*(1+.5j)/np.sqrt(1.25)],[0,16]],complex));r['y']=enc([1e-8+2e-8j,-1.5e-8+.5e-8j]);r['noiseVariance']=1e-6;r['settings'].update(edgeTolerance=tol,maxIterations=10,damping=1,tolerance=1e-14)
  cases.append({'id':f'pruning-{rel}-{tol}','receiver':r})
(OUT/'pruning-inputs.json').write_text(json.dumps(cases))
subprocess.run(['node',str(OUT.parent/'run_probe_cases.mjs'),str(OUT/'pruning-inputs.json'),str(OUT/'pruning-js-results.json')],check=True)
actual=json.loads((OUT/'pruning-js-results.json').read_text())['cases'];report=[]
for case,js in zip(cases,actual):
 r=case['receiver'];H,y,C=dec(r['H']),dec(r['y']),dec(r['constellation']);G=H.conj().T@H;z=H.conj().T@y;v=r['noiseVariance'];ids=np.array(list(itertools.product(range(4),repeat=2)))
 # Remove symbol-independent QPSK diagonal energy before enumeration to avoid
 # cancellation against huge Gii/v. Retain all pair interactions, no pruning.
 x=C[ids];logits=2*np.real(x.conj()@z)/v-2*np.real(x[:,0].conj()*G[0,1]*x[:,1])/v;weights=np.exp(norm(logits));p=np.array([[weights[ids[:,i]==q].sum() for q in range(4)] for i in range(2)])
 m=js['mpg']['value'];graph=m['graph'];expectedCut=r['settings']['edgeTolerance']*max(1,np.max(abs(G)));expectedEdges=int(abs(G[0,1])>expectedCut);removed=np.sqrt(2)*abs(G[0,1]) if not expectedEdges else 0
 assert graph['edgeCount']==expectedEdges;assert abs(graph['removedGramFrobenius']-removed)<1e-22
 report.append({'id':case['id'],'edgeCount':graph['edgeCount'],'cutoff':graph['cutoff'],'removedGramFrobenius':graph['removedGramFrobenius'],'unprunedExactGap':float(np.max(abs(np.array(m['probabilities'])-p)))})
(OUT/'pruning-report.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
