"""Acceptance assertions for the corrected, held-input independent review."""
import hashlib,json
from pathlib import Path
R=Path(__file__).resolve().parent;ROOT=R.parent;C=R/'corrected'
n=json.loads((C/'numerical-report.json').read_text());h=json.loads((C/'high-precision-report.json').read_text());m=json.loads((C/'mpg-high-precision-report.json').read_text());checks=[]
def check(name,condition):
 assert condition,name
 checks.append(name)
check('original held inputs preserved',json.loads((R/'probe-inputs.json').read_text())==json.loads((C/'probe-inputs.json').read_text()))
check('reviewed source hashes unchanged',all(hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==v for p,v in n['sourceHashes'].items()))
check('fixed accepted reference core unchanged',n['sourceHashes']['reference/otfs_reference.py']=='92b997201493a3187b5ddb37026672ef44e163131e422bdf8618f11b17aa235f')
valid=[f for f in n['findings'] if f.get('validation')=='returned'];invalid=[f for f in n['findings'] if f.get('validation')=='threw']
check('103 valid raw receivers complete both methods',len(valid)==103 and all(f['mpgStatus']==f['lmmseStatus']=='returned' for f in valid))
check('4 out-of-bound receiver cases rejected',len(invalid)==4 and all(f['mpgError']['code']==f['lmmseError']['code']=='invalid-input' for f in invalid))
check('all MP statuses and iterations match replay',all(f['mpgStatusMatches'] and f['mpgIterationsMatches'] for f in valid))
ordinary=[f for f in valid if f['id'].startswith('raw-')]
check('48 ordinary arbitrary H/y soft outputs and computed histories within1e-10',len(ordinary)==48 and all(f[k]<1e-10 for f in ordinary for k in ['mpgProbabilityError','lmmseProbabilityError','historyMarginalError','historyMessageError','mpgTraceError']))
check('58 operator cases within1e-13',sum('operatorError' in f for f in n['findings'])==58 and n['maxima']['operatorError']<1e-13)
check('four complex trees agree with exhaustive likelihood',sum(f.get('exactKind')=='tree' for f in valid)==4 and all(f['mpgExactGap']<1e-12 for f in valid if f.get('exactKind')=='tree'))
check('loopy approximation discrepancy retained',all(f['mpgExactGap']>1e-3 for f in valid if f.get('exactKind')=='loopy'))
check('31 high precision full-LMMSE cases within1e-12 probability',h['caseCount']==31 and all(f['lmmseProbabilityError']<1e-12 for f in h['findings']))
check('high precision full-LMMSE scaled logs within1e-10',all(f['lmmseLogScaledError']<1e-10 for f in h['findings']))
check('4 high precision MP cases within1e-7 under extreme scale',len(m['findings'])==4 and all(f['probabilityError']<1e-7 and f['traceError']<1e-7 for f in m['findings']))
check('unitary/scale/conjugation invariance within1e-12',all(v<1e-12 for case in n['invariances'].values() for v in case.values()))
p=json.loads((C/'pruning-report.json').read_text())
check('pruning ledger challenge retained with non-negligible gap',len(p)==8 and max(x['unprunedExactGap'] for x in p)>4e-5)
result={'status':'passed-bounded-with-disclosed-numerical-limits','checkCount':len(checks),'checks':checks,'sourceHashes':n['sourceHashes']}
(C/'acceptance-checks.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
