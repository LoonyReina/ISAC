# Independent judgement: corrected bounded MP-G/full-LMMSE port

## Decision

**Accept kernel 0.2.0 as an independently checked bounded numerical/Node Worker prototype, with the numerical and pruning limits below.** The three original findings are repaired and independently re-tested. This does not approve browser behavior, UI, deployment, paper-size execution, sensing, MP-Psi, or equivalence to an exact finite rectangular waveform.

The original rejection, inputs, outputs and source snapshots remain in `BASELINE-JUDGEMENT.md`, the top-level JSON artifacts, `protocol/`, and `frozen-source/`. Corrected results are separate under `corrected/` and `protocol-corrected/`. The accepted Python reference was not modified; removal of its inherited variance floor is a disclosed port correction, validated independently rather than justified by reference parity.

## Corrected findings and verification

- All 103 valid raw receivers now complete both detectors; all four deliberately out-of-range receivers reject as invalid-input. The exact same 165 baseline inputs were replayed (107 receiver plus 58 operator cases)
- Independent 31-case 100-digit full-complex-LMMSE/direct-scalar oracle: maximum probability error **1.17e-15**, versus the baseline defect of 2.26e-5. The formerly failing tiny-channel and high-score tied-posterior cases now work
- Across 48 ordinary fresh arbitrary H/y cases, MP-G probability error ≤2.97e-14 and full-LMMSE probability error ≤4.85e-14. H and y were independently chosen, never generated from hidden transmitted symbols
- Every captured MP-G history is genuinely recomputed by an independent cavity implementation: probability history error ≤3.51e-14, directed-message probability error ≤3.32e-14. Status/iteration comparisons agree on all valid returned cases
- Four complex chain/star trees agree with exhaustive marginals to ≤1.12e-15. The two loopy examples retain exact-posterior gaps of approximately 0.4234 and 0.00844; convergence is not exact inference
- 58 independent basis-assembled operator cases agree to ≤7.95e-16. Fractional signs, complex gains, column stacking, both ceiling branches, endpoint degeneracies and single-path unitarity are covered
- Unitary row mixing, common scale changes and conjugation/label reversal preserve probabilities to ≤6.11e-16
- Corrected real Worker audit: **27/27 checks pass**, no remaining confirmed lifecycle defect. Sparse inputs reject before hashing; cancellation after iterations 1/4/12, supersession after iteration 4, 40-job churn, duplicate IDs, one-terminal behavior, recovery and stale filtering all pass. Actual maximum cancellation-to-terminal was 10.210 ms in this run only
- Digests use the explicitly identified sorted-key-json-js-v1 encoding. Cross-language ordinary JSON serializers are not claimed byte-equivalent

`corrected/acceptance-checks.json` contains 15 explicit reviewer acceptance assertions. No production source was changed by this reviewer.

## Limits that must remain visible

1. **Exact local sums are on the retained Gram graph.** The allowed edgeTolerance is a real approximation parameter. Eight additional pruning probes verify cutoff/edge/removed-Gram metadata. At H components near 16 and v=1e-6, pruning a 2.53e-10 Gram coupling at tolerance 1e-12 changes a two-variable exact marginal by 4.27e-5. Setting tolerance zero retains that edge (remaining error ~4.8e-9 from double-precision common-energy cancellation). The small relative Gram threshold is not a universal negligible-posterior-error bound
2. **Double-precision accuracy varies with scale and conditioning.** Four 100-digit MP-G challenges include full dense extreme input: worst marginal error 4.65e-9 and trace error 2.17e-8. Ordinary cases are far more accurate. Full LMMSE at a nearly rank-one 12×12 matrix with minimum variance has gain error 6.13e-7 and residual-variance error 1.13e-6 against 100-digit algebra; final soft probabilities still agree within 1.17e-15 in the high-precision set. Small linear residual does not independently certify small forward error in every intermediate quantity
3. **Large-magnitude log probabilities require scaled error interpretation.** Full-LMMSE worst absolute log error is 2.11e-4 at an extreme input, but worst |error|/(1+|logp|) is 6.23e-13; probabilities there are saturated. Do not claim uniformly machine-precision absolute logs across every allowed scale
4. **Extremely subnormal information can produce an explicit numerical-failure.** Natural H=1e-200, y=1, v=.3 reaches a nonzero filter whose squared residual underflows. It now reports that condition rather than silently returning miscalibrated certainty or pretending exact zero information. The Worker recovers. Zero H itself remains uniform
5. **Lifecycle helper boundaries remain intentional.** The consumer gate is a trusted completion-record predicate, not a full schema validator or deduplicator. An invalid fresh run supersedes the previous active run before receiver validation. These behaviors were observed and are not hidden; a future UI must apply the documented consumer contract
6. Supplied arbitrary H tests validate the receiver algebra, not physical two-path realizability. Literal Eq14 remains the declared sampled cyclic/right-endpoint/negative-carrier/shifted-origin model. Effective-AWGN LMMSE is a calibrated linear surrogate, not exact multiuser posterior inference

## Reproduce corrected review

From prototype root:

    REVIEW_OUTPUT_DIR=independent-review/corrected OPENBLAS_NUM_THREADS=1 python independent-review/probe_raw_numerics.py
    REVIEW_OUTPUT_DIR=independent-review/corrected OPENBLAS_NUM_THREADS=1 python independent-review/probe_high_precision.py
    REVIEW_OUTPUT_DIR=independent-review/corrected OPENBLAS_NUM_THREADS=1 python independent-review/probe_mpg_high_precision.py
    OPENBLAS_NUM_THREADS=1 python independent-review/probe_pruning.py
    OPENBLAS_NUM_THREADS=1 python independent-review/assess_corrected.py
    node independent-review/protocol-corrected/probe-lifecycle.mjs

Numeric seed: 202610121638. Node v24.19.0; Python 3.12.14; NumPy 2.3.5; mpmath 1.3.0. All reviewer writes are inside `independent-review/`. Baseline files are retained rather than overwritten by these corrected commands.

## Frozen accepted source hashes

- src/kernel.mjs: **80fad52c681d19eaa5d82a6b1d20dd329a6cf40d39c08cd92774f88118d8f1e7**
- src/protocol.mjs: **d7242dbe37ed8a060f2b14471538cd0920149aeb0a05aa16064996dfc572be9a**
- src/node-worker.mjs: f7e2fd941ca3959f2d3259554bba36022c2972560c35bbf5e74b2cf147940a5d
- src/browser-worker.mjs: ddc639f67253409104e101aaef7bad6c5ce7d8ae51290619237c0d6a921d4ee5
- src/simulation.mjs: 17fa68083040da01023d976acb42cd7ab69a9ba490844a02013b6e00c86f3940
- reference/otfs_reference.py: **92b997201493a3187b5ddb37026672ef44e163131e422bdf8618f11b17aa235f**

Source hashes were checked before/after numerical and lifecycle runs, and again by the final acceptance assertions. Corrected source snapshots are retained under `corrected/frozen-source/`.

## Addendum: accepted exact-distribution pruning bound

**Accepted, with the stated factors and scope.** Let CmaxSquared=max over constellation symbols of |c|², and let S be the omitted undirected Gram pairs. Full and retained-graph unnormalized log weights differ by

    Δ(x) = −(2/v) Σ_(i,j in S) Re(conj(x_i) G_ij x_j).

Because |conj(x_i)x_j|≤CmaxSquared, |Δ(x)|≤B where

    B = (2*CmaxSquared/v) Σ_(i,j in S) |G_ij|
      ≤ (2*CmaxSquared/v) sqrt(Edrop/2) * removedGramFrobenius.

The factor sqrt(Edrop/2) is correct: the kernel accumulates `removed2 += 2*|Gij|²`, so the reported Frobenius norm includes both Hermitian entries, whereas Edrop=D(D−1)/2−edgeCount counts undirected omitted pairs. Exact zero pairs may be counted in Edrop; that only loosens the Cauchy–Schwarz bound. If no nonzero coupling is dropped, B=0.

For the two **exact** distributions with the same unary/prior factors, exp(−B)≤w_full/w_retained≤exp(B). Their partition-function ratio is also in that interval. Therefore the absolute normalized joint log-probability ratio is at most **2B**. Summing those pointwise probability inequalities over all states with a fixed coordinate value gives the same **2B** bound on every exact marginal log-probability ratio. This does not bound the difference between either distribution and loopy BP, the sensitivity of BP outputs to pruning, convergence, stopping iteration, or floating-point error. In finite precision, the displayed formula is a diagnostic rather than an outward-rounded interval certificate.

Independent verification: `probe_pruning_bound.py` checks all eight held kernel pruning cases and six synthetic QPSK/16-QAM examples, including complex partial omission, no omission, and aligned equal couplings that attain both the unnormalized bound and the Cauchy–Schwarz step. **14/14 checks pass.** Artifact: `corrected/pruning-bound-report.json`. Reproduce with `OPENBLAS_NUM_THREADS=1 python independent-review/probe_pruning_bound.py`.

The owner's zero-pruning profile script and saved evidence were also read and checked, without re-running or changing them: 12 actual Node Worker cases completed, maximum observed startup-through-transfer 177.238 ms; two MP-G iteration-cap outcomes remain explicitly retained. All cases use edgeTolerance=0 and E=66, so their pruning bound is zero. In the six P=1 cases, the largest noise-scaled pair coefficient is at most 2.64e-15, and MP-G/LMMSE probability difference at most 1.03e-15. These tiny retained Gram edges are floating-point roundoff, **not physical multipath**.

Recommendation: use **edgeTolerance=0 for the first desktop lesson**, with explicit Run, N=3/M=4, a disclosed iteration cap and actual computed histories. Retaining the roundoff edges avoids an extra pruning interpretation; graph displays should label their tiny noise-scaled effect. The cited 177 ms is Node evidence only. Actual browser and named-desktop control-to-result, cancellation and teaching/UI gates remain open. Reviewed production source hashes above are unchanged.
