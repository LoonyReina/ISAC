"""100-digit independent MP-G cavity recursion for extreme accepted raw inputs."""
import json,os
from pathlib import Path
import mpmath as mp
mp.mp.dps=100
OUT=Path(os.environ.get('REVIEW_OUTPUT_DIR',str(Path(__file__).resolve().parent/'corrected'))).resolve()
cases=json.loads((OUT/'probe-inputs.json').read_text());js={c['id']:c for c in json.loads((OUT/'probe-js-results.json').read_text())['cases']}
def c(z):return mp.mpc(str(z['re']),str(z['im']))
def lse(vals):
 m=max(vals);return m+mp.log(sum(mp.exp(z-m) for z in vals))
def norm(vals):
 m=max(vals);x=[z-m for z in vals];s=mp.log(sum(mp.exp(z) for z in x));return [z-s for z in x]
findings=[]
for case in cases:
 if case['id'] not in ['max-dense-Q4-v1e-06','rank-one-Q4-v1e-06','rank-nearly-one-Q16-v1e-06','raw-N3-M4-Q16-0']:continue
 r=case['receiver'];H=mp.matrix([[c(z) for z in row] for row in r['H']]);y=mp.matrix([c(z) for z in r['y']]);C=[c(z) for z in r['constellation']];v=mp.mpf(str(r['noiseVariance']));D=len(y);Q=len(C);s=r['settings'];G=H.H*H;z=H.H*y
 unary=[norm([(2*mp.re(mp.conj(a)*z[i])-mp.re(G[i,i])*abs(a)**2)/v for a in C]) for i in range(D)]
 cutoff=mp.mpf(str(s['edgeTolerance']))*max(1,max(abs(e) for e in G));edges=[(i,j) for i in range(D) for j in range(i+1,D) if abs(G[i,j])>cutoff]
 nb={i:[] for i in range(D)};pair={}
 for i,j in edges:
  nb[i].append(j);nb[j].append(i);p=[[-2*mp.re(mp.conj(a)*G[i,j]*b)/v for b in C] for a in C];pair[i,j]=p;pair[j,i]=list(zip(*p))
 msgs={(a,b):[-mp.log(Q)]*Q for i,j in edges for a,b in [(i,j),(j,i)]};post=unary;trace=[]
 for iteration in range(1,s['maxIterations']+1):
  nxt={}
  for i in range(D):
   for j in nb[i]:
    cavity=[unary[i][a]+sum(msgs[k,i][a] for k in nb[i] if k!=j) for a in range(Q)]
    vec=norm([lse([cavity[a]+pair[i,j][a][b] for a in range(Q)]) for b in range(Q)])
    if s['damping']<1:
     damping=mp.mpf(str(s['damping']));vec=[lse([mp.log(damping)+a,mp.log(1-damping)+b]) for a,b in zip(vec,msgs[i,j])]
    nxt[i,j]=vec
  delta=max([abs(mp.exp(a)-mp.exp(b)) for e in msgs for a,b in zip(nxt[e],msgs[e])] or [mp.mpf(0)])
  nxtpost=[norm([unary[i][a]+sum(nxt[j,i][a] for j in nb[i]) for a in range(Q)]) for i in range(D)]
  md=max(abs(mp.exp(a)-mp.exp(b)) for row1,row2 in zip(nxtpost,post) for a,b in zip(row1,row2));post=nxtpost;msgs=nxt;trace.append([delta,md])
  if delta<mp.mpf(str(s['tolerance'])):break
 actual=js[case['id']]['mpg']['value']
 f={'id':case['id'],'iterations':iteration,'probabilityError':float(max(abs(mp.mpf(str(a))-mp.exp(b)) for arow,brow in zip(actual['probabilities'],post) for a,b in zip(arow,brow))),
 'traceError':float(max(abs(mp.mpf(str(a))-b) for rec,row in zip(actual['trace'],trace) for a,b in zip([rec['messageDelta'],rec['marginalDelta']],row))),
 'logScaledError':float(max(abs(mp.mpf(str(a))-b)/(1+abs(b)) for arow,brow in zip(actual['logProbabilities'],post) for a,b in zip(arow,brow)))}
 findings.append(f)
(OUT/'mpg-high-precision-report.json').write_text(json.dumps({'precision':100,'findings':findings},indent=2));print(json.dumps(findings,indent=2))
