/** Independent review: actual Node Worker lifecycle and controller/gate edges.
 * No simulation fixture or existing tests are imported. Writes only beside this file.
 * Run: node independent-review/protocol/probe-lifecycle.mjs
 */
import assert from 'node:assert/strict';
import {Worker} from 'node:worker_threads';
import {createHash} from 'node:crypto';
import {readFile, writeFile} from 'node:fs/promises';
import {performance} from 'node:perf_hooks';
import {createController,createResultGate} from '../../src/protocol.mjs';
import {validateReceiver} from '../../src/kernel.mjs';

const root=new URL('../../',import.meta.url),outdir=new URL('./',import.meta.url);
const sourceNames=['src/kernel.mjs','src/protocol.mjs','src/node-worker.mjs'];
const freeze=async()=>Object.fromEntries(await Promise.all(sourceNames.map(async n=>[n,createHash('sha256').update(await readFile(new URL(n,root))).digest('hex')])));
const initialHashes=await freeze();
const expectedHashes={
  'src/kernel.mjs':'c5ff00fcfcc24b5006c846620de23d496eddefdba52a8552226936b4a1e4c06c',
  'src/protocol.mjs':'e7f8c14a160d1ed53c8b96af956766b6c3e2fd0a2f63ea28db58bd9e8b267155',
  'src/node-worker.mjs':'f7e2fd941ca3959f2d3259554bba36022c2972560c35bbf5e74b2cf147940a5d',
};
assert.deepEqual(initialHashes,expectedHashes,'Source changed from review snapshot');
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
function constellation(Q=16){const n=Math.sqrt(Q),scale=Math.sqrt(2*(Q-1)/3);return Array.from({length:Q},(_,a)=>({re:(2*Math.floor(a/n)-n+1)/scale,im:(2*(a%n)-n+1)/scale}));}
function receiver({D=12,Q=16,iterations=100,history=true}={}){
  return {frame:D===12?{N:3,M:4}:{N:1,M:D},model:'eq14_literal',csi:'perfect-supplied',
    H:Array.from({length:D},(_,r)=>Array.from({length:D},(_,c)=>({re:.36*Math.sin((r+1)*4.13+(c+1)*1.71)+(r===c?.5:0),im:.3*Math.cos((r+1)*2.31-(c+1)*.93)}))),
    y:Array.from({length:D},(_,i)=>({re:.5*Math.sin(i+1),im:.6*Math.cos(2*i+1)})),
    noiseVariance:.8,constellation:constellation(Q),settings:{maxIterations:iterations,tolerance:1e-14,damping:.05,edgeTolerance:0,captureHistory:history}};
}
const canonical=x=>x===null||typeof x!=='object'?JSON.stringify(x):Array.isArray(x)?'['+x.map(canonical).join(',')+']':'{'+Object.keys(x).sort().map(k=>JSON.stringify(k)+':'+canonical(x[k])).join(',')+'}';
const digest=x=>'sha256:'+createHash('sha256').update(canonical(x)).digest('hex');
const terminal=id=>m=>m.type==='terminal'&&m.requestId===id;
const compact=m=>Object.fromEntries(Object.entries({type:m.type,requestId:m.requestId,status:m.status,phase:m.phase,iteration:m.iteration,inputDigest:m.inputDigest,partialResult:m.partialResult,mpgIterations:m.methods?.mpg?.iterations??m.partial?.mpg?.iterations,mpgStatus:m.methods?.mpg?.status??m.partial?.mpg?.status,error:m.error}).filter(([,v])=>v!==undefined));
class Harness{
  constructor(){this.messages=[];this.hooks=new Set();this.waiters=new Set();this.errors=[];this.worker=new Worker(new URL('src/node-worker.mjs',root));this.closed=false;
    this.worker.on('message',m=>{this.messages.push(m);for(const hook of this.hooks)hook(m);for(const w of [...this.waiters])if(w.p(m)){clearTimeout(w.timer);this.waiters.delete(w);w.resolve(m);}});
    this.worker.on('error',e=>{this.errors.push(e.message);for(const w of this.waiters){clearTimeout(w.timer);w.reject(e);}this.waiters.clear();});
  }
  send(m){this.worker.postMessage(m);}
  wait(p,timeout=15000){const old=this.messages.find(p);if(old)return Promise.resolve(old);return new Promise((resolve,reject)=>{const w={p,resolve,reject};w.timer=setTimeout(()=>{this.waiters.delete(w);reject(Error('Worker response timeout'));},timeout);this.waiters.add(w);});}
  on(hook){this.hooks.add(hook);return()=>this.hooks.delete(hook);}
  async close(){this.closed=true;for(const w of this.waiters){clearTimeout(w.timer);w.reject(Error('Harness closed'));}this.waiters.clear();await this.worker.terminate();}
  transcript(){return this.messages.map(compact);}
  unique(ids){for(const id of ids){const ms=this.messages.filter(m=>m.requestId===id),terms=ms.filter(m=>m.type==='terminal');assert.equal(terms.length,1,`terminal uniqueness for ${id}`);const index=ms.findIndex(m=>m.type==='terminal');assert(!ms.slice(index+1).some(m=>m.type==='progress'),`progress after terminal for ${id}`);}assert.deepEqual(this.errors,[]);}
}
async function withWorker(fn){const h=new Harness();try{return await fn(h);}finally{await h.close();}}
const checks=[],findings=[];
async function check(name,fn){const start=performance.now();try{const details=await fn();checks.push({name,status:'passed',elapsedMs:performance.now()-start,details});console.log('PASS',name);}catch(e){checks.push({name,status:'failed',elapsedMs:performance.now()-start,error:e.stack||String(e)});console.log('FAIL',name,e.message);}}
const finding=(id,severity,title,evidence,interpretation)=>findings.push({id,severity,title,evidence,interpretation});

await check('actual Worker: independent fixture completion, digest, ordering, one terminal',()=>withWorker(async h=>{
  const r=receiver({iterations:5});h.send({type:'run',requestId:'complete',receiver:r});const m=await h.wait(terminal('complete'));await sleep(40);h.unique(['complete']);
  assert.equal(m.status,'completed');assert.equal(m.inputDigest,digest(r));assert.deepEqual(m.receiver,r);assert.equal(m.partialResult,false);assert.equal(m.methods.mpg.iterations,5);assert.equal(m.methods.mpg.status,'max-iterations');assert.equal(m.methods.lmmse.status,'solved');
  assert.deepEqual(h.messages.filter(m=>m.phase==='mp-g').map(m=>m.iteration),[1,2,3,4,5]);
  assert(h.messages.every(m=>m.schemaVersion==='otfs-communication-v1'&&m.kernelVersion==='0.1.0'));
  return {transcript:h.transcript()};
}));

for(const cancelAt of [1,4,12])for(let repetition=0;repetition<3;repetition++)await check(`actual Worker: cancel during iteration ${cancelAt}, repetition ${repetition+1}`,()=>withWorker(async h=>{
  const id=`cancel.${cancelAt}.${repetition}`,r=receiver();let requested=null;
  h.on(m=>{if(m.requestId===id&&m.phase==='mp-g'&&m.iteration===cancelAt){requested=performance.now();h.send({type:'cancel',requestId:id});}});
  h.send({type:'run',requestId:id,receiver:r});const m=await h.wait(terminal(id)),latency=performance.now()-requested;await sleep(40);h.unique([id]);
  assert.notEqual(requested,null);assert.equal(m.status,'cancelled');assert.equal(m.partialResult,true);assert.equal(m.methods,undefined);assert(m.partial.mpg.iterations>=cancelAt&&m.partial.mpg.iterations<100);assert.equal(m.inputDigest,digest(r));
  assert.equal(m.partial.mpg.history.length,m.partial.mpg.iterations+1);assert.equal(m.partial.mpg.trace.length,m.partial.mpg.iterations);
  return {requestedIteration:cancelAt,observedIterations:m.partial.mpg.iterations,cancelToTerminalMs:latency,terminal:compact(m)};
}));

await check('actual Worker: early cancellation before iterations; repeated and late cancels',()=>withWorker(async h=>{
  const r=receiver();h.send({type:'run',requestId:'early',receiver:r});h.send({type:'cancel',requestId:'early'});h.send({type:'cancel',requestId:'early'});
  const m=await h.wait(terminal('early'));assert.equal(m.status,'cancelled');assert(!h.messages.some(m=>m.phase==='mp-g'));assert.equal(m.methods,undefined);
  h.send({type:'cancel',requestId:'early'});await h.wait(m=>m.type==='cancel-ignored'&&m.requestId==='early');await sleep(30);h.unique(['early']);return {transcript:h.transcript()};
}));

await check('actual Worker: supersession after iteration 4 and immediate middle/latest replacement',()=>withWorker(async h=>{
  const a=receiver(),c=receiver({iterations:3});c.y[0].re+=.11;
  h.on(m=>{if(m.requestId==='old'&&m.phase==='mp-g'&&m.iteration===4){h.send({type:'run',requestId:'middle',receiver:a});h.send({type:'run',requestId:'latest',receiver:c});}});
  h.send({type:'run',requestId:'old',receiver:a});const [old,middle,last]=await Promise.all(['old','middle','latest'].map(id=>h.wait(terminal(id))));await sleep(40);h.unique(['old','middle','latest']);
  assert.equal(old.status,'superseded');assert.equal(middle.status,'superseded');assert.equal(old.partialResult,true);assert(old.partial.mpg.iterations>=4&&old.partial.mpg.iterations<100);assert.equal(last.status,'completed');assert.equal(last.inputDigest,digest(c));
  return {transcript:h.transcript()};
}));

await check('actual Worker: 40 rapid jobs give 39 superseded and exactly one completed',()=>withWorker(async h=>{
  const ids=Array.from({length:40},(_,i)=>`burst.${i}`),r=receiver({iterations:3});for(const requestId of ids)h.send({type:'run',requestId,receiver:r});
  const ts=await Promise.all(ids.map(id=>h.wait(terminal(id))));await sleep(40);h.unique(ids);assert(ts.slice(0,-1).every(m=>m.status==='superseded'));assert.equal(ts.at(-1).status,'completed');
  return {terminalCounts:Object.fromEntries(['superseded','completed'].map(s=>[s,ts.filter(m=>m.status===s).length])),transcript:h.transcript()};
}));

await check('actual Worker: active duplicate ID and malformed cancellation do not disturb valid job',()=>withWorker(async h=>{
  const r=receiver({iterations:16});let attempted=false;
  h.on(m=>{if(!attempted&&m.requestId==='original'&&m.phase==='mp-g'){attempted=true;h.send({type:'run',requestId:'original',receiver:receiver({iterations:1})});h.send({type:'cancel',requestId:'original',unexpected:true});h.send({type:'run',requestId:'envelope.bad',receiver:r,unexpected:true});}});
  h.send({type:'run',requestId:'original',receiver:r});const t=await h.wait(terminal('original'));await sleep(40);h.unique(['original']);assert.equal(t.status,'completed');assert.equal(t.methods.mpg.iterations,16);assert.equal(h.messages.filter(m=>m.type==='protocol-error').length,3);
  return {transcript:h.transcript()};
}));

await check('actual Worker: IDs remain consumed after completed, invalid, cancelled, superseded',()=>withWorker(async h=>{
  const r=receiver({iterations:1});h.send({type:'run',requestId:'done',receiver:r});await h.wait(terminal('done'));
  h.send({type:'run',requestId:'bad',receiver:{}});await h.wait(terminal('bad'));
  h.send({type:'run',requestId:'cancelled',receiver:r});h.send({type:'cancel',requestId:'cancelled'});assert.equal((await h.wait(terminal('cancelled'))).status,'cancelled');
  h.send({type:'run',requestId:'superseded',receiver:r});h.send({type:'run',requestId:'replacement',receiver:r});assert.equal((await h.wait(terminal('superseded'))).status,'superseded');await h.wait(terminal('replacement'));
  for(const id of ['done','bad','cancelled','superseded']){h.send({type:'run',requestId:id,receiver:r});const e=await h.wait(m=>m.type==='protocol-error'&&m.requestId===id);assert.match(e.error.message,/already used/);}
  await sleep(30);h.unique(['done','bad','cancelled','superseded','replacement']);return {transcript:h.transcript()};
}));

await check('actual Worker: malformed envelope matrix and safe ID boundaries',()=>withWorker(async h=>{
  const malformed=[null,[],1,'message',true,3n,{}, {type:'run',requestId:3}, {type:'run',requestId:''}, {type:'run',requestId:'a b'}, {type:'run',requestId:'é'}, {type:'run',requestId:'x'.repeat(81)}, {type:'unknown',requestId:'unknown'}, {type:'cancel',requestId:'extra.cancel',receiver:{}}, {type:'run',requestId:'extra.run',receiver:{},truth:[1]}];
  for(let i=0;i<malformed.length;i++){const before=h.messages.length;h.send(malformed[i]);await h.wait(m=>h.messages.indexOf(m)>=before&&m.type==='protocol-error');}
  assert.equal(h.messages.length,malformed.length);assert(h.messages.every(m=>m.status==='invalid-input'));
  const r=receiver({D:1,Q:4,iterations:1});for(const requestId of ['A_z-9.:','x'.repeat(80)]){h.send({type:'run',requestId,receiver:r});assert.equal((await h.wait(terminal(requestId))).status,'completed');}
  h.send({type:'cancel',requestId:'never.submitted'});assert.equal((await h.wait(m=>m.type==='cancel-ignored')).status,'not-active');return {malformedCount:malformed.length,transcript:h.transcript()};
}));

await check('actual Worker: ordinary invalid receivers produce invalid-input and recover',()=>withWorker(async h=>{
  const cases=[['missing',undefined],['null',null],['array',[]],['truth',Object.assign(receiver(),{truthIndices:[1]})],['nan',(()=>{const r=receiver();r.noiseVariance=NaN;return r;})()],['infinity',(()=>{const r=receiver();r.H[0][0].im=Infinity;return r;})()],['wrong-shape',(()=>{const r=receiver();r.y.pop();return r;})()],['explicit-undefined',(()=>{const r=receiver();r.y[0]=undefined;return r;})()],['wrong-settings',(()=>{const r=receiver();r.settings.maxIterations=101;return r;})()]];
  for(const [name,r]of cases){h.send({type:'run',requestId:`bad.${name}`,receiver:r});const m=await h.wait(terminal(`bad.${name}`));assert.equal(m.status,'invalid-input');assert.equal(m.methods,undefined);assert.equal(m.inputDigest,null);}
  h.send({type:'run',requestId:'recovered',receiver:receiver({iterations:1})});assert.equal((await h.wait(terminal('recovered'))).status,'completed');await sleep(30);h.unique([...cases.map(([name])=>`bad.${name}`),'recovered']);return {transcript:h.transcript()};
}));

await check('actual Worker: sparse structured-clone input classification and recovery',()=>withWorker(async h=>{
  const cases=[['H-row',r=>delete r.H[0]],['H-cell',r=>delete r.H[0][0]],['y-cell',r=>delete r.y[0]],['constellation-cell',r=>delete r.constellation[0]]],observed=[];
  for(const [name,change]of cases){const r=receiver({D:2,Q:4,iterations:1});change(r);h.send({type:'run',requestId:`sparse.${name}`,receiver:r});const m=await h.wait(terminal(`sparse.${name}`));assert.notEqual(m.status,'completed');assert.equal(m.methods,undefined);observed.push({case:name,terminal:compact(m)});}
  h.send({type:'run',requestId:'sparse.recover',receiver:receiver({D:1,Q:4,iterations:1})});assert.equal((await h.wait(terminal('sparse.recover'))).status,'completed');await sleep(30);h.unique([...cases.map(([name])=>`sparse.${name}`),'sparse.recover']);
  const wrong=observed.filter(x=>x.terminal.status!=='invalid-input');if(wrong.length)finding('P1','medium','Sparse receiver arrays are not consistently rejected as invalid-input',wrong,'Worker structured cloning preserves holes. Array .map/.some skip those holes in validation; malformed arrays then reach hashing/kernel stages. The Worker recovers and emits one hard error terminal, but the public error classification is wrong. Reject missing own indices before mapping.');
  return {observed};
}));

await check('actual Worker: invalid new receiver supersedes active valid work',()=>withWorker(async h=>{
  h.on(m=>{if(m.requestId==='valid.active'&&m.phase==='mp-g'&&m.iteration===4){const bad=receiver();bad.y=[];h.send({type:'run',requestId:'invalid.replacement',receiver:bad});}});
  h.send({type:'run',requestId:'valid.active',receiver:receiver()});const [a,b]=await Promise.all(['valid.active','invalid.replacement'].map(id=>h.wait(terminal(id))));await sleep(30);h.unique(['valid.active','invalid.replacement']);assert.equal(a.status,'superseded');assert.equal(b.status,'invalid-input');
  return {policyObservation:'A syntactically valid fresh run supersedes the active job before receiver validation. An invalid replacement therefore cancels prior useful work.',transcript:h.transcript()};
}));

await check('actual Worker: naturally reachable numerical-failure is terminal and recoverable',()=>withWorker(async h=>{
  const r=receiver({D:1,Q:4,iterations:1});r.H=[[{re:1e-12,im:0}]];r.y=[{re:64,im:64}];r.noiseVariance=1e-6;validateReceiver(r);
  h.send({type:'run',requestId:'numeric',receiver:r});const m=await h.wait(terminal('numeric'));assert.equal(m.status,'numerical-failure');assert.equal(m.error.name,'KernelError');assert.equal(m.methods,undefined);
  h.send({type:'run',requestId:'numeric.recover',receiver:receiver({D:1,Q:4,iterations:1})});assert.equal((await h.wait(terminal('numeric.recover'))).status,'completed');await sleep(30);h.unique(['numeric','numeric.recover']);return {validReceiver:r,transcript:h.transcript()};
}));

await check('actual Worker: 1000-request session budget includes rejected receivers; duplicates deterministic',()=>withWorker(async h=>{
  const ids=Array.from({length:1000},(_,i)=>`budget.${i}`);for(const requestId of ids)h.send({type:'run',requestId,receiver:{}});
  await Promise.all(ids.map(id=>h.wait(terminal(id))));h.send({type:'run',requestId:'budget.over',receiver:receiver({D:1,Q:4,iterations:1})});const over=await h.wait(m=>m.type==='protocol-error'&&m.requestId==='budget.over');assert.match(over.error.message,/budget exhausted/);
  h.send({type:'run',requestId:'budget.0',receiver:receiver()});const duplicate=await h.wait(m=>m.type==='protocol-error'&&m.requestId==='budget.0');assert.match(duplicate.error.message,/already used/);
  await sleep(30);h.unique(ids);assert(h.messages.filter(m=>m.type==='terminal').every(m=>m.status==='invalid-input'));
  return {terminalCount:ids.length,overBudget:compact(over),duplicate:compact(duplicate),policyObservation:'Rejected receiver jobs consume the documented per-session request budget; Worker recreation is required after 1000 accepted envelopes.'};
}));

await check('controller: injected yield failure is internal-error; subsequent run recovers',async()=>{
  const messages=[];let fail=true;const controller=createController(m=>messages.push(m),{yieldTask:async()=>{if(fail)throw Error('independent-probe-yield-failure');}});
  controller.receive({type:'run',requestId:'injected.error',receiver:receiver({D:1,Q:4,iterations:1})});
  for(let i=0;i<200&&!messages.some(terminal('injected.error'));i++)await sleep(5);
  const error=messages.find(terminal('injected.error'));assert(error);assert.equal(error.status,'internal-error');assert.equal(error.methods,undefined);assert.match(error.error.message,/independent-probe-yield-failure/);
  fail=false;controller.receive({type:'run',requestId:'injected.recover',receiver:receiver({D:1,Q:4,iterations:1})});for(let i=0;i<200&&!messages.some(terminal('injected.recover'));i++)await sleep(5);assert.equal(messages.find(terminal('injected.recover')).status,'completed');
  assert.equal(messages.filter(terminal('injected.error')).length,1);assert.equal(messages.filter(terminal('injected.recover')).length,1);return {transcript:messages.map(compact),boundary:'Dependency-fault injection against the exported controller only; production Node worker uses the real timer yield.'};
});

await check('controller: receiver snapshot survives mutation after receive',async()=>{
  const messages=[],r=receiver({D:2,Q:4,iterations:1}),original=structuredClone(r),c=createController(m=>messages.push(m));c.receive({type:'run',requestId:'snapshot',receiver:r});r.H[0][0].re=13;r.y[0].re=52;r.settings.maxIterations=19;r.constellation[0].re=-1;
  for(let i=0;i<200&&!messages.some(terminal('snapshot'));i++)await sleep(5);const m=messages.find(terminal('snapshot'));assert(m);assert.equal(m.status,'completed');assert.deepEqual(m.receiver,original);assert.equal(m.inputDigest,digest(original));return {terminal:compact(m)};
});

await check('result gate: strict current ID/digest, terminal completed, immediate invalidation',()=>{
  const g=createResultGate(),good={type:'terminal',status:'completed',requestId:'new',inputDigest:'sha256:new'};assert.equal(g.accepts(good),false);g.expect('new','sha256:new');assert.equal(g.accepts(good),true);
  const rejects=[{...good,requestId:'old'},{...good,inputDigest:'sha256:old'},...['cancelled','superseded','invalid-input','numerical-failure','internal-error'].map(status=>({...good,status})),{...good,type:'progress'}];for(const r of rejects)assert.equal(g.accepts(r),false);
  g.invalidate();assert.equal(g.accepts(good),false);g.expect('newer','sha256:newer');assert.equal(g.accepts(good),false);assert.equal(g.accepts({...good,requestId:'newer',inputDigest:'sha256:newer'}),true);return {negativeCases:rejects.length+3};
});

await check('result gate: malformed inputs, duplicate completions and missing schema observations',()=>{
  const g=createResultGate();g.expect('x','d');const good={type:'terminal',status:'completed',requestId:'x',inputDigest:'d'},observed=[];
  for(const value of [null,undefined,{},[],true,'text']){try{observed.push({input:value===undefined?'undefined':JSON.stringify(value),result:g.accepts(value)});}catch(e){observed.push({input:value===undefined?'undefined':JSON.stringify(value),thrown:e.name,message:e.message});}}
  assert.equal(g.accepts(good),true);assert.equal(g.accepts(good),true);
  return {observed,policyObservation:'The gate assumes a trusted record object. It throws on null/undefined, does not check schema/payload validity, and is deliberately a predicate rather than a consume-once gate; repeated matching completions are accepted. Production controller terminal uniqueness is verified separately.'};
});

const finalHashes=await freeze();const unchanged=JSON.stringify(initialHashes)===JSON.stringify(finalHashes);assert(unchanged,'Source mutated during independent review');
const report={review:'Independent protocol/lifecycle challenge',createdAt:new Date().toISOString(),command:'node independent-review/protocol/probe-lifecycle.mjs',runtime:{node:process.version,platform:process.platform,arch:process.arch},sourceHashes:initialHashes,sourceHashesUnchanged:unchanged,
  boundaries:['Real node:worker_threads Worker used unless test name says controller or result gate.','Fixtures independently constructed; no simulation generator, test fixture, prerecorded numerical result, or browser was used.','Only independent-review/protocol/ files were written. No source changes.','Exactly-one-terminal checks include a 30–40 ms post-terminal observation plus all message order seen; no timing guarantee is inferred for arbitrary deployment hardware.','Stale-result filter was tested as an exported consumer helper; there is no UI/browser lifecycle claim.'],
  status:checks.some(t=>t.status==='failed')?'probe-failed':findings.length?'completed-with-findings':'passed',summary:{checks:checks.length,passed:checks.filter(t=>t.status==='passed').length,failed:checks.filter(t=>t.status==='failed').length,confirmedFindings:findings.length},findings,checks};
await writeFile(new URL('results.json',outdir),JSON.stringify(report,null,2)+'\n');
const cancel=checks.filter(t=>t.name.includes('cancel during iteration')&&t.status==='passed');
const md=`# Independent protocol / lifecycle review\n\nRun: \`${report.command}\` (Node ${process.version})\n\nResult: **${report.status}**. ${report.summary.passed}/${report.summary.checks} probe checks passed; ${findings.length} confirmed finding(s).\n\n## Finding\n\n${findings.map(f=>`- **${f.id} (${f.severity}): ${f.title}.** ${f.interpretation}\n  Observations: ${f.evidence.map(e=>`${e.case} → ${e.terminal.status} (${e.terminal.error?.message})`).join('; ')}`).join('\n')||'None.'}\n\n## Verified lifecycle behavior\n\n- Actual iterations were observed before cancellation at 1, 4, and 12, each repeated three times. Observed cancel-to-terminal maximum: ${Math.max(...cancel.map(t=>t.details.cancelToTerminalMs)).toFixed(3)} ms on this run, with no completion leakage.\n- Cancellation/supersession produced a single terminal, bounded partial state, correct digest, and no subsequent progress. Real-Worker rapid replacement gave 39 superseded jobs and one completed newest job.\n- Duplicate IDs were rejected during work and after completed, cancelled, superseded, and invalid jobs. Malformed protocol messages did not interrupt active valid work.\n- Invalid-input, numerical-failure, and injected internal-error terminals were followed by successful fresh runs.\n- Completion payloads preserved independently constructed receiver values and independently calculated canonical SHA-256 digests.\n- Gate rejected stale IDs/digests and non-completed statuses, and immediate invalidation prevented acceptance.\n\n## Edge observations (not asserted as defects without a stronger contract)\n\n- A fresh run supersedes active work before receiver validation; an invalid replacement stops the previous useful run.\n- Rejected receivers consume the 1000-job session budget. Beyond that budget a fresh Worker is required; duplicate-ID errors still take precedence.\n- The gate is a trusted-object predicate, not schema validation or deduplication: null/undefined throw when an expectation is active; a matching minimal completion and repeated matching completion are accepted.\n- Exported controller dependency-fault test injected a rejected timer-yield promise; no production source was mocked or edited.\n\n## Frozen sources\n\n${Object.entries(initialHashes).map(([p,h])=>`- \`${p}\`: \`${h}\``).join('\n')}\n\nHashes rechecked unchanged after probes. Full per-case evidence and transcripts: [results.json](results.json).\n\n## Limits\n\n${report.boundaries.map(x=>'- '+x).join('\n')}\n`;
await writeFile(new URL('README.md',outdir),md);
console.log(JSON.stringify({status:report.status,...report.summary,sourceHashesUnchanged:unchanged}));
if(report.summary.failed)process.exitCode=1;
