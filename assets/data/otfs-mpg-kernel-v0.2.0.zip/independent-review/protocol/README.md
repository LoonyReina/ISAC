# Independent protocol / lifecycle review

Run: `node independent-review/protocol/probe-lifecycle.mjs` (Node v24.19.0)

Result: **completed-with-findings**. 25/25 probe checks passed; 1 confirmed finding(s).

## Finding

- **P1 (medium): Sparse receiver arrays are not consistently rejected as invalid-input.** Worker structured cloning preserves holes. Array .map/.some skip those holes in validation; malformed arrays then reach hashing/kernel stages. The Worker recovers and emits one hard error terminal, but the public error classification is wrong. Reject missing own indices before mapping.
  Observations: H-row → numerical-failure (Gram matrix contains nonfinite arithmetic); H-cell → numerical-failure (Gram matrix contains nonfinite arithmetic); y-cell → internal-error (Cannot read properties of undefined (reading 're')); constellation-cell → internal-error (Cannot read properties of undefined (reading 're'))

## Verified lifecycle behavior

- Actual iterations were observed before cancellation at 1, 4, and 12, each repeated three times. Observed cancel-to-terminal maximum: 8.047 ms on this run, with no completion leakage.
- Cancellation/supersession produced a single terminal, bounded partial state, correct digest, and no subsequent progress. Real-Worker rapid replacement gave 39 superseded jobs and one completed newest job.
- Duplicate IDs were rejected during work and after completed, cancelled, superseded, and invalid jobs. Malformed protocol messages did not interrupt active valid work.
- Invalid-input, numerical-failure, and injected internal-error terminals were followed by successful fresh runs.
- Completion payloads preserved independently constructed receiver values and independently calculated canonical SHA-256 digests.
- Gate rejected stale IDs/digests and non-completed statuses, and immediate invalidation prevented acceptance.

## Edge observations (not asserted as defects without a stronger contract)

- A fresh run supersedes active work before receiver validation; an invalid replacement stops the previous useful run.
- Rejected receivers consume the 1000-job session budget. Beyond that budget a fresh Worker is required; duplicate-ID errors still take precedence.
- The gate is a trusted-object predicate, not schema validation or deduplication: null/undefined throw when an expectation is active; a matching minimal completion and repeated matching completion are accepted.
- Exported controller dependency-fault test injected a rejected timer-yield promise; no production source was mocked or edited.

## Frozen sources

- `src/kernel.mjs`: `c5ff00fcfcc24b5006c846620de23d496eddefdba52a8552226936b4a1e4c06c`
- `src/protocol.mjs`: `e7f8c14a160d1ed53c8b96af956766b6c3e2fd0a2f63ea28db58bd9e8b267155`
- `src/node-worker.mjs`: `f7e2fd941ca3959f2d3259554bba36022c2972560c35bbf5e74b2cf147940a5d`

Hashes rechecked unchanged after probes. Full per-case evidence and transcripts: [results.json](results.json).

## Limits

- Real node:worker_threads Worker used unless test name says controller or result gate.
- Fixtures independently constructed; no simulation generator, test fixture, prerecorded numerical result, or browser was used.
- Only independent-review/protocol/ files were written. No source changes.
- Exactly-one-terminal checks include a 30–40 ms post-terminal observation plus all message order seen; no timing guarantee is inferred for arbitrary deployment hardware.
- Stale-result filter was tested as an exported consumer helper; there is no UI/browser lifecycle claim.
