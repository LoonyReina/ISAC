"""Independent numerical reference for arXiv:1910.01896v1.

This is not a port of site code. Models are deliberately named, since printed
Eq14, its Eq8-derived sampled counterpart, and a finite physical frame differ.
All noise_variance arguments mean E[|w|**2] (complex variance).
Array vectorization follows the source's column stacking: index = k + N*l.
"""
from dataclasses import dataclass
from itertools import product
import time
import numpy as np
from scipy.optimize import minimize
from scipy.special import logsumexp

MODEL_NAMES = ("eq14_literal", "eq14_negative_delay_cyclic", "exact_rect_finite")


@dataclass(frozen=True)
class Frame:
    N: int = 4
    M: int = 8
    T: float = 6.4e-6
    fc: float = 5.89e9

    def __post_init__(self):
        if not isinstance(self.N, int) or not isinstance(self.M, int) or min(self.N, self.M) < 1:
            raise ValueError("N and M must be positive integers")
        if not np.isfinite(self.T) or self.T <= 0 or not np.isfinite(self.fc) or self.fc <= 0:
            raise ValueError("T and fc must be finite positive")

    @property
    def size(self): return self.N * self.M
    @property
    def bandwidth(self): return self.M / self.T

    def physical(self, delay_bin, doppler_bin):
        tau = delay_bin / self.bandwidth
        nu = doppler_bin / (self.N*self.T)
        return {"delay_s": float(tau), "doppler_hz": float(nu),
                "monostatic_range_m": float(299792458*tau/2),
                "monostatic_velocity_mps": float(299792458*nu/(2*self.fc))}


def _validate_parameters(frame, delay_bin, doppler_bin):
    if not np.isfinite(delay_bin) or not 0 <= delay_bin < frame.M:
        raise ValueError("delay must satisfy 0 <= tau < T")
    if not np.isfinite(doppler_bin) or not abs(doppler_bin) < frame.N:
        raise ValueError("Doppler must satisfy |nu| < delta_f")


def dirichlet(size, arg):
    """Finite exponential sum avoids removable 0/0 at grid points."""
    return np.mean(np.exp(2j*np.pi*np.asarray(arg)[..., None]*np.arange(size)/size), axis=-1)


def isfft_matrix(frame):
    k, l = np.unravel_index(np.arange(frame.size), (frame.N, frame.M), order="F")
    n, m = k, l
    return np.exp(2j*np.pi*(n[:, None]*k/frame.N-m[:, None]*l/frame.M))/np.sqrt(frame.size)


def isfft(x, frame):
    """Unitary normalization of Eq3, with inverse on receive; units unchanged."""
    return (isfft_matrix(frame)@np.asarray(x)).reshape((frame.N, frame.M), order="F")


def sfft(X, frame):
    return isfft_matrix(frame).conj().T@np.asarray(X).reshape(-1, order="F")


def eq14_operator(frame, delay_bin, doppler_bin, *, physical_delay_sign=False):
    """Literal Eq14/16, or separately labelled sign-only audit variant.

    q=tau*M*delta_f, a=nu*N*T. hprime=h*exp(2pi*j*nu*tau).
    No integer-grid rounding, sparsity truncation, or generic 2-D FFT surrogate.
    """
    _validate_parameters(frame, delay_bin, doppler_bin)
    k, l = np.unravel_index(np.arange(frame.size), (frame.N, frame.M), order="F")
    kd = k[None, :]-k[:, None]+doppler_bin
    ld = l[None, :]-l[:, None]+delay_bin
    if physical_delay_sign: ld = -ld
    phase = np.exp(2j*np.pi*doppler_bin*l/(frame.N*frame.M))
    isi = l >= frame.M-int(np.ceil(delay_bin))
    phase *= np.where(isi, np.exp(-2j*np.pi*(k+doppler_bin)/frame.N), 1)
    return dirichlet(frame.N, kd)*dirichlet(frame.M, ld)*phase


def exact_rect_operator(frame, delay_bin, doppler_bin):
    """Exact finite-window integral, independently from Eq4-9, rect/sqrt(T).

    Frame has N symbols and zero before/after; receive windows cover [0,NT).
    Tail guard is not folded back. Matrix multiplies hprime, not h.
    Orthogonal rectangular receive atoms preserve white complex noise.
    """
    _validate_parameters(frame, delay_bin, doppler_bin)
    N, M = frame.N, frame.M
    d, v = delay_bin/M, doppler_bin/N  # units T=1 inside integral
    n, m = np.unravel_index(np.arange(frame.size), (N, M), order="F")
    lo = np.maximum(n[:, None], n[None, :]+d)
    hi = np.minimum(n[:, None]+1, n[None, :]+1+d)
    width = np.maximum(hi-lo, 0)
    freq = v+m[None, :]-m[:, None]
    H = width*np.sinc(freq*width)*np.exp(2j*np.pi*freq*(lo+hi)/2)
    H *= np.exp(-2j*np.pi*m[None, :]*d)
    H *= np.exp(-2j*np.pi*v*d)  # h to hprime reparameterization
    U = isfft_matrix(frame)
    return U.conj().T@H@U


def path_operator(frame, delay_bin, doppler_bin, model="eq14_literal"):
    if model == "eq14_literal": return eq14_operator(frame, delay_bin, doppler_bin)
    if model == "eq14_negative_delay_cyclic":
        return eq14_operator(frame, delay_bin, doppler_bin, physical_delay_sign=True)
    if model == "exact_rect_finite": return exact_rect_operator(frame, delay_bin, doppler_bin)
    raise ValueError("Unrecognized model; choose an explicitly named model")


def channel_operator(frame, paths, model="eq14_literal"):
    """paths are (delay_bin, Doppler_bin, hprime); CSI input at communication Rx."""
    return sum((complex(gain)*path_operator(frame, q, a, model) for q, a, gain in paths),
               np.zeros((frame.size, frame.size), complex))


def noise(rng, size, variance):
    if variance < 0 or not np.isfinite(variance): raise ValueError("Invalid noise variance")
    return np.sqrt(variance/2)*(rng.normal(size=size)+1j*rng.normal(size=size))


def qam(order=16):
    n = int(np.sqrt(order))
    if n*n != order or n & (n-1): raise ValueError("Square power-of-two QAM required")
    levels = 2*np.arange(n)-(n-1)
    symbols = (levels[:, None]+1j*levels[None, :]).reshape(-1)
    symbols = symbols/np.sqrt(np.mean(abs(symbols)**2))
    bits = int(np.log2(n))
    labels = np.array([[(i^(i>>1)) >> b & 1 for b in range(bits-1,-1,-1)]+
                       [(j^(j>>1)) >> b & 1 for b in range(bits-1,-1,-1)]
                       for i in range(n) for j in range(n)], int)
    return symbols, labels


def _normalize(logp): return logp-logsumexp(logp, axis=-1, keepdims=True)


def _observations(H, y, variance, constellation):
    H, y, c = np.asarray(H, complex), np.asarray(y, complex), np.asarray(constellation, complex)
    if H.ndim != 2 or y.shape != (H.shape[0],) or c.ndim != 1 or len(c)<2:
        raise ValueError("Invalid channel, observation, or constellation shape")
    if variance <= 0 or not np.isfinite(variance) or not all(np.all(np.isfinite(z)) for z in [H,y,c]):
        raise ValueError("Nonfinite input or nonpositive complex noise variance")
    return H, y, c


def mp_g(H, y, noise_variance, constellation, *, max_iter=30, tolerance=1e-9,
         damping=1., edge_tolerance=1e-13):
    """Eq39-44 degree-two SPA with flooding schedule and log-domain messages.

    Damping 1 is source flooding (no damping). Finite cap is not convergence.
    Only near-roundoff G edges are dropped, and the removed norm is returned.
    Cyclic graph SPA is approximate marginalization, not exact global MAP.
    """
    H, y, c = _observations(H,y,noise_variance,constellation)
    if max_iter < 1 or not 0 < damping <= 1: raise ValueError("Invalid iteration controls")
    start = time.perf_counter()
    G, z = H.conj().T@H, H.conj().T@y
    D, Q = H.shape[1], len(c)
    unary = (2*np.real(z[:,None]*c.conj())-G.diagonal().real[:,None]*abs(c)**2)/noise_variance
    unary = _normalize(unary)
    cutoff = edge_tolerance*max(1., np.max(abs(G)))
    edges = [(i,j) for i in range(D) for j in range(i+1,D) if abs(G[i,j]) > cutoff]
    removed = G.copy(); np.fill_diagonal(removed,0)
    for i,j in edges: removed[i,j]=removed[j,i]=0
    pair = np.array([-2*np.real(G[i,j]*c.conj()[:,None]*c[None,:])/noise_variance for i,j in edges])
    # incoming[e,0] is message j->i; incoming[e,1] is i->j
    incoming = np.full((len(edges),2,Q), -np.log(Q))
    post = unary.copy(); trace=[]; status="max-iterations"
    for it in range(1,max_iter+1):
        belief = unary.copy()
        for e,(i,j) in enumerate(edges): belief[i]+=incoming[e,0]; belief[j]+=incoming[e,1]
        updated = np.empty_like(incoming)
        for e,(i,j) in enumerate(edges):
            cavity_i = belief[i]-incoming[e,0]
            cavity_j = belief[j]-incoming[e,1]
            updated[e,0] = _normalize(logsumexp(pair[e]+cavity_j[None,:],axis=1))
            updated[e,1] = _normalize(logsumexp(pair[e]+cavity_i[:,None],axis=0))
        if damping < 1 and len(edges):
            updated = np.logaddexp(np.log(damping)+updated,np.log1p(-damping)+incoming)
        delta = float(np.max(abs(np.exp(updated)-np.exp(incoming)))) if len(edges) else 0.
        incoming = updated
        belief = unary.copy()
        for e,(i,j) in enumerate(edges): belief[i]+=incoming[e,0]; belief[j]+=incoming[e,1]
        next_post = _normalize(belief)
        marginal_delta = float(np.max(abs(np.exp(next_post)-np.exp(post))))
        post = next_post
        trace.append({"iteration":it,"message_delta":delta,"marginal_delta":marginal_delta})
        if not np.all(np.isfinite(post)): status="nonfinite"; break
        if delta < tolerance: status="converged"; break
    return {"probabilities":np.exp(post),"log_probabilities":post,"status":status,
            "iterations":it,"trace":trace,"edge_count":len(edges),
            "removed_G_frobenius":float(np.linalg.norm(removed)),
            "pairwise_scalar_terms_per_iteration":2*len(edges)*Q*Q,
            "elapsed_ms":1000*(time.perf_counter()-start)}


def mp_psi(H, y, noise_variance, constellation, *, max_iter=30, damping=.7,
           confidence=.99, drop_threshold=.2, edge_tolerance=1e-13,
           soft_output_retention="best-confidence-latest-tie"):
    """Gaussian-interference MP from arXiv:1802.05242v2 Eqs35-41.

    Nominal H is supplied by caller, so rounding mismatch is never hidden.
    No Doppler edge truncation; confidence-drop and iteration-cap retained.
    The cited paper defines hard decisions, not a unique soft-output retention
    rule. Default retains latest posterior at ties for best confidence; the
    stricter alternative is exposed as a sensitivity test, never hidden.
    """
    H,y,c = _observations(H,y,noise_variance,constellation)
    if max_iter < 1 or not 0 < damping <= 1: raise ValueError("Invalid iteration controls")
    if soft_output_retention not in ("best-confidence-latest-tie","strict-best-confidence","last"):
        raise ValueError("Invalid soft-output retention rule")
    if not 0<confidence<=1 or not 0<=drop_threshold<=1: raise ValueError("Invalid confidence controls")
    start=time.perf_counter(); R,D=H.shape; Q=len(c)
    mask=abs(H)>edge_tolerance*max(1.,np.max(abs(H)))
    p=np.full((R,D,Q),1/Q); post=np.full((D,Q),1/Q); best=post.copy()
    best_eta=-1.; trace=[]; status="max-iterations"
    for it in range(1,max_iter+1):
        means=np.sum(p*c,axis=2)
        variances=np.maximum(np.sum(p*abs(c)**2,axis=2)-abs(means)**2,0)
        term=H*means
        mu=term.sum(axis=1)[:,None]-term
        var=noise_variance+(abs(H)**2*variances).sum(axis=1)[:,None]-abs(H)**2*variances
        ll=-abs(y[:,None,None]-mu[:,:,None]-H[:,:,None]*c)**2/np.maximum(var[:,:,None],1e-15)
        ll=np.where(mask[:,:,None],ll,0)
        logpost=_normalize(ll.sum(axis=0)); post=np.exp(logpost)
        eta=float(np.mean(post.max(axis=1)>=confidence))
        trace.append({"iteration":it,"confident_fraction":eta,"marginal_delta":float(np.max(abs(post-best)))})
        if eta>best_eta or (eta==best_eta and soft_output_retention=="best-confidence-latest-tie"):
            best=post.copy();best_eta=eta
        if eta == 1.: best=post;status="confidence-converged";break
        if best_eta-eta>drop_threshold: status="confidence-drop";break
        cavity=np.exp(_normalize(logpost[None,:,:]-ll))
        p=damping*cavity+(1-damping)*p
    if soft_output_retention=="last": best=post
    return {"probabilities":best,"log_probabilities":np.log(np.maximum(best,1e-300)),
            "status":status,"iterations":it,"trace":trace,"edge_count":int(mask.sum()),
            "soft_output_retention":soft_output_retention,
            "elapsed_ms":1000*(time.perf_counter()-start)}


def lmmse(H,y,noise_variance,constellation):
    """Eq47, plus explicit effective-AWGN scalar soft output for comparison."""
    H,y,c=_observations(H,y,noise_variance,constellation)
    start=time.perf_counter()
    energy=float(np.mean(abs(c)**2))
    W=np.linalg.solve(H.conj().T@H+noise_variance/energy*np.eye(H.shape[1]),H.conj().T)
    A=W@H; out=W@y; gain=A.diagonal()
    residual_var=energy*((abs(A)**2).sum(axis=1)-abs(gain)**2)+noise_variance*(abs(W)**2).sum(axis=1)
    lp=_normalize(-abs(out[:,None]-gain[:,None]*c)**2/np.maximum(residual_var[:,None],1e-15))
    return {"probabilities":np.exp(lp),"log_probabilities":lp,"status":"solved",
            "iterations":1,"effective_sinr":energy*abs(gain)**2/np.maximum(residual_var,1e-15),
            "elapsed_ms":1000*(time.perf_counter()-start)}


def exact_marginals(H,y,noise_variance,constellation,max_states=1_100_000):
    """Exhaustive likelihood oracle for truly tiny independent checks only."""
    H,y,c=_observations(H,y,noise_variance,constellation)
    D,Q=H.shape[1],len(c)
    if Q**D>max_states: raise ValueError("Exhaustive oracle exceeds explicit state budget")
    ids=np.array(list(product(range(Q),repeat=D)))
    states=c[ids]
    lp=-np.sum(abs(y[:,None]-H@states.T)**2,axis=0)/noise_variance
    lp-=logsumexp(lp)
    out=np.array([[logsumexp(lp[ids[:,i]==q]) for q in range(Q)] for i in range(D)])
    return {"probabilities":np.exp(out),"log_probabilities":out,"states":Q**D}


def soft_metrics(result, truth_indices, labels):
    """Truth is used here only, outside all receiver APIs.

    Entropy proxy Eq54 is NOT calibrated MI for loopy/mismatched posteriors.
    Truth-scored log score log2(Q)+E log2 q(X|Y) is reported separately and may
    be negative. No clipping disguises an overconfident wrong decoder.
    """
    p=result["probabilities"];lp=result["log_probabilities"]
    truth=np.asarray(truth_indices);hard=p.argmax(axis=1);Q=p.shape[1]
    return {"symbol_error_rate":float(np.mean(hard!=truth)),
            "bit_error_rate":float(np.mean(labels[hard]!=labels[truth])),
            "entropy_proxy_bits":float(np.log2(Q)+np.mean(np.sum(np.where(p>0,p*lp,0),axis=1))/np.log(2)),
            "truth_log_score_bits":float(np.log2(Q)+np.mean(lp[np.arange(len(p)),truth])/np.log(2))}


def profile_gain(template,y):
    den=float(np.vdot(template,template).real)
    if den<=1e-25: return 0j,-np.inf,np.inf
    inner=np.vdot(template,y);h=inner/den
    return h,float(abs(inner)**2/den),float(np.vdot(y-h*template,y-h*template).real)


def _validate_radar(frame,x,y,bounds,model):
    x,y=np.asarray(x,complex),np.asarray(y,complex)
    if x.shape!=(frame.size,) or y.shape!=(frame.size,) or not np.all(np.isfinite([x,y])):
        raise ValueError("Radar arrays must be finite and exactly frame size")
    if np.vdot(x,x).real<1e-20: raise ValueError("Zero-energy transmitted frame has no sensing information")
    (qlo,qhi),(alo,ahi)=bounds
    if not 0<=qlo<qhi<frame.M or not -frame.N<alo<ahi<frame.N:
        raise ValueError("Invalid search domain")
    if model not in MODEL_NAMES: raise ValueError("Invalid model")
    return x,y


def radar_ml(frame,x,y,*,bounds,model="eq14_literal",grid_shape=(17,25),starts_per_delay_cell=2,max_iter=100):
    """Single-path continuous profile ML, unknown complex gain, no truth input.

    Grid initializes only. Every delay cell is optimized separately because
    ceil(q) makes Eq14 discontinuous. Endpoints are separately evaluated.
    This multistart local solver does not certify a global continuum optimum.
    """
    x,y=_validate_radar(frame,x,y,bounds,model)
    if min(grid_shape)<2 or starts_per_delay_cell<1 or max_iter<1: raise ValueError("Invalid search budget")
    start=time.perf_counter(); evals=0; candidates=[]
    def evaluate(theta):
        nonlocal evals
        evals+=1
        s=path_operator(frame,*theta,model)@x
        h,score,res=profile_gain(s,y)
        return score,h,res
    qgrid=np.linspace(*bounds[0],grid_shape[0]);agrid=np.linspace(*bounds[1],grid_shape[1])
    grid=[]
    for q,a in product(qgrid,agrid):
        score,h,res=evaluate((q,a));grid.append((score,q,a,h,res))
    grid.sort(key=lambda z:z[0],reverse=True)
    grid_best=grid[0]
    candidates.append({"score":grid_best[0],"delay_bin":grid_best[1],"doppler_bin":grid_best[2],
                       "gain":grid_best[3],"residual":grid_best[4],"status":"grid-initialization"})
    cuts=sorted(set([bounds[0][0],bounds[0][1]]+[float(k) for k in range(int(np.ceil(bounds[0][0])),int(np.floor(bounds[0][1]))+1)]))
    if model=="exact_rect_finite": cuts=[bounds[0][0],bounds[0][1]]
    eps=1e-9
    for left,right in zip(cuts[:-1],cuts[1:]):
        lo=left+(eps if left==round(left) and model!="exact_rect_finite" else 0)
        hi=right-(eps if right==round(right) and model!="exact_rect_finite" else 0)
        if lo>=hi: continue
        seeds=[z for z in grid if lo<=z[1]<=hi][:starts_per_delay_cell]
        if not seeds:
            seeds=[(0,(lo+hi)/2,z[2],0,0) for z in grid[:starts_per_delay_cell]]
        for _,q,a,_,_ in seeds:
            fun=lambda t:-evaluate(t)[0]
            out=minimize(fun,[q,a],method="L-BFGS-B",bounds=[(lo,hi),bounds[1]],
                         options={"maxiter":max_iter,"ftol":1e-13,"gtol":1e-8,"maxls":30})
            score,h,res=evaluate(out.x)
            candidates.append({"score":score,"delay_bin":float(out.x[0]),"doppler_bin":float(out.x[1]),
                               "gain":h,"residual":res,"status":"converged" if out.success else "optimizer-failed",
                               "optimizer_message":str(out.message),"iterations":int(out.nit)})
    # Exact source ceil branch at every included integer q, optimized in Doppler.
    if model!="exact_rect_finite":
        for q in cuts:
            if q!=round(q): continue
            seeds=sorted([(evaluate((q,a))[0],a) for a in agrid],reverse=True)[:starts_per_delay_cell]
            for _,a in seeds:
                out=minimize(lambda z:-evaluate((q,z[0]))[0],[a],method="L-BFGS-B",bounds=[bounds[1]],
                             options={"maxiter":max_iter,"ftol":1e-13,"gtol":1e-8})
                score,h,res=evaluate((q,out.x[0]))
                candidates.append({"score":score,"delay_bin":q,"doppler_bin":float(out.x[0]),
                                   "gain":h,"residual":res,"status":"converged" if out.success else "optimizer-failed"})
    best=max(candidates,key=lambda z:z["score"])
    return {**best,"model":model,"search_bounds":bounds,"grid_shape":grid_shape,
            "grid_initialization":{"delay_bin":grid_best[1],"doppler_bin":grid_best[2],"score":grid_best[0]},
            "candidates":candidates,"evaluations":evals,"global_optimum_certified":False,
            "elapsed_ms":1000*(time.perf_counter()-start)}


def fisher_single(frame,x,q,a,gain,noise_variance,model="eq14_literal",step=1e-5):
    """Real/imag gain nuisance Schur-equivalent full FIM from finite differences.

    Normalized-bin derivatives; CRB is local only, and undefined at literal
    Eq14's delay branch boundary. Pavg is not multiplied a second time.
    """
    if noise_variance<=0: raise ValueError("Positive noise variance required")
    if model!="exact_rect_finite" and abs(q-round(q))<2*step:
        return {"status":"undefined-at-delay-branch", "variance_delay_bin":None,"variance_doppler_bin":None}
    if q-step<0 or q+step>=frame.M or abs(a)+step>=frame.N:
        return {"status":"derivative-outside-domain"}
    s=path_operator(frame,q,a,model)@x
    dq=gain*(path_operator(frame,q+step,a,model)@x-path_operator(frame,q-step,a,model)@x)/(2*step)
    da=gain*(path_operator(frame,q,a+step,model)@x-path_operator(frame,q,a-step,model)@x)/(2*step)
    J=np.column_stack([s,1j*s,dq,da]);F=2*np.real(J.conj().T@J)/noise_variance
    cond=float(np.linalg.cond(F))
    if not np.isfinite(cond) or cond>1e12: return {"status":"singular-information","condition":cond}
    C=np.linalg.inv(F)
    return {"status":"computed","variance_delay_bin":float(C[2,2]),"variance_doppler_bin":float(C[3,3]),
            "condition":cond,"FIM":F,"covariance":C}


def gaussian_rates(frame,H,snr,guard_over_T=.25):
    """Eq52/53. Same useful N,M,T; different total durations are explicit."""
    if snr<0 or guard_over_T<0: raise ValueError("Invalid SNR or guard")
    eig=np.linalg.eigvalsh(H@H.conj().T)
    return {"otfs_bits_s_hz":float(frame.N/(frame.N+guard_over_T)*np.mean(np.log2(1+snr*np.maximum(eig,0)))),
            "ofdm_bits_s_hz":float(np.log2(1+snr)/(1+guard_over_T)),
            "otfs_total_duration_s":float((frame.N+guard_over_T)*frame.T),
            "ofdm_total_duration_s":float(frame.N*(1+guard_over_T)*frame.T)}


def multipath_eq21(frame,x,y,*,path_count,bounds,model="eq14_literal",grid_shape=(17,25),
                   initialization="source-zero",max_iter=5,tolerance=1e-5):
    """Audit implementation of Eq19/21, retaining source initialization failure.

    source-zero reproduces the printed all-zero gains. All p then maximize the
    same S and the gain system is singular. distinct-peaks is an explicitly
    unprinted engineering initialization. Eq21's complex I is replaced by Re(I),
    another declared interpretation, and all blocks use previous-iteration
    quantities (Jacobi, as indexed by the source). Grid only in this audit
    branch; continuous single-path ML remains the separate radar_ml routine.
    """
    x,y=_validate_radar(frame,x,y,bounds,model)
    if not isinstance(path_count,int) or path_count<1 or path_count>frame.size: raise ValueError("Invalid known path count")
    if min(grid_shape)<2 or max_iter<1 or tolerance<0: raise ValueError("Invalid multipath search controls")
    if initialization not in ("source-zero","distinct-peaks"): raise ValueError("Invalid initialization")
    candidates=np.array(list(product(np.linspace(*bounds[0],grid_shape[0]),np.linspace(*bounds[1],grid_shape[1]))))
    templates=np.array([path_operator(frame,*v,model)@x for v in candidates])
    norms=np.sum(abs(templates)**2,axis=1)
    inner=templates.conj()@y
    S=abs(inner)**2/norms
    h=np.zeros(path_count,complex); selected=np.repeat(np.argmax(S),path_count)
    trace=[]
    def solve(indices):
        A=templates[indices].T
        sv=np.linalg.svd(A,compute_uv=False)
        if sv[-1]<1e-10*sv[0]: return None,float(np.inf),sv
        gains=np.linalg.lstsq(A,y,rcond=None)[0]
        return gains,float(np.linalg.norm(y-A@gains)**2),sv
    if initialization=="distinct-peaks":
        selected=[]
        for i in np.argsort(S)[::-1]:
            if all(np.linalg.norm((candidates[i]-candidates[j])/[.5,.5])>=1 for j in selected): selected.append(i)
            if len(selected)==path_count: break
        if len(selected)<path_count: return {"status":"insufficient-distinct-peaks","trace":[]}
        selected=np.array(selected)
        h,_,_=solve(selected)
        if h is None: return {"status":"singular-initial-gain-system","trace":[]}
    status="max-iterations"
    for it in range(1,max_iter+1):
        old=selected.copy();new=[]
        for p in range(path_count):
            other=sum((h[j]*templates[selected[j]] for j in range(path_count) if j!=p),np.zeros(frame.size,complex))
            Ip=(templates.conj()@other)*inner.conj()/norms
            new.append(int(np.argmax(S-Ip.real)))
        selected=np.array(new)
        h,res,sv=solve(selected)
        trace.append({"iteration":it,"parameters":candidates[selected].tolist(),"residual":res,
                      "smallest_singular_value":float(sv[-1]),"gain_condition":float(sv[0]/sv[-1]) if sv[-1]>0 else None})
        if h is None: status="singular-gain-system";break
        if np.max(abs(candidates[selected]-candidates[old]))<tolerance: status="grid-stationary";break
    return {"status":status,"parameters":candidates[selected],"gains":h,"trace":trace,
            "initialization":initialization,"complex_objective_interpretation":"take-real-part",
            "continuous":False,"known_path_count":path_count,"model":model}
