# OTFS effectiveness: fixed-source audit

Status: independent numerical reference and selected bounded experiments, not a production or full-paper reproduction claim. No repository or website files were modified.

## Source provenance

- Main source: Gaudio, Kobayashi, Caire and Colavolpe, *On the Effectiveness of OTFS for Joint Radar and Communication*, arXiv:1910.01896v1, 2019-10-04, 30 pages
- Fixed URL: https://arxiv.org/pdf/1910.01896v1
- Retrieved 2026-10-12 directly from arXiv with HTTPS; PDF SHA-256: `7787286d004ea1014fea059dea88ad4320536a8afcef44dc89a482b0feaaabdc`
- MP-Psi details omitted in the main source were read from Raviteja et al., arXiv:1802.05242v2: https://arxiv.org/pdf/1802.05242v2 ; SHA-256 `489890190cfdb3570f7a9329543b3c960787e6d275849ab60b4018a7632fce37`
- The cited OFDM predecessor was also acquired for baseline scope: https://arxiv.org/pdf/1902.01184v1 ; SHA-256 `8127e5d126f6a96c164d52b7c46f6fe170276ebe1b1906b860391dca3cefe848`
- No author code or experimental random seeds are linked in the fixed main PDF. This is an original implementation from equations, not an author-code execution
- Local `*source-private.pdf` and `*source-private.txt` files are research inputs only. They must not be redistributed or included in a downloadable reference archive

## Equation-to-code map

| Main source location | Reference function | Fidelity boundary |
|---|---|---|
| §II Eq1, p5 | `channel_operator` | Scalar narrow-sector paths, constant delay/Doppler/gain during frame; no self-interference |
| §III Eq3–9, pp6–7 | `isfft_matrix`, `isfft`, `sfft`, `exact_rect_operator` | Unitary transform scaling, exact continuous rectangular overlap, finite frame with no periodic extension |
| §III Eq14–16, pp8–9 | `eq14_operator` | Literally printed finite exponential sums, continuous arguments, both ICI/ISI column branches, printed ceiling |
| §IV-A Eq17–19, pp9–10 | `profile_gain`, `radar_ml` | Unknown complex gain profiled; source fine-grid search retained separately; continuous local refinement is an explicit extension |
| §IV-A Eq19–21, pp9–11 | `multipath_eq21` | Source-zero initialization failure retained; distinct-peak/real-part choices explicitly separate; grid-only audit branch |
| §IV-B Eq23, p11 | `fisher_single` | Real/imaginary gain nuisance parameters, independent finite-difference derivatives, complex-noise convention; no CRB at discontinuity |
| §V-A Eq37,39–44, pp15–17 | `mp_g` | Pairwise Gram-matrix factorization, exact local discrete sums, synchronous log-domain flooding, no Gaussian approximation |
| §V-B, pp18–19; Raviteja v2 Eq35–41/Alg1 | `mp_psi` | Gaussian-interference messages, damping and stopping; nominal CSI rounding chosen explicitly by caller |
| §V-C Eq47, p19 | `lmmse` | Full matrix LMMSE plus documented effective-AWGN soft-output calibration |
| §VI-B Eq52–53, p22 | `gaussian_rates` | Gaussian input rate including original distinct frame/CP overhead |
| §VI-C Eq54, p25 | `soft_metrics` | Literal entropy expression retained as proxy; truth-scored log score and BER added to expose miscalibration |

Page numbers above are the document's printed page numbers, equivalent to PDF 1-based pages. Supporting reviewer scripts derive and integrate waveforms independently of the implementation.

## Observation, dimensions and units

An OTFS DD frame is `N × M`: Doppler index k first, delay index l second. Flatten by columns, `i = k + N*l`. The transmit symbols x are known to the colocated radar. A communication receiver gets y, constellation, noise variance and the explicitly declared perfect or mismatched channel matrix; it does not receive the transmitted data or simulation seed.

Use normalized delay q = tau*M/T = tau*B and normalized Doppler a = nu*N*T. The physical restriction is 0 ≤ q < M and |a| < N. These are model validity bounds, not a proof of unambiguous identification over their entire extent. Search intervals are supplied independently of the simulated truth. The radar coordinate conversion is monostatic: r=c*tau/2 and v=c*nu/(2*fc). Forward-communication paths have one-way delay/Doppler; the same matrix algebra does not authorize using the radar factor two for a forward link.

The unknown complex gain is h′ = h*exp(j*2*pi*nu*tau). Every named path operator multiplies h′. The exact physical path matrix is derived from h*s(t−tau)*exp(j*2*pi*nu*t), then divided by the gain reparameterization phase. Comparing conventions must transform gains consistently.

The code uses unitary ISFFT/SFFT and unit-energy rectangular atoms, so useful frame energy is ||x||² and the unit-average-energy QAM constellation has expected frame energy NM. Source Eq3 and Eq9 use mutually inverse unnormalized transforms; using unitary transforms leaves their sandwich channel matrix unchanged but makes the transmit/noise energy ledger explicit. There is no second multiplication by Pavg after energy has already been embedded in x.

All numerical routines define noise variance v = E|w|². Noise is sqrt(v/2)*(normal+j*normal). A proper complex Gaussian likelihood is proportional to exp(−||y−Hx||²/v). The FIM for real parameters is 2*Re(JᴴJ)/v. This single convention is used by all compared methods.

## Printed-coordinate and model ambiguities

These are scoped to the fixed v1. They are not claims that all versions of the research are defective. Alternative consistent conventions and the effects of choices are tested rather than silently altered.

1. **Exact model versus quadrature.** Eq12 is exact for specified pulses and the finite transmitted frame. Eq14 is reached after an M-node approximation to an overlap integral. A low-dimensional use of Eq14 is a literal reduced algorithm experiment; it is not automatically an accurate physical small-frame approximation. The reference separately implements the exact continuous rectangular projection so the approximation can be measured.
2. **Fractional-delay sign and coordinate gauge.** In the printed positive-frequency Eq3–9 coordinates, direct derivation yields the complex-conjugate delay Dirichlet sum relative to Eq14. However, a fixed DD-coordinate rephasing and a per-path gain phase transform one into the other. Therefore the delay sign by itself is not sufficient evidence of a typo. The sign-only audit variant is explicitly named and never silently substituted for the literal model. The second independent review establishes a coherent cyclic/right-endpoint/negative-carrier/one-sample-DD-origin convention reproducing all of Eq14 within 2.72e-15. This changes explicit elements of the earlier printed waveform and quadrature equations; it is not asserted to be the authors' intended convention.
3. **Finite versus cyclic frame.** The finite n′=0,…,N−1 waveform has no previous symbol at n′=−1. The compact Eq14 formula wraps this contribution. A tail guard alone does not specify copying the last symbol to a prefix or folding the received tail. The exact reference receives [0,NT) and deliberately does not invent such processing.
4. **Sampling endpoints and ceiling.** Direct left-end transmit-grid quadrature of Eq13 and Eq8 produces a different noninteger overlap partition than the printed Eq16 ceiling. Integer-grid examples hide this difference. The independently verified right-endpoint/cyclic convention explains it when declared alongside transformed coordinates. Neither a convention transformation nor a finer Doppler grid removes the sampling approximation.
5. **Delay-boundary discontinuity.** Literal Eq14 is smooth only within ceiling intervals. For N>1, the relative Frobenius jump crossing an integer q from below to above is sqrt(2/M). The finite continuous-pulse operator is continuous there. `radar_ml` optimizes separate intervals and integer branches; it does not run one smooth optimizer through all ceiling boundaries. `fisher_single` returns undefined-at-delay-branch rather than a misleading local CRB on the discontinuity.
6. **Noise convention.** Eq12 says complex covariance sigma_w² I, while Eq36 and Eq39–40 use a likelihood denominator 2*sigma_w². The latter is consistent if sigma_w² means each real component's variance. Eq47 again has sigma_w² as the complex variance. The reference resolves this by one explicit v convention and separately verifies normalization; it does not label a factor-two difference a detector gain.
7. **Posterior transcription.** Expansion of Eq37 requires xᴴGx, whereas Eq38 prints xᴴGz. Eq42/44 mix message argument/index labels. The code follows the unambiguous factorization of the likelihood, and independent exact enumeration validates it. Approximate loopy marginals remain approximate even if local factor sums are exact and the messages converge.
8. **Derivative expressions.** The printed Eq24–25 use a delay exponent different from literal Eq14, and Eq25 prints the same ISI label for both cases. Rather than assume corrections, the reference computes independent central differences of the chosen named observation model, away from branch boundaries, and includes gain nuisance terms.
9. **Multipath objective and initialization.** Individual interference terms I_p in Eq20 are generally complex; their aggregate at a solved gain system can be real, but Eq21's individual maximization needs a real-valued interpretation. Also, with all gains initialized to zero, each path maximizes the same S and selects the same strongest peak; the gain system is singular for P>1. The reference keeps this failed outcome. An additional `distinct-peaks` and `Re(I_p)` audit branch is labelled an engineering interpretation. It is neither source-complete continuous multipath ML nor a guaranteed monotonic optimizer.
10. **Pragmatic capacity and calibration.** Source Eq54 can be estimated from detector entropy only when the reported posterior is calibrated for the relevant conditional distribution. A mismatched, confidently wrong detector can score near log2|C| by entropy while making many errors. Results therefore show the Eq54 quantity as an entropy proxy alongside BER and the truth-scored log score, which is allowed to be negative. Neither is silently relabelled measured mutual information.
11. **Fine grid versus continuous numerical search.** The p11 paragraph after Eq25 says the authors find the maximizer on a fine discrete grid Γ; p12 qualifies P=1 optimality by that grid error. `benchmark_search.py` exhaustively evaluates disclosed fine grids using the source objective. `radar_ml` uses a smaller grid to initialize independent within-cell continuous optimizations and exact integer-delay branches. This is an explicitly declared numerical-search extension; it does not reproduce an undisclosed source Γ or certify the global continuous maximum.
12. **MP-Psi soft-output retention.** Raviteja v2 Algorithm1 and Eqs39–41 (pp16–18) give a confidence fraction, a local-improvement rule for hard decisions and three stopping cases. They do not uniquely specify which soft posterior the later paper should retain. Default `best-confidence-latest-tie`, `strict-best-confidence` and `last` are distinct labelled engineering policies. Strict best can retain first-iteration marginals while all confidence fractions stay zero. The first complete sweep is preserved under `historical-strict-best-output`; the final sweep uses latest ties. `mp-psi-policy-sensitivity.json` saves identical complete receiver inputs and all three outputs, hard decisions, confidence traces and the separate source hard-update interpretation. This change is not a claimed correction to an author-specified soft rule.

## Consequences for the selected figures

- Literal Eq14 is a product of unitary Dirichlet matrices and a diagonal matrix of unit-modulus phases. For P=1, G=|h′|²I exactly: MP-G has no pair edges and calibrated LMMSE produces the same symbol posterior. Any visible P=1 separation between those curves in the source requires an additional model/calibration/implementation choice; the reference will not manufacture it
- Original N=50,M=64, guard=T/4 Gaussian rate checkpoints from Fig4 bottom can be calculated exactly using the unitary determinant identity. This is not execution of a 3200-dimensional detector and does not complete Fig4's radar panels
- Reduced Fig6/7-style experiments use the same realization/observation for all detectors, full versus rounded-delay nominal CSI, 16-QAM and disclosed path powers, dimensions and stopping rules. They are not original fullsize figure reproduction
- A reduced Fig4-style sensing sweep compares grid-only and continuous estimates on the same y, with CRB and all threshold/optimizer failures retained. OFDM/FMCW comparative radar claims remain open pending their complete guard/window/sign/resource audit
- Fullsize Fig4–7 Monte Carlo, analytical waterfall Eq26–35, general P>1 continuous estimation, low-complexity LMMSE [26], original channel distributions and browser execution remain uncompleted gates
