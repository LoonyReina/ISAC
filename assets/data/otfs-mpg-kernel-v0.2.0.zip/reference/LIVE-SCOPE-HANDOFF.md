# Bounded fresh-input scope after the reference gate

This is a numerical/runtime handoff, not browser approval. No website, JavaScript port, Worker, browser screenshot or end-to-end latency has been implemented or tested here.

## Stable mathematical scope

- P=1 sensing: known complex transmit x, observed y, unknown h′, q=τB and a=νNT; source-style grid search and explicitly extended continuous per-cell profile-ML search
- Named observation models: `eq14_literal` and `exact_rect_finite`; the former is a sampled cyclic surrogate with explicit convention, the latter is the finite continuous-pulse projection. `eq14_negative_delay_cyclic` is audit-only
- Communication: P=1 or P=2 integer/fractional channels, perfect supplied CSI, uniform unit-energy QPSK or 16-QAM, actual Gram-factor MP-G and calibrated full block LMMSE on the identical y
- Optional MP-Psi is an explicitly labelled Gaussian-message/soft-retention adaptation, with its rounded-delay CSI variant kept separate. Do not infer the numerical source's hidden retention choices from the new default
- Exact exhaustive posterior is a tiny-state validation oracle, never substituted for an iterative detector
- Multipath sensing is excluded from initial live scope: source-zero initialization fails and the unprinted augmented grid branch can stop away from joint ML even noiselessly

## Domains to profile, not release

Start numerical JavaScript parity and Worker profiling at N=3,M=4 for a 16-QAM two-path detector, then N=4,M=8. A bigger offline Python test is not permission to make it a default browser slider range. Retain a Run action, strict budget, cancellation and stale-result protection. The source N=50,M=64 detector is an offline engineering task, not each-slider recomputation.

`offline-compute-benchmarks.json` reports actual Python construction+MP-G costs on an AMD EPYC container and individual outcomes. `search-budget-comparison.json` reports source-style grids versus continuous extension, with intentionally unequal evaluation counts on identical observations. These measurements are not browser latency and were collected in a shared task environment, without an isolated-process performance guarantee.

For dense source-size D=3200, a complex128 channel or Gram matrix alone occupies 163,840,000 bytes. An uncompressed all-pair 16-QAM float64 potential table can exceed 10 GB. This is a storage upper bound, not a measured runtime or a claim that no structured/sparse faithful implementation is possible. Any pruning, low-rank approximation, batching or alternate message layout must be declared and validated before changing evidence status.

## Allowed exact implementation simplification

Literal Eq14 separates as a delay Dirichlet matrix, a Doppler Dirichlet matrix and an input-column unit-modulus phase. A port may exploit this *exact algebraic factorization* rather than materialize each NM-by-NM matrix for every candidate, if independent fixtures verify output, gain phase, vector ordering and both branches. It must not replace the channel by an unrelated ideal-pulse 2-D circular convolution or an integer-only FFT peak detector.

Every complete MP-G outgoing probability vector requires summing all constellation pairs at an edge; the generic scalar-term count is 2*E*Q² per flooding iteration. The paper's statement about linear complexity per output-symbol value does not imply that all Q entries of every message together cost O(Q) without further structure.

## Required input/information boundary

Radar receiver: frame, known x, actual y, model, search domain and budgets only. Communication receiver: actual y, explicitly supplied H, complex noise variance, constellation and budgets only. Truth, simulation seed/noise, oracle answers and true-label-selected starts stay in generator/evaluator records. A method/model toggle must not regenerate the held observation.

Return real message deltas, actual local search outcomes and failure/cap statuses. Current reference traces do not include probability snapshots, inspected templates, full grid surfaces or graph-edge display arrays; an adapter must compute/emit and independently validate them. Do not animate a fictitious history.

## Release gates still open

JavaScript parity over fresh arbitrary inputs; independent export replay; model-specific physical/normalized units; source-grid versus continuous-extension labels; local-CRB boundary and finite-sample caveats; safe complexity limits; Worker cancellation/supersession; measured desktop control-to-result latency; actual teaching/interaction review; and exact-commit deployment verification.
