# Independent rectangular-pulse operator review

## Decision

**Eq. (14) is a coherent sampled, cyclic-frame operator under an explicit alternative convention. It is not the exact finite-frame operator defined by the printed Eqs. (3)–(9), and those two models must not be silently identified.** The fractional-delay sign is not, by itself, evidence of a typo: a fixed delay-coordinate phase change plus a path-gain phase removes that difference. A complete alternative convention also explains the ceiling mask. This review does not infer an author-intended correction or authorize changing the literal implementation.

Recommended disposition: retain `eq14_literal` for explicitly labelled formula reproduction; retain `exact_rect_finite` for the stated finite continuous-time waveform. The existing `eq14_negative_delay_cyclic` is a **sign-only diagnostic**, not the literal Eq. (13) left-node quadrature, because it retains the ceiling mask. A physical production simulator needs an explicit choice of frame extension, observation window, quadrature, coordinate origin, and gain convention.

## Source and independent implementation

Source: [arXiv:1910.01896v1](https://arxiv.org/pdf/1910.01896v1), PDF SHA-256 `7787286d004ea1014fea059dea88ad4320536a8afcef44dc89a482b0feaaabdc`.

Relevant locations:
- PDF p. 6: Eqs. (3)–(4), positive subcarriers, finite transmit indices, pulse support
- PDF p. 7: Eqs. (5)–(9), channel law, matched filter, ambiguity definition, and gain reparameterization; Eq. (11) is at the top of that page
- PDF p. 8: Eq. (14), column stacking following Eq. (12), left-endpoint quadrature Eq. (13), rectangular-pulse claim and Eq. (15)
- PDF p. 9: ceiling definition and the two index sets in Eq. (16)
- PDF p. 22: the OTFS guard interval is described as inserted at the **end** of the frame; the text does not explicitly provide the cyclic prehistory needed below

`probe_conventions.py` derives operators independently and imports only NumPy. It does not import `otfs_reference.py`. Run:

    OPENBLAS_NUM_THREADS=1 python probe_conventions.py

The run writes `results.json`; assertions verify exact-integral/direct-waveform agreement, finite and cyclic left-node closed forms, the sign gauge identity, and the complete alternative convention. Additional checks use non-power-of-two dimensions, negative Doppler, near-frame-length delay, and N=1. `reference_crosscheck.json` records a subsequent independent-vs-existing-code comparison; all exact-operator errors are below 5.0e-15, and literal operators match exactly. No shared implementation was edited.

## Derivation from Eqs. (3)–(9)

Use dimensionless d=τ/T=q/M, v=νT=α/N and unit-energy rectangular pulses. Let U be the unitary version of Eq. (3). This changes transmit/receive normalization together and leaves the end-to-end operator unchanged. Column index is k+N*l, exactly the source's column stacking. Operators below multiply h′=h exp(2πiντ).

For receive symbol n and transmit symbol n′, with transmit-local time u:

    a = max(0, n−n′−d),  b = min(1, n−n′+1−d)
    H[n,m;n′,m′] = exp(2πi v n′) exp(−2πi m d)
                   × ∫[a,b] exp(2πi(m′−m+v)u) du
    Ψ_exact = Uᴴ H U

An empty overlap contributes zero. For width w=b−a>0 and f=m′−m+v, the integral equals w*sinc(fw)*exp(2πi f(a+b)/2). The finite frame restricts both n and n′ to 0,…,N−1. A separately labelled cyclic model adds n′=−1 with X[−1,m]=X[N−1,m], preserving the actual time −T in its Doppler phase.

A second implementation directly synthesizes s(t−τ) from Eq. (4), applies Eq. (5), and integrates Eq. (6) with split Gauss–Legendre quadrature. Its tested relative errors against the analytic operator are below 1e-14.

### What the printed M-node left quadrature gives

Let D_L(z)=(1/L)Σ[j=0,…,L−1] exp(2πi jz/L). At transmit-local nodes u=i/M, the sum over m′ selects i=l′. For half-open pulses [0,T), the next receive symbol is selected by

    b_l′ = 1{l′+q ≥ M} = 1{l′ ≥ M−floor(q)}.

For a cyclic frame, the resulting operator is

    Ψ_left,cyclic[k,l;k′,l′]
      = D_N(k′−k+α) D_M(l−l′−q)
        × exp(2πi v l′/M) exp(−2πi b_l′(k′/N+v)).

For the actual finite frame, replace its last Doppler factors by

    (1/N) Σ[n′=0,…,N−1−b_l′] exp(2πi n′(k′−k+α)/N)
    × exp(−2πi b_l′ k/N).

Both formulas match independently assembled quadrature matrices to approximately 1e-15. Literal Eq. (14) instead uses D_M(l′−l+q), the ceiling mask, and the full cyclic Doppler sum.

## Conventions investigated

### 1. The delay-kernel sign is a removable coordinate/gain gauge

For the **same** boundary mask define R[k,l]=exp(−2πi l/M) and c(q)=exp(−2πi q(M−1)/M). Then exactly

    Ψ_negative_delay = c(q) R Ψ_literal Rᴴ.

This follows from D_M(−z)=exp(−2πi z(M−1)/M)D_M(z). A fixed coordinate rephasing and a per-path complex-gain change therefore explain the sign. With the original coordinates fixed, a scalar gain alone does not suffice: at N=4, M=8, q=1.3, α=.37 its best residual is 0.535114. At integer q the two kernels already coincide on their support, so integer-delay tests cannot detect this issue.

### 2. A complete consistent convention reproduces **all** of Eq. (14)

Make these explicit choices:
1. Cyclic frame prehistory, X[−1,m]=X[N−1,m]
2. Physical carrier frequencies 0,−Δf,…,−(M−1)Δf
3. Corresponding transforms with delay origin l+1: the transmit exponent is 2πi(nk/N + m(l+1)/M), and reception uses its inverse
4. Right-endpoint quadrature u=(j+1)/M on pulses (0,T], using strict crossing u+d>1
5. Gain h′_literal=h′_physical exp(2πi v/M)

The crossing mask is then precisely l′≥M−ceil(q), including grid points, and the matrix before gain conversion is exp(2πi v/M) Ψ_literal. Across all tested dimensions and parameters, the gain-adjusted relative error is at most 2.72e-15.

Thus a physically meaningful sampled convention exists. It changes explicit elements of Eqs. (3), (4), (7), and (13); it does not make all printed equations simultaneously verbatim identical. This distinction is essential if known DD pilots/data are used without the corresponding coordinate change.

### 3. Fourier signs, normalization, stacking, channel sign, and gain

Changing either FFT sign consistently is a basis permutation; column/row stacking is another permutation. Complex conjugation, reversing the Doppler/delay coordinate convention consistently, fixed phase origins, and unitary Fourier normalization do not remove physical window/projection loss. Applying the same four Fourier-sign choices or row stacking to both models leaves the measured discrepancy invariant (1.5602259324 in the fractional example).

Using h exp(2πiνt) versus h′ exp(2πiν(t−τ)) merely changes the path gain by exp(2πiντ). Moving a common carrier-frequency origin also supplies a path-delay gain phase when modulation and demodulation are changed consistently. These phases cannot change singular values or repair finite-frame loss.

This invariant argument is stronger than searching a finite list of conventions: literal Eq. (14) is unitary for one unit-gain path, since it factors into two unitary circulant kernels and a unit-modulus diagonal matrix. The exact finite-frame matrix generically has unequal singular values. No scalar gain plus any unitary Fourier/sign/permutation/phase convention can make these operators identical in general.

### 4. Cyclic extension and guard handling are modeling choices

The full D_N factor assumes cyclic prehistory or an equivalent explicit boundary treatment. A zero guard after a finite frame does not by itself supply the missing prehistory. Collecting the delayed tail as additional samples changes the observation matrix; folding the tail back is another processing operation and must be stated.

For integer q in the sampled model, the finite-versus-cyclic relative Frobenius discrepancy is sqrt(q/(NM−q)); q=2, N=4, M=8 gives 0.2581988897. This remains despite integer delay and any redefinition of the scalar path gain.

### 5. Eq. (11) is not Eq. (8) verbatim under the printed ambiguity definition

Eq. (8) uses ambiguity argument (m−m′)Δf−ν, while Eq. (11) prints +(ν) and swaps the pulse labels. Equal real rectangular pulses make the pulse-label swap irrelevant, but not the Doppler sign. At τ=0 this changes within-symbol exp(+2πiνu) to exp(−2πiνu) while leaving slow-time exp(+2πiνnT) unchanged; a single global Doppler-sign choice cannot do that. Implementing the printed Eq. (11) integral separately produces relative errors 0.629173 at q=0, α=.37 and 0.603845 at q=1.3, α=.37, versus Eq. (8). Eq. (13)'s pulse label/integrand and Eq. (15)'s sign also warrant explicit interpretation rather than silent transcription. No author-intended correction is asserted here.

## Quantified model separation

Errors below are ||A−B||_F/||B||_F for N=4, M=8, and all gain/coordinate choices are as printed unless noted.

| q | α | Literal Eq14 vs exact finite | After best scalar gain fit |
|---:|---:|---:|---:|
| 0 | 0 | 9.68e-16 | 9.68e-16 |
| 0 | 1 | .324469 | .307662 |
| 2 | 0 | .533312 | .488919 |
| 2 | 1 | .543545 | .496125 |
| 2 | .37 | .534755 | .489940 |
| 1.3 | 0 | 1.557706 | .739519 |
| 1.3 | .37 | 1.560226 | .737453 |

For q=1.3, α=.37:
- Exact cyclic vs exact finite: .182157
- Correct left-node cyclic quadrature vs exact cyclic: .366177
- Ceiling-mask vs floor-mask sign-corrected sampled models: .500000
- Exact finite singular values span .000203951 to .9999999996; the literal operator has all singular values 1 within roundoff

These separated errors are diagnostic, not additive.

The exact operator is continuous at τ=0. Eq. (14)'s ceiling mask has a right-limit jump sqrt(2/M)=.5 for N>1, whereas the exact change at q=1e-10 is 3.32e-10. This is compatible with a right-endpoint sampled surrogate, not an exact integral. At q=1.3, α=.37, increasing quadrature nodes per symbol from 8→64→4096 reduces the physical finite left-rule error .348570→.031692→.000501. At fixed q=1.3 with increasing M=8,16,32,64, the M-node cyclic-vs-exact error is .366177,.254025,.178352,.126003. Large M helps in these probes but does not justify claiming machine-precision equivalence at a chosen finite M.

## Acceptance boundary

- **Accepted:** existing literal Eq. (14) transcription and existing exact finite rectangular-pulse implementation independently reproduce their respective stated models
- **Accepted with explicit assumptions:** a coherent sampled cyclic convention explaining literal Eq. (14), including fractional delay and Doppler
- **Not established:** that this alternative was the authors' intended convention, that all printed equations are jointly verbatim consistent, or that the approximation is sufficiently accurate at any production parameter point without validation
- **Required before physical claims:** select and document one waveform/receiver/window convention; test the intended dimensions and parameter range; avoid estimating under Eq. (14) and reporting its results as exact finite-waveform behavior
