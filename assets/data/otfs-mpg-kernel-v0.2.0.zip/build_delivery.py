"""Freeze the explicit deliverable allowlist; never include private paper inputs."""
from pathlib import Path
import hashlib,json,zipfile,datetime
ROOT=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
accepted={
'src/kernel.mjs':'80fad52c681d19eaa5d82a6b1d20dd329a6cf40d39c08cd92774f88118d8f1e7',
'src/protocol.mjs':'d7242dbe37ed8a060f2b14471538cd0920149aeb0a05aa16064996dfc572be9a',
'src/node-worker.mjs':'f7e2fd941ca3959f2d3259554bba36022c2972560c35bbf5e74b2cf147940a5d',
'src/browser-worker.mjs':'ddc639f67253409104e101aaef7bad6c5ce7d8ae51290619237c0d6a921d4ee5',
'src/simulation.mjs':'17fa68083040da01023d976acb42cd7ab69a9ba490844a02013b6e00c86f3940',
'reference/otfs_reference.py':'92b997201493a3187b5ddb37026672ef44e163131e422bdf8618f11b17aa235f'}
for path,digest in accepted.items():assert sha(ROOT/path)==digest,path
assert 'Accept kernel 0.2.0' in (ROOT/'independent-review/JUDGEMENT.md').read_text()
assert '26' in (ROOT/'evidence/owner-tests.tap').read_text()
for path in ['evidence/python-oracle-report.json','evidence/high-precision-report.json','evidence/node-runtime.json','evidence/node-stress.json','evidence/zero-pruning-runtime.json']:
 assert json.loads((ROOT/path).read_text())['status']=='passed',path
freeze={
 'schemaVersion':'otfs-mpg-prototype-freeze-v1','kernelVersion':'0.2.0','frozenAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'status':'accepted-bounded-numerical-node-prototype','sourceHashes':accepted,
 'scope':{'model':'eq14_literal-explicit-sampled-cyclic-convention','maxN':3,'maxM':4,'maxD':12,'paths':[1,2],'constellations':[4,16],
 'methods':['Gram-factor MP-G exact local sums on retained graph','full LMMSE effective-AWGN soft conversion'],
 'maxIterations':100,'recommendedFirstLesson':{'N':3,'M':4,'maxIterations':30,'damping':1,'edgeTolerance':0}},
 'verification':{'ownerKernelWorkerTests':26,'ownerPythonCases':48,'owner80DigitCases':12,'independentValidRawReceivers':103,'independentOperatorCases':58,'independent100DigitLMMSECases':31,'independentWorkerChecks':27,'independentPruningBoundChecks':14,'nodeProfileRuns':40,'nodeDenseMaximumBudgetRuns':5,'nodeCancellationTimingRuns':10,'nodeZeroPruningLessonRuns':12},
 'correction':'Frozen Python unchanged. Port removes absolute LMMSE variance floor, cancels common score analytically, stabilizes log normalization, and rejects sparse input arrays; see NUMERICAL-CORRECTION.md.',
 'pruning':'PRUNING.md bound is for exact full-vs-retained distributions only, not loopy BP sensitivity. First lesson recommends edgeTolerance=0.',
 'notApproved':['browser execution','browser worker adapter execution','desktop or UI timing','UI interaction','browser-download export replay','repository integration','publication','MP-Psi','sensing implementation','paper-size detectors','exact finite physical waveform equivalence'],
 'review':'independent-review/JUDGEMENT.md','referenceFreezeSHA256':sha(ROOT/'reference/FREEZE.json'),
 'timingBoundary':'Actual Node workers in shared cloud environment; no browser/desktop latency claim.'}
(ROOT/'FREEZE.json').write_text(json.dumps(freeze,indent=2,allow_nan=False)+'\n')
top=['README.md','INTERFACE.md','NUMERICAL-CORRECTION.md','PRUNING.md','package.json','requirements.txt','run_all.sh','build_delivery.py','FREEZE.json']
allowed=[ROOT/p for p in top]
for name in ['src','tests','evidence','reference','independent-review']:
 for p in sorted((ROOT/name).rglob('*')):
  if p.is_file() and '__pycache__' not in p.parts and p.suffix not in ['.pyc','.pdf'] and 'private' not in p.name and '.mpl-cache' not in p.parts:allowed.append(p)
assert len(allowed)==len(set(allowed))
for p in allowed:
 assert not p.is_symlink()
 assert not any(s in p.name for s in ['source-private','.pdf'])
manifest={'schemaVersion':'otfs-mpg-delivery-manifest-v1','version':'0.2.0','fileCount':len(allowed),'files':[{'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(allowed)]}
mpath=ROOT/'DELIVERY-MANIFEST.json';mpath.write_text(json.dumps(manifest,indent=2)+'\n')
archive=ROOT/'otfs-mpg-kernel-v0.2.0.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(allowed+[mpath]):z.write(p,str(p.relative_to(ROOT)))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 assert set(z.namelist())=={str(p.relative_to(ROOT)) for p in allowed+[mpath]}
 for entry in manifest['files']:assert hashlib.sha256(z.read(entry['path'])).hexdigest()==entry['sha256']
record={'status':'verified','archive':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive),'fileCount':len(allowed)+1,
 'freezeSHA256':sha(ROOT/'FREEZE.json'),'manifestSHA256':sha(mpath),'allArchiveEntriesRehashed':True,'privateSourceInputsIncluded':False}
(ROOT/'DELIVERY.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))
