# Bounded OTFS communication numerical prototype

Independent JavaScript implementation for **fresh receiver inputs**, scoped to literal Eq. (14), actual Gram-factor MP-G, and calibrated full block LMMSE. No UI, repository integration, browser launch, publication, source-sized detector, MP-Psi, or sensing implementation is included. Sensing remains a distinct parallel/next stage; this communication port does not replace it.

## Evidence status

- Accepted Python reference subset pinned in `reference/` (the copied upstream delivery manifest describes the separate full reference, not files all included in this port); its core SHA-256 is `92b997201493a3187b5ddb37026672ef44e163131e422bdf8618f11b17aa235f`
- Independent NumPy oracle plus accepted-reference comparison: **48 cases**, including fresh random fractional inputs, both delay-boundary sides, P=1 equality, raw rank-deficient/zero/tree/loopy matrices, damping and capped solves. Full inputs and outputs are saved under `evidence/`
- Owner pure-kernel and actual Node Worker tests: **26/26 passed** after the scale-stable correction
- Actual Node Worker bounded profiling: 40 ordinary settings, 5 maximum dense-budget cases, 10 cancellation cases, with configured 64 MiB old-generation/16 MiB young-generation V8 limits
- Independent review accepted corrected v0.2.0 for the bounded numerical/Node scope: 103 valid raw receiver cases, 58 operator checks, 31 independent 100-digit soft-conversion checks, and 27 Worker lifecycle checks. See `independent-review/JUDGEMENT.md` for exact limits and hashes
- **Browser execution, browser Worker entrypoint execution, desktop control-to-result latency, browser download/replay, UI interaction, production packaging and deployment have not been tested**

No dependency installation is needed for JavaScript. Python checks need NumPy/SciPy (the latter only for the pinned reference); high-precision correction checks additionally use mpmath.

Version 0.2.0 makes two disclosed numerical corrections beyond the frozen reference: stable log normalization after removing the maximum, and scale-stable full-LMMSE soft calibration without an absolute residual-variance floor. See `NUMERICAL-CORRECTION.md`. The original reference is unchanged; universal parity to its flawed floor at tiny gains is explicitly not claimed.

```sh
OPENBLAS_NUM_THREADS=1 python tests/check_python_oracle.py
OPENBLAS_NUM_THREADS=1 python tests/check_high_precision.py
npm test
node tests/benchmark.mjs
node tests/stress_worker.mjs
```

## Mathematical interpretation

Source: [Gaudio et al., arXiv:1910.01896v1](https://arxiv.org/pdf/1910.01896v1), PDF SHA-256 `7787286d004ea1014fea059dea88ad4320536a8afcef44dc89a482b0feaaabdc`. Eq. (14)/(16) supplies the operator; Eqs. (37)/(39)–(44) supply Gram-factor sum-product; Eq. (47) supplies the full linear estimator. The reference audit resolves printed factorization/noise inconsistencies explicitly.

This is **literal Eq. (14) under an explicit sampled cyclic convention**: cyclic prehistory, right-endpoint quadrature, negative carriers, a one-sample DD origin, and the corresponding effective path-gain phase. It is not the finite continuous rectangular-pulse waveform of printed Eqs. (3)–(9). The ceiling branch discontinuity is retained. Small N/M is an algorithm teaching budget, not a claim that sampling error is physically negligible.

- Coordinate order: Doppler k first, delay l second; vector index d=k+N*l
- Delay q=τB; Doppler a=νNT; 0≤q<M, |a|<N
- JSON matrix H is an array of rows; every scalar is `{re,im}`
- H multiplies the explicitly declared effective gain h′, not an unadjusted physical h
- Noise variance is **v=E|w|²**, and the likelihood is exp(−||y−Hx||²/v)
- QPSK/16-QAM are uniformly distributed, unit-average-energy, canonical real-level-then-imaginary-level ordering, with separate Gray labels for evaluation
- Exact finite exponential sums implement the complex operator; no generic FFT channel or integer-grid proxy is substituted
- MP-G computes each local constellation-pair sum on the retained graph in the log domain and uses synchronous flooding. Damping=1 is undamped flooding. Dropped G edges are below a declared relative cutoff, and their removed Frobenius norm is returned. A small relative Gram cutoff is not necessarily negligible after division by very small noise variance: an independent edgeTolerance=10⁻¹² stress case changed exact tiny-tree marginals by about 4.27×10⁻⁵. Use edgeTolerance=0 to retain every numerically nonzero coupling; this does not remove floating-point error
- Full LMMSE solves (HᴴH+v/E I)W=Hᴴ using complex Cholesky. Severe conditioning can amplify forward error in intermediate gains/variances despite a small solve residual; the independent review quantifies this rather than claiming universal machine precision. Soft outputs use A=WH, gain=Aii, and residual variance E Σj≠i |Aij|² + v Σr |Wir|². This effective-AWGN calibration is explicit; it is not asserted to give exact multiuser posteriors
- Loopy MP convergence is a message-delta test, not proof of correct marginals. Extreme high-amplitude/low-noise cases also have greater floating-point sensitivity; the independent 100-digit dense stress comparison observed approximately 4.65×10⁻⁹ MP probability error, rather than ordinary-case near-machine-precision parity. A capped method remains `max-iterations`, even when the containing comparison finishes
- P=1 literal Eq14 is unitary up to path gain. Its Gram matrix is diagonal within numerical tolerance, the meaningful MP graph has zero edges, and calibrated MP-G/LMMSE probabilities agree. No detector gap is manufactured

## Modules

- `src/kernel.mjs`: pure equation operator, strict receiver validation, MP-G session, full LMMSE, synchronous comparison and canonical input digest
- `src/simulation.mjs`: fresh seeded data/noise generation and truth-scored evaluation. Neither numerical receiver nor Worker imports this module
- `src/protocol.mjs`: shared asynchronous Worker controller and consumer stale-result gate
- `src/node-worker.mjs`: tested `worker_threads` endpoint
- `src/browser-worker.mjs`: browser module-Worker adapter using the same controller. Browser compatibility is an untested release gate
- `tests/check_python_oracle.py`: new independent NumPy formulas, frozen-reference checks, tiny exact likelihood checks; exhaustive oracles exist only in tests

## Approved implementation limits

These are **implementation limits**, not physical impossibility boundaries:

| Quantity | Limit |
|---|---|
| Frame N, M | integer 1≤N≤3; 1≤M≤4; D≤12 |
| Generated paths | one or two |
| Generator gain components | each real/imaginary component within ±4 |
| Receiver H | D×D, each real/imaginary component within ±16 |
| Receiver y | D entries, each real/imaginary component within ±64 |
| Complex noise variance | 10⁻⁶ through 1000 inclusive |
| Constellation | exactly canonical unit-energy QPSK or 16-QAM, 10⁻¹² input tolerance |
| Iterations | integer 1 through 100 |
| Message convergence tolerance | 10⁻¹⁴ through 10⁻³ |
| Damping weight on new messages | .05 through 1 |
| Relative Gram edge tolerance | 0 through 10⁻¹² |
| History | explicit Boolean; at most initial state + 100 actual iterations |

Raw H is accepted for independent receiver experiments. The receiver cannot prove CSI is perfect or H is realizable by two Eq14 paths from that array alone. The caller is responsible for that provenance; the bundled generator establishes it by returning the actual same H used to simulate y. Arbitrary/rank matrices in tests are numerical stress cases, not two-path physical claims.

## Input and output contract

See `INTERFACE.md` for complete request/status and snapshot semantics. `PRUNING.md` gives the noise-scaled cutoff bound and recommends edgeTolerance=0 for the first bounded lesson; it distinguishes exact-distribution bounds from loopy message outputs. Every result is a fresh computation from supplied arrays. No cached curves, fixtures, generated truth, seed or offline optimum are read by the solvers.

Receiver inputs contain only frame/model/CSI declarations, H, y, noise variance, constellation and detector settings. Validators reject unknown fields, including truth/seed/noiseless/noise/oracle fields at the receiver boundary. Actual arrays are authoritative; a seed is neither a substitute for them nor a receiver input.

`simulation.mjs` produces a separate `evaluation` record. Evaluation can reveal symbol/bit errors, an entropy proxy, and a truth log score. The entropy proxy is **not capacity or measured mutual information**. Confidently wrong truth log scores can be negative and are not clipped.

Both methods consume identical immutable validated H/y/noise/constellation input. The canonical sorted-key JSON SHA-256 includes the settings too. Changing only method budget changes the request digest, while preserving the underlying observation arrays. A view-only selection of an actual saved history does not rerun or alter the solve.

## Runtime interpretation

The 40-run Node measurement, on a shared AMD EPYC 9V74 container with Node v24.19.0, measured a maximum-budget 16-QAM/E48/100-iteration/history-on median of approximately **352 ms** from Node Worker creation through transfer (five samples). The arbitrary dense E66 maximum-budget run reached approximately **418 ms** in five samples; largest serialized terminal response was approximately **5.01 MB**. Ten cancellation tests terminated after the first computed iteration, with the slowest observed cancel-to-terminal approximately **4.75 ms**.

The independent lifecycle review additionally exercised cancellation after iterations 1, 4 and 12, with its own separately recorded timing. Read that report rather than treating the owner’s first-iteration timings as a universal cancellation ceiling.

These are observations in a shared Node container, not real-time promises, browser timings, named-desktop results or robust p95 guarantees. “p95” over five samples is just the sample maximum. Configured V8 heap ceilings are not measured peak memory, browser-memory ceilings, or total process RSS.

The largest generic scalar pairwise term count is 2×66×16² = 33,792 per flooding iteration, up to 3,379,200 at 100 iterations. Complexity grows with complete constellation-pair messages, not merely O(Q) per full message.

## Remaining release gates

Actual browser Worker and unsupported-browser failure checks; UI freshness/cancellation/display semantics; downloaded export replay; named-desktop runtime and memory measurements; physical resource/unit presentation; teaching/interaction review; and separate authorization for repository integration and publication. The browser adapter source alone does not close these gates.
