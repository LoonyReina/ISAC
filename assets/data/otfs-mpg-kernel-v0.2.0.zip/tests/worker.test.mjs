import test from 'node:test';
import assert from 'node:assert/strict';
import {Worker} from 'node:worker_threads';
import {generateObservation} from '../src/simulation.mjs';
import {solveSync,inputDigest} from '../src/kernel.mjs';
const receiver=()=>generateObservation({frame:{N:3,M:4},paths:[{delayBin:.72,dopplerBin:-.54,gain:{re:1,im:.2}},{delayBin:2.12,dopplerBin:.61,gain:{re:.6,im:-.3}}],seed:713,settings:{maxIterations:100,tolerance:1e-14,damping:.05,edgeTolerance:1e-13,captureHistory:true}}).receiver;
function harness(t) {
 const worker=new Worker(new URL('../src/node-worker.mjs',import.meta.url)),messages=[],waiters=[];
 worker.on('message',m=>{messages.push(m);for(const w of [...waiters])if(w.predicate(m)){clearTimeout(w.timer);waiters.splice(waiters.indexOf(w),1);w.resolve(m);}});
 t.after(()=>worker.terminate());
 return {worker,messages,send:m=>worker.postMessage(m),wait(predicate,ms=10000){const old=messages.find(predicate);if(old)return Promise.resolve(old);return new Promise((resolve,reject)=>{const w={predicate,resolve,timer:setTimeout(()=>reject(new Error('Worker wait timed out')),ms)};waiters.push(w);});}};
}
const terminal=id=>m=>m.type==='terminal'&&m.requestId===id;
test('actual Node Worker completes same numerical solve and immutable digest',async t=>{
 const h=harness(t),r=receiver();r.settings.maxIterations=5;const expected=solveSync(r),digest=await inputDigest(r);h.send({type:'run',requestId:'complete',receiver:r});const out=await h.wait(terminal('complete'));
 assert.equal(out.status,'completed');assert.equal(out.inputDigest,digest);assert.deepEqual(out.receiver,r);assert.deepEqual(out.methods.mpg,expected.mpg);assert.deepEqual(out.methods.lmmse,expected.lmmse);assert(h.messages.some(m=>m.phase==='mp-g'&&m.iteration===1));assert(out.timing.totalCoreWallMs>0);assert.equal(out.partialResult,false);
});
test('actual Worker accepts cancellation between real iterations with no completed result',async t=>{
 const h=harness(t);h.send({type:'run',requestId:'cancel',receiver:receiver()});await h.wait(m=>m.requestId==='cancel'&&m.phase==='mp-g'&&m.iteration===1);h.send({type:'cancel',requestId:'cancel'});const out=await h.wait(terminal('cancel'));
 assert.equal(out.status,'cancelled');assert(out.partial.mpg.iterations>=1&&out.partial.mpg.iterations<100);assert.equal(out.partialResult,true);assert(!h.messages.some(m=>m.type==='terminal'&&m.requestId==='cancel'&&m.status==='completed'));
});
test('new Run supersedes old job; rapid repeated flows complete only the latest',async t=>{
 const h=harness(t),r=receiver();h.send({type:'run',requestId:'old',receiver:r});await h.wait(m=>m.requestId==='old'&&m.phase==='mp-g');
 const fresh=structuredClone(r);fresh.settings.maxIterations=2;fresh.y[0].re+=.013;
 h.send({type:'run',requestId:'middle',receiver:r});h.send({type:'run',requestId:'latest',receiver:fresh});
 const [old,middle,latest]=await Promise.all(['old','middle','latest'].map(id=>h.wait(terminal(id))));
 assert.equal(old.status,'superseded');assert.equal(middle.status,'superseded');assert.equal(latest.status,'completed');assert.equal(latest.inputDigest,await inputDigest(fresh));
});
test('invalid input yields hard terminal without methods; valid run afterward recovers',async t=>{
 const h=harness(t),bad=receiver();bad.truthIndices=[1,2];h.send({type:'run',requestId:'bad',receiver:bad});const out=await h.wait(terminal('bad'));assert.equal(out.status,'invalid-input');assert.equal(out.methods,undefined);assert.match(out.error.message,/truthIndices/);
 const good=receiver();good.settings.maxIterations=1;h.send({type:'run',requestId:'good',receiver:good});assert.equal((await h.wait(terminal('good'))).status,'completed');
});
test('duplicate IDs, unknown protocol fields and inactive cancellation are explicit',async t=>{
 const h=harness(t),r=receiver();r.settings.maxIterations=1;h.send({type:'run',requestId:'once',receiver:r});await h.wait(terminal('once'));h.send({type:'run',requestId:'once',receiver:r});const dup=await h.wait(m=>m.type==='protocol-error'&&m.requestId==='once');assert.match(dup.error.message,/already used/);
 h.send({type:'run',requestId:'extra',receiver:r,truth:[]});assert.equal((await h.wait(m=>m.type==='protocol-error'&&m.requestId==='extra')).status,'invalid-input');
 h.send({type:'cancel',requestId:'inactive'});assert.equal((await h.wait(m=>m.type==='cancel-ignored')).status,'not-active');
});
test('real arithmetic underflow emits numerical-failure with no successful methods',async t=>{
 const h=harness(t),r=generateObservation({frame:{N:1,M:1},paths:[{delayBin:0,dopplerBin:0,gain:{re:1,im:0}}],order:4,noiseVariance:1e-6}).receiver;r.H[0][0].re=1e-200;
 h.send({type:'run',requestId:'underflow',receiver:r});const out=await h.wait(terminal('underflow'));assert.equal(out.status,'numerical-failure');assert.equal(out.methods,undefined);assert.match(out.error.message,/underflow/);
});
