"""80-digit full-LMMSE/direct scalar posterior regression for scale-safe correction.
No reference floor is used. Input decimal/binary floats are promoted exactly.
"""
import json, math, subprocess
from pathlib import Path
import mpmath as mp
import numpy as np
ROOT=Path(__file__).resolve().parents[1];mp.mp.dps=80

def enc(a):
 a=np.asarray(a)
 if a.ndim==0:return {'re':float(a.real),'im':float(a.imag)}
 return [enc(x) for x in a]
def scalar(x):return mp.mpc(mp.mpf(x['re']),mp.mpf(x['im']))
def normalize(u):
 m=max(u);p=[mp.exp(x-m) for x in u];s=sum(p);return [float(x/s) for x in p]
def high_lmmse(r):
 H=mp.matrix([[scalar(x) for x in row] for row in r['H']]);y=mp.matrix([scalar(x) for x in r['y']]);c=[scalar(x) for x in r['constellation']];v=mp.mpf(r['noiseVariance']);D=H.cols
 E=sum(abs(x)**2 for x in c)/len(c);W=(H.H*H+v/E*mp.eye(D))**-1*H.H;A=W*H;out=W*y;posterior=[]
 for i in range(D):
  gain=A[i,i];res=E*sum(abs(A[i,j])**2 for j in range(D) if j!=i)+v*sum(abs(W[i,j])**2 for j in range(D))
  if res==0:posterior.append([1/len(c)]*len(c))
  else:posterior.append(normalize([-abs(out[i]-gain*x)**2/res for x in c]))
 return np.array(posterior)
def direct_scalar(r):
 h=scalar(r['H'][0][0]);y=scalar(r['y'][0]);v=mp.mpf(r['noiseVariance']);c=[scalar(x) for x in r['constellation']]
 return np.array([normalize([-abs(y-h*x)**2/v for x in c])])

cases=[]
def add(id,H,y,v,Q=4):
 H=np.array(H,complex);D=len(H);n=int(math.sqrt(Q));c=np.array([complex(i,j) for i in range(1-n,n,2) for j in range(1-n,n,2)])/math.sqrt(2*(Q-1)/3)
 cases.append({'id':id,'receiver':{'frame':{'N':1,'M':D},'model':'eq14_literal','csi':'perfect-supplied','H':enc(H),'y':enc(y),'noiseVariance':v,'constellation':enc(c),'settings':{'maxIterations':30,'tolerance':1e-9,'damping':1.,'edgeTolerance':1e-13,'captureHistory':False}}})
add('reported-tiny-gain-real-y',[[1e-12]],[64],1e-6)
add('reported-tiny-gain-complex-y',[[1e-12]],[64+64j],1e-6)
add('tiny-complex-gain',[[1e-12+3e-13j]],[-63+64j],1e-6,16)
add('smaller-complex-gain',[[1e-100+1e-101j]],[64+64j],1e-6)
add('zero-channel',[[0]],[64+64j],1e-6)
add('high-score-tie',[[16+16j]],[64+0j],1e-6)
add('high-score-near-tie',[[16+16j]],[64+1e-8j],1e-6)
add('qam16-high-score',[[16-16j]],[64+64j],1e-6,16)
add('tiny-rank-one',[[1e-12,2e-12j],[2e-12,4e-12j]],[64+64j,-64+32j],1e-6,16)
add('mixed-column-scales',[[1,1e-12],[0,1e-12j]],[64+64j,31-42j],1e-6,16)
add('tiny-dense-complex',[[1e-11,2e-11j,1e-10+2e-12j],[2e-11,1e-12,3e-10j],[1e-12j,2e-11,1e-10]],[64+64j,-32+21j,13-62j],1e-6,16)
add('regular-complex-full',[[1+.4j,.2-.3j,.3],[.3j,.8-.4j,.12],[.2,.3j,.4+.7j]],[3+2j,2-3j,1-4j],.34,16)
(ROOT/'evidence/high-precision-inputs.json').write_text(json.dumps(cases,allow_nan=False))
subprocess.run(['node',str(ROOT/'tests/run_cases.mjs'),str(ROOT/'evidence/high-precision-inputs.json'),str(ROOT/'evidence/high-precision-js.json')],check=True)
outputs=json.loads((ROOT/'evidence/high-precision-js.json').read_text());findings=[]
for case,out in zip(cases,outputs):
 expected=high_lmmse(case['receiver']);actual=np.array(out['result']['lmmse']['probabilities']);error=float(np.max(abs(expected-actual)))
 assert error<1e-8,(case['id'],error,expected,actual)
 item={'id':case['id'],'lmmseMaxProbabilityError':error,'expectedLMMSE':expected.tolist(),'status':'passed'}
 if len(actual)==1:
  direct=direct_scalar(case['receiver']);item['directScalarLMMSEError']=float(np.max(abs(direct-actual)));item['directScalarMPGError']=float(np.max(abs(direct-np.array(out['result']['mpg']['probabilities']))))
  assert item['directScalarLMMSEError']<1e-8 and item['directScalarMPGError']<1e-8,item
 findings.append(item)
report={'status':'passed','precisionDecimalDigits':mp.mp.dps,'mpmathVersion':mp.__version__,'caseCount':len(cases),'findings':findings,'interpretation':'Direct full LMMSE effective-AWGN soft conversion using 80-digit arithmetic; scalar cases additionally use direct observation likelihood. No absolute residual variance floor.'}
(ROOT/'evidence/high-precision-report.json').write_text(json.dumps(report,indent=2,allow_nan=False));print(json.dumps({'status':'passed','cases':len(cases),'maxLMMSEProbabilityError':max(x['lmmseMaxProbabilityError'] for x in findings)}))
