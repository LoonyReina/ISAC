import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {buildChannel,qam,validateReceiver,createMPG,solveSync,lmmse,inputDigest,canonicalJSON,KernelError} from '../src/kernel.mjs';
import {generateObservation,evaluateDetector} from '../src/simulation.mjs';
import {createResultGate} from '../src/protocol.mjs';
const base=()=>generateObservation({frame:{N:3,M:4},paths:[{delayBin:.83,dopplerBin:-.39,gain:{re:1,im:.1}},{delayBin:2.27,dopplerBin:.71,gain:{re:.4,im:-.25}}],seed:802,order:16});
const clone=structuredClone;
const maxDiff=(a,b)=>{const x=a.flat(Infinity),y=b.flat(Infinity);return Math.max(...x.map((v,i)=>Math.abs(v-y[i])));};
const rejected=(f)=>assert.throws(f,e=>e instanceof KernelError&&e.code==='invalid-input');

test('literal zero-delay zero-Doppler identity and column stacking',()=>{
 const H=buildChannel({N:3,M:4},[{delayBin:0,dopplerBin:0,gain:{re:1,im:0}}]);
 for(let i=0;i<12;i++)for(let j=0;j<12;j++)assert(Math.hypot(H[i][j].re-(i===j?1:0),H[i][j].im)<1e-14);
});
test('literal single-path unitarity and ceiling discontinuity are retained',()=>{
 const channel=q=>buildChannel({N:3,M:4},[{delayBin:q,dopplerBin:.4,gain:{re:1,im:0}}]);
 const H=channel(1.23);for(let i=0;i<12;i++)for(let j=0;j<12;j++){
 let re=0,im=0;for(let k=0;k<12;k++){re+=H[k][i].re*H[k][j].re+H[k][i].im*H[k][j].im;im+=H[k][i].re*H[k][j].im-H[k][i].im*H[k][j].re;}assert(Math.hypot(re-(i===j?1:0),im)<1e-13);}
 const L=channel(1-1e-10),R=channel(1+1e-10);let delta=0;for(let i=0;i<12;i++)for(let j=0;j<12;j++)delta+=(L[i][j].re-R[i][j].re)**2+(L[i][j].im-R[i][j].im)**2;
 assert(Math.abs(Math.sqrt(delta/12)-Math.sqrt(2/4))<1e-8);
});
test('canonical QAM energy and Gray labels',()=>{for(const Q of [4,16]){const {symbols,labels}=qam(Q);assert(Math.abs(symbols.reduce((s,c)=>s+c.re*c.re+c.im*c.im,0)/Q-1)<1e-15);assert.equal(new Set(labels.map(x=>x.join(''))).size,Q);}});
test('single path MP-G equals calibrated full LMMSE',()=>{
 const o=generateObservation({frame:{N:3,M:4},paths:[{delayBin:1.25,dopplerBin:-.39,gain:{re:.8,im:.4}}],seed:505});const r=solveSync(o.receiver);
 assert.equal(r.mpg.graph.edgeCount,0);assert.equal(r.mpg.status,'converged');assert.equal(r.mpg.iterations,1);assert(maxDiff(r.mpg.probabilities,r.lmmse.probabilities)<1e-12);
});
test('zero information is uniform and rank deficiency is regularized',()=>{
 const r=base().receiver;r.H=r.H.map(row=>row.map(()=>({re:0,im:0})));const out=solveSync(r);
 assert(out.mpg.probabilities.flat().every(x=>Math.abs(x-1/16)<1e-15));assert(out.lmmse.probabilities.flat().every(x=>Math.abs(x-1/16)<1e-15));assert(out.lmmse.effectiveSinr.every(x=>x===0));assert.equal(out.lmmse.solveRelativeResidual,0);
});
test('actual history final state, deltas, normalization and edge complexity',()=>{
 const r=solveSync(base().receiver),m=r.mpg;assert.equal(m.history.length,m.iterations+1);assert.equal(m.graph.pairwiseScalarTermsPerIteration,2*m.graph.edgeCount*16*16);
 assert.deepEqual(m.history.at(-1).probabilities,m.probabilities);assert.deepEqual(m.history.at(-1).logProbabilities,m.logProbabilities);
 for(let n=1;n<m.history.length;n++){
 const curr=m.history[n],prev=m.history[n-1];assert.equal(curr.iteration,n);
 assert(Math.abs(maxDiff(curr.probabilities,prev.probabilities)-curr.marginalDelta)<1e-15);
 const toP=a=>a.map(row=>row.map(Math.exp));assert(Math.abs(maxDiff(toP(curr.incomingLogMessages),toP(prev.incomingLogMessages))-curr.messageDelta)<1e-15);
 for(const row of [...curr.probabilities,...toP(curr.incomingLogMessages)])assert(Math.abs(row.reduce((a,b)=>a+b,0)-1)<1e-10);
 }
});
test('captureHistory toggles storage only',()=>{const a=base().receiver,b=clone(a);b.settings.captureHistory=false;const x=solveSync(a),y=solveSync(b);assert.deepEqual(x.mpg.probabilities,y.mpg.probabilities);assert.deepEqual(x.mpg.trace,y.mpg.trace);assert.deepEqual(y.mpg.history,[]);});
test('cap is preserved and does not claim convergence',()=>{const r=base().receiver;r.settings.maxIterations=1;r.settings.tolerance=1e-14;const o=solveSync(r);assert.equal(o.mpg.status,'max-iterations');assert.equal(o.mpg.iterations,1);});
test('truth never enters receiver or changes solve',async()=>{
 const o=base(),before=canonicalJSON(o.receiver),digest=await inputDigest(o.receiver),r1=solveSync(o.receiver),e1=evaluateDetector(r1.mpg,o.evaluation);
 o.evaluation.truthIndices=o.evaluation.truthIndices.map(x=>(x+3)%16);o.generator.seed=456;const r2=solveSync(o.receiver),e2=evaluateDetector(r2.mpg,o.evaluation);
 assert.equal(canonicalJSON(o.receiver),before);assert.equal(await inputDigest(o.receiver),digest);assert.deepEqual(r1,r2);assert.notEqual(e1.truthLogScoreBits,e2.truthLogScoreBits);
 for(const name of ['truth','truthIndices','x','seed','noiseless','oracle','noiseSamples']){const bad=clone(o.receiver);bad[name]=o.evaluation.truthIndices;rejected(()=>solveSync(bad));}
});
test('fresh generator is deterministic per seed and regenerates observations',()=>{assert.deepEqual(base(),base());const b=base(),s={...b.generator,settings:b.receiver.settings};const other=generateObservation({...s,seed:s.seed+1});assert.notDeepEqual(b.receiver.y,other.receiver.y);assert.deepEqual(b.receiver.H,other.receiver.H);});
test('all invalid receiver ranges, shapes, types and unknown fields rejected',()=>{
 const mutations=[r=>r.frame.N=4,r=>r.frame.M=5,r=>r.frame.N=1.5,r=>r.H[0].pop(),r=>r.y.pop(),r=>r.H[0][0].re=NaN,r=>r.H[0][0].im=Infinity,r=>r.H[0][0].re=17,r=>r.y[0].im=65,r=>r.noiseVariance=0,r=>r.noiseVariance=1e-7,r=>r.noiseVariance=1001,r=>r.constellation.reverse(),r=>r.constellation[0].re=.001,r=>r.settings.maxIterations=101,r=>r.settings.maxIterations=1.3,r=>r.settings.damping=0,r=>r.settings.damping=1.1,r=>r.settings.edgeTolerance=1e-5,r=>r.settings.tolerance=0,r=>r.settings.captureHistory='true',r=>r.settings.truth=[],r=>r.frame.seed=1,r=>r.model='exact_rect_finite',r=>r.csi='estimated'];
 for(const mutate of mutations){const r=base().receiver;mutate(r);rejected(()=>validateReceiver(r));}
});
test('invalid channel domains and path count rejected',()=>{
 for(const ps of [[],[{delayBin:4,dopplerBin:0,gain:{re:1,im:0}}],[{delayBin:-1,dopplerBin:0,gain:{re:1,im:0}}],[{delayBin:0,dopplerBin:3,gain:{re:1,im:0}}],[{delayBin:0,dopplerBin:0,gain:{re:5,im:0}}]])rejected(()=>buildChannel({N:3,M:4},ps));
 const p={delayBin:0,dopplerBin:0,gain:{re:1,im:0}};rejected(()=>buildChannel({N:3,M:4},[p,p,p]));
});
test('entropy proxy is not capacity; confident wrong log score remains negative',()=>{
 const Q=4,probs=[[1-3e-9,1e-9,1e-9,1e-9]],r={probabilities:probs,logProbabilities:probs.map(row=>row.map(Math.log))},e=evaluateDetector(r,{truthIndices:[1]});
 assert(e.entropyProxyBits>1.99);assert(e.truthLogScoreBits<0);assert.equal(e.bitErrorRate,.5);assert.match(e.interpretation,/not capacity/);
});
test('evaluation rejects corrupted posterior and malformed truth',()=>{
 const o=base(),r=solveSync(o.receiver);const p=clone(r.mpg);p.probabilities[0][0]=NaN;rejected(()=>evaluateDetector(p,o.evaluation));rejected(()=>evaluateDetector(r.mpg,{truthIndices:[]}));
});
test('canonical digest ignores object key insertion order but binds numerical input/settings',async()=>{
 const a=base().receiver,b=Object.fromEntries(Object.entries(a).reverse());assert.equal(await inputDigest(a),await inputDigest(b));b.y=clone(b.y);b.y[0].re+=1e-9;assert.notEqual(await inputDigest(a),await inputDigest(b));rejected(()=>canonicalJSON({a:Infinity}));
});
test('consumer result gate rejects stale/cancelled/incorrect digest and invalidation',()=>{
 const gate=createResultGate(),r={type:'terminal',status:'completed',requestId:'a',inputDigest:'sha256:a'};assert(!gate.accepts(r));gate.expect('a','sha256:a');assert(gate.accepts(r));for(const patch of [{requestId:'b'},{inputDigest:'sha256:b'},{status:'cancelled'},{type:'progress'}])assert(!gate.accepts({...r,...patch}));gate.invalidate();assert(!gate.accepts(r));
});
test('saved independent Python oracle gate exists, is finite, and includes rank cases',()=>{
 const report=JSON.parse(fs.readFileSync(new URL('../evidence/python-oracle-report.json',import.meta.url)));assert.equal(report.status,'passed');assert(report.caseCount>=48);assert(report.findings.some(x=>x.id==='rank-one'));assert(report.findings.some(x=>x.id==='loopy-approximation'&&x.exactPosteriorGap>1e-6));assert(report.findings.some(x=>x.id==='cap-preserved'&&x.status==='max-iterations'));
});
test('scale-safe corrected soft conversion matches scalar likelihood below old floor',()=>{
 const c=qam(4).symbols,r={frame:{N:1,M:1},model:'eq14_literal',csi:'perfect-supplied',H:[[{re:1e-12,im:0}]],y:[{re:64,im:64}],noiseVariance:1e-6,constellation:c,settings:{maxIterations:3,tolerance:1e-9,damping:1,edgeTolerance:1e-13,captureHistory:true}};
 const out=solveSync(r);assert(out.lmmse.residualVariance[0]<1e-15);assert(maxDiff(out.mpg.probabilities,out.lmmse.probabilities)<1e-14);
 for(const y of [1,64]){r.H[0][0].re=16;r.y[0]={re:y,im:0};const x=solveSync(r);for(const p of [x.mpg.probabilities[0],x.lmmse.probabilities[0]])assert(Math.abs(p.reduce((a,b)=>a+b,0)-1)<1e-14);}
});
test('sparse arrays are invalid input, not numerical/internal failures',()=>{
 for(const mutate of [r=>delete r.H[0],r=>delete r.H[0][0],r=>delete r.y[0],r=>delete r.constellation[0]]){const r=base().receiver;mutate(r);rejected(()=>solveSync(r));}
 const paths=new Array(1);rejected(()=>buildChannel({N:1,M:1},paths));rejected(()=>canonicalJSON(new Array(1)));rejected(()=>canonicalJSON({a:undefined}));
});
test('nonzero underflowing LMMSE filter raises explicit numerical failure',()=>{
 const r=generateObservation({frame:{N:1,M:1},paths:[{delayBin:0,dopplerBin:0,gain:{re:1,im:0}}],order:4,noiseVariance:1e-6}).receiver;r.H[0][0].re=1e-200;
 assert.throws(()=>lmmse(r),e=>e instanceof KernelError&&e.code==='numerical-failure'&&/underflow/.test(e.message));
});
