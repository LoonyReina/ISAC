import fs from 'node:fs';
import {Worker} from 'node:worker_threads';
import {performance} from 'node:perf_hooks';
import {generateObservation} from '../src/simulation.mjs';
import {solveSync} from '../src/kernel.mjs';
const paths=[{delayBin:.93,dopplerBin:-.37,gain:{re:1,im:.12}},{delayBin:2.14,dopplerBin:.63,gain:{re:.7,im:-.25}}];
const records=[];
for(const P of [1,2])for(const Q of [4,16])for(let seed=410;seed<413;seed++){
 const r=generateObservation({frame:{N:3,M:4},paths:paths.slice(0,P),order:Q,seed,noiseVariance:.4,settings:{maxIterations:30,tolerance:1e-9,damping:1,edgeTolerance:0,captureHistory:true}}).receiver;
 const w=new Worker(new URL('../src/node-worker.mjs',import.meta.url),{resourceLimits:{maxOldGenerationSizeMb:64,maxYoungGenerationSizeMb:16}}),start=performance.now();
 const out=await new Promise((resolve,reject)=>{const timer=setTimeout(()=>{w.terminate();reject(Error('zero-pruning run exceeded10s'));},10000);w.on('error',reject);w.on('message',m=>{if(m.type==='terminal'){clearTimeout(timer);resolve(m);}});w.postMessage({type:'run',requestId:'zero-pruning',receiver:r});});
 const startupThroughTransferMs=performance.now()-start;await w.terminate();if(out.status!=='completed')throw Error(JSON.stringify(out));
 const baseline=structuredClone(r);baseline.settings.edgeTolerance=1e-13;const pruned=solveSync(baseline);
 const diff=(a,b)=>Math.max(...a.flat().map((x,i)=>Math.abs(x-b.flat()[i]))),g=out.methods.mpg.graph,energyMax=Math.max(...r.constellation.map(x=>x.re*x.re+x.im*x.im));
 const largestNoiseScaledPairCoefficient=Math.max(...g.edges.map(e=>2*energyMax*Math.hypot(e.coefficient.re,e.coefficient.im)/r.noiseVariance));
 const exactUnnormalizedLogWeightBound=2*energyMax/r.noiseVariance*Math.sqrt((66-g.edgeCount)/2)*g.removedGramFrobenius;
 records.push({P,Q,seed,edgeTolerance:0,edgeCount:g.edgeCount,iterations:out.methods.mpg.iterations,status:out.methods.mpg.status,startupThroughTransferMs,
  largestNoiseScaledPairCoefficient,exactUnnormalizedLogWeightBound,versusPositiveCutoffMaxProbabilityDifference:diff(out.methods.mpg.probabilities,pruned.mpg.probabilities),
  singlePathMPvsLMMSE:P===1?diff(out.methods.mpg.probabilities,out.methods.lmmse.probabilities):null,responseJSONBytes:Buffer.byteLength(JSON.stringify(out))});
}
const report={status:'passed',runtime:process.version,records,recommendedFirstLessonPreset:'edgeTolerance=0; maxIterations=30; N3M4; source flooding damping=1; actual histories; explicit Run',
 boundary:'Actual Node Worker profile only. Browser and named-desktop profiling still required. P1 retains finite-precision roundoff edges; largestNoiseScaledPairCoefficient characterizes their influence, not physical multipath.'};
fs.writeFileSync(new URL('../evidence/zero-pruning-runtime.json',import.meta.url),JSON.stringify(report,null,2));console.log(JSON.stringify({status:'passed',cases:records.length,maxWorkerWallMs:Math.max(...records.map(x=>x.startupThroughTransferMs)),maxDifferenceVersusPositiveCutoff:Math.max(...records.map(x=>x.versusPositiveCutoffMaxProbabilityDifference)),maxP1EqualityError:Math.max(...records.filter(x=>x.P===1).map(x=>x.singlePathMPvsLMMSE))}));
