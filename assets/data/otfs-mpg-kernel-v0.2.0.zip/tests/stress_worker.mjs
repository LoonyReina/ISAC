import fs from 'node:fs';
import {Worker} from 'node:worker_threads';
import {performance} from 'node:perf_hooks';
import {generateObservation} from '../src/simulation.mjs';
const input=generateObservation({frame:{N:3,M:4},paths:[{delayBin:.9,dopplerBin:.6,gain:{re:1,im:0}}],seed:603,order:16,
 settings:{maxIterations:100,tolerance:1e-14,damping:.05,edgeTolerance:1e-13,captureHistory:true}}).receiver;
for(let i=0;i<12;i++)for(let j=0;j<12;j++)input.H[i][j]={re:Math.sin((i+1)*13.4+(j+1)*7.8),im:Math.cos((i+1)*7.1-(j+1)*3.7)};
const dense=[],cancellation=[];
async function run(cancel=false) {
 const w=new Worker(new URL('../src/node-worker.mjs',import.meta.url),{resourceLimits:{maxOldGenerationSizeMb:64,maxYoungGenerationSizeMb:16}}),start=performance.now();let cancelAt=null;
 const result=await new Promise((resolve,reject)=>{
  const timer=setTimeout(()=>{w.terminate();reject(new Error('10-second deadline exceeded'));},10000);
  w.on('error',reject);w.on('message',m=>{
   if(cancel&&cancelAt===null&&m.type==='progress'&&m.phase==='mp-g'&&m.iteration>=1){cancelAt=performance.now();w.postMessage({type:'cancel',requestId:'stress'});}
   if(m.type==='terminal'){clearTimeout(timer);resolve(m);}
  });w.postMessage({type:'run',requestId:'stress',receiver:input});
 });
 const end=performance.now();await w.terminate();
 if(result.status!==(cancel?'cancelled':'completed'))throw Error(JSON.stringify(result));
 const method=cancel?result.partial.mpg:result.methods.mpg;
 if(method.graph.edgeCount!==66)throw Error('Not all-pair dense case');
 return {status:result.status,methodStatus:method.status,iterations:method.iterations,edgeCount:66,pairwiseScalarTermsPerIteration:method.graph.pairwiseScalarTermsPerIteration,
  startupThroughTransferMs:end-start,cancelToTerminalMs:cancelAt===null?null:end-cancelAt,responseJSONBytes:Buffer.byteLength(JSON.stringify(result))};
}
for(let i=0;i<5;i++)dense.push(await run());for(let i=0;i<10;i++)cancellation.push(await run(true));
fs.writeFileSync(new URL('../evidence/node-stress.json',import.meta.url),JSON.stringify({status:'passed',runtime:process.version,dense,cancellation,
 boundary:'Actual Node workers in shared cloud container. Raw arbitrary dense H is a solver-budget test, not an OTFS two-path realizability claim. 64MiB old/16MiB young configured V8 limits, not observed peak or RSS. No browser/UI measured.'},null,2));
console.log(JSON.stringify({status:'passed',maxDenseMs:Math.max(...dense.map(x=>x.startupThroughTransferMs)),maxResponseBytes:Math.max(...dense.map(x=>x.responseJSONBytes)),maxCancelMs:Math.max(...cancellation.map(x=>x.cancelToTerminalMs)),cancelIterationRange:[Math.min(...cancellation.map(x=>x.iterations)),Math.max(...cancellation.map(x=>x.iterations))]}));
