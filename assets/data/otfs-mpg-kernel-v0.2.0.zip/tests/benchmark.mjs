import fs from 'node:fs';
import os from 'node:os';
import {Worker} from 'node:worker_threads';
import {performance} from 'node:perf_hooks';
import {generateObservation} from '../src/simulation.mjs';
import {solveSync} from '../src/kernel.mjs';
const base=new URL('../',import.meta.url),records=[];
const paths=[{delayBin:.93,dopplerBin:-.37,gain:{re:1,im:.12}},{delayBin:2.14,dopplerBin:.63,gain:{re:.7,im:-.25}}];
for(const maxIterations of [30,100])for(const order of [4,16])for(const captureHistory of [false,true])for(let trial=0;trial<5;trial++){
 const input=generateObservation({frame:{N:3,M:4},paths,order,seed:977+trial,noiseVariance:.4,
   settings:{maxIterations,tolerance:1e-14,damping:.05,edgeTolerance:1e-13,captureHistory}}).receiver;
 const t=performance.now(),direct=solveSync(input),syncMs=performance.now()-t;
 const worker=new Worker(new URL('../src/node-worker.mjs',import.meta.url),{resourceLimits:{maxOldGenerationSizeMb:64,maxYoungGenerationSizeMb:16}});
 const start=performance.now();let firstProgressMs=null;
 const result=await new Promise((resolve,reject)=>{
   const timeout=setTimeout(()=>{worker.terminate();reject(new Error('bounded Worker benchmark exceeded 10 seconds'));},10000);
   worker.on('error',reject);worker.on('message',m=>{if(m.type==='progress'&&firstProgressMs===null)firstProgressMs=performance.now()-start;if(m.type==='terminal'){clearTimeout(timeout);resolve(m);}});
   worker.postMessage({type:'run',requestId:'benchmark',receiver:input});
 });
 const startupThroughTransferMs=performance.now()-start;await worker.terminate();
 if(result.status!=='completed')throw Error(JSON.stringify(result));
 if(JSON.stringify(result.methods.mpg.probabilities)!==JSON.stringify(direct.mpg.probabilities))throw Error('Worker parity failure');
 records.push({maxIterations,order,captureHistory,trial,actualIterations:result.methods.mpg.iterations,edgeCount:result.methods.mpg.graph.edgeCount,
   methodStatus:result.methods.mpg.status,syncMs,firstProgressMs,startupThroughTransferMs,workerTiming:result.timing,
   responseJSONBytes:Buffer.byteLength(JSON.stringify(result)),workerResourceLimits:{maxOldGenerationSizeMb:64,maxYoungGenerationSizeMb:16}});
}
const percentile=(v,p)=>[...v].sort((a,b)=>a-b)[Math.ceil(v.length*p)-1];
const groups=[];for(const maxIterations of [30,100])for(const order of [4,16])for(const captureHistory of [false,true]){
 const r=records.filter(x=>x.maxIterations===maxIterations&&x.order===order&&x.captureHistory===captureHistory);
 groups.push({maxIterations,order,captureHistory,trials:r.length,syncMedianMs:percentile(r.map(x=>x.syncMs),.5),syncP95Ms:percentile(r.map(x=>x.syncMs),.95),
 workerStartupThroughTransferMedianMs:percentile(r.map(x=>x.startupThroughTransferMs),.5),workerStartupThroughTransferP95Ms:percentile(r.map(x=>x.startupThroughTransferMs),.95),maximumResponseJSONBytes:Math.max(...r.map(x=>x.responseJSONBytes))});
}
const report={status:'passed',date:new Date().toISOString(),runtime:process.version,platform:process.platform,arch:process.arch,cpu:os.cpus()[0].model,
 environment:'Shared cloud container. Actual Node worker_threads, not browser or user desktop.',
 boundary:'Direct sync timing includes validation/Gram/history/MP-G/full LMMSE. Worker wall includes thread startup, async yields, protocol and structured-clone transfer; no DOM/render/UI. Five samples per setting, p95 is sample maximum, not a robust latency guarantee.',
 resourceLimits:'Every measured Worker ran with V8 64 MiB old generation and 16 MiB young generation limits. This is a configured heap ceiling, not observed peak memory or a total process RSS claim.',
 groups,records};
fs.writeFileSync(new URL('evidence/node-runtime.json',base),JSON.stringify(report,null,2));console.log(JSON.stringify({status:report.status,groups},null,2));
