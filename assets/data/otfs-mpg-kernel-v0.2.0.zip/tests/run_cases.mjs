import fs from 'node:fs';
import {solveSync,buildChannel} from '../src/kernel.mjs';
const data=JSON.parse(fs.readFileSync(process.argv[2],'utf8'));
const results=data.map(({id,receiver,paths})=>({id,channel:paths?buildChannel(receiver.frame,paths):null,result:solveSync(receiver)}));
fs.writeFileSync(process.argv[3],JSON.stringify(results));
