"""Independent NumPy oracle plus frozen accepted reference comparison.
The independent functions below do not import the reference; reference calls are
an additional parity check. Actual arrays and all findings are saved for replay.
"""
import hashlib, json, math, platform, subprocess, sys, time
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
EXPECTED='92b997201493a3187b5ddb37026672ef44e163131e422bdf8618f11b17aa235f'
assert hashlib.sha256((ROOT/'reference/otfs_reference.py').read_bytes()).hexdigest()==EXPECTED
sys.path.insert(0,str(ROOT/'reference'))
import otfs_reference as reference

def encode(a):
    a=np.asarray(a)
    if a.ndim==0:return {'re':float(a.real),'im':float(a.imag)}
    return [encode(x) for x in a]
def decode(a):
    if isinstance(a,dict):return complex(a['re'],a['im'])
    return np.array([decode(x) for x in a])
def lse(x,axis=-1):
    m=np.max(x,axis=axis,keepdims=True)
    return np.squeeze(m+np.log(np.sum(np.exp(x-m),axis=axis,keepdims=True)),axis=axis)
def normalize(x):return x-lse(x)[...,None]
def constellation(Q):
    n=int(math.sqrt(Q));levels=np.arange(1-n,n,2)
    return np.array([complex(r,i) for r in levels for i in levels])/math.sqrt(2*(Q-1)/3)
def literal(N,M,paths):
    D=N*M;H=np.zeros((D,D),complex)
    # Literal finite exponential sums. Deliberately no imported kernel/factorization.
    for p in paths:
        q,a,h=p['delayBin'],p['dopplerBin'],decode(p['gain'])
        for row in range(D):
            k,l=row%N,row//N
            for col in range(D):
                kp,lp=col%N,col//N
                slow=sum(np.exp(2j*np.pi*n*(kp-k+a)/N) for n in range(N))/N
                delay=sum(np.exp(2j*np.pi*m*(lp-l+q)/M) for m in range(M))/M
                phase=np.exp(2j*np.pi*a*lp/(N*M))
                if lp>=M-math.ceil(q):phase*=np.exp(-2j*np.pi*(kp+a)/N)
                H[row,col]+=h*slow*delay*phase
    return H

def independent_mpg(H,y,v,c,settings):
    D,Q=H.shape[1],len(c);G=H.conj().T@H;z=H.conj().T@y
    unary=normalize((2*np.real(z[:,None]*c.conj())-G.diagonal().real[:,None]*abs(c)**2)/v)
    cutoff=settings['edgeTolerance']*max(1,np.max(abs(G)))
    edges=[(i,j) for i in range(D) for j in range(i+1,D) if abs(G[i,j])>cutoff]
    messages=np.full((len(edges),2,Q),-np.log(Q));post=unary.copy();traces=[];hist=[(post.copy(),messages.copy())]
    status='max-iterations'
    for iteration in range(1,settings['maxIterations']+1):
        belief=unary.copy()
        for e,(i,j) in enumerate(edges):belief[i]+=messages[e,0];belief[j]+=messages[e,1]
        new=np.zeros_like(messages)
        for e,(i,j) in enumerate(edges):
            potential=-2*np.real(G[i,j]*c.conj()[:,None]*c[None,:])/v
            new[e,0]=normalize(lse(potential+belief[j][None,:]-messages[e,1][None,:],axis=1))
            new[e,1]=normalize(lse(potential+belief[i][:,None]-messages[e,0][:,None],axis=0))
        damping=settings['damping']
        if damping<1:new=np.logaddexp(np.log(damping)+new,np.log1p(-damping)+messages)
        delta=float(np.max(abs(np.exp(new)-np.exp(messages)))) if len(edges) else 0.
        messages=new;belief=unary.copy()
        for e,(i,j) in enumerate(edges):belief[i]+=messages[e,0];belief[j]+=messages[e,1]
        next_post=normalize(belief)
        traces.append((delta,float(np.max(abs(np.exp(next_post)-np.exp(post))))));post=next_post
        hist.append((post.copy(),messages.copy()))
        if delta<settings['tolerance']:status='converged';break
    return {'logp':post,'prob':np.exp(post),'hist':hist,'trace':traces,'status':status,'edges':edges,'G':G,'z':z}

def independent_lmmse(H,y,v,c):
    E=float(np.mean(abs(c)**2));D=H.shape[1]
    W=np.linalg.solve(H.conj().T@H+v/E*np.eye(D),H.conj().T);A=W@H;out=W@y;gain=A.diagonal()
    residual=np.array([E*sum(abs(A[i,j])**2 for j in range(D) if j!=i)+v*np.vdot(W[i],W[i]).real for i in range(D)])
    lp=normalize(-abs(out[:,None]-gain[:,None]*c)**2/np.maximum(residual[:,None],1e-15))
    return lp,E*abs(gain)**2/np.maximum(residual,1e-15)

def exact(H,y,v,c):
    import itertools
    ids=np.array(list(itertools.product(range(len(c)),repeat=H.shape[1])))
    assert len(ids)<=65536
    lp=-np.sum(abs(y[:,None]-H@c[ids].T)**2,axis=0)/v;lp-=lse(lp)
    return np.array([[np.exp(lse(lp[ids[:,i]==q])) for q in range(len(c))] for i in range(H.shape[1])])

rng=np.random.default_rng(607130019);cases=[]
def add(id,N,M,H,order=4,v=.3,paths=None,settings=None,y=None,exact_kind=None):
    c=constellation(order);D=N*M
    if y is None:y=H@rng.choice(c,D)+np.sqrt(v/2)*(rng.normal(size=D)+1j*rng.normal(size=D))
    s={'maxIterations':30,'tolerance':1e-9,'damping':1.,'edgeTolerance':1e-13,'captureHistory':True};s.update(settings or {})
    receiver={'frame':{'N':N,'M':M},'model':'eq14_literal','csi':'perfect-supplied','H':encode(H),'y':encode(y),'noiseVariance':v,'constellation':encode(c),'settings':s}
    cases.append({'id':id,'receiver':receiver,'paths':paths,'exactKind':exact_kind})
def path(q,a,h=1):return {'delayBin':q,'dopplerBin':a,'gain':encode(h)}
for i,(q,a) in enumerate([(0,0),(1,1),(1.2,-.61),(3.999999,-2.9),(1-1e-10,.42),(1+1e-10,.42)]):
    p=[path(q,a,.8+.3j)];add('single-'+str(i),3,4,literal(3,4,p),16,paths=p)
for i in range(32):
    N=int(rng.integers(1,4));M=int(rng.integers(1,5));P=1+i%2
    ps=[path(float(rng.uniform(0,M)),float(rng.uniform(-N,N)),complex(rng.normal(),rng.normal())*.5) for _ in range(P)]
    add('random-fractional-'+str(i),N,M,literal(N,M,ps),[4,16][i%2],10**rng.uniform(-2,.7),ps,{'damping':[1.,.7,.5][i%3]})
add('zero-channel',1,3,np.zeros((3,3),complex),16,exact_kind='exact')
add('rank-one',1,2,np.array([[1,.4+.2j],[.5,.2+.1j]]),4,exact_kind='exact')
add('rank-deficient-16qam',1,2,np.array([[1,.4+.2j],[.5,.2+.1j]]),16,exact_kind='exact')
add('tiny-gain',1,2,np.eye(2)*1e-12,4,exact_kind='exact')
G=np.array([[1,.18+.1j,0],[.18-.1j,1,.2j],[0,-.2j,1]])
add('chain-tree',1,3,np.linalg.cholesky(G).conj().T,4,exact_kind='exact')
H=(rng.normal(size=(3,3))+1j*rng.normal(size=(3,3)))/2
add('loopy-approximation',1,3,H,4,exact_kind='loopy')
add('cancelled-path-channel',3,4,np.zeros((12,12),complex),16,paths=[path(.9,.3,1),path(.9,.3,-1)])
add('ill-conditioned-high-snr',3,4,np.full((12,12),2+2j),16,1e-6,settings={'maxIterations':3})
add('cap-preserved',3,4,(rng.normal(size=(12,12))+1j*rng.normal(size=(12,12)))/3,16,.4,settings={'maxIterations':1})
add('damping-edge-zero',1,3,H,4,.1,settings={'edgeTolerance':0,'damping':.05,'maxIterations':100})
(ROOT/'evidence/python-inputs.json').write_text(json.dumps(cases,allow_nan=False))
subprocess.run(['node',str(ROOT/'tests/run_cases.mjs'),str(ROOT/'evidence/python-inputs.json'),str(ROOT/'evidence/js-results.json')],check=True)
js=json.loads((ROOT/'evidence/js-results.json').read_text());findings=[]
def err(a,b):
    a,b=np.array(a),np.array(b)
    return float(np.max(abs(a-b))) if a.size else 0.
for case,output in zip(cases,js):
    r=case['receiver'];H=decode(r['H']);y=decode(r['y']);c=decode(r['constellation']);v=r['noiseVariance'];s=r['settings'];N,M=r['frame'].values()
    m=independent_mpg(H,y,v,c,s);lp,sinr=independent_lmmse(H,y,v,c);j=output['result'];p=j['mpg'];l=j['lmmse']
    errors={'mpProbability':err(p['probabilities'],m['prob']),'mpLogProbability':err(p['logProbabilities'],m['logp']),
      'lmmseProbability':err(l['probabilities'],np.exp(lp)),'lmmseLogProbability':err(l['logProbabilities'],lp),
      'sinrRelative':err(np.array(l['effectiveSinr'])/(1+sinr),sinr/(1+sinr)),'gram':err(decode(p['graph']['G']),m['G']),'z':err(decode(p['graph']['z']),m['z'])}
    assert p['status']==m['status'],case['id']
    assert p['iterations']==len(m['trace'])
    assert p['graph']['edgeCount']==len(m['edges'])
    assert [(e['i'],e['j']) for e in p['graph']['edges']]==m['edges']
    errors['historyProbability']=max(err(h['probabilities'],np.exp(o[0])) for h,o in zip(p['history'],m['hist']))
    errors['historyMessageProbability']=max(err(np.exp(np.array(h['incomingLogMessages']).reshape((-1,2,len(c)))),np.exp(o[1])) for h,o in zip(p['history'],m['hist']))
    errors['trace']=err([[t['messageDelta'],t['marginalDelta']] for t in p['trace']],m['trace'])
    rm=reference.mp_g(H,y,v,c,max_iter=s['maxIterations'],tolerance=s['tolerance'],damping=s['damping'],edge_tolerance=s['edgeTolerance'])
    rl=reference.lmmse(H,y,v,c)
    errors['frozenReferenceMP']=err(p['probabilities'],rm['probabilities']);errors['frozenReferenceLMMSE']=err(l['probabilities'],rl['probabilities'])
    if case['paths']:
      errors['literalChannel']=err(decode(output['channel']),H)
      rh=reference.channel_operator(reference.Frame(N=N,M=M),[(p['delayBin'],p['dopplerBin'],decode(p['gain'])) for p in case['paths']])
      errors['frozenReferenceChannel']=err(decode(output['channel']),rh)
    # Large scores at the deliberately ill-conditioned high-SNR boundary amplify tiny solve differences.
    tol=2e-6 if case['id']=='ill-conditioned-high-snr' else 2e-8
    for key,value in errors.items():
      if key.endswith('LogProbability'):assert value<max(tol,1e-8*float(np.max(abs(lp))) if key.startswith('lmmse') else tol),(case['id'],key,value)
      else:assert value<tol,(case['id'],key,value)
    evidence={'id':case['id'],'errors':errors,'status':p['status'],'iterations':p['iterations'],'edges':p['graph']['edgeCount'],'lmmseSolveResidual':l['solveRelativeResidual']}
    if case['exactKind']:
      exact_probs=exact(H,y,v,c);gap=err(p['probabilities'],exact_probs);evidence['exactPosteriorGap']=gap
      if case['exactKind']=='exact':assert gap<1e-8,(case['id'],gap)
    if case['id'].startswith('single-'):
      assert p['graph']['edgeCount']==0
      evidence['singlePathMPvsLMMSE']=err(p['probabilities'],l['probabilities']);assert evidence['singlePathMPvsLMMSE']<1e-12
    findings.append(evidence)
report={'status':'passed','referenceSHA256':EXPECTED,'caseCount':len(cases),'seed':607130019,'numpy':np.__version__,'python':platform.python_version(),'findings':findings,
 'note':'Independent NumPy oracle and fixed accepted Python reference. Arbitrary/rank matrices are solver validation inputs, not claims that every matrix is realizable by two OTFS paths. No Python timings are browser claims.'}
(ROOT/'evidence/python-oracle-report.json').write_text(json.dumps(report,indent=2,allow_nan=False))
print(json.dumps({'status':'passed','cases':len(cases),'maximumProbabilityError':max(max(v for k,v in x['errors'].items() if 'Probability' in k and 'Log' not in k) for x in findings)}))
