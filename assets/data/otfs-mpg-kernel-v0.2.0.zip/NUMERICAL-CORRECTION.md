# Scale-stable soft outputs: disclosed v0.2.0 correction

The accepted frozen Python core is **unchanged**, SHA-256 `92b997201493a3187b5ddb37026672ef44e163131e422bdf8618f11b17aa235f`. The initial JS v0.1.0 faithfully inherited its `max(residualVariance,1e-15)` full-LMMSE soft-output policy. Independent adversarial review found that this is not scale invariant inside the admitted raw receiver range.

## Preserved failure

For scalar QPSK, H=10⁻¹², y=64, v=10⁻⁶, the actual LMMSE residual variance is approximately 10⁻¹⁸. Replacing it by 10⁻¹⁵ reduces the soft log odds by about 1000. The initial port differed from direct scalar AWGN probabilities by approximately 2.26049×10⁻⁵ while reporting solved. Using y=64+64j also exposed loss of the normalization constant when subtracting a very large common squared-output score. Separate high-score scalar MP-G ties had a related normalization issue.

Original source and independent failure inputs/results are preserved under `independent-review/frozen-source/` and the review's baseline evidence. Ordinary reference parity alone did not detect these errors.

## Derived correction

Let W=(HᴴH+v/E I)⁻¹Hᴴ, A=WH, tᵢ=(Wy)ᵢ, gᵢ=Aᵢᵢ, and

rᵢ = E Σⱼ≠ᵢ |Aᵢⱼ|² + v Σₖ |Wᵢₖ|².

The effective-AWGN log likelihood is −|tᵢ−gᵢc|²/rᵢ. A symbol-independent additive constant does not affect a normalized posterior. Remove −|tᵢ|²/rᵢ analytically, **before** floating-point subtraction. With t̃ᵢ=tᵢ/√rᵢ and g̃ᵢ=gᵢ/√rᵢ, compute

ℓᵢ(c) = 2 Re(t̃ᵢ conjugate(g̃ᵢc)) − |g̃ᵢc|².

The SINR is E|g̃ᵢ|². This is algebraically the same full-LMMSE effective-AWGN conversion for positive rᵢ, with no absolute noise/variance floor and no truth input. Whitening avoids forming very small gain-squared values before division. By Cauchy–Schwarz, |tᵢ|/√rᵢ ≤ ||y||/√v because rᵢ≥v||Wᵢ:||², so the normalized output remains bounded within the admitted input domain.

An exactly zero filter is uninformative and returns uniform probability. If a nonzero filter's squared norm/variance underflows to zero, the implementation returns `numerical-failure`; it does not add an arbitrary floor or claim exact uniform inference. Extremely small nonzero values can therefore be admitted as finite inputs but fail numerically with an explicit status.

For all log normalizations, let m=max a and s=log Σ exp(a−m). Compute normalized log probabilities as **(a−m)−s**, rather than a−(m+s). The latter needlessly rounds away s when m is large. This correction applies to MP-G as well as LMMSE and changes no message schedule, factors, convergence rule or damping.

Sparse JavaScript array holes are now traversed and rejected as `invalid-input`, rather than falling through to `internal-error`/`numerical-failure`. These validation corrections do not change dense valid input semantics. Digest encoding is explicitly named `sorted-key-json-js-v1`.

## Proof and range

Implementation limits remain N≤3, M≤4, Q=4/16, each H component ≤16 in magnitude, y component ≤64, and 10⁻⁶≤v≤1000, with the documented iteration and damping limits. This is a numerical prototype, not a claim that every supplied H is realizable by two OTFS paths or that every finite subnormal input can be solved.

- `tests/check_high_precision.py` independently evaluates the full complex linear estimator and scalar soft conversion with **80 decimal digits**. Its 12 saved cases include the reported failures, tiny complex gain, tiny rank-one and dense matrices, mixed scales, high-score ties, QPSK and 16-QAM. Scalar cases additionally use the direct original-observation likelihood. Maximum corrected LMMSE probability error is below 4.45×10⁻¹⁶
- `tests/check_python_oracle.py` reruns the original 48 fractional/random/rank cases against the independent NumPy oracle and the unchanged accepted Python reference. Largest probability difference after the correction is below 7.23×10⁻¹³ in that tested ordinary domain
- Pure/Worker tests preserve caps, actual histories, input separation, zero-information uniform output, explicit underflow failure, sparse rejection, cancellation and supersession
- The independent reviewer repeats its own fresh-input and 100-digit checks; the final accepted boundary is in its judgement

Universal equality to the original reference on the corrected tiny-residual domain is **not claimed**. There the original absolute floor is the source of a quantified discrepancy; the high-precision/direct likelihood oracle is the validation authority for the correction. No figures or detector-gap claims are inferred from this change.
