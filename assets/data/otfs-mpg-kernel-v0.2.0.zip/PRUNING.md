# Noise-scaled edge pruning and the first lesson preset

## Recommended first bounded desktop-lesson preset

Use **edgeTolerance=0**, N=3, M=4, QPSK or 16-QAM, source flooding damping=1, maxIterations=30, and an explicit Run action. This keeps every numerically nonzero Gram coupling. It removes the need to justify a positive cutoff as negligible. The unchanged general numerical API still permits edgeTolerance in [0,10⁻¹²].

`tests/profile_zero_pruning.mjs` ran 12 actual Node Worker cases: P=1/2, Q=4/16, three fresh seeds each, full actual history enabled. Maximum startup-through-transfer time was approximately 177 ms on the shared cloud Node runtime. The largest probability difference against the 10⁻¹³ cutoff in those ordinary cases was 6.39×10⁻¹⁵; P=1 MP-G/full-LMMSE equality held to 1.03×10⁻¹⁵. Exact inputs/results are represented by the reproducible script and its recorded settings; per-case observed timing/edge/outcome values are in `evidence/zero-pruning-runtime.json`.

These are Node measurements, **not browser or named-desktop measurements**. Actual browser/desktop profiling remains necessary before a responsiveness claim or range expansion. This recommendation does not silently change the underlying frozen Python default or the generator's explicit settings.

At zero cutoff, P=1 may retain many **roundoff-sized** off-diagonal entries even though the mathematical literal single-path Gram matrix is diagonal. The UI must label them as numerical residuals and may separately show a clearly labelled display-only significance threshold; that threshold must not alter computation or claim physical multipath. A meaningful edge magnitude is 2 Cmax² |Gij| / v, not |Gij| alone.

## Conservative diagnostic for a positive cutoff

Let Cmax² = max over constellation points |c|² (1 for canonical QPSK, 1.8 for canonical 16-QAM), and let v=E|w|². Let D be the number of data symbols.

Define the omitted undirected edge set

S = {(i,j): i<j and the pair is absent from the retained graph}.

Its size **Edrop=D(D−1)/2−edgeCount counts undirected pairs**. It includes zero-valued omitted coefficients, which make zero contribution. The source returns

Fremoved = ||Gremoved||F = sqrt(2 Σ over S |Gij|²),

because **both Hermitian entries Gij and Gji are included** in the Frobenius norm. The kernel accumulates `removed2 += 2*|Gij|²` for every omitted i<j pair.

Each removed pair contributes −2 Re(Gij conjugate(xi) xj)/v to the log likelihood. Consequently, for any complete symbol configuration x,

|log wfull(x) − log wretained(x)| ≤ Bexact

Bexact = (2 Cmax² / v) Σ over S |Gij|

≤ Bbound = (2 Cmax² / v) sqrt(Edrop/2) Fremoved.

The final inequality is Cauchy–Schwarz. It is conservative and may be loose. If an interface only has `removedGramFrobenius`, D, edgeCount, the constellation and v, it can compute Bbound without reconstructing the dropped coefficients.

For the **exact normalized distributions** under the full and retained models, partition-function ratios lie between exp(−B) and exp(B). Thus

|log pfull(x) − log pretained(x)| ≤ 2B,

and the same bound holds for the log ratio of any exact symbol marginal/event with positive probability. Use natural logarithms; divide 2B by ln(2) for a log₂ ratio bound. All finite-noise discrete configurations have positive mathematical probability, even when a floating-point representation underflows.

**This is not a bound on loopy MP-G output changes, convergence, or error rates.** MP-G need not return either exact distribution. There is no demonstrated universal BP perturbation guarantee here. Keep this warning immediately next to any UI display of Bbound/2B; never relabel it “MP error” or “BER bound.”

The independent reviewer checks the factor of two, the undirected-edge convention, and the implementation's Frobenius accounting in its judgement addendum. It also preserves an adversarial example where a seemingly tiny omitted Gram coupling changes exact tiny-tree marginals by approximately 4.27×10⁻⁵ after low-noise scaling. The separate finite-arithmetic error remains present even at zero cutoff.
