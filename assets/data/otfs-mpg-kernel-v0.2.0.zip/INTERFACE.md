# OTFS communication interface v1

All messages carry JSON-compatible plain values; successful numerical outputs contain no NaN/Infinity. Complex scalars use `{re:number, im:number}`. H uses explicit array-of-row ordering; symbol coordinate d=k+N*l. `schemaVersion` is `otfs-communication-v1`; `kernelVersion` is `0.2.0`. The digest encoding identifier is `sorted-key-json-js-v1` (recursive sorted object keys, array order retained, ECMAScript JSON.stringify finite-number encoding). This is not claimed byte-identical to default Python JSON formatting.

## Pure interfaces

```js
buildChannel({N,M}, [{delayBin,dopplerBin,gain:{re,im}}, ...]) // D×D H
qam(4 /* or 16 */) // {symbols:[{re,im},...], labels:[[bit,...],...]}
validateReceiver(receiver) // strict validated deep numerical copy
createMPG(receiver) // {graph,status,iteration,step(),result()}
lmmse(receiver) // full estimator + calibrated soft outputs
solveSync(receiver) // immutable validated receiver + both method outputs
inputDigest(receiver) // Promise<string> SHA256 of validated canonical sorted-key JSON
```

The synchronous functions throw `KernelError` with `code=invalid-input` for violated limits and `code=numerical-failure` for nonfinite/unreliable arithmetic. They do not return a successful partial result. Pure synchronous execution is intended for tests or an already isolated thread; UI callers should use a Worker.

Required receiver object, with no additional fields:

```js
{
  frame: {N:3,M:4},
  model: 'eq14_literal',
  csi: 'perfect-supplied',
  H: [[{re:0,im:0}, /* D columns */], /* D rows */],
  y: [{re:0,im:0}, /* D observations */],
  noiseVariance: 0.1,
  constellation: qam(16).symbols,
  settings: {
    maxIterations:30,
    tolerance:1e-9,
    damping:1,
    edgeTolerance:1e-13,
    captureHistory:true
  }
}
```

`perfect-supplied` is an explicit caller provenance claim, not a matrix property the solver can verify. Physical/nonphysical solver tests must label their provenance separately. No generator path parameters are required by the receiver because it receives the full supplied H.

## Worker messages

Create a module Worker from `src/browser-worker.mjs` in a secure context that supports WebCrypto SHA-256. Browser execution is not yet tested. Node tests instantiate `src/node-worker.mjs` using `worker_threads`. Both call the same protocol controller.

Requests:

```js
{type:'run',requestId:'unique-1',receiver}
{type:'cancel',requestId:'unique-1'}
```

IDs must be 1–80 ASCII letters/digits/underscore/period/colon/hyphen, unique within the Worker session. A session permits at most 1000 distinct accepted run IDs; then create a fresh Worker. Duplicate IDs are rejected, never reused. A new valid-shaped `run` supersedes the currently active run immediately, including when the new receiver later proves invalid. This is intentional input-freshness behavior.

Progress events contain `schemaVersion`, `kernelVersion`, `type:'progress'`, `requestId`, `phase`, and `iteration`. Validated/digest-ready phases also include `inputDigest`. MP-G events include actual `messageDelta`, `marginalDelta`, and method `status`. They are emitted only after real completed iterations; they do not imply a complete comparison.

One terminal event per accepted run:

```js
{
  schemaVersion:'otfs-communication-v1',kernelVersion:'0.2.0',inputEncoding:'sorted-key-json-js-v1',type:'terminal',
  requestId:'unique-1',status:'completed',inputDigest:'sha256:...',elapsedMs:0,
  receiver,methods:{mpg:{...},lmmse:{...}},
  timing:{runtime:'worker-core',validationAndDigestMs:0,mpInitializationMs:0,
          mpWithYieldMs:0,lmmseMs:0,totalCoreWallMs:0},
  comparison:'Both methods used the identical supplied H, y, constellation and proper-complex noise variance.',
  partialResult:false
}
```

Timing numbers above are illustrative field types, not recorded performance. `mpWithYieldMs` includes asynchronous scheduling delay; do not call it pure CPU time. `totalCoreWallMs` excludes Worker startup and final transfer. Parent-side timing is needed for those boundaries and a UI result needs additional rendering timing.

Terminal statuses:

- `completed`: both methods computed. MP-G may separately be `converged` or `max-iterations`; that distinction is preserved
- `cancelled`, `superseded`: no successful complete result; may include `partial:{mpg:...},partialResult:true` after at least one completed iteration. Before that, partial data is absent
- `invalid-input`: rejected receiver, with `{error:{name,message}}`, no successful methods
- `numerical-failure`: nonfinite arithmetic, failed normalization, failed positive Cholesky or linear-system relative residual >10⁻⁶, with error, no successful methods
- `internal-error`: unexpected exception, including unsupported runtime capability, with error, no successful methods

Malformed protocol messages return `type:'protocol-error',status:'invalid-input'`; they are not accepted runs. Cancelling a nonactive ID returns `type:'cancel-ignored',status:'not-active'`.

Macrotask yields between computed iterations allow actual incoming cancellation/new-run events. There is no fabricated cancellation progress or artificial convergence trace. Noninterruptible initialization and one iteration are bounded by D≤12, Q≤16; cancellation is not a hard real-time guarantee.

`createResultGate()` is a consumer helper. Call `expect(id, awaitedInputDigest)` for the exact submitted request; call `invalidate()` immediately when inputs change. Accept a result only when `accepts(record)` is true. This requires completed status plus both matching ID and matching digest. The controller preventing an old active solve from finishing is complementary to this consumer check; neither alone is a UI freshness test. This helper assumes a trusted, non-null Worker record; it is not a general external-payload schema validator or duplicate-result consumption guard. Import/replay code must validate full payloads separately.

## MP-G result and history

- `algorithm:'mp-g'`, `status`, `iterations`
- `probabilities[D][Q]`, `logProbabilities[D][Q]`
- `trace[]`: real iteration number, maximum absolute probability-message delta and maximum absolute marginal probability delta
- `history[]`: empty when disabled, otherwise the initial state plus each real computed step. Each snapshot contains the same deltas, all marginal probabilities/log-probabilities, and `incomingLogMessages[2E][Q]`
- `graph`: G, z, normalized unary log factors, sorted edges `(i,j)` with complex `Gij`, edge cutoff, removed Gram Frobenius norm and `2E Q²` scalar terms per iteration

For edge e=(i,j), row 2e is j→i, row 2e+1 is i→j. Every message row is normalized in log space. Initial messages are uniform and initial marginals are normalized unary factors. Iteration zero's two deltas are zero by definition. A positive cutoff changes the retained factor graph and is disclosed by cutoff and removed norm. Its effect need not be negligible at low noise or extreme raw-input scale; independently tested marginal changes reached about 4.27×10⁻⁵ at edgeTolerance=10⁻¹². Zero cutoff retains every numerically nonzero edge and may retain roundoff edges. “Exact local sums” refers to the retained graph, never exact global loopy marginals.

The history is not interpolated, synthesized from convergence deltas, or selected using true labels. No hidden full-state enumeration is used by production modules. Exact tiny posterior enumeration is test-only and reports the loopy approximation gap honestly.

## LMMSE result

`algorithm:'full-lmmse-effective-awgn'`, `status:'solved'`, `iterations:1`, calibrated probabilities/log-probabilities, actual effective gain, residual variance and SINR, linear-solve relative residual, and minimum/maximum Cholesky-pivot ratio. The pivot ratio is a numerical diagnostic, not a spectral condition number. Version 0.2.0 removes the frozen reference’s absolute variance floor and analytically removes the common squared-output score term before evaluating whitened log factors. See `NUMERICAL-CORRECTION.md`. Exact zero filters yield uniform probabilities; a nonzero filter whose variance underflows to zero produces `numerical-failure`, never an invented posterior.

## Observation, evaluation and reproducibility

`generateObservation(...)` returns independent `receiver`, `generator`, and `evaluation` records. It uses `mulberry32-domain-separated-box-muller-v1`: uint32 seed XOR `0x243f6a88` for data, XOR `0x85a308d3` for proper-complex Gaussian noise. Box–Muller uses `sqrt(-2 log(1-u))` and an independent angle; each real component scales by `sqrt(v/2)`. Both detector methods receive the same generated observation.

`evaluateDetector(result,evaluation)` calculates SER, BER, entropy proxy, and truth-scored log score only after inference. The bit label convention is derived from canonical QAM. Truth changes may change evaluation, but cannot change receiver digest, solver path, iterations, retained output or probabilities.

Exports are ordinary saved terminal/observation JSON records; arrays are authoritative. This package supplies fixtures and independently checks raw saved arrays. It does not yet provide a browser download button or claim independently validated browser-export packaging. Replay must retain provenance, full inputs/settings, typed statuses, actual histories and the evaluation boundary. Unknown prior result values are historical claims until independently replayed.
