"""Independent contractions, real-Jacobian FIM, finite differences and edge tests.
Uses the solver API, but rederives observations/constraints outside its metrics.
"""
from reference import *
from experiment import clean,save,ROOT
import json
checks=[];details=[]
def check(label,condition,value=None):
 checks.append({'name':label,'passed':bool(condition),'value':clean(value)})
 if not condition: print('FAILED',label,value,flush=True)
def independent_arrays(c,theta=None):
 theta=np.deg2rad(c.theta_degrees) if theta is None else theta
 at=np.exp(1j*np.pi*(np.arange(c.nt)-(c.nt-1)/2)*np.sin(theta))
 ar=np.exp(1j*np.pi*(np.arange(c.nr)-(c.nr-1)/2)*np.sin(theta))
 return ar[:,None]*at.conj()[None,:]
def validate_observation(s,c,label):
 W=np.column_stack((s['Wc'],s['Wa'])); rows=len(W.T); L=c.snapshots
 S=np.exp(2j*np.pi*np.arange(rows)[:,None]*np.arange(L)[None,:]/L);X=W@S
 check(label+' stream orthogonality',np.linalg.norm(S@S.conj().T/L-np.eye(rows))<1e-10)
 RX=X@X.conj().T/L
 check(label+' finite-block covariance',np.linalg.norm(RX-s['R_recovered'])/np.linalg.norm(RX)<1e-12)
 # h_k^H is row H[k]; direct time averages of every stream's channel response.
 HW=s['H']@W;desired=abs(np.diag(HW[:,:len(s['H'])]))**2
 denominator=np.sum(abs(HW)**2,axis=1)-desired+c.communication_noise_mw
 sinr=desired/denominator
 check(label+' independent beam feasibility',np.min(sinr/s['gamma'])>=1-2e-5 and np.vdot(X,X).real/L<=c.power_mw*(1+2e-5),sinr/s['gamma'])
 if s['report']['kind']=='point':
  h=1e-6;t=np.deg2rad(c.theta_degrees);A=independent_arrays(c)
  D=(independent_arrays(c,t+h)-independent_arrays(c,t-h))/(2*h)
  d=(c.alpha*D@X).ravel(order='F');z=(A@X).ravel(order='F')
  J=np.column_stack([d,z,1j*z]);F=2/c.radar_noise_mw*(J.conj().T@J).real
  inverse=np.linalg.inv(F); numeric=float(inverse[0,0]);reported=s['report']['radar']['crb_rad2']
  error=abs(numeric/reported-1)
  check(label+' independent finite-difference FIM',error<1e-7,error)
  details.append({'id':label,'fim':F.tolist(),'finite_difference_crb':numeric,'reported_crb':reported,'relative_error':error})
 else:
  # Complex vectorized normal-equation covariance: sigma^2 (XX^H)^-T ⊗ I.
  J=np.kron((X@X.conj().T).T,np.eye(c.nr))/c.radar_noise_mw
  val=float(np.trace(np.linalg.inv(J)).real); reported=s['report']['radar']['crb_G_frobenius_mse']
  check(label+' full Kronecker complex FIM',abs(val/reported-1)<1e-10,abs(val/reported-1))

# Cross-solver comparison genuinely reruns nontrivial optimization.
for seed in [131,517]:
 c=Config(nt=4,nr=6,snapshots=12,power_mw=8.,theta_degrees=23.)
 H=rayleigh(seed,2,4); gamma=np.array([2.,3.])
 for kind in ['point','extended']:
  sols=[]
  for solver in ['CLARABEL','SCS']:
   s=finalize_solution(solve_sdr(H,gamma,c,kind,solver,tol=1e-8),c);sols.append(s)
   save(f'{kind}-{solver}-seed{seed}',s,c,{'validation':'cross-solver fresh case'},ROOT/'validation-cases')
   check(f'{kind}/{solver}/{seed} accepted',s['report'].get('accepted',False))
   validate_observation(s,c,f'{kind}/{solver}/{seed}')
  o=[s['report']['diagnostics']['recomputed_objective'] for s in sols]
  check(f'{kind}/{seed} independent algorithm objective agreement',abs(o[0]-o[1])/max(abs(o[0]),1)<2e-5,o)

# General complex single-user analytic optima, including active constraints.
for seed in [21,22]:
 c=Config(nt=6,nr=8,snapshots=20,power_mw=10.,theta_degrees=-31.)
 h=rayleigh(seed,1,6)[0].conj(); norm=np.linalg.norm(h)**2
 for frac in [.001,.15,.75]:
  gamma=frac*c.power_mw*norm/c.communication_noise_mw
  for kind in ['point','extended']:
   s=(solve_single_point_sdp(h,gamma,c) if kind=='point' else finalize_solution(solve_sdr(h.conj()[None,:],np.array([gamma]),c,kind,tol=1e-9),c))
   if kind=='point':
    w=single_point(h,gamma,c);expected=point_metrics(np.outer(w,w.conj()),c)['crb_rad2'];got=s['report']['radar']['crb_rad2']
   else:
    R,w=single_extended(h,gamma,c);expected=c.radar_noise_mw*c.nr/c.snapshots*np.trace(np.linalg.inv(R)).real;got=s['report']['radar']['crb_G_frobenius_mse']
   err=abs(got/expected-1)
   check(f'closed-form/{kind}/{seed}/{frac}',err<1e-4,err)
   save(f'analytic-{kind}-seed{seed}-fraction{frac}',s,c,{'validation':'Theorems1,3','analytic_relative_error':err},ROOT/'validation-cases')

# Deliberately infeasible duplicate-channel constraints: gamma>1 for both.
c=Config(nt=4,nr=6,snapshots=12,power_mw=10.)
h=rayleigh(88,1,4);H=np.vstack([h,h])
for kind in ['point','extended']:
 s=solve_sdr(H,np.full(2,2.),c,kind,solver='SCS',tol=1e-8)
 check('duplicate-channel infeasible '+kind,s['report']['status'] in ('infeasible','infeasible_inaccurate'),s['report']['status'])
 save('infeasible-duplicate-SCS-'+kind,s,c,{'validation':'same channel gamma2 each impossible'},ROOT/'validation-cases')
# Previous K1 Eq33 comparison is a documented counterexample, not discarded.
counter_cfg=Config(nt=6,nr=8,snapshots=20,power_mw=10.,theta_degrees=-31.)
ch=rayleigh(21,1,6)
counter_s=finalize_solution(solve_sdr(ch,np.array([.75*counter_cfg.power_mw*np.linalg.norm(ch)**2]),counter_cfg,'point',tol=1e-9),counter_cfg)
counter=save('single-point-seed21-fraction0.75',counter_s,counter_cfg,{'validation':'retained non-tight K1 Eq33 counterexample'},ROOT/'validation-cases')
check('K1 Eq33 non-tight counterexample retained',not counter['report']['accepted'] and counter['report']['recovery']['rank_one_relative_residuals'][0]>.2)
# Theorem 2 condition failure must be exposed even when feasible.
s=finalize_solution(solve_sdr(H,np.full(2,.1),c,'point',tol=1e-9),c)
check('rank-condition exception exposed',not s['report']['recovery']['theorem2_rank_condition'])
# Singular radar cases and exact single-user extended upper endpoint.
a,_=steering(4,0);w=np.array([1,-1,1,-1],complex)
check('zero illumination declared singular',point_metrics(np.outer(w,w.conj()),c)['status']=='singular')
check('zero reflectivity declared singular',point_metrics(np.outer(a,a.conj()),Config(nt=4,nr=6,snapshots=12,alpha=0))['status']=='singular')
check('endfire declared singular',point_metrics(np.eye(4),Config(nt=4,nr=6,snapshots=12,theta_degrees=90))['status']=='singular')
check('extended singular covariance declared',extended_metrics(np.outer(a,a.conj()),c)['status']=='singular')
check('extended upper endpoint infinite bound',single_extended(h[0].conj(),c.power_mw*np.linalg.norm(h[0])**2,c) is None)
# Unit change: all powers and noises /1000 preserves both CRBs and SINR.
W=np.array([[1,2j],[.2,1],[1j,.2],[.7,-.8j]])
cc=Config(nt=4,nr=6,snapshots=12,power_mw=c.power_mw/1000,communication_noise_mw=.001,radar_noise_mw=.001)
check('mW-to-W point invariance',abs(point_metrics(W@W.conj().T,c)['crb_rad2']/point_metrics(W@W.conj().T/1000,cc)['crb_rad2']-1)<1e-12)
check('mW-to-W extended invariance',abs(extended_metrics(np.eye(4),c)['crb_G_frobenius_mse']/extended_metrics(np.eye(4)/1000,cc)['crb_G_frobenius_mse']-1)<1e-12)
# Explicit singular/invalid design inputs reject before constructing a solver.
for label,cc,HH in [('zero-alpha',Config(nt=4,nr=6,snapshots=12,alpha=0),rayleigh(3,2,4)),('endfire',Config(nt=4,nr=6,snapshots=12,theta_degrees=90),rayleigh(3,2,4)),('nan-power',Config(nt=4,nr=6,snapshots=12,power_mw=float('nan')),rayleigh(3,2,4)),('empty-users',Config(nt=4,nr=6,snapshots=12),np.empty((0,4)))]:
 try:
  solve_sdr(HH,np.ones(len(HH)),cc,'point');rejected=False
 except ValueError:rejected=True
 check('input guard '+label,rejected)
result={'passed':all(x['passed'] for x in checks),'check_count':len(checks),'checks':checks,'details':details}
(ROOT/'VALIDATION.json').write_text(json.dumps(clean(result),indent=2,allow_nan=False)+'\n')
print(json.dumps({'passed':result['passed'],'checks':len(checks),'failed':[x for x in checks if not x['passed']]}),flush=True)
if not result['passed']: raise SystemExit(1)
