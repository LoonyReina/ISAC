from reference import *
import json,time
for kind,k in [('point',4),('extended',6),('extended',12)]:
 s=solve_sdr(rayleigh(20261012,k,16),np.full(k,10**(20/10)),Config(),kind,tol=1e-8)
 r=s['report'];print(kind,k,r['status'],r['wall_seconds'],r.get('accepted'));print(json.dumps(r.get('diagnostics',{})));print(r.get('radar'));print(flush=True)
