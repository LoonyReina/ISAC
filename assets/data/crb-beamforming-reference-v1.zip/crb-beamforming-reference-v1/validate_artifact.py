"""Strict hash/package and numerical-evidence integrity checks, no optimization."""
from pathlib import Path
import json,hashlib,sys
import numpy as np
ROOT=Path(__file__).resolve().parent
checks=[]
def check(name,ok):
 checks.append((name,bool(ok)))
 if not ok:print('FAILED:',name)
manifest_path=ROOT/'ARTIFACT-MANIFEST.json'
if manifest_path.exists():
 m=json.loads(manifest_path.read_text())
 for r in m['files']:
  p=ROOT/r['path'];check('exists '+r['path'],p.is_file())
  if p.is_file():check('hash '+r['path'],hashlib.sha256(p.read_bytes()).hexdigest()==r['sha256'] and p.stat().st_size==r['bytes'])
else:print('Manifest not present yet; data integrity checks only')
check('no primary PDF',not list(ROOT.rglob('*.pdf')))
source=json.loads((ROOT/'SOURCE-MANIFEST.json').read_text());check('fixed primary hash',source['sha256']=='3bb9519855b92a8cca870caf603efe0d05dc1d9369cadad0fb7de20750a61e6d')
rows=json.loads((ROOT/'results/SUMMARY.json').read_text());check('prescribed source trial count',len(rows)==19)
for r in rows:
 d=np.load(ROOT/'results'/r['data_file']);rep=r['report'];name=r['id']
 check(name+' input H',d['H'].shape==(len(rep['gamma']),16))
 individual=json.loads((ROOT/'results'/(name+'.json')).read_text());check(name+' summary agrees',individual==r)
 if rep.get('accepted'):
  W=np.column_stack((d['Wc'],d['Wa']));received=abs(d['H']@W)**2;desired=np.diag(received[:,:len(d['H'])]);sinr=desired/(received.sum(axis=1)-desired+1)
  check(name+' independently feasible within tolerance',np.min(sinr/d['gamma'])>=1-2e-5 and np.sum(abs(W)**2)<=1000*(1+2e-5))
  check(name+' reported certificate threshold',-2e-5<=rep['certificate']['relative_gap']<=1e-4)
v=json.loads((ROOT/'VALIDATION.json').read_text());check('all validation checks',v['passed'] and all(x['passed'] for x in v['checks']))
for f,key,count in [('point-ml.json','results',8)]:
 q=json.loads((ROOT/'observations'/f).read_text());check('ML results count',len(q[key])==count and all(z['failures_dropped']==0 for z in q[key]))
print(json.dumps({'passed':all(x[1] for x in checks),'check_count':len(checks),'failed':[x[0] for x in checks if not x[1]]},indent=2))
if not all(x[1] for x in checks):sys.exit(1)
