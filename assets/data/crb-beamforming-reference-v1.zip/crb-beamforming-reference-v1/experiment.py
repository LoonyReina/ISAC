from reference import *
from pathlib import Path
import json,sys
ROOT=Path(__file__).resolve().parent

def clean(x):
 if isinstance(x,dict): return {k:clean(v) for k,v in x.items()}
 if isinstance(x,(list,tuple)): return [clean(v) for v in x]
 if isinstance(x,np.ndarray):return clean(x.tolist())
 if isinstance(x,(np.integer,np.floating)):return x.item()
 if isinstance(x,float) and not np.isfinite(x):return str(x)
 return x

def save(name,s,c,metadata,out=ROOT/'results'):
 out.mkdir(exist_ok=True,parents=True)
 arrays={k:v for k,v in s.items() if isinstance(v,np.ndarray)}
 np.savez_compressed(out/(name+'.npz'),**arrays)
 conf=asdict(c);conf['alpha']=[c.alpha.real,c.alpha.imag]
 result=clean({'id':name,'config':conf,'metadata':metadata,'report':s['report'],'data_file':name+'.npz'})
 (out/(name+'.json')).write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
 print(name,s['report']['status'],s['report'].get('accepted'),s['report'].get('certificate',{}).get('relative_gap'),flush=True)
 return result

def main():
 c=Config();summary=[]
 # One source Fig.3 design slice, three fixed independent Rayleigh channels.
 for seed in [20261012,20261013,20261014]:
  H=rayleigh(seed,4,16);gam=np.full(4,10**1.5)
  s=finalize_solution(solve_sdr(H,gam,c,'point',tol=1e-9),c)
  diag=minpower_diagnostic(H,gam,c)
  if 'Wc' in diag:s['diagnostic_Wc']=diag['Wc'];s['report']['own_minpower_diagnostic']=diag['report']
  summary.append(save(f'point-k4-g15-s{seed}',s,c,{'source_slice':'Fig.3 dimensions, target angle, SINR and power/noise; new declared random channels','seed':seed,'paper_11_12_baselines':'not implemented; own min-power comparison separately labeled'}))
 # Fig.6 parameter slice with every trial/status retained, INCLUDING infeasible.
 for k in [6,12]:
  for seed in [20261012,20261013]:
   H=rayleigh(seed,k,16)
   for db in [10,20,25,30]:
    s=finalize_solution(solve_sdr(H,np.full(k,10**(db/10)),c,'extended',tol=1e-9),c)
    if 'Wks' in s:
     try:
      baseline=eigen_baseline(s,c);s['baseline_Wc']=baseline['Wc'];s['baseline_Wa']=baseline['Wa'];s['report']['eigen_baseline']=baseline['report']
     except Exception as ex:s['report']['eigen_baseline']={'error':repr(ex)}
    summary.append(save(f'extended-k{k}-g{db}-s{seed}',s,c,{'source_slice':'Fig.6; Nt16 Nr20 P30dBm noises0dBm L30; two seeds per K/Gamma point','seed':seed,'gamma_db':db,'no_failure_censoring':True,'baseline_convention':'retain original auxiliary covariance and principal eigenpairs of data covariances; no renormalization'}))
 (ROOT/'results'/'SUMMARY.json').write_text(json.dumps(clean(summary),indent=2,allow_nan=False)+'\n')
if __name__=='__main__':main()
