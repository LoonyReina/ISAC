# Independent numerical review

## Verdict

The tested multi-user mathematical core is consistent with the paper: array/channel conjugation, Eq. (7), the normalized Eq. (33) point-target SDP, the extended-target inverse-trace SDP equivalent to Eq. (46), the Eq. (48)–(49) recovery, and the explicit real-cone dual adjoint all passed independent checks. This supports a **partial, tolerance-qualified numerical reference**, not a complete replication of the source figures or an exact/interval-arithmetic proof of global optimality.

I independently revalidated all 13 accepted source-parameter attempts out of 19 retained attempts. Six extended-target attempts remain unaccepted. Independent minimum-power dual checks separate them into three power-budget-infeasible cases and three feasible numerical SDR failures. Explicit full-rank feasible witnesses were constructed for all three numerical failures. An alternative optimization formulation improved one of these, but did not close its objective certificate to the prescribed tolerance.

No production, browser, GitHub, or parent reference/result files were modified. All review artifacts are in this directory.

## Primary source checked

- Fan Liu et al., “Cramér-Rao Bound Optimization for Joint Radar-Communication Beamforming,” IEEE Transactions on Signal Processing, vol. 70 (2022), pp. 240–253, DOI 10.1109/TSP.2021.3135692
- Local version-of-record PDF SHA256: `3bb9519855b92a8cca870caf603efe0d05dc1d9369cadad0fb7de20750a61e6d`
- Reviewed Eq. (7), Eq. (33), Theorem 2, Eq. (46)–(49), source numerical settings, Fig. 6 discussion and its failure-censoring footnote
- First tested reference.py SHA256: `28a87b336403accfb0163a50dd134113b5df778cc29f011de860c7b43d9ae3fc`
- Later observed SHA256 after the parent's single-user helper addition: `c0e7482d68a50608395e266a068e6857c0a2e798e6b457ddbeec570c282bb6c0`

## Independent checks and results

### Array derivative and point Fisher information

An independently formed real-parameter FIM for `(theta, Re(alpha), Im(alpha))`, with explicit complex echo-mean derivatives, gives CRB 1.623864815172774e-5. `point_metrics` gives 1.623864815172773e-5: relative difference 6.26e-16. A central finite-difference array derivative agrees to 3.35e-11 relative. This exercises a nonzero angle, complex alpha, nonunit noise, and non-source dimensions.

### Independent physical-unit SDPs

Four fresh solves use Nt=4, Nr=7, L=11, P=7 mW, communication noise=0.3 mW, radar noise=0.8 mW, theta=27 degrees, alpha=0.6+0.8j, K=2, Gamma=[2,3], and channel seeds 901 and 902.

The independent formulation uses physical covariance variables, unnormalized channel outer products, original noise RHS values and CVXPY native complex Hermitian PSD cones. The reference uses normalized variables and explicit real embeddings. Relative objective differences were:

- Point seed 901: 1.47e-9
- Point seed 902: 1.12e-9
- Extended seed 901: 1.97e-8
- Extended seed 902: 2.66e-9

All four reference candidates passed the declared acceptance criteria. These tests validate an independently formulated primal; they do not rely on the same normalization or cone embedding.

### Complex dual adjoint and repaired certificates

The real-embedding adjoint identity was checked on arbitrary Hermitian matrices and arbitrary positive-semidefinite real dual matrices in dimensions 2 and 4, with zero measured relative error.

For the four fresh cases, I reconstructed the LMI pullback from individual Hermitian basis evaluations rather than reusing the reference stationarity expression. Repaired dual stationarity minimum eigenvalues are approximately +1e-11; equality residuals are at machine precision. Independently evaluated dual objectives exactly match the stored bounds.

The dual signs/scales checked are:

- Point maximization: upper bound `mu - lambda dot eta`
- Extended minimization: lower bound `lambda dot eta - mu - 2 Re tr(Z12)`
- Extended normalized objective: `P/Nt^2 * tr(R_physical^-1)`
- Extended Schur block: `[Nt*R_normalized, I; I, T]`, objective `tr(T)/Nt`

These scales are internally consistent; no factor-of-two, transpose, or conjugation defect was found in the explicit-real-cone path.

### Extended recovery

Arbitrary complex high-rank PSD data covariances and an auxiliary covariance were constructed independently. Eq. (48) recovery used column channels `h = H[k].conj()`; the resulting covariance relative error was 1.70e-16, desired-power relative error 1.51e-16, and total received-power relative error 3.15e-16. Consequently interference and SINR are preserved in exact arithmetic. This test catches the common row/column conjugation mistake.

### Closed forms and single-user limitation

Four selected single-user examples (point/extended at 2% and 85% of maximum noise-limited SINR) match the analytic helper metrics within 1.10e-7 relative. These examples do **not** establish universal tightness of Eq. (33) for K=1.

I independently recomputed the parent's K=1 counterexample (Nt=6, Nr=8, theta=-31 degrees, P=10 mW, seed 21, 75% maximum SINR):

- Analytic feasible single beam has normalized information 0.266728354369 and CRB 3.29726475520e-6
- Eq. (33) relaxation has normalized information 0.285096238044 and relaxed CRB 3.08483201358e-6
- Its two significant covariance eigenvalues are 1.88200965854 and 8.11799035924 mW

Theorem 2 requires `rank(H [a, a_dot]) = 2`, which cannot hold with K=1. A generic Eq. (33) solve plus principal-eigenpair extraction is therefore not a general single-user optimum procedure. The parent's added Eq. (25)/Theorem 1 branch is the correct way to validate single-user point designs; the counterexample must remain visible.

### Solver-failure handling

Two identical user channels with Gamma=2 for each are provably infeasible: summing their SINR inequalities yields a contradiction for positive receiver noise.

In the fresh test, CLARABEL reports `infeasible_inaccurate` for point and a solver error/status null for extended. Both are rejected by the implementation. The initial test's stronger expectation that CLARABEL would classify extended infeasibility failed and is retained in `fresh-tests.json` (13/14 checks pass). A separate SCS retry classifies the exact same extended problem as infeasible in 200 iterations and passes. Solver error must not be relabeled infeasibility without such independent evidence.

## Audit of all saved source-parameter cases

`audit_source_cases.py` read every source JSON and NPZ and recomputed actual beam powers, all SINRs, extended MSE, repaired dual cones/coefficient equality/stationarity, objective gaps, and baseline auxiliary-covariance preservation.

At review completion:

- 19 source attempts retained: 3 point, 16 extended
- 13 accepted: all 3 point, 10 extended
- All 13 accepted entries pass independent re-evaluation of the declared tolerances
- Accepted relative dual gaps: 5.54e-8 through 9.49e-6
- Accepted minimum SINR ratio range: 0.999994459849 through 1.00136610045
- Accepted power fraction range: 0.999997640870 through 1.000000003542
- Failures: three PSD-recovery failures and three CLARABEL solver errors
- Eigen baseline: ten available cases; six satisfy the declared feasibility tolerance and four do not

The raw and corrected candidate data are retained; no independent filtering or favorable-channel replacement was used.

### Important qualification on “feasible” and “certificate”

A few accepted beams violate exact arithmetic constraints by tiny amounts (worst SINR shortfall 5.54 ppm and worst power excess 3.54e-9 fractional). They satisfy the declared 2e-5 feasibility tolerance. Accordingly, “numerically feasible within tolerance” and “floating-point repaired dual check” are accurate descriptions. “Strictly feasible global optimum certified” would overstate the evidence. For stronger one-sided bounds, enforce an inward feasibility margin and use rigorous error bounds/interval checks.

## One independently reformulated source failure

At the parent's request, I attempted exactly one source failure using the independently formulated physical-unit/native-complex-cone SDP: K=6, Gamma=30 dB, seed 20261012. Original H, noises, power and other resources were unchanged.

- Solve time: 11.18 seconds
- Solver status: optimal_inaccurate
- Recovered power fraction: 0.999999895920
- Minimum SINR ratio: 1.000001075943
- Auxiliary remainder minimum eigenvalue: +2.47649e-7 mW
- Recovered normalized inverse-trace objective: 1.292235142348
- Recovered extended MSE: 0.220541464294

This is a feasible candidate, so the original failed attempt is **not evidence of problem infeasibility**. Its original failure was a non-PSD recovered remainder of -0.000464520358 mW.

The native complex-cone dual in this ill-conditioned solve had poor coefficient/stationarity behavior and is not trusted as a tight certificate. Combining the new primal with the original explicit-real-cone repaired dual gives the independently useful interval:

`1.288396661452 <= normalized optimum <= 1.292235142348`

The resulting relative gap is 0.00297042 (0.297%), above the prescribed 1e-4 acceptance threshold. This remains a rejected-for-tight-certification refinement, clearly separate from the original source cases. Both the unsuccessful native certificate and useful cross-certificate are retained.

## Independent verification of all six failure classifications

After the initial review, the parent added SINR-only minimum-power SOCP primal candidates and explicit SDP duals for all six unsuccessful source attempts. I independently rebuilt the dual stationarity matrix for each transmitted stream as `I - mu_j Q_j + sum_{i != j} mu_i Gamma_i Q_i` and the objective as `sigma_C^2 sum_i mu_i Gamma_i`. This form is equivalent to the parent’s implementation but uses separately accumulated per-stream coefficients.

All six have nonnegative dual multipliers, stationarity minimum eigenvalues approximately +1e-10, and stored matrix agreement within 1.37e-12. The lower bounds were reproduced exactly:

- K12, Gamma25, seed20261013: 1012.102775689 mW, exceeding the 1000 mW budget
- K12, Gamma30, seed20261012: 2340.206248371 mW, exceeding the budget
- K12, Gamma30, seed20261013: 3212.158078411 mW, exceeding the budget

These are strong floating-point dual infeasibility witnesses for communication, hence also for extended sensing under those constraints. No exact interval-arithmetic proof is claimed.

The other three failures have low-power communication candidates. To establish actual extended-target feasibility, rather than merely SINR-only feasibility, I scaled each data beam by sqrt(1.05) and added a small positive isotropic auxiliary covariance under the resulting strict SINR margins. The independently verified witnesses are:

- K6, Gamma30, seed20261012: 601.333727489 mW, minimum SINR ratio 1.03701137518, covariance minimum eigenvalue 0.000580396625 mW
- K6, Gamma30, seed20261013: 633.662490486 mW, minimum SINR ratio 1.03700448788, covariance minimum eigenvalue 0.000539097061 mW
- K12, Gamma25, seed20261012: 775.068760882 mW, minimum SINR ratio 1.03685848039, covariance minimum eigenvalue 0.000529895490 mW

Thus all three PSD-recovery failures are genuinely numerical failures on feasible extended problems. All three original solver-error cases have separately verified communication infeasibility. Evidence: `failure-diagnosis-audit.json`, its log, `audit_failure_diagnosis.py`, and the three `*-feasible-witness.npz` files. All six diagnosis checks pass.

## Scope limits and recommendations

1. Keep the K=1 point branch distinct; do not cite Theorem 2 outside its rank hypothesis
2. Preserve solver-error, recovery-error and exact feasibility status separately; do not call all unsuccessful cases infeasible
3. Preserve tolerance-qualified wording for accepted candidates and certificate results
4. Report all source attempt and eigen-baseline failure counts alongside any curves or aggregate claims
5. These two-seed Fig. 6 parameter slices do not reconstruct the source Monte Carlo experiment. The source eigen baseline's treatment of auxiliary factors is not fully specified, and its footnote censors infeasible eigen approximations. The chosen uncensored, original-auxiliary/no-renormalization convention is useful and explicitly declared, but is a controlled variant
6. The communication minimum-power diagnostic is not either prior-paper beampattern approximation baseline and must remain separately labeled

## Reproduction commands

All Python commands use:

`OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 /workspace/shared/isac-paper-execution/atomic-receiver-reference/.venv/bin/python`

Executed scripts:

- `independent-review/review_tests.py` -> `fresh-tests.json`, `fresh-tests.log`
- `independent-review/audit_source_cases.py` -> `source-case-audit.json`, `source-case-audit.log`
- `independent-review/refine_source_native.py` -> source-native JSON/NPZ/log
- `independent-review/audit_failure_diagnosis.py` -> `failure-diagnosis-audit.json`, log, and full-rank feasible-witness NPZ files
- An inline SCS retry of the same duplicate-channel extended test -> `solver-failure-retry.json`
- An inline independent analytic evaluation of the saved single-user counterexample -> `single-user-counterexample.json`
- An inline primal/dual cross-certificate evaluation using the source and native NPZ files -> source-cross-certificate JSON/NPZ

Software: Python environment supplied by the parent, CVXPY 1.9.3, NumPy 2.3.5, CLARABEL and SCS. The review directory includes every fresh script and numeric result above; parent files are untouched.

## Final guard-only update

Final reference.py SHA256: `70f0a44a67b261f3ffc62e47455a42b08208aebebd6e99b8dc58b81f97fa3d0a`. Inspected the new resource/channel guards and the point-design visible-sector/endfire and zero-reflectivity guards. No solver, normalization, recovery or certificate algebra changed. Independently executed `guard_checks.py` with the same supplied Python environment and one-thread BLAS settings: all 17 checks passed, with no optimization invoked. Existing valid source inputs remain accepted and the prior numerical-review verdict applies unchanged. This review does not independently assert the outcome of the parent’s separate 67-check rerun.

Final-hash reconciliation: the earlier `d124703c3f2174f36689ec6fd6a0c2262a09a8c3c06594ccbdc027a84ae8cf04` snapshot was recorded at 14:58:06 UTC before the final point-only alpha=0 rejection guard. The final file was re-read after that change and its SHA256 is `70f0a44a67b261f3ffc62e47455a42b08208aebebd6e99b8dc58b81f97fa3d0a`; all 17 fast guards pass against this exact final version. No numerical optimization was repeated.
