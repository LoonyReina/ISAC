# Independent review verdict

**The tested multi-user mathematical core passes independent review. The evidence supports a partial, tolerance-qualified numerical reproduction only. No browser, production, or full-paper acceptance is granted.**

## Accepted scope

All original 19 source-parameter attempts were retained. I independently recomputed beam powers, SINRs, extended MSE, dual PSD/stationarity/equality residuals and gaps from the saved arrays:

- **13/19 accepted within the declared tolerances:** three point-target and ten extended-target cases
- Accepted relative objective certificate gaps: **5.54e-8 to 9.49e-6**
- Worst accepted SINR ratio: **0.999994459849**; largest power fraction: **1.000000003542**

These are numerical tolerance checks, not exact feasibility or interval-arithmetic proofs. No failed trial was replaced or censored.

## Six unsuccessful cases

Independent reconstruction of the minimum-power dual confirms three budget-infeasible cases:

- K12/Gamma25/seed20261013: lower bound **1012.102775689 mW**
- K12/Gamma30/seed20261012: **2340.206248371 mW**
- K12/Gamma30/seed20261013: **3212.158078411 mW**

Each exceeds the source's 1000 mW budget. Reconstructed dual stationarity minima are approximately +1e-10, with stored-matrix agreement within 1.37e-12. These are floating-point dual certificates.

The other three remain **unresolved numerical optimization/recovery failures**, despite independently constructed full-rank feasible witnesses:

- K6/Gamma30/seed20261012: **601.334 mW**, minimum SINR ratio **1.03701**
- K6/Gamma30/seed20261013: **633.662 mW**, ratio **1.03700**
- K12/Gamma25/seed20261012: **775.069 mW**, ratio **1.03686**

One independently reformulated K6/Gamma30/seed20261012 solve additionally produced a feasible MSE **0.220541464294**, but its cross-certificate gap remains **0.297%**, exceeding the 0.01% criterion. Original source records remain unchanged.

## Independent checks

- Explicit real-parameter Fisher information matches Eq. (7) within **6.3e-16 relative**
- Four fresh native-complex-cone, physical-unit SDPs match normalized reference objectives within **2e-8 relative**
- Independently reconstructed real-cone adjoints and dual stationarity pass
- Eq. (48)–(49) preserves covariance, desired power and total received power within **3.2e-16 relative**
- Initial fresh suite: **13/14 checks passed**; the retained failure was CLARABEL not classifying a provably infeasible case. A separate SCS retry correctly classifies it as infeasible
- All **six** new failure-diagnosis checks pass
- A retained K=1 counterexample confirms Eq. (33) is not universally tight outside Theorem 2's rank condition. Use the separate Eq. (25)/Theorem 1 single-user branch

## Remaining limitations

The two-seed extended slices do not reproduce the source's Monte Carlo figure experiment. Only ten eigen-baseline cases are available; six pass feasibility and four fail. The original-auxiliary/no-renormalization convention differs from the source's incompletely specified, failure-censored baseline protocol. The minimum-power diagnostic is not a prior-paper beampattern baseline.

## Evidence and reproducibility

All files are under this `independent-review/` directory. `DETAILS.md` records source hashes, derivations, test settings and executed commands. `MANIFEST.json` contains SHA256 hashes for every review artifact.

- `review_tests.py`, `fresh-tests.json`, `fresh-tests.log`
- `audit_source_cases.py`, `source-case-audit.json`, `source-case-audit.log`
- `audit_failure_diagnosis.py`, `failure-diagnosis-audit.json`, `failure-diagnosis-audit.log`
- `refine_source_native.py`, `*-native.json/npz`, `*-cross-certificate.json/npz`
- Three `*-feasible-witness.npz` files
- `single-user-counterexample.json`, `solver-failure-retry.json`

Execution used the supplied virtual environment, CVXPY 1.9.3 and NumPy 2.3.5, with OPENBLAS_NUM_THREADS=1 and OMP_NUM_THREADS=1. All review scripts compile and all review JSON parses strictly. No parent code/results or external state were modified.

## Final input-guard update

The final input-validation and point-angle guards were inspected; 17 inexpensive guard checks pass without invoking a solver. Empty channels, noninteger dimensions, nonfinite physical parameters, point designs at/outside endfire and point designs with zero reflectivity are rejected; endfire and zero-reflectivity metrics remain singular. The solver/recovery/dual algebra is unchanged, so the numerical verdict above continues to apply. Final `reference.py` SHA256: `70f0a44a67b261f3ffc62e47455a42b08208aebebd6e99b8dc58b81f97fa3d0a`. Evidence: `guard_checks.py`, `guard-checks.json`, `guard-checks.log`.
