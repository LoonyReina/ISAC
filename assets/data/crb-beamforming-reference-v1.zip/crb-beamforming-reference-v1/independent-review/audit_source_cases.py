import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
import numpy as np,json,sys,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT));import reference as r
out=[]
for path in sorted((ROOT/'results').glob('*.json')):
    if path.name=='SUMMARY.json': continue
    j=json.loads(path.read_text());z=np.load(path.with_suffix('.npz'));rep=j['report'];conf=j['config'];conf['alpha']=complex(*conf['alpha']);c=r.Config(**conf);H=z['H'];gamma=z['gamma'];n=c.nt;k=len(H);row={'id':j['id'],'solver_status':rep['status'],'accepted':rep['accepted']}
    if 'Wks' in z:
        Ws=z['Wks'];R=Ws.sum(0)
        row.update(min_covariance_eigenvalue_mw=float(min(np.linalg.eigvalsh((W+W.conj().T)/2).min() for W in Ws)),raw_covariance_power_fraction=float(np.trace(R).real/c.power_mw))
    if 'Wc' in z:
        B=np.column_stack([z['Wc'],z['Wa']]);R=B@B.conj().T
        powers=abs(H@B)**2;desired=np.array([powers[i,i] for i in range(k)]);interference=powers.sum(1)-desired;sinr=desired/(interference+c.communication_noise_mw)
        row.update(actual_power_fraction=float(np.sum(abs(B)**2)/c.power_mw),min_sinr_ratio=float(np.min(sinr/gamma)),stored_power_abs_error=float(abs(np.sum(abs(B)**2)-rep['communication']['power_mw'])),stored_sinr_abs_error=float(np.max(abs(sinr-rep['communication']['sinr']))))
        if rep['kind']=='extended':
            row['independent_MSE']=float(c.nr*c.radar_noise_mw/c.snapshots*np.linalg.inv(R).trace().real)
            row['stored_MSE_relative_error']=float(abs(row['independent_MSE']/rep['radar']['crb_G_frobenius_mse']-1))
        if 'cert_dual_lmi' in z:
            Z=z['cert_dual_lmi'];la=z['cert_dual_sinr'];mu=float(z['cert_dual_power']);Q=[h.conj()[:,None]*h[None,:]/sum(abs(h)**2) for h in H]
            eta=c.communication_noise_mw/(c.power_mw*np.sum(abs(H)**2,axis=1))
            if rep['kind']=='point':
                t=np.deg2rad(c.theta_degrees);p=np.arange(n)-(n-1)/2;q=np.arange(c.nr)-(c.nr-1)/2;a=np.exp(1j*np.pi*p*np.sin(t));b=np.exp(1j*np.pi*q*np.sin(t));da=1j*np.pi*p*np.cos(t)*a;db=1j*np.pi*q*np.cos(t)*b;A=b[:,None]*a.conj()[None,:];D=db[:,None]*a.conj()[None,:]+b[:,None]*da.conj()[None,:]
                scaleA=np.linalg.norm(A)**2;scaleD=np.linalg.norm(D)**2;M0=A.conj().T@A/scaleA;M2=D.conj().T@D/scaleD;M1=D.conj().T@A/np.sqrt(scaleA*scaleD)
                F=Z[0,0]*M2+Z[1,1]*M0+Z[1,0]*M1+Z[0,1]*M1.conj().T
                obj=float((np.trace(D.conj().T@D@R).real-abs(np.trace(D.conj().T@A@R))**2/np.trace(A.conj().T@A@R).real)/(c.power_mw*scaleD));bound=mu-la@eta;gap=bound-obj;co=float(abs(Z[0,0]-1));cnt=k
            else:
                F=n*Z[:n,:n];obj=float(c.power_mw/n**2*np.linalg.inv(R).trace().real);bound=la@eta-mu-2*np.trace(Z[:n,n:]).real;gap=obj-bound;co=float(np.linalg.norm(Z[n:,n:]-np.eye(n)/n));cnt=k+1
            S=[mu*np.eye(n)-F+sum(la[i]*Q[i] for i in range(k))-(la[j]*(1+1/gamma[j])*Q[j] if j<k else 0) for j in range(cnt)]
            row.update(dual_min_eigenvalue=float(np.linalg.eigvalsh(Z).min()),dual_stationarity_min_eigenvalue=float(min(np.linalg.eigvalsh((x+x.conj().T)/2).min() for x in S)),dual_coefficient_residual=co,dual_bound=float(bound),independent_relative_gap=float(gap/obj),dual_nonnegative_multipliers=bool(mu>=0 and min(la)>=0))
    if 'baseline_Wc' in z:
        B=np.column_stack([z['baseline_Wc'],z['baseline_Wa']]);p=abs(H@B)**2;desired=np.diag(p[:,:k]);ratio=desired/(p.sum(1)-desired+c.communication_noise_mw)/gamma
        original=np.linalg.eigvalsh(z['Wks'][-1]);rho=z['baseline_Wa']@z['baseline_Wa'].conj().T
        row.update(baseline_power_fraction=float(np.sum(abs(B)**2)/c.power_mw),baseline_min_sinr_ratio=float(ratio.min()),baseline_aux_covariance_relative_error=float(np.linalg.norm(rho-z['Wks'][-1])/max(np.linalg.norm(z['Wks'][-1]),1e-30)),baseline_accepted=rep['eigen_baseline']['communication']['feasible_at_2e-5'])
    row['audit_pass']=bool(not row['accepted'] or ('independent_relative_gap' in row and row['actual_power_fraction']<=1+2e-5 and row['min_sinr_ratio']>=1-2e-5 and row['dual_min_eigenvalue']>=-1e-7 and row['dual_stationarity_min_eigenvalue']>=-1e-7 and row['dual_coefficient_residual']<1e-7 and row['dual_nonnegative_multipliers'] and -2e-5<=row['independent_relative_gap']<=1e-4))
    out.append(row)
ROOT.joinpath('independent-review/source-case-audit.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'total':len(out),'accepted':sum(x['accepted'] for x in out),'all_accepted_independently_revalidated':all(x['audit_pass'] for x in out),'rows':out},indent=2))
