"""Fast final input-guard checks; deliberately no numerical optimization."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
import sys,json,hashlib
from dataclasses import replace
import numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT));import reference as r
c=r.Config(nt=4,nr=7,snapshots=11,power_mw=7);H=r.rayleigh(441,2,4);rows=[]
def reject(name,fn):
 try:fn();rows.append({'name':name,'PASS':False,'result':'unexpected acceptance'})
 except ValueError as e:rows.append({'name':name,'PASS':True,'result':str(e)})
 except Exception as e:rows.append({'name':name,'PASS':False,'result':repr(e)})
reject('empty H',lambda:r.validate(c,np.empty((0,4)),1))
for field,value in [('nt',4.),('nr',7.),('snapshots',11.),('power_mw',np.nan),('communication_noise_mw',np.inf),('radar_noise_mw',np.nan),('theta_degrees',np.inf),('alpha',complex(np.nan,1))]:
 reject(f'{field}={value}',lambda field=field,value=value:r.validate(replace(c,**{field:value}),H,1))
for angle in [-90,90,91]:reject(f'point solver theta={angle}',lambda angle=angle:r.solve_sdr(H,1,replace(c,theta_degrees=angle),'point'))
for angle in [-90,90]:
 result=r.point_metrics(np.eye(4),replace(c,theta_degrees=angle));rows.append({'name':f'endfire metric theta={angle}','PASS':result['status']=='singular' and result['crb_rad2'] is None,'result':result['status']})
reject('point solver alpha=0',lambda:r.solve_sdr(H,1,replace(c,alpha=0),'point'))
zero_alpha_metric=r.point_metrics(np.eye(4),replace(c,alpha=0));rows.append({'name':'zero alpha metric','PASS':zero_alpha_metric['status']=='singular' and zero_alpha_metric['crb_rad2'] is None,'result':zero_alpha_metric['status']})
r.validate(c,H,[1,2]);rows.append({'name':'valid source-domain input','PASS':True,'result':'accepted'})
out={'reference_sha256':hashlib.sha256((ROOT/'reference.py').read_bytes()).hexdigest(),'optimization_invoked':False,'checks':rows,'total':len(rows),'passed':sum(x['PASS'] for x in rows)}
(ROOT/'independent-review/guard-checks.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
