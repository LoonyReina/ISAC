"""Independent physical-unit primal, Fisher-information, recovery, and certificate audit."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'; os.environ['OMP_NUM_THREADS']='1'
import sys, json, hashlib
from pathlib import Path
import numpy as np
import cvxpy as cp
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import reference as ref
OUT=Path(__file__).resolve().parent
results=[]
def log(name, data):
    row={'name':name, **data};results.append(row);print(json.dumps(row, default=lambda x: x.item() if isinstance(x,np.generic) else str(x)),flush=True)
def rel(a,b):return float(abs(a-b)/max(abs(a),abs(b),1e-30))
def independent_array(n,t):
    indices=np.arange(1,n+1)-(n+1)/2
    arr=np.exp(1j*np.pi*indices*np.sin(t))
    return arr,arr*(1j*np.pi*indices*np.cos(t))
def independent_info(R,c):
    a,da=independent_array(c.nt,np.deg2rad(c.theta_degrees));b,db=independent_array(c.nr,np.deg2rad(c.theta_degrees))
    A=b[:,None]*a.conj()[None,:];D=db[:,None]*a.conj()[None,:]+b[:,None]*da.conj()[None,:]
    e,U=np.linalg.eigh((R+R.conj().T)/2);X=(U*np.sqrt(np.maximum(e,0)))*np.sqrt(c.snapshots)
    vec=lambda x:x.reshape(-1,order='F')
    # Real parameters are theta, real(alpha), imag(alpha).
    deriv=np.column_stack((vec(c.alpha*D@X),vec(A@X),vec(1j*A@X)))
    F=2*np.real(deriv.conj().T@deriv)/c.radar_noise_mw
    crb=float(np.linalg.inv(F)[0,0])
    return crb,A,D,F

def independent_sdr(H,gamma,c,kind):
    # Physical W and R, raw Q=h h^H, native Hermitian PSD cones.
    k,n=H.shape; Q=[row.conj()[:,None]*row[None,:] for row in H]
    W=[cp.Variable((n,n),hermitian=True) for _ in range(k)]
    if kind=='extended':
        R=cp.Variable((n,n),hermitian=True)
        constraints=[R-sum(W)>>0]
    else:R=sum(W);constraints=[]
    constraints += [w>>0 for w in W]+[cp.real(cp.trace(R))<=c.power_mw]
    for j in range(k):
        constraints.append(cp.real(cp.trace(Q[j]@W[j]))-gamma[j]*cp.real(cp.trace(Q[j]@(R-W[j])))>=gamma[j]*c.communication_noise_mw)
    if kind=='point':
        _,A,D,_=independent_info(np.eye(n),c);scale=c.power_mw*np.linalg.norm(D,'fro')**2
        t=cp.Variable(); cross=cp.trace(D.conj().T@A@R)
        constraints += [cp.bmat([[cp.real(cp.trace(D.conj().T@D@R))-t,cross],[cp.conj(cross),cp.real(cp.trace(A.conj().T@A@R))]])>>0]
        prob=cp.Problem(cp.Maximize(t/scale),constraints)
    else:
        T=cp.Variable((n,n),hermitian=True)
        constraints += [cp.bmat([[R,np.eye(n)],[np.eye(n),T]])>>0]
        prob=cp.Problem(cp.Minimize(cp.real(cp.trace(T))*c.power_mw/n**2),constraints)
    prob.solve(solver='CLARABEL',tol_gap_abs=1e-10,tol_gap_rel=1e-10,tol_feas=1e-10,max_iter=300)
    return {'status':prob.status,'objective':prob.value,'power':float(np.trace(R.value).real) if R.value is not None else None}

def audit_dual(s,c):
    H=s['H'];k,n=H.shape;gamma=s['gamma'];kind=s['report']['kind']
    # Reconstruct coefficients afresh from physical trace identities and derivatives.
    _,A,D,_=independent_info(np.eye(n),c)
    Z=s['cert_dual_lmi']; lam=s['cert_dual_sinr'];mu=float(s['cert_dual_power']);scaleA=np.linalg.norm(A,'fro')**2;scaleD=np.linalg.norm(D,'fro')**2
    def mapmat(V):
        if kind=='point':
            return np.array([[np.trace(D.conj().T@D@V)/scaleD,np.trace(D.conj().T@A@V)/np.sqrt(scaleA*scaleD)],[np.trace(A.conj().T@D@V)/np.sqrt(scaleA*scaleD),np.trace(A.conj().T@A@V)/scaleA]])
        return np.block([[n*V,np.zeros((n,n))],[np.zeros((n,n)),np.zeros((n,n))]])
    # Pull back a linear functional using diagonal + real/imag Hermitian basis evaluations.
    F=np.zeros((n,n),complex)
    for i in range(n):
        E=np.zeros((n,n),complex);E[i,i]=1;F[i,i]=np.trace(Z@mapmat(E)).real
        for j in range(i):
            E=np.zeros((n,n),complex);E[i,j]=E[j,i]=1
            re=np.trace(Z@mapmat(E)).real/2
            E[i,j]=1j;E[j,i]=-1j
            im=np.trace(Z@mapmat(E)).real/2
            F[i,j]=re+1j*im;F[j,i]=re-1j*im
    mats=[]
    for j in range(k+(kind=='extended')):
        S=mu*np.eye(n,dtype=complex)-F
        for i,row in enumerate(H):
            Q=row.conj()[:,None]*row[None,:]/np.sum(abs(row)**2)
            S+=lam[i]*Q
            if j==i:S-=lam[i]*(1+1/gamma[i])*Q
        mats.append((S+S.conj().T)/2)
    eta=c.communication_noise_mw/(c.power_mw*np.sum(abs(H)**2,axis=1))
    bound=mu-lam@eta if kind=='point' else lam@eta-mu-2*np.trace(Z[:n,n:]).real
    return {'dual_min_eigenvalue':float(np.linalg.eigvalsh(Z).min()),'stationarity_min_eigenvalue':float(min(np.linalg.eigvalsh(S).min() for S in mats)),'coefficient_residual':float(abs(Z[0,0]-1) if kind=='point' else np.linalg.norm(Z[n:,n:]-np.eye(n)/n)),'bound_error':float(abs(bound-s['report']['certificate']['bound_normalized']))}

rng=np.random.default_rng(881932)
c=ref.Config(nt=4,nr=7,snapshots=11,power_mw=7,communication_noise_mw=.3,radar_noise_mw=.8,theta_degrees=27,alpha=.6+.8j)
B=rng.normal(size=(4,4))+1j*rng.normal(size=(4,4));R=B@B.conj().T;R*=c.power_mw/np.trace(R).real
crb,A,D,F=independent_info(R,c);metric=ref.point_metrics(R,c)['crb_rad2']
step=1e-6;a1,_=independent_array(c.nt,np.deg2rad(c.theta_degrees)+step);b1,_=independent_array(c.nr,np.deg2rad(c.theta_degrees)+step);a0,_=independent_array(c.nt,np.deg2rad(c.theta_degrees)-step);b0,_=independent_array(c.nr,np.deg2rad(c.theta_degrees)-step)
Dfd=(b1[:,None]*a1.conj()[None,:]-b0[:,None]*a0.conj()[None,:])/(2*step)
log('explicit_real_parameter_FIM',{'crb_inverse_FIM':crb,'crb_reference':metric,'relative_error':rel(crb,metric),'derivative_finite_difference_relative_error':float(np.linalg.norm(D-Dfd)/np.linalg.norm(D)),'PASS':rel(crb,metric)<1e-12})
# Arbitrary high-rank covariances exercise channel conjugation and exact recovery.
H=ref.rayleigh(728491,3,4); qs=[]
for j in range(4):
    B=rng.normal(size=(4,4))+1j*rng.normal(size=(4,4));qs.append(B@B.conj().T)
R=sum(qs);wc,wa,rep=ref.recover_extended(R,qs[:3],H)
old_des=np.array([np.real(H[j]@qs[j]@H[j].conj()) for j in range(3)]);new_des=abs(np.diag(H@wc))**2
old_tot=np.real(np.einsum('ki,ij,kj->k',H,R,H.conj()));new_tot=np.sum(abs(H@np.column_stack([wc,wa]))**2,axis=1)
log('exact_extended_recovery_arbitrary_covariances',{'relative_covariance_error':float(np.linalg.norm(R-wc@wc.conj().T-wa@wa.conj().T)/np.linalg.norm(R)),'desired_relative_error':float(np.max(abs(old_des-new_des)/old_des)),'total_received_relative_error':float(np.max(abs(old_tot-new_tot)/old_tot)),'PASS':np.allclose(old_des,new_des,rtol=1e-12) and np.allclose(old_tot,new_tot,rtol=1e-12)})
for kind in ['point','extended']:
    for seed in [901,902]:
        H=ref.rayleigh(seed,2,4);gamma=np.array([2.,3.]);s=ref.finalize_solution(ref.solve_sdr(H,gamma,c,kind,tol=1e-10),c);other=independent_sdr(H,gamma,c,kind)
        cert=s['report'].get('certificate',{})
        log(f'independent_physical_primal_{kind}_{seed}',{'native_complex_psd':other,'reference_status':s['report']['status'],'reference_objective':s['report']['diagnostics']['recomputed_objective'],'relative_objective_error':rel(other['objective'],s['report']['diagnostics']['recomputed_objective']),'accepted':s['report']['accepted'],'certificate':cert,'independent_dual':audit_dual(s,c),'PASS':rel(other['objective'],s['report']['diagnostics']['recomputed_objective'])<2e-6})
for kind in ['point','extended']:
    h=ref.rayleigh(9122,1,4)[0].conj(); H=h.conj()[None,:]
    for fraction in [.02,.85]:
        gamma=fraction*c.power_mw*np.linalg.norm(h)**2/c.communication_noise_mw
        s=ref.finalize_solution(ref.solve_sdr(H,np.array([gamma]),c,kind,tol=1e-10),c)
        if kind=='point':
            w=ref.single_point(h,gamma,c);exact=ref.point_metrics(np.outer(w,w.conj()),c)['crb_rad2'];computed=s['report']['radar']['crb_rad2']
        else:
            Re,w=ref.single_extended(h,gamma,c);exact=ref.extended_metrics(Re,c)['trace_inverse_per_mw'];computed=s['report']['radar']['trace_inverse_per_mw']
        log(f'single_user_closed_form_{kind}_{fraction}',{'closed_form_metric':exact,'numerical_metric':computed,'relative_error':rel(exact,computed),'accepted':s['report']['accepted'],'PASS':rel(exact,computed)<2e-6})
for kind in ['point','extended']:
    H=np.repeat(ref.rayleigh(993,1,4),2,axis=0)
    s=ref.finalize_solution(ref.solve_sdr(H,np.array([2.,2.]),c,kind),c)
    log(f'provably_infeasible_duplicate_channel_{kind}',{'status':s['report']['status'],'accepted':s['report']['accepted'],'PASS':s['report']['status'] in ['infeasible','infeasible_inaccurate'] and not s['report']['accepted']})
# Real-embedding adjoint identity checked independently with nonsymmetric real dual blocks.
for n in [2,4]:
    Q=rng.normal(size=(n,n))+1j*rng.normal(size=(n,n));M=Q+Q.conj().T;Q=rng.normal(size=(2*n,2*n));D=Q@Q.T
    EM=np.block([[M.real,-M.imag],[M.imag,M.real]])
    left=float(np.trace(D@EM));right=float(np.trace(ref.dual_unembed(D)@M).real)
    log(f'real_cone_dual_adjoint_{n}',{'relative_error':rel(left,right),'PASS':rel(left,right)<1e-12})
OUT.joinpath('fresh-tests.json').write_text(json.dumps(results,indent=2)+'\n')
print('TOTAL',len(results),'PASS',sum(bool(x['PASS']) for x in results),flush=True)
