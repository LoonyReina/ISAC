import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
import numpy as np,cvxpy as cp,json,sys,time,warnings
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT));import reference as r
c=r.Config();source='extended-k6-g30-s20261012';raw=np.load(ROOT/'results'/(source+'.npz'));H=raw['H'];gamma=raw['gamma'];n=c.nt;k=len(H)
R=cp.Variable((n,n),hermitian=True);T=cp.Variable((n,n),hermitian=True);W=[cp.Variable((n,n),hermitian=True) for _ in range(k)]
rem=R-sum(W);cones=[w>>0 for w in W];aux=rem>>0;power=cp.real(cp.trace(R))<=c.power_mw;sinr=[]
for j,row in enumerate(H):
 Q=row.conj()[:,None]*row[None,:]
 sinr.append(cp.real(cp.trace(Q@W[j]))-gamma[j]*cp.real(cp.trace(Q@(R-W[j])))>=gamma[j]*c.communication_noise_mw)
lmi=cp.bmat([[R,np.eye(n)],[np.eye(n),T]])>>0
prob=cp.Problem(cp.Minimize(cp.real(cp.trace(T))*c.power_mw/n**2),cones+[aux,power]+sinr+[lmi]);start=time.time()
with warnings.catch_warnings(record=True) as warn:
 warnings.simplefilter('always')
 try:prob.solve(solver='CLARABEL',tol_gap_abs=1e-9,tol_gap_rel=1e-9,tol_feas=1e-9,max_iter=300);error=None
 except Exception as e:error=repr(e)
report={'source':source,'formulation':'native complex Hermitian PSD, physical mW covariances, original Gamma noise RHS; objective P/Nt^2 trace(R^-1)','status':prob.status,'objective':prob.value,'elapsed':time.time()-start,'warnings':[str(x.message) for x in warn],'error':error}
s={}
if R.value is not None:
 cov=r.herm(R.value);wks=np.array([r.herm(w.value) for w in W]+[r.herm(rem.value)])
 report['min_covariance_eigenvalue_mw']=float(min(np.linalg.eigvalsh(w).min() for w in wks))
 report['covariance_power_fraction']=float(np.trace(cov).real/c.power_mw)
 report['physical_sinr_constraint_min_slack']=float(min(x.violation()*-1 if x.violation() else 0 for x in sinr))
 try:
  wc,wa,recovery=r.recover_extended(cov,wks[:k],H)
  report['recovery']=recovery;report['communication']=r.beam_metrics(wc,wa,H,gamma,c);report['radar']=r.extended_metrics(wc@wc.conj().T+wa@wa.conj().T,c)
  # CVXPY native complex PSD dual is half the complex trace-pairing multiplier.
  Zp=2*np.asarray(lmi.dual_value);ki=np.diag(np.r_[np.full(n,np.sqrt(c.power_mw/n)),np.full(n,np.sqrt(n/c.power_mw))]);Z=ki@Zp@ki
  la=np.array([float(x.dual_value) for x in sinr])*c.power_mw*gamma*np.sum(abs(H)**2,axis=1);mu=float(power.dual_value)*c.power_mw
  s={'report':{'kind':'extended','communication':report['communication'],'radar':report['radar']},'H':H,'gamma':gamma,'R':cov,'Wks':wks,'Wc':wc,'Wa':wa,'R_recovered':wc@wc.conj().T+wa@wa.conj().T,'dual_lmi':Z,'dual_sinr':la,'dual_power':np.array(mu)}
  s=r.finalize_solution(s,c);report['finalization']=s['report']
 except Exception as e:report['recovery_or_certificate_error']=repr(e)
 np.savez_compressed(ROOT/'independent-review'/(source+'-native.npz'),H=H,gamma=gamma,R=cov,Wks=wks,**{key:val for key,val in s.items() if key not in ['H','gamma','R','Wks'] and isinstance(val,np.ndarray)})
(ROOT/'independent-review'/(source+'-native.json')).write_text(json.dumps(report,indent=2,default=lambda x:x.item() if isinstance(x,np.generic) else str(x))+'\n')
print(json.dumps(report,indent=2,default=lambda x:x.item() if isinstance(x,np.generic) else str(x)),flush=True)
