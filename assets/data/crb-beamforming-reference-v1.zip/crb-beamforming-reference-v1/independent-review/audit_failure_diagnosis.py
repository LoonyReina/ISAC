import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
import numpy as np,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];rows=[]
for f in sorted((ROOT/'failure-diagnosis').glob('*.npz')):
 z=np.load(f);j=json.loads(f.with_suffix('.json').read_text());H=z['H'];g=z['gamma'];m=z['dual_mu'];n=H.shape[1];k=len(H)
 # Derive coefficients directly from each transmitted stream's received powers.
 S=[]
 for beam in range(k):
  M=np.eye(n,dtype=complex)
  for user in range(k):
   h=H[user].conj();coef=-m[user] if user==beam else m[user]*g[user]
   M+=coef*h[:,None]*h.conj()[None,:]
  S.append((M+M.conj().T)/2)
 S=np.array(S);lower=float(g@m) # source sigma_C^2=1 mW
 W=z['minimum_power_Wc'];p=abs(H@W)**2;desired=np.diag(p);sinr=desired/(p.sum(1)-desired+1);power=float(np.sum(abs(W)**2))
 row={'id':f.stem,'minimum_dual_multiplier':float(m.min()),'independent_stationarity_min_eigenvalue':float(min(np.linalg.eigvalsh(M).min() for M in S)),'stored_stationarity_max_abs_error':float(np.max(abs(S-z['dual_stationarity']))),'independent_dual_lower_mw':lower,'stored_dual_lower_abs_error':float(abs(lower-j['dual_min_power_lower_mw'])),'independent_primal_power_mw':power,'min_primal_sinr_ratio':float(np.min(sinr/g)),'relative_primal_dual_gap':float((power-lower)/power),'classification':j['classification']}
 # Construct an explicitly feasible full-rank extended covariance when there is ample headroom.
 if power<990:
  factor=1.05;W1=np.sqrt(factor)*W
  ratios=abs(H@W1)**2;des=np.diag(ratios);inter=ratios.sum(1)-des
  # Small positive isotropic probing noise under all user's strict SINR margins.
  eps=float(min(.25*(1000-factor*power)/n,np.min(.25*(des/g-inter-1)/np.sum(abs(H)**2,axis=1))))
  B=np.column_stack([W1,np.sqrt(eps)*np.eye(n)]);pr=abs(H@B)**2;d=np.diag(pr[:,:k]);sr=d/(pr.sum(1)-d+1)/g
  row['full_rank_feasible_witness']={'isotropic_aux_eigenvalue_mw':eps,'power_mw':float(np.sum(abs(B)**2)),'min_sinr_ratio':float(sr.min()),'covariance_min_eigenvalue_mw':float(np.linalg.eigvalsh(B@B.conj().T).min())}
  np.savez_compressed(ROOT/'independent-review'/(f.stem+'-feasible-witness.npz'),H=H,gamma=g,Wc=W1,Wa=np.sqrt(eps)*np.eye(n))
 row['PASS']=bool(row['minimum_dual_multiplier']>=0 and row['independent_stationarity_min_eigenvalue']>=-1e-7 and row['stored_dual_lower_abs_error']<1e-8 and row['stored_stationarity_max_abs_error']<1e-7 and (lower>1000 if 'infeasible_by' in row['classification'] else row['full_rank_feasible_witness']['min_sinr_ratio']>1 and row['full_rank_feasible_witness']['power_mw']<1000 and row['full_rank_feasible_witness']['isotropic_aux_eigenvalue_mw']>0))
 rows.append(row)
(ROOT/'independent-review/failure-diagnosis-audit.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows,indent=2));print('TOTAL',len(rows),'PASS',sum(x['PASS'] for x in rows))
