# CRB beamforming: independent offline reference

Actual multiuser point-target Eq.(33) SDP and extended-target Eq.(46) SDP plus Eq.(48)–(49) beam recovery for Liu et al., IEEE TSP 70 (2022), 240–253. See [SOURCE-MODEL-AUDIT.md](SOURCE-MODEL-AUDIT.md) before interpreting results. No author code/PDF redistribution and no full-paper reproduction claim.

## Reproduce

Python 3.12; install the pinned reputable scientific packages in `requirements.txt` in your own virtual environment. The original run reused an already installed environment without modifying it.

```sh
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
python experiment.py
python validate_reference.py
python observation_experiments.py
python diagnose_failures.py
python build_report.py
python validate_artifact.py
```

The source-sized SDP sweep takes minutes. The noise experiment computes an actual full-field profile-likelihood grid search. Seeds, full matrices, solver failures/warnings, raw and corrected beams, raw and repaired duals, observation errors, timing and tolerances are stored. Different solver/library/platform versions may change last digits and marginal accept/reject outcomes; the exact committed evidence has a hash manifest.

`reference.py` is callable from fresh input arrays, not a stored-curve evaluator. H rows are h_k^H. Physical powers are mW. Every source trial shares the documented fixed physical settings; no axis-fitting normalization is applied.

## Main files

- `SOURCE-MANIFEST.json`, `SOURCE-MODEL-AUDIT.md`: fixed paper hash, equation locators, derivation, assumptions, comparison limits
- `reference.py`: solvers, exact single-user references, recovery and numerical dual-gap checks
- `experiment.py`: predetermined 3 point and 16 extended source-parameter trials
- `results/*.npz`, `results/*.json`: full inputs/matrices and per-trial outcomes, including rejected solutions
- `validate_reference.py`, `VALIDATION.json`: independent raw-observation finite differences, full real/complex FIMs, cross-solver tests, analytic checks, singular/degenerate/infeasible cases
- `historical/`: initial failed validation and numerical probes retained with explanations, not erased
- `observation_experiments.py`, `observations/`: actual noisy point-angle ML and extended-response ML experiments
- `independent-review/`: separately implemented numerical review
- `NUMERICAL-REPORT.md`, `REPORT.json`: bounded conclusions and failure counts
- `ARTIFACT-MANIFEST.json`: exact per-file byte counts and hashes

## Important limits

K=1 Eq.(33) is not generally a tight replacement for the single-stream problem; use the separately implemented Eq.(25)/Theorem1 branch. High-SINR numerical failures remain visible. The paper's eigen-baseline comparison conditions on feasibility; this package reports that condition and all failures. The own minimum-power-direction diagnostic is not either paper beampattern baseline. No live browser solver, browser latency, UI acceptance, or entire-paper reproduction is established.
