# Numerical report: CRB beamforming reference

## Verdict

Actual point/extended multiuser SDRs execute from fresh complex channels. 13/19 prescribed source-sized trials pass tolerance-qualified recovered-beam and dual-gap checks: 3/3 point and 10/16 extended. This is a bounded reference milestone, not full-paper reproduction or a live browser implementation.

Independent validation: 71 checks, all passed. Separate reviewer evidence is in `independent-review/`.

## Fidelity and numerical precision

Largest accepted repaired relative dual gap: 9.48523296e-06. Minimum accepted SINR/threshold: 0.999994459849; maximum power/P: 1.00000000354. Feasibility tolerance is 2e-5 relative. These are floating-point numerical certificates and tolerance-qualified optima; the most negative accepted SINR margin is about 5.54 ppm, so do not describe them as exact inequality proofs.

All successful source solver calls retain their `optimal_inaccurate` warnings. Acceptance follows independent reconstructed beams/cones/gaps, not the status label. Three primary calls returned a solver error and three returned materially indefinite recovery remainders. No failure was silently removed.

## Source parameter slice

Nt16, Nr20, centered half-wavelength unnormalized ULAs, theta0; P=1000 mW (30dBm), sigmaC²=sigmaR²=1 mW (0dBm), L30. Point: K4/Gamma15dB, three declared channel seeds. Extended: K6/12, Gamma10/20/25/30dB, two seeds each. The paper supplies no channel seeds/Monte Carlo count, so these are new source-parameter trials, not exact published curve matches.

K | SINR dB | accepted / attempted | accepted mean full-G MSE | feasible eigen baseline / attempted | feasible-only baseline MSE
--- | ---: | ---: | ---: | ---: | ---:
6 | 10 | 2 / 2 | 0.17066674 | 2 / 2 | 0.83387717
6 | 20 | 2 / 2 | 0.18421423 | 2 / 2 | 0.86595758
6 | 25 | 2 / 2 | 0.19162968 | 0 / 2 | unavailable
6 | 30 | 0 / 2 | unavailable | 0 / 2 | unavailable
12 | 10 | 2 / 2 | 0.19436621 | 2 / 2 | 0.74710172
12 | 20 | 2 / 2 | 0.32684212 | 0 / 2 | unavailable
12 | 25 | 0 / 2 | unavailable | 0 / 2 | unavailable
12 | 30 | 0 / 2 | unavailable | 0 / 2 | unavailable

Eigen baseline: 10 factorizations available; 6 meet tolerance-qualified feasibility, 4 do not; 6 are unavailable due to the primary solve/recovery failure. Conditional means above must be read with their denominators. Eigen decomposition is solver/decomposition-dependent; the retained auxiliary covariance and no-rescaling convention are explicit. Original source [11]/[12] point-target beampattern baselines are not present.

## Failed-trial diagnosis

A separate SINR-only minimum-power SOCP and independently feasible dual distinguish source-budget infeasibility from numerical failure. All original results remain unchanged.

Trial | minimum power lower / upper, mW | outcome
--- | ---: | ---
extended-k6-g30-s20261012 | 572.689940 / 572.689944 | communication_power_feasible_numerical_SDR_failure
extended-k6-g30-s20261013 | 603.479721 / 603.479871 | communication_power_feasible_numerical_SDR_failure
extended-k12-g25-s20261012 | 738.152461 / 738.152650 | communication_power_feasible_numerical_SDR_failure
extended-k12-g30-s20261012 | 2340.206248 / 2340.207518 | source_power_budget_infeasible_by_numerical_dual
extended-k12-g25-s20261013 | 1012.102776 / 1012.102903 | source_power_budget_infeasible_by_numerical_dual
extended-k12-g30-s20261013 | 3212.158078 / 3212.174232 | source_power_budget_infeasible_by_numerical_dual

Three trials exceed the 1000mW budget even before dedicated probing. The other three have sufficient communication power but the full extended SDP/recovery needs stronger numerical refinement. The independent reviewer obtained one feasible K6/Gamma30 native-cone design; its 0.297% certified gap is wider than the 0.01% acceptance threshold, so it remains a nonaccepted refinement.

## Actual point-angle ML, not substituted CRB

One source K4/Gamma15 channel, unknown alpha profiled out, exhaustive full-field .005-degree grid, 256 noise trials/condition; exact DFT symbol rows. Radar SNR is the paper’s |alpha|² L P/sigmaR², without inserted array gain. No failed noise trials are removed.

Design | radar SNR dB | RMSE deg | root-CRB deg | >5 degree outliers
--- | ---: | ---: | ---: | ---:
crb_sdr | -20 | 30.584058 | 1.2892828 | 150 / 256
crb_sdr | -10 | 0.42292554 | 0.40770703 | 0 / 256
crb_sdr | 0 | 0.12941462 | 0.12892828 | 0 / 256
crb_sdr | 10 | 0.040724637 | 0.040770703 | 0 / 256
own_minpower_diagnostic | -20 | 41.756088 | 4.1896417 | 234 / 256
own_minpower_diagnostic | -10 | 37.764875 | 1.324881 | 196 / 256
own_minpower_diagnostic | 0 | 5.0112905 | 0.41896417 | 2 / 256
own_minpower_diagnostic | 10 | 0.13969065 | 0.1324881 | 0 / 256

The communication-oriented comparator is our own same-power diagnostic, not the paper’s two beampattern baselines. One channel and 256 paired noise draws do not establish a general ranking. At high SNR finite-trial/grid RMSE can lie slightly below the local unbiased-estimator CRB; bootstrap intervals and every trial error are exported. At low SNR threshold/outlier behavior dominates.

## Actual extended-response ML

1024 independent source-distribution response/noise trials: mean Frobenius MSE 0.1850480698; Eq.(17) CRB 0.1850982179; ratio 0.9997290732. Bootstrap95% mean-MSE interval [0.18440836127908114, 0.18569290045758072]; no per-entry normalization and no failures discarded.

## Important retained boundary

The K1 Eq.(33) stress example is rank2 and is not tight for the single-stream problem. Theorem2 cannot apply at K1; the generic single-user theorem is separately validated against Eq.(25). Initial failed test expectations and solver errors remain in `historical/`, with the corrected validation protocol documented in the audit.

## Performance and open gates

Source primary solver wall time total 252.843s, median 14.286s, max 23.300s on the recorded cloud environment. This is offline Python/CVXPY timing, not browser input-to-result latency.

Remaining: full paper experiments/source baselines, authors’ unspecified Monte Carlo details, stricter high-SINR numerical refinement, browser solver port, input cancellation/stale-state tests, hosted-browser verification and measured latency. No production/GitHub writes or browser work were performed.
