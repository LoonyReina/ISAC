# Source/model/algorithm audit

## Fixed primary edition

Fan Liu, Ya-Feng Liu, Ang Li, Christos Masouros, Yonina C. Eldar, *Cramér-Rao Bound Optimization for Joint Radar-Communication Beamforming*, IEEE Transactions on Signal Processing 70, 240–253 (2022), DOI [10.1109/TSP.2021.3135692](https://doi.org/10.1109/TSP.2021.3135692). [Institution-hosted published PDF](https://www.weizmann.ac.il/math/yonina/sites/math.yonina/files/Cramr-Rao_Bound_Optimization_for_Joint_Radar-Communication_Beamforming.pdf).

The 14-page published PDF was inspected as actual bytes and text. SHA-256: `3bb9519855b92a8cca870caf603efe0d05dc1d9369cadad0fb7de20750a61e6d`. This matches the already audited fixed source. The institutional URL was reopened with the web tool on 2026-10-12; a direct curl refetch returned HTTP 502, so the byte audit used the existing downloaded copy. No claim of a newly downloaded byte-identical copy. No PDF or extracted full text is redistributed in this package.

Journal publication metadata: published online 2021-12-15, current version 2022-01-11. Equation locators below refer to this journal edition, not arXiv versions. The introduction's section-outline prose differs from the final headings; use the actual headings/locators.

## Observations, unknowns, known design inputs

- §II-A, p242, Eqs. (1)–(6): known narrowband transmit block X; communication Yc=HX+Zc and radar Yr=GX+Zr. H has rows h_k^H and is known at transmitter. Independent circular complex noise, each complex sample variance sigma², real/imag variance sigma²/2
- Point target G=alpha b(theta)a(theta)^H. Angle theta and both real components of complex alpha are unknown to the radar estimator. Theta used at design is a fixed direction of interest. This is a local tracking-direction design, not a prior-free search beam
- Extended target: unknown unconstrained complex Nr-by-Nt response G. This is estimation of a response matrix, not identification of individual scatterers. No claim of resolvability of the latent paths
- Source arrays are centered unnormalized half-wavelength ULAs, Eq. (20)–(22), pp243–244. a_m=exp(j*pi*(m-(Nt-1)/2)*sin(theta)); derivatives use radians; steering norms are sqrt(Nt), sqrt(Nr). Nt<Nr and K<=Nt. No normalization to unit steering norm in physical outputs
- Source temporal covariance assumption Eq. (3)/(8), p242, is asymptotic and then treated as equality. Our observation experiments use explicit DFT rows satisfying it exactly at finite L. This is a declared controlled exact-orthogonality experiment, not simulation of iid finite-length communication symbols
- Dedicated extended-target probing causes interference at users: Eq. (18), p243. No known-probe cancellation is assumed

## Point-target CRB and actual SDR

Eq. (7), p242: define s0=tr(A^H A R), s1=tr(Adot^H A R), s2=tr(Adot^H Adot R), R=XX^H/L. Effective angular information before its constant multiplier is s2-|s1|²/s0. The angular CRB is sigmaR²/[2|alpha|² L (s2-|s1|²/s0)]. This eliminates unknown complex reflectivity; using s2 alone is incorrect. Zero illumination, zero alpha, or zero effective information is not assigned a finite conventional CRB.

Eq. (19), p243, constrains each communication SINR and the total power. Eqs. (30)–(33), p244, lift W_k=w_k w_k^H, discard rank-one constraints and impose the 2-by-2 Schur LMI with bottom-right s0, top-left s2-t, off-diagonal s1 and its conjugate. SINR is tr(Q_k W_k)/[sum_{i!=k}tr(Q_k W_i)+sigmaC²]. We optimize the real epigraph information t, then actually extract beams and recompute SINR/CRB.

Theorem 2, p244, is conditional on rank(H[a,adot])=2. The code records its singular values and does not assume this for arbitrary channels. It also records numerical rank residuals. In regular random K>=2 source cases, the eigensolutions are numerically rank one; recovering an eigenvector alone is never an acceptance criterion.

**Important K=1 boundary found by this work:** H[a,adot] cannot have rank 2 for one user. A retained Nt6/Nr8 stress example (seed21, 75% of communication-only maximum SNR) gives a rank-two Eq. (33) covariance, with eigenvalues about 8.118 and 1.882 mW. Its principal eigenvector is a bad answer to the original single-stream problem. This does not contradict Theorem 2's stated condition. The generic single-user exact theorem is instead checked against its own lifted Eq. (25) linear-objective SDP and Eqs. (27)–(29). No broad equivalence between K=1 Eq. (33) and the original single-stream problem is asserted. The paper's Fig.2 prose mentions numerical Eq. (33); our counterexample is not evidence that the particular unpublished Fig.2 channel fails.

## Extended-target SDR and constructive recovery

Eqs. (10)–(17), p243: vectorized linear Gaussian observation has complex FIM (L/sigmaR²)(R^T kron I_Nr). The Frobenius MSE bound is (sigmaR² Nr/L) tr(R^-1), with no per-entry division. If K<Nt and only K data streams are sent, R is rank deficient; the full response G is not identifiable under this unconstrained model.

We implement Eq. (46), p246, equivalently Eq. (36), p245, with K PSD data covariances and one unrestricted-rank PSD auxiliary covariance. The objective is tr(R^-1), with total power and Eq. (18) SINR. The auxiliary covariance is an actual optimization variable and its interference is counted. Eqs. (47)–(49)/Theorem4, p246: w_k=W_k h_k/sqrt(h_k^H W_k h_k); factor R-sum_k w_k w_k^H as the auxiliary beam matrix. Desired received power, total covariance, per-user interference, objective and total power are preserved in exact arithmetic. Tiny negative eigenvalues are checked and reported before bounded numerical clipping; materially indefinite remainders reject recovery.

Theorem3/Eqs. (43)–(45), p245, provide a separate single-user closed form. At the upper communication-only feasibility endpoint, all non-channel eigenvalues are zero, so the extended-target inverse objective is infinite. The finite-bound API reports that endpoint as unavailable rather than applying an inverse to a singular covariance.

## Reversible conditioning, recovery correction, acceptance

All physical power/noise values are stored in mW. The source 30dBm/0dBm settings are 1000mW/1mW. Internally V_k=W_k/P so trace(sum V)<=1. Point LMI congruence scales its diagonal by the Frobenius norms of A and Adot; the reported objective converts back exactly. Extended inverse epigraph uses [Nt sum V,I; I,T] PSD and minimizes tr(T)/Nt; this equals P tr(R^-1)/Nt². These are invertible numerical scalings, not changed channel/noise/steering normalization. Unit-change tests independently confirm mW/W invariance.

Complex cones are explicitly real embedded [Re M,-Im M; Im M,Re M]. Dual matrices are decoded using the two diagonal and two off-diagonal blocks. No undocumented assumption about the solver's complex-cone dual convention is used. Raw cones, raw duals, raw objectives and warnings are exported.

A failed feasible-beam check can trigger a separate small fixed-direction scalar-power QP. It enforces the original power and SINR limits, does not claim to preserve R exactly, and retains raw beams and its power changes. The corrected radar objective must be close to the original SDR bound. This is an explicitly recorded a-posteriori numerical correction, not an unreported source algorithm.

The certificate PSD-projects the dual, fixes its coefficient equality (scalar normalization for point; congruence for extended), and shifts the total-power multiplier enough to make matrix stationarity inequalities PSD. Weak duality gives an upper information bound for point or lower inverse-trace bound for extended. Acceptance requires feasible recovered beams at relative 2e-5 and a repaired dual relative gap no larger than 1e-4, with separately checked cone/equality residuals. These are floating-point numerical certificates, not interval-arithmetic proofs. Raw `optimal_inaccurate` is retained; a solver status alone is not acceptance.

## Experiments and comparison contract

- Source settings in §V p246: Nt16, Nr20, P30dBm, both noises0dBm, L30, H iid CN(0,1). Point design theta0. Extended G iid CN(0,1). A physical RF bandwidth, carrier, sample period, path-loss convention beyond alpha, random seed, solver tolerance and total Monte Carlo count are not supplied
- Fig.3 / §V-B pp246–247: K4/Gamma15dB, three new declared seeds. We produce actual designs at the source dimensions. Full prior-design comparison is still open
- Fig.6 / §V-C pp247–248: K6/12 and SINR tradeoff. We run four SINR values with two channel seeds per K, 16 prescribed trials. All failures remain in the denominator. This is a bounded source-parameter slice, not a reproduction of the paper's unpublished Monte Carlo population or exact curves
- Source Fig.6 baseline: rank-one eigenvalue approximation of data Wks. The paper does not fully specify a unique decomposition/solver or how auxiliary covariance is handled. Our convention keeps its original auxiliary covariance, takes the principal eigenpair of each communication Wk, and does not rescale power. This is declared. Feasibility is separately recorded; we report the source-style feasible-only statistic together with all attempted/failed counts. The baseline is decomposition/solver dependent. Same budget does not mean equal actually used power
- Paper [11]/[12] beampattern approximation designs plus radar-only reference [37] with 10-degree width are **not** reimplemented here. Reusing a previously implemented design with a different per-antenna budget would not be a fair substitute. The additional minimum-communication-power-direction design is our own diagnostic and is explicitly not either author baseline; it is scaled to the same total power, same H, L, noise, aperture and receiver
- Source Fig.4 radar SNR convention is |alpha|² L P/sigmaR², without extra array gain. Our actual point ML trial uses that exact convention, full [-90,90] search, .005-degree grid, 256 noise trials and one fixed channel. It profiles unknown alpha. Full trial errors and >5-degree outlier counts are retained. CRB is distinct from actual RMSE; low-SNR failures are not removed
- The extended ML experiment uses 1024 iid response/noise draws and a linear least-squares receiver Ghat=Y X^H(XX^H)^-1, comparing mean full Frobenius error with Eq. (17)

## Gates still open

Full original Monte Carlo count/seed and exact figure replication; the two prior-paper beampattern baselines; an exact source-baseline auxiliary-covariance convention; robust resolution of every high-SINR source trial; full paper coverage and theoretical proof review; browser implementation, live control-to-result latency and UI/hosted-browser QA. No production site or browser was changed by this reference task.
