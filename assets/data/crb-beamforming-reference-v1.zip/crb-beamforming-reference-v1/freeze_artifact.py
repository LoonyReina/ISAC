"""Freeze exact files and build deterministic standalone zip; excludes caches/PDFs."""
from pathlib import Path
import hashlib,json,zipfile
ROOT=Path(__file__).resolve().parent
files=[]
for p in sorted(ROOT.rglob('*')):
 if not p.is_file() or '__pycache__' in p.parts or p.suffix in ('.pyc','.pdf') or p.name in ('ARTIFACT-MANIFEST.json',):continue
 if p.suffix=='.zip':continue
 b=p.read_bytes();files.append({'path':p.relative_to(ROOT).as_posix(),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
manifest={'schema_version':1,'frozen_date_utc':'2026-10-12','artifact':'crb-beamforming-reference-v1','scope':'independent offline bounded numerical reference; no primary PDF redistribution','primary_source_sha256':'3bb9519855b92a8cca870caf603efe0d05dc1d9369cadad0fb7de20750a61e6d','hash_algorithm':'sha256','manifest_excludes_itself':True,'files':files}
mp=ROOT/'ARTIFACT-MANIFEST.json';mp.write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n')
archive=ROOT.parent/'crb-beamforming-reference-v1.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for relative in [f['path'] for f in files]+['ARTIFACT-MANIFEST.json']:
  info=zipfile.ZipInfo('crb-beamforming-reference-v1/'+relative,date_time=(2026,10,12,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,(ROOT/relative).read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
receipt={'artifact_path':str(archive),'artifact_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'artifact_bytes':archive.stat().st_size,'manifest_path':str(mp),'manifest_sha256':hashlib.sha256(mp.read_bytes()).hexdigest(),'manifest_file_count':len(files),'reference_sha256':hashlib.sha256((ROOT/'reference.py').read_bytes()).hexdigest(),'report_sha256':hashlib.sha256((ROOT/'NUMERICAL-REPORT.md').read_bytes()).hexdigest()}
(ROOT.parent/'CRB-REFERENCE-ARTIFACT.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
