"""Actual raw-echo ML experiments, separate from optimizer outputs.
No true theta or alpha passed to point receiver: exhaustive profile likelihood.
"""
from reference import *
from experiment import ROOT,clean
from dataclasses import replace
import json,time
out=ROOT/'observations';out.mkdir(exist_ok=True)

def bootstrap_mean_ci(values,seed,root=False):
 rng=np.random.default_rng(seed);values=np.asarray(values)
 means=np.mean(values[rng.integers(0,len(values),size=(1000,len(values)))],axis=1)
 if root:means=np.sqrt(means)
 return np.quantile(means,[.025,.975]).tolist()

def point_run():
 source='point-k4-g15-s20261012';d=np.load(ROOT/'results'/(source+'.npz'));c=Config();H=d['H']
 Wlist=[('crb_sdr',d['Wc']),('own_minpower_diagnostic',d['diagnostic_Wc'])]
 # 0.005-degree exhaustive full field of view. Requested truth is absent from receiver.
 grid=np.linspace(-90,90,36001);th=np.deg2rad(grid)
 aa=np.exp(1j*np.pi*(np.arange(c.nt)-(c.nt-1)/2)[None,:]*np.sin(th)[:,None])
 bb=np.exp(1j*np.pi*(np.arange(c.nr)-(c.nr-1)/2)[None,:]*np.sin(th)[:,None])
 trials=256;seed=948211;rng=np.random.default_rng(seed)
 noises=(rng.normal(size=(trials,c.nr,c.snapshots))+1j*rng.normal(size=(trials,c.nr,c.snapshots)))*np.sqrt(c.radar_noise_mw/2)
 data={'grid_degrees':grid,'first_noise':noises[0]};summary=[]
 for method,W in Wlist:
  S=exact_streams(W.shape[1],c.snapshots);X=W@S
  # Matched filter is sufficient after projection onto the transmitted row space.
  templates=(bb[:,:,None]*(aa.conj()@W)[:,None,:]).reshape(len(grid),-1)
  denom=np.sum(abs(templates)**2,axis=1)
  usable=denom>1e-12*denom.max()
  data[method+'_X']=X;data[method+'_W']=W
  for snr_db in [-20,-10,0,10]:
   alpha=np.sqrt(10**(snr_db/10)*c.radar_noise_mw/(c.snapshots*c.power_mw));cc=replace(c,alpha=complex(alpha))
   A,_=matrices(cc);Y=alpha*(A@X)[None,:,:]+noises
   Z=np.einsum('trl,kl->trk',Y,S.conj())/c.snapshots
   start=time.perf_counter();est=[]
   for begin in range(0,trials,32):
    scores=abs(templates.conj()@Z[begin:begin+32].reshape(-1,templates.shape[1]).T)**2/np.maximum(denom[:,None],1e-300)
    scores[~usable]=0;est.extend(grid[np.argmax(scores,axis=0)])
   elapsed=time.perf_counter()-start;err=np.asarray(est)-c.theta_degrees;squared=err**2
   radar=point_metrics(W@W.conj().T,cc);rid=f'{method}_snr{snr_db}'
   data[rid+'_estimates']=np.asarray(est);data[rid+'_errors']=err;data[rid+'_first_Y']=Y[0]
   summary.append({'method':method,'snr_db':snr_db,'alpha_true_for_generator':alpha,'trial_count':trials,'rmse_degrees':float(np.sqrt(np.mean(squared))),'rmse_bootstrap_95_ci_degrees':bootstrap_mean_ci(squared,20201012,True),'root_crb_degrees':radar['root_crb_degrees'],'outlier_abs_error_over_5_degrees_count':int(np.sum(abs(err)>5)),'max_absolute_error_degrees':float(abs(err).max()),'estimator_wall_seconds':elapsed,'failures_dropped':0})
   print(rid,summary[-1]['rmse_degrees'],summary[-1]['root_crb_degrees'],flush=True)
 np.savez_compressed(out/'point-ml.npz',**data)
 report={'source':'Section V-B / Fig4 parameter slice; independent channels, declared exhaustive grid/trial count','design_result':source,'Nt':16,'Nr':20,'L':30,'K':4,'gamma_db':15,'power_mw':1000,'noise_mw':1,'noise_seed':seed,'common_noise_across_methods_and_snr':True,'streams':'exact DFT rows, SS^H/L=I, controlled exact form of Eqs3,8','receiver':'maximize |<A(theta)X,Y>|^2 / ||A(theta)X||_F^2 over full [-90,90] grid, unknown complex alpha profiled out','grid_step_degrees':.005,'trial_count_per_condition':trials,'seed_variability_scope':'one channel, two designs, common 256 independent noise draws; not author MC reproduction','baseline':'own communication minimum-power directions scaled to full power; NOT paper [11]/[12]','results':summary}
 (out/'point-ml.json').write_text(json.dumps(clean(report),indent=2,allow_nan=False)+'\n')

def extended_run():
 source='extended-k6-g20-s20261012';d=np.load(ROOT/'results'/(source+'.npz'));c=Config();W=np.column_stack((d['Wc'],d['Wa']));X=W@exact_streams(W.shape[1],c.snapshots)
 trials=1024;seed=883221;r=np.random.default_rng(seed)
 G=(r.normal(size=(trials,c.nr,c.nt))+1j*r.normal(size=(trials,c.nr,c.nt)))/np.sqrt(2)
 Z=(r.normal(size=(trials,c.nr,c.snapshots))+1j*r.normal(size=(trials,c.nr,c.snapshots)))*np.sqrt(c.radar_noise_mw/2)
 Y=G@X+Z;estimate=Y@X.conj().T@np.linalg.inv(X@X.conj().T)
 err=estimate-G;mse=np.sum(abs(err)**2,axis=(1,2));bound=extended_metrics(X@X.conj().T/c.snapshots,c)['crb_G_frobenius_mse']
 report={'source':'Eqs10,11,17 actual unconstrained linear ML estimate of G','design_result':source,'trials':trials,'seed':seed,'G':'iid CN(0,1), source SectionV convention','noise':'iid CN(0,1) mW','streams':'K+Nt=22 exact DFT rows in L30 block','mse_definition':'mean ||Ghat-G||_F^2, NOT per-entry normalization','mean_mse':float(np.mean(mse)),'crb_G_frobenius_mse':bound,'mean_mse_to_crb_ratio':float(np.mean(mse)/bound),'mean_mse_bootstrap_95_ci':bootstrap_mean_ci(mse,78413),'standard_error':float(np.std(mse,ddof=1)/np.sqrt(trials)),'failures_dropped':0}
 np.savez_compressed(out/'extended-ml.npz',X=X,first_G=G[0],first_Y=Y[0],first_estimate=estimate[0],trial_mse=mse)
 (out/'extended-ml.json').write_text(json.dumps(clean(report),indent=2,allow_nan=False)+'\n');print('extended MSE ratio',report['mean_mse_to_crb_ratio'],flush=True)
if __name__=='__main__':point_run();extended_run()
