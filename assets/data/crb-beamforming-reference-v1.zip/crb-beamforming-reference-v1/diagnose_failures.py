"""No source failures erased: independently bound SINR-only minimum power.
A dual lower bound above the source budget certifies communication infeasibility
numerically; otherwise a failed source optimizer remains a numerical failure.
"""
from reference import *
from experiment import clean,ROOT
import json
out=ROOT/'failure-diagnosis';out.mkdir(exist_ok=True)
rows=json.loads((ROOT/'results'/'SUMMARY.json').read_text());summaries=[]
for item in rows:
 if item['report'].get('accepted'):continue
 name=item['id'];data=np.load(ROOT/'results'/item['data_file']);H=data['H'];gam=data['gamma'];c=Config();k,n=H.shape
 primal=minpower_diagnostic(H,gam,c)
 Q=[np.outer(h.conj(),h) for h in H];mu=cp.Variable(k,nonneg=True);sumterm=sum(gam[i]*mu[i]*Q[i] for i in range(k))
 dual=cp.Problem(cp.Maximize(c.communication_noise_mw*(gam@mu)),[real_embed(np.eye(n)+sumterm-(1+gam[j])*mu[j]*Q[j])>>0 for j in range(k)])
 # _solve intentionally imported explicitly: star excludes private helpers.
 import reference
 rep=reference._solve(dual,'CLARABEL',1e-9)
 result={'id':name,'original_status':item['report']['status'],'original_accepted':False,'primal_minpower':primal['report'],'dual_solver':rep}
 arrays={'H':H,'gamma':gam}
 if mu.value is not None:
  m=np.maximum(mu.value,0);G=[herm(sum(gam[i]*m[i]*Q[i] for i in range(k))-(1+gam[j])*m[j]*Q[j]) for j in range(k)]
  gmin=min(np.linalg.eigvalsh(g).min() for g in G);scale=min(1.,-1/gmin if gmin<0 else 1.)*(1-1e-10);m*=scale
  matrices=[herm(np.eye(n)+sum(gam[i]*m[i]*Q[i] for i in range(k))-(1+gam[j])*m[j]*Q[j]) for j in range(k)]
  lower=float(c.communication_noise_mw*(gam@m));upper=primal['report'].get('minimum_power_mw')
  result.update(dual_min_power_lower_mw=lower,primal_min_power_upper_mw=upper,dual_stationarity_min_eigenvalue=float(min(np.linalg.eigvalsh(z).min() for z in matrices)),classification=('source_power_budget_infeasible_by_numerical_dual' if lower>c.power_mw*(1+1e-6) else 'communication_power_feasible_numerical_SDR_failure' if upper is not None and upper<c.power_mw*(1-1e-6) else 'inconclusive'))
  arrays.update(dual_mu=m,dual_stationarity=np.array(matrices))
  if 'Wc' in primal:arrays['minimum_power_Wc']=primal['Wc']*np.sqrt(upper/c.power_mw)
 np.savez_compressed(out/(name+'.npz'),**arrays);(out/(name+'.json')).write_text(json.dumps(clean(result),indent=2,allow_nan=False)+'\n');summaries.append(result)
 print(name,result.get('classification'),result.get('dual_min_power_lower_mw'),result.get('primal_min_power_upper_mw'),flush=True)
(out/'SUMMARY.json').write_text(json.dumps(clean(summaries),indent=2,allow_nan=False)+'\n')
