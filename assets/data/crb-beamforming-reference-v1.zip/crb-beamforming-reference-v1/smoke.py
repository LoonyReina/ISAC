from reference import *
import json
for kind in ['point','extended']:
 c=Config(nt=6,nr=8,snapshots=20,power_mw=10.)
 s=solve_sdr(rayleigh(29,3,6),np.full(3,3.),c,kind)
 print(kind,json.dumps(s['report'],indent=2))
