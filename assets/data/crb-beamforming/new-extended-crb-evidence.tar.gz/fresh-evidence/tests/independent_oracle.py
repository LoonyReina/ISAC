"""Recreated 2026-10-18 from visible conversation. No JS arithmetic imported.
CVXPY is optional until solve/generate_oracles is called. No installation performed.
"""
import json,time
from pathlib import Path
import numpy as np
OUT=Path(__file__).parent

def packed(a):
 a=np.asarray(a);return {'real':a.real.tolist(),'imag':a.imag.tolist()}
def unpack(a):return np.asarray(a['real'])+1j*np.asarray(a['imag'])
def config(H,db):
 n=H.shape[1];return dict(Nt=n,Nr=n+4,K=2,L=30,powerMw=1000,communicationNoiseMw=1,radarNoiseMw=1,gammaDb=db,H=packed(H))
def input_cases():
 cases=[]
 for n in (4,6):
  for seed in (271,811):
   rng=np.random.default_rng(seed+n);H=(rng.normal(size=(2,n))+1j*rng.normal(size=(2,n)))/np.sqrt(2)
   for db in (0,10,20):cases.append(dict(id=f'fresh-n{n}-seed{seed}-g{db}',input=config(H,db)))
  rng=np.random.default_rng(159+n);H=(rng.normal(size=(2,n))+1j*rng.normal(size=(2,n)))/np.sqrt(2);H[1]=.85*H[0]+np.sqrt(1-.85**2)*H[1]
  for db in (0,10,20):cases.append(dict(id=f'correlated-n{n}-g{db}',input=config(H,db)))
 return cases

def recovery_cases():
 cases=[]
 for n in (4,6):
  for seed in (77,99):
   rng=np.random.default_rng(seed+n);H=rng.normal(size=(2,n))+1j*rng.normal(size=(2,n));qs=[]
   for _ in range(3):
    a=rng.normal(size=(n,n))+1j*rng.normal(size=(n,n));qs.append(a@a.conj().T)
   scale=1000/np.trace(sum(qs)).real;qs=[q*scale for q in qs]
   cases.append(dict(id=f'arbitrary-psd-n{n}-seed{seed}',input=config(H,10),Wks=[packed(q) for q in qs],R=packed(sum(qs))))
 return cases

def solve(H,db):
 import cvxpy as cp
 n=H.shape[1];g=10**(db/10);blocks=[cp.Variable((n,n),hermitian=True) for _ in range(3)];R=sum(blocks);T=cp.Variable((n,n),hermitian=True)
 embed=lambda a:cp.bmat([[cp.real(a),-cp.imag(a)],[cp.imag(a),cp.real(a)]])
 constraints=[embed(v)>>0 for v in blocks]+[cp.real(cp.trace(R))<=1,embed(cp.bmat([[R,np.eye(n)],[np.eye(n),T]]))>>0]
 for k in range(2):
  h=H[k].conj();q=np.outer(h,h.conj());constraints += [cp.real(cp.trace(q@blocks[k])) >= g*(cp.real(cp.trace(q@(R-blocks[k])))+0.001)]
 prob=cp.Problem(cp.Minimize(cp.real(cp.trace(T))/n**2),constraints);t=time.monotonic();prob.solve(solver='CLARABEL',tol_gap_abs=1e-10,tol_feas=1e-10,tol_gap_rel=1e-10,max_iter=500)
 out=dict(status=prob.status,normalizedObjective=prob.value,seconds=time.monotonic()-t)
 if R.value is not None:
  D=constraints[4].dual_value;m=2*n;Z=D[:m,:m]+D[m:,m:]+1j*(D[m:,:m]-D[:m,m:]);lam=np.array([constraints[5+k].dual_value for k in range(2)]);mu=float(constraints[3].dual_value)
  out.update(dualPower=mu,dualSINR=lam.tolist(),dualSchur=packed(Z),dualBottomResidual=float(np.linalg.norm(Z[n:,n:]-np.eye(n)/n**2)))
  r=R.value*1000;ev=np.linalg.eigvalsh(r);out.update(traceInverse=float(np.sum(1/ev)),R=packed(r),Wks=[packed(v.value*1000) for v in blocks],powerMw=float(np.trace(r).real),minEigenvalue=float(ev.min()))
 return out

if __name__=='__main__':
 import argparse
 ap=argparse.ArgumentParser();ap.add_argument('--inputs-only',action='store_true');args=ap.parse_args();cases=input_cases()
 (OUT/'fresh-inputs-regenerated.json').write_text(json.dumps(cases,indent=2));(OUT/'recovery-fixtures.json').write_text(json.dumps(recovery_cases(),indent=2))
 if not args.inputs_only:
  for c in cases:c['oracle']=solve(unpack(c['input']['H']),c['input']['gammaDb']);print(c['id'],c['oracle']['status'])
  (OUT/'oracle-fixtures.json').write_text(json.dumps(cases,indent=2))
