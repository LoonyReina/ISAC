"""Recreated independent certificate verifier; requires newly generated oracle JSON."""
from independent_oracle import *
results=[]
for case in json.loads((OUT/'oracle-fixtures.json').read_text()):
 o=case['oracle'];H=unpack(case['input']['H']);n=H.shape[1];g=10**(case['input']['gammaDb']/10);Q=[np.outer(h.conj(),h) for h in H];R=unpack(o['R']);Ws=[unpack(w) for w in o['Wks']]
 desired=np.array([(H[k]@Ws[k]@H[k].conj()).real for k in range(2)]);total=np.array([(h@R@h.conj()).real for h in H]);ratio=desired/(total-desired+1)/g
 Z=unpack(o['dualSchur']);ev,U=np.linalg.eigh(Z);Z=(U*np.maximum(0,ev))@U.conj().T;ev,U=np.linalg.eigh(Z[n:,n:]);C=(U/(n*np.sqrt(ev)))@U.conj().T;S=np.eye(2*n,dtype=complex);S[n:,n:]=C;Z=S@Z@S.conj().T
 lam=np.maximum(0,np.array(o['dualSINR']));mu=max(0,o['dualPower']);F=Z[:n,:n];common=mu*np.eye(n)-F+sum(g*lam[k]*Q[k] for k in range(2));mins=[np.linalg.eigvalsh(common-(g+1)*lam[k]*Q[k]).min() for k in range(2)]+[np.linalg.eigvalsh(common).min()];mu+=max(0,-min(mins))+1e-10
 lb=g*.001*lam.sum()-mu-2*np.trace(Z[:n,n:]).real;obj=1000/n**2*np.trace(np.linalg.inv(R)).real;gap=(obj-lb)/obj
 results.append(dict(id=case['id'],powerFraction=float(np.trace(R).real/1000),minSINRRatio=float(ratio.min()),normalizedObjective=float(obj),repairedDualLowerBound=float(lb),relativeGap=float(gap),oracleQualified=bool(ratio.min()>=1-2e-5 and np.trace(R).real<=1000*(1+2e-5) and -2e-5<=gap<=1e-4)))
(OUT/'oracle-certificate-checks.json').write_text(json.dumps(results,indent=2));print(json.dumps(results,indent=2));assert all(x['oracleQualified'] for x in results)
