"""NEW 2026-10-18 execution using unchanged recovered frozen scenarios and oracle formulation."""
import sys,json,time,traceback
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'tests'))
import independent_oracle as o
cases=json.loads((ROOT/'tests/fresh-inputs-regenerated.json').read_text())
assert cases==o.input_cases(), 'Frozen scenarios differ from recovered deterministic generator'
for c in cases:
 start=time.time()
 try:c['oracle']=o.solve(o.unpack(c['input']['H']),c['input']['gammaDb'])
 except Exception as e:
  c['oracle']={'status':'exception','exception':repr(e),'traceback':traceback.format_exc()}
 print(c['id'],c['oracle']['status'],c['oracle'].get('normalizedObjective'),time.time()-start,flush=True)
 (ROOT/'tests/oracle-fixtures.json').write_text(json.dumps(cases,indent=2))
